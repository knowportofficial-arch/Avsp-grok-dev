# AVSP Screen Intelligence V2
Based on the supplied AVSP source ZIP.

Implemented:
- automatic post-recording on-device analysis
- 1-second frame sampling, capped at 600 frames
- ML Kit OCR for Latin and Devanagari
- sensitive-data detection: phone, email, Aadhaar-like number, PAN, OTP, card-like number, IP and URL
- timeline highlights for text/visual changes and sensitive findings
- low-information cut suggestions
- privacy-safe script draft
- normalized time/region redaction manifest for a future renderer
- analysis JSON + redaction JSON + script stored beside the recording

Boundary: V2 generates the redaction PLAN; it does not rewrite the original MP4 with blur. The renderer must consume the manifest to perform actual blur.
