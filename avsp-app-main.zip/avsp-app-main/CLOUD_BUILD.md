# AVSP cloud build

Every push to `main` builds and tests the app on GitHub (about 10-15 minutes).

Get the APK on your phone:
1. Open the GitHub app or github.com -> this repo -> **Actions** -> latest green "Build AVSP APK" run.
2. Scroll to **Artifacts** -> download `AVSP-APK-<number>` (a zip containing the APK).
3. Open the zip, tap the APK, install. It updates the existing AVSP app and keeps your data.

Build by hand: Actions -> Build AVSP APK -> Run workflow.
