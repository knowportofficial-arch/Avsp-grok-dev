package com.avsp.pro.video.doodle

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * P11 DOODLE: a small library of hand-drawn icons as pen strokes in a
 * 100 x 100 box. Each stroke is drawn progressively ("being drawn") and the
 * icon's [fill] area gets a highlighter colour afterwards.
 * Pure Kotlin (no Android) so it is unit-tested.
 */
data class DoodleIcon(
    val id: String,
    val strokes: List<List<Pair<Float, Float>>>,
    val fill: List<Pair<Float, Float>> = emptyList(),
    val accent: Long = 0xFFFFD54F
)

object DoodleIcons {

    private fun line(x1: Float, y1: Float, x2: Float, y2: Float) = listOf(x1 to y1, x2 to y2)

    private fun arc(cx: Float, cy: Float, rx: Float, ry: Float, fromDeg: Float, toDeg: Float, steps: Int = 24): List<Pair<Float, Float>> =
        (0..steps).map { i ->
            val a = (fromDeg + (toDeg - fromDeg) * i / steps) * PI / 180.0
            (cx + rx * cos(a)).toFloat() to (cy + ry * sin(a)).toFloat()
        }

    private fun circle(cx: Float, cy: Float, r: Float) = arc(cx, cy, r, r, -90f, 275f, 32)

    private fun poly(vararg p: Float): List<Pair<Float, Float>> = p.toList().chunked(2).map { it[0] to it[1] }

    private fun rays(cx: Float, cy: Float, r1: Float, r2: Float, n: Int) = (0 until n).map { i ->
        val a = 2 * PI * i / n
        line((cx + r1 * cos(a)).toFloat(), (cy + r1 * sin(a)).toFloat(), (cx + r2 * cos(a)).toFloat(), (cy + r2 * sin(a)).toFloat())
    }

    private val cloudOutline = arc(30f, 60f, 16f, 14f, 90f, 270f) + arc(48f, 44f, 20f, 20f, 190f, 340f) +
        arc(70f, 56f, 16f, 15f, 250f, 450f) + listOf(70f to 71f, 30f to 74f)

    val ALL: Map<String, DoodleIcon> = listOf(
        DoodleIcon("sun", listOf(circle(50f, 50f, 18f)) + rays(50f, 50f, 26f, 40f, 8), circle(50f, 50f, 18f), 0xFFFFD54F),
        DoodleIcon("cloud", listOf(cloudOutline), cloudOutline, 0xFFB3E5FC),
        DoodleIcon("rain", listOf(cloudOutline.map { it.first to it.second - 12f }) +
            listOf(line(32f, 72f, 28f, 84f), line(48f, 72f, 44f, 86f), line(64f, 72f, 60f, 84f)), cloudOutline.map { it.first to it.second - 12f }, 0xFF90CAF9),
        DoodleIcon("thermometer", listOf(poly(44f, 70f, 44f, 18f, 46f, 13f, 54f, 13f, 56f, 18f, 56f, 70f), circle(50f, 78f, 10f),
            line(50f, 70f, 50f, 34f), line(58f, 30f, 64f, 30f), line(58f, 42f, 64f, 42f), line(58f, 54f, 64f, 54f)), circle(50f, 78f, 10f), 0xFFEF9A9A),
        DoodleIcon("star", listOf(poly(50f, 12f, 60f, 38f, 88f, 39f, 66f, 56f, 74f, 84f, 50f, 68f, 26f, 84f, 34f, 56f, 12f, 39f, 40f, 38f, 50f, 12f)),
            poly(50f, 12f, 60f, 38f, 88f, 39f, 66f, 56f, 74f, 84f, 50f, 68f, 26f, 84f, 34f, 56f, 12f, 39f, 40f, 38f), 0xFFFFE082),
        DoodleIcon("moon", listOf(arc(50f, 50f, 34f, 34f, 60f, 300f) + arc(64f, 46f, 26f, 28f, 250f, 110f)),
            arc(50f, 50f, 34f, 34f, 60f, 300f) + arc(64f, 46f, 26f, 28f, 250f, 110f), 0xFFFFF59D),
        DoodleIcon("book", listOf(poly(50f, 28f, 14f, 20f, 14f, 76f, 50f, 84f, 86f, 76f, 86f, 20f, 50f, 28f), line(50f, 28f, 50f, 84f),
            line(22f, 34f, 42f, 38f), line(22f, 46f, 42f, 50f), line(58f, 38f, 78f, 34f), line(58f, 50f, 78f, 46f)),
            poly(50f, 28f, 14f, 20f, 14f, 76f, 50f, 84f, 86f, 76f, 86f, 20f), 0xFFC5E1A5),
        DoodleIcon("train", listOf(poly(24f, 70f, 24f, 22f, 32f, 14f, 68f, 14f, 76f, 22f, 76f, 70f, 24f, 70f), poly(30f, 24f, 70f, 24f, 70f, 44f, 30f, 44f, 30f, 24f),
            circle(36f, 58f, 5f), circle(64f, 58f, 5f), line(30f, 70f, 20f, 86f), line(70f, 70f, 80f, 86f), line(16f, 86f, 84f, 86f)),
            poly(24f, 70f, 24f, 22f, 32f, 14f, 68f, 14f, 76f, 22f, 76f, 70f), 0xFFFFCC80),
        DoodleIcon("drop", listOf(arc(50f, 60f, 22f, 22f, -20f, 200f) + listOf(50f to 14f, 71f to 53f)),
            arc(50f, 60f, 22f, 22f, -20f, 200f) + listOf(50f to 14f), 0xFF81D4FA),
        DoodleIcon("heart", listOf(arc(36f, 38f, 15f, 15f, 150f, 360f) + arc(64f, 38f, 15f, 15f, 180f, 390f) + listOf(50f to 82f, 22f to 46f)),
            arc(36f, 38f, 15f, 15f, 150f, 360f) + arc(64f, 38f, 15f, 15f, 180f, 390f) + listOf(50f to 82f), 0xFFF48FB1),
        DoodleIcon("house", listOf(poly(14f, 46f, 50f, 16f, 86f, 46f), poly(24f, 40f, 24f, 84f, 76f, 84f, 76f, 40f), poly(42f, 84f, 42f, 62f, 58f, 62f, 58f, 84f)),
            poly(24f, 40f, 24f, 84f, 76f, 84f, 76f, 40f, 50f, 18f), 0xFFFFAB91),
        DoodleIcon("person", listOf(circle(50f, 26f, 12f), line(50f, 38f, 50f, 64f), line(50f, 46f, 30f, 56f), line(50f, 46f, 70f, 56f),
            line(50f, 64f, 36f, 86f), line(50f, 64f, 64f, 86f)), circle(50f, 26f, 12f), 0xFFFFE0B2),
        DoodleIcon("globe", listOf(circle(50f, 50f, 34f), arc(50f, 50f, 14f, 34f, -90f, 270f), line(16f, 50f, 84f, 50f),
            arc(50f, 32f, 30f, 6f, 0f, 180f), arc(50f, 68f, 30f, 6f, 180f, 360f)), circle(50f, 50f, 34f), 0xFFA5D6A7),
        DoodleIcon("clock", listOf(circle(50f, 50f, 34f), line(50f, 50f, 50f, 28f), line(50f, 50f, 66f, 58f)), circle(50f, 50f, 34f), 0xFFB39DDB),
        DoodleIcon("calendar", listOf(poly(16f, 24f, 84f, 24f, 84f, 84f, 16f, 84f, 16f, 24f), line(16f, 38f, 84f, 38f), line(32f, 16f, 32f, 30f), line(68f, 16f, 68f, 30f),
            line(28f, 52f, 36f, 52f), line(46f, 52f, 54f, 52f), line(64f, 52f, 72f, 52f), line(28f, 68f, 36f, 68f), line(46f, 68f, 54f, 68f)),
            poly(16f, 24f, 84f, 24f, 84f, 38f, 16f, 38f), 0xFFEF9A9A),
        DoodleIcon("bulb", listOf(arc(50f, 40f, 22f, 22f, 135f, 405f) + listOf(42f to 66f, 58f to 66f, 66f to 56f), line(42f, 72f, 58f, 72f), line(44f, 78f, 56f, 78f),
            line(50f, 8f, 50f, 2f), line(22f, 18f, 18f, 14f), line(78f, 18f, 82f, 14f)), arc(50f, 40f, 22f, 22f, 135f, 405f), 0xFFFFF176),
        DoodleIcon("chart", listOf(line(14f, 86f, 86f, 86f), line(14f, 86f, 14f, 14f), poly(22f, 72f, 40f, 54f, 54f, 62f, 80f, 26f), poly(68f, 26f, 80f, 26f, 80f, 38f)),
            poly(22f, 86f, 22f, 72f, 40f, 54f, 54f, 62f, 80f, 26f, 80f, 86f), 0xFFA5D6A7),
        DoodleIcon("trophy", listOf(poly(30f, 16f, 70f, 16f, 66f, 44f, 50f, 56f, 34f, 44f, 30f, 16f), arc(26f, 28f, 8f, 10f, 90f, 270f), arc(74f, 28f, 8f, 10f, -90f, 90f),
            line(50f, 56f, 50f, 72f), poly(34f, 84f, 66f, 84f, 62f, 72f, 38f, 72f, 34f, 84f)), poly(30f, 16f, 70f, 16f, 66f, 44f, 50f, 56f, 34f, 44f), 0xFFFFD54F),
        DoodleIcon("laugh", listOf(circle(50f, 50f, 34f), arc(38f, 42f, 6f, 5f, 180f, 360f), arc(62f, 42f, 6f, 5f, 180f, 360f), arc(50f, 56f, 18f, 14f, 0f, 180f) + listOf(68f to 56f, 32f to 56f)),
            circle(50f, 50f, 34f), 0xFFFFE082),
        DoodleIcon("phone", listOf(poly(32f, 10f, 68f, 10f, 68f, 90f, 32f, 90f, 32f, 10f), line(32f, 20f, 68f, 20f), line(32f, 78f, 68f, 78f), circle(50f, 84f, 3f)),
            poly(32f, 20f, 68f, 20f, 68f, 78f, 32f, 78f), 0xFF80DEEA),
        DoodleIcon("tree", listOf(arc(50f, 36f, 26f, 24f, 0f, 360f), line(50f, 60f, 50f, 88f), line(50f, 72f, 40f, 64f), line(36f, 88f, 64f, 88f)),
            arc(50f, 36f, 26f, 24f, 0f, 360f), 0xFFA5D6A7),
        DoodleIcon("coin", listOf(circle(50f, 50f, 32f), circle(50f, 50f, 24f), poly(40f, 38f, 60f, 38f), poly(40f, 46f, 60f, 46f), poly(40f, 38f, 48f, 38f, 52f, 42f, 48f, 46f, 42f, 46f, 58f, 64f)),
            circle(50f, 50f, 32f), 0xFFFFD54F),
        DoodleIcon("cap", listOf(poly(10f, 40f, 50f, 22f, 90f, 40f, 50f, 58f, 10f, 40f), poly(28f, 48f, 28f, 68f, 50f, 78f, 72f, 68f, 72f, 48f), line(86f, 42f, 86f, 66f)),
            poly(10f, 40f, 50f, 22f, 90f, 40f, 50f, 58f), 0xFF9FA8DA),
        DoodleIcon("flag", listOf(line(24f, 10f, 24f, 90f), poly(24f, 14f, 78f, 18f, 66f, 32f, 78f, 46f, 24f, 42f)), poly(24f, 14f, 78f, 18f, 66f, 32f, 78f, 46f, 24f, 42f), 0xFFFFAB91),
        DoodleIcon("warning", listOf(poly(50f, 12f, 88f, 82f, 12f, 82f, 50f, 12f), line(50f, 36f, 50f, 60f), circle(50f, 70f, 2.5f)), poly(50f, 12f, 88f, 82f, 12f, 82f), 0xFFFFCC80),
        DoodleIcon("megaphone", listOf(poly(18f, 42f, 18f, 58f, 34f, 58f, 70f, 76f, 70f, 24f, 34f, 42f, 18f, 42f), line(34f, 58f, 40f, 80f), arc(74f, 50f, 10f, 14f, -60f, 60f)),
            poly(18f, 42f, 18f, 58f, 34f, 58f, 70f, 76f, 70f, 24f, 34f, 42f), 0xFFF48FB1),
        DoodleIcon("check", listOf(circle(50f, 50f, 34f), poly(32f, 52f, 45f, 64f, 70f, 36f)), circle(50f, 50f, 34f), 0xFFA5D6A7),
        DoodleIcon("question", listOf(arc(50f, 34f, 16f, 16f, 180f, 405f) + listOf(50f to 58f), circle(50f, 74f, 2.5f)), emptyList(), 0xFFFFE082),
        DoodleIcon("wind", listOf(arc(60f, 30f, 10f, 9f, -180f, 90f) + listOf(14f to 39f), arc(70f, 52f, 10f, 9f, -180f, 90f) + listOf(14f to 61f),
            arc(52f, 72f, 8f, 7f, 180f, -90f) + listOf(14f to 65f)), emptyList(), 0xFFB3E5FC)
    ).associateBy { it.id }

    /** Generic icons used in turn when no keyword matches. */
    val GENERIC = listOf("bulb", "star", "check", "chart", "megaphone", "globe")
}
