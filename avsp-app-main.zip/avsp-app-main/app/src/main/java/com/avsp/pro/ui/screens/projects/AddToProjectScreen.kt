package com.avsp.pro.ui.screens.projects

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avsp.pro.m5.M5InputEngine
import com.avsp.pro.m5.UnifiedInputKind
import com.avsp.pro.m5.UnifiedInputResult
import com.avsp.pro.ui.viewmodel.HomeViewModel

/**
 * P19: "Add to this project" - the same simple box as Home (text, website or
 * YouTube link, photos, videos, files), added to the project you are in.
 * Replaces the old developer input screen.
 */
@Composable
fun AddToProjectScreen(projectId: String, viewModel: HomeViewModel, onDone: () -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val working by viewModel.working.collectAsState()
    val error by viewModel.actionError.collectAsState()
    var text by remember { mutableStateOf("") }
    val items = remember { mutableStateListOf<UnifiedInputResult>() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        uris.forEach { uri ->
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            val r = M5InputEngine.analyzeLocalMediaUnified(context, uri)
            if (items.none { it.reference == r.reference }) items += r
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("Add to this project", style = MaterialTheme.typography.headlineSmall)
        Text("Add more text, a website or YouTube link, photos, video clips or documents. Your photos and clips are used in the video before any free pictures.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        OutlinedTextField(value = text, onValueChange = { text = it }, label = { Text("Paste text, a website or YouTube link") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(enabled = text.isNotBlank(), onClick = {
                val r = M5InputEngine.analyzeUnifiedText(text.trim())
                if (items.none { it.reference == r.reference }) items += r
                text = ""
            }) { Text("Add") }
            OutlinedButton(onClick = { picker.launch(arrayOf("image/*", "video/*", "application/pdf", "text/*", "audio/*")) }) { Text("Photos, clips & files") }
        }
        items.forEachIndexed { i, s ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(label(s.kind), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                    Text(s.title.ifBlank { s.reference }, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
                TextButton(onClick = { items.removeAt(i) }) { Text("Remove") }
            }
        }
        working?.let { LinearProgressIndicator(Modifier.fillMaxWidth()); Text(it, style = MaterialTheme.typography.bodySmall) }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        Button(enabled = items.isNotEmpty() && working == null, onClick = {
            viewModel.addSourcesToProject(projectId, items.toList()) { onDone() }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (items.isEmpty()) "Add something first" else "Add ${items.size} to the project") }
    }
}

private fun label(kind: UnifiedInputKind) = when (kind) {
    UnifiedInputKind.YOUTUBE -> "YouTube video"
    UnifiedInputKind.URL -> "Website"
    UnifiedInputKind.TEXT -> "Text"
    UnifiedInputKind.IMAGE -> "Photo"
    UnifiedInputKind.VIDEO -> "Video clip"
    UnifiedInputKind.SCREEN_RECORDING -> "Screen recording"
    else -> kind.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
}
