﻿package com.avsp.pro.audio.processing

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * M3 Audio Processing V1.
 *
 * Pure PCM/WAV post-processing layer. It deliberately does not own TTS.
 * TTS remains responsible for producing the individual narration WAVs.
 *
 * V1 capabilities:
 * - validates PCM WAV inputs
 * - optional head/tail silence
 * - concatenates narration segments
 * - optional intro/outro
 * - optional background music with ducking under narration
 * - peak normalization with a deterministic target
 * - emits one standard PCM WAV master
 *
 * No Android/Media3 dependency: deterministic unit tests can run off-device.
 */
object AudioPostProcessor {

    data class Options(
        val leadingSilenceMs: Long = 0L,
        val trailingSilenceMs: Long = 0L,
        val introWav: ByteArray? = null,
        val outroWav: ByteArray? = null,
        val musicWav: ByteArray? = null,
        val narrationGain: Float = 1.0f,
        val musicGain: Float = 0.10f,
        val musicDucking: Float = 0.12f,
        val normalizePeak: Float = 0.92f
    )

    data class Result(
        val wavBytes: ByteArray,
        val durationMs: Long,
        val sampleRateHz: Int,
        val channels: Int,
        val bitsPerSample: Int,
        val peakBeforeNormalization: Float,
        val peakAfterNormalization: Float
    )

    private data class Pcm(
        val sampleRate: Int,
        val channels: Int,
        val bitsPerSample: Int,
        val samples: ShortArray
    )

    fun process(
        narrationWavs: List<ByteArray>,
        options: Options = Options()
    ): Result {
        require(narrationWavs.isNotEmpty()) { "At least one narration WAV is required." }
        require(options.narrationGain >= 0f) { "narrationGain must be >= 0." }
        require(options.musicGain >= 0f) { "musicGain must be >= 0." }
        require(options.musicDucking in 0f..1f) { "musicDucking must be between 0 and 1." }
        require(options.normalizePeak in 0.01f..1.0f) { "normalizePeak must be between 0.01 and 1.0." }

        val narration = narrationWavs.map { decode(it) }
        val base = narration.first()
        narration.drop(1).forEach { requireCompatible(base, it) }

        val intro = options.introWav?.let(::decode)?.also { requireCompatible(base, it) }
        val outro = options.outroWav?.let(::decode)?.also { requireCompatible(base, it) }
        val music = options.musicWav?.let(::decode)?.also { requireCompatible(base, it) }

        val silenceHead = silence(base, options.leadingSilenceMs)
        val silenceTail = silence(base, options.trailingSilenceMs)

        val narrationSamples = concat(
            listOfNotNull(
                silenceHead,
                intro?.samples,
                *narration.map { it.samples }.toTypedArray(),
                outro?.samples,
                silenceTail
            )
        )

        val mixed = if (music != null) {
            mixMusic(narrationSamples, music.samples, options.musicGain, options.musicDucking)
        } else {
            narrationSamples.copyOf()
        }

        for (i in mixed.indices) {
            mixed[i] = clampToShort(mixed[i].toFloat() * options.narrationGain)
        }

        val peakBefore = peak(mixed)
        val normalization = if (peakBefore > 0f) options.normalizePeak / peakBefore else 1f
        for (i in mixed.indices) {
            mixed[i] = clampToShort(mixed[i].toFloat() * normalization)
        }
        val peakAfter = peak(mixed)

        val bytes = encode(
            sampleRate = base.sampleRate,
            channels = base.channels,
            bitsPerSample = base.bitsPerSample,
            samples = mixed
        )

        val frames = mixed.size / base.channels
        val durationMs = (frames.toLong() * 1000L) / base.sampleRate

        return Result(
            wavBytes = bytes,
            durationMs = durationMs,
            sampleRateHz = base.sampleRate,
            channels = base.channels,
            bitsPerSample = base.bitsPerSample,
            peakBeforeNormalization = peakBefore,
            peakAfterNormalization = peakAfter
        )
    }

    private fun requireCompatible(a: Pcm, b: Pcm) {
        require(a.sampleRate == b.sampleRate) {
            "WAV sample-rate mismatch: ${a.sampleRate} != ${b.sampleRate}"
        }
        require(a.channels == b.channels) {
            "WAV channel mismatch: ${a.channels} != ${b.channels}"
        }
        require(a.bitsPerSample == b.bitsPerSample) {
            "WAV bit-depth mismatch: ${a.bitsPerSample} != ${b.bitsPerSample}"
        }
        require(a.bitsPerSample == 16) { "Only 16-bit PCM WAV is supported in M3 V1." }
    }

    private fun silence(reference: Pcm, durationMs: Long): ShortArray {
        if (durationMs <= 0L) return ShortArray(0)
        val frames = ((reference.sampleRate.toLong() * durationMs) / 1000L)
            .toInt()
            .coerceAtLeast(0)
        return ShortArray(frames * reference.channels)
    }

    private fun concat(parts: List<ShortArray>): ShortArray {
        val total = parts.sumOf { it.size }
        val out = ShortArray(total)
        var cursor = 0
        parts.forEach {
            it.copyInto(out, cursor)
            cursor += it.size
        }
        return out
    }

    private fun mixMusic(
        narration: ShortArray,
        music: ShortArray,
        musicGain: Float,
        ducking: Float
    ): ShortArray {
        if (music.isEmpty()) return narration.copyOf()
        val out = narration.copyOf()
        for (i in out.indices) {
            val m = music[i % music.size].toFloat() * musicGain
            val duck = if (abs(out[i].toFloat()) > 1200f) ducking else 1f
            out[i] = clampToShort(out[i].toFloat() + m * duck)
        }
        return out
    }

    private fun peak(samples: ShortArray): Float {
        if (samples.isEmpty()) return 0f
        var maxAbs = 0
        samples.forEach { maxAbs = max(maxAbs, abs(it.toInt())) }
        return maxAbs.toFloat() / Short.MAX_VALUE.toFloat()
    }

    private fun clampToShort(value: Float): Short =
        min(Short.MAX_VALUE.toFloat(), max(Short.MIN_VALUE.toFloat(), value)).toInt().toShort()

    private fun decode(bytes: ByteArray): Pcm {
        require(bytes.size >= 44) { "Invalid WAV: file too small." }
        require(ascii(bytes, 0, 4) == "RIFF") { "Invalid WAV: missing RIFF." }
        require(ascii(bytes, 8, 4) == "WAVE") { "Invalid WAV: missing WAVE." }

        var offset = 12
        var sampleRate = -1
        var channels = -1
        var bits = -1
        var dataOffset = -1
        var dataSize = -1

        while (offset + 8 <= bytes.size) {
            val id = ascii(bytes, offset, 4)
            val size = readIntLE(bytes, offset + 4)
            require(size >= 0) { "Invalid WAV chunk size." }
            val chunkStart = offset + 8
            require(chunkStart <= bytes.size) { "Invalid WAV chunk." }
            val chunkEnd = chunkStart.toLong() + size.toLong()
            require(chunkEnd <= bytes.size) { "Truncated WAV chunk." }

            when (id) {
                "fmt " -> {
                    require(size >= 16) { "Invalid WAV fmt chunk." }
                    val format = readShortLE(bytes, chunkStart)
                    channels = readShortLE(bytes, chunkStart + 2)
                    sampleRate = readIntLE(bytes, chunkStart + 4)
                    bits = readShortLE(bytes, chunkStart + 14)
                    require(format == 1) { "Only PCM WAV is supported." }
                }
                "data" -> {
                    dataOffset = chunkStart
                    dataSize = size
                }
            }

            offset = chunkStart + size + (size and 1)
        }

        require(sampleRate > 0 && channels > 0 && bits > 0) { "WAV fmt chunk not found." }
        require(dataOffset >= 0 && dataSize >= 0) { "WAV data chunk not found." }
        require(bits == 16) { "Only 16-bit PCM WAV is supported in M3 V1." }
        require(dataSize % 2 == 0) { "Invalid 16-bit PCM data size." }

        val samples = ShortArray(dataSize / 2)
        var p = dataOffset
        for (i in samples.indices) {
            samples[i] = readShortLE(bytes, p).toShort()
            p += 2
        }
        return Pcm(sampleRate, channels, bits, samples)
    }

    private fun encode(
        sampleRate: Int,
        channels: Int,
        bitsPerSample: Int,
        samples: ShortArray
    ): ByteArray {
        require(bitsPerSample == 16)
        val dataSize = samples.size * 2
        val out = ByteArrayOutputStream(44 + dataSize)
        out.write("RIFF".toByteArray())
        writeIntLE(out, 36 + dataSize)
        out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray())
        writeIntLE(out, 16)
        writeShortLE(out, 1)
        writeShortLE(out, channels)
        writeIntLE(out, sampleRate)
        writeIntLE(out, sampleRate * channels * 2)
        writeShortLE(out, channels * 2)
        writeShortLE(out, bitsPerSample)
        out.write("data".toByteArray())
        writeIntLE(out, dataSize)
        samples.forEach { writeShortLE(out, it.toInt()) }
        return out.toByteArray()
    }

    private fun ascii(bytes: ByteArray, offset: Int, length: Int): String =
        bytes.copyOfRange(offset, offset + length).toString(Charsets.US_ASCII)

    private fun readIntLE(bytes: ByteArray, offset: Int): Int =
        ByteBuffer.wrap(bytes, offset, 4).order(ByteOrder.LITTLE_ENDIAN).int

    private fun readShortLE(bytes: ByteArray, offset: Int): Int =
        ByteBuffer.wrap(bytes, offset, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt() and 0xFFFF

    private fun writeIntLE(out: ByteArrayOutputStream, value: Int) {
        out.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(value).array())
    }

    private fun writeShortLE(out: ByteArrayOutputStream, value: Int) {
        out.write(ByteBuffer.allocate(2).order(ByteOrder.LITTLE_ENDIAN).putShort(value.toShort()).array())
    }
}
