package com.avsp.pro.video.engine

/**
 * P18 CONTEXT TRANSITIONS (pure, testable) - chosen from what the scenes say:
 *  - FADE  at the start, into the CTA and for hand-drawn (doodle) scenes
 *  - ZOOM  (quick punch-in) when the next scene continues the same idea
 *  - SLIDE (whip in from the side, direction alternating) when the topic moves on
 * The move lasts [MS] and never shows an empty edge (the picture is scaled up
 * exactly as much as it is shifted). Captions are not moved.
 */
object Transitions {
    enum class Kind { FADE, ZOOM, SLIDE_LEFT, SLIDE_RIGHT }

    const val MS = 350L

    private val STOP = setOf("the", "and", "for", "with", "this", "that", "are", "was", "you", "your", "from", "have", "has", "will", "can", "its", "into",
        "about", "more", "also", "here", "what", "they", "their", "them", "there", "which", "been", "were", "one", "all", "our", "how", "who")

    private fun words(t: String) = t.lowercase().split(Regex("""[^\p{L}\p{N}]+""")).filter { it.length > 2 && it !in STOP }.map { it.removeSuffix("s") }.toSet()

    /** Kind for every scene (in order). */
    fun plan(narrations: List<String>, ctaIndex: Int?, doodle: List<Boolean>): List<Kind> {
        var slides = 0
        return narrations.indices.map { i ->
            when {
                i == 0 || i == ctaIndex || doodle.getOrElse(i) { false } || doodle.getOrElse(i - 1) { false } -> Kind.FADE
                (words(narrations[i - 1]) intersect words(narrations[i])).size >= 2 -> Kind.ZOOM
                else -> if (slides++ % 2 == 0) Kind.SLIDE_LEFT else Kind.SLIDE_RIGHT
            }
        }
    }

    /** Scale and horizontal shift (normalised: full width = 2) at [ms] after the scene starts. */
    fun motion(kind: Kind, ms: Long): Pair<Float, Float> {
        if (kind == Kind.FADE || ms >= MS) return 1f to 0f
        val x = (ms.coerceAtLeast(0).toFloat() / MS)
        val left = (1f - x) * (1f - x) * (1f - x)            // ease-out cubic: fast start, gentle landing
        return when (kind) {
            Kind.ZOOM -> (1f + 0.18f * left) to 0f
            Kind.SLIDE_LEFT -> (1f + 0.25f * left) to (0.25f * left)
            Kind.SLIDE_RIGHT -> (1f + 0.25f * left) to (-0.25f * left)
            Kind.FADE -> 1f to 0f
        }
    }
}
