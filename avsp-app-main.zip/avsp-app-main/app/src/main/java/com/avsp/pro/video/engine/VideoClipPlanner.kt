package com.avsp.pro.video.engine

/**
 * Pure timeline math for fitting a source video clip to an exact scene duration.
 * A short source is repeated; a long source is trimmed; the sum is exact.
 */
object VideoClipPlanner {
    data class Piece(val startMs: Long, val endMs: Long, val durationMs: Long)

    /**
     * P13: [windowStartMs] is where the best part of a LONG clip starts (chosen
     * from picture quality); a long clip then plays from there, not from 0.
     */
    fun pieces(sourceDurationMs: Long, targetDurationMs: Long, windowStartMs: Long = 0L): List<Piece> {
        require(sourceDurationMs > 0) { "Source duration must be > 0" }
        require(targetDurationMs > 0) { "Target duration must be > 0" }
        if (sourceDurationMs > targetDurationMs) {
            val start = windowStartMs.coerceIn(0L, sourceDurationMs - targetDurationMs)
            return listOf(Piece(start, start + targetDurationMs, targetDurationMs))
        }
        val result = mutableListOf<Piece>()
        var remaining = targetDurationMs
        while (remaining > 0) {
            val piece = minOf(sourceDurationMs, remaining)
            result += Piece(0L, piece, piece)
            remaining -= piece
        }
        check(result.sumOf { it.durationMs } == targetDurationMs)
        return result
    }

    /**
     * P20 slow motion: [sourcePieces] cover scene * speed of the clip; each plays 1/speed longer.
     * Start/end stay in source time (what is cut); durationMs becomes on-screen time, and the
     * on-screen total is exactly [sceneMs].
     */
    fun slowPieces(sourcePieces: List<Piece>, speed: Float, sceneMs: Long): List<Piece> {
        require(speed > 0f) { "speed must be > 0" }
        val out = sourcePieces.map { it.copy(durationMs = Math.round(it.durationMs / speed.toDouble())) }.toMutableList()
        if (out.isNotEmpty()) {
            val diff = sceneMs - out.sumOf { it.durationMs }
            val last = out.last()
            out[out.lastIndex] = last.copy(durationMs = (last.durationMs + diff).coerceAtLeast(1L))
        }
        return out
    }
}
