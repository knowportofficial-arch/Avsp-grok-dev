package com.avsp.pro.media

import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection

/**
 * P15 FREE MUSIC: real background music matched to the video's mood, from
 * Openverse (keyless; Jamendo / Freesound tracks under CC0 or CC BY). The
 * credit line goes into the video description, as CC BY requires. Any failure
 * -> null, and the video keeps AVSP's own generated music.
 */
class FreeMusicProvider(private val cacheDir: File) {

    data class Track(val id: String, val title: String, val creator: String, val license: String, val source: String, val url: String, val durationS: Int) {
        val credit: String get() = "Music: \"$title\" by ${creator.ifBlank { "unknown" }} (${licenseLabel(license)}) via Openverse/${source.replaceFirstChar { it.uppercase() }}"
    }

    data class Picked(val file: File, val track: Track)

    /**
     * Downloads one fitting track (≤ 8 MB, lighter 96 kbps copy when the source offers one)
     * into [cacheDir]/music with its credit next to it (`.credit.txt`). Throws with the reason.
     */
    fun fetch(mood: Mood, seed: Int): Picked {
        val tracks = search(mood.query).ifEmpty { search(Mood.CALM.query) }
        check(tracks.isNotEmpty()) { "no free music found" }
        val t = tracks[Math.floorMod(seed, tracks.size)]
        val dir = File(cacheDir, "music").apply { mkdirs() }
        val f = File(dir, "ov_${t.id.take(12).replace(Regex("[^A-Za-z0-9-]"), "")}.mp3")
        if (!f.exists() || f.length() < 50_000) download(lighter(t.url), f)
        check(f.length() >= 50_000) { f.delete(); "music download too small" }
        File(dir, f.name + ".credit.txt").writeText(t.credit)
        return Picked(f, t)
    }

    private fun search(q: String): List<Track> {
        val url = "https://api.openverse.org/v1/audio/?q=" + java.net.URLEncoder.encode(q, "UTF-8") +
            "&license=cc0,by&category=music&page_size=20"
        val c = java.net.URI(url).toURL().openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 6_000; c.readTimeout = 8_000
            c.setRequestProperty("User-Agent", "AVSP/1.0 (Android)")
            check(c.responseCode in 200..299) { "Openverse HTTP ${c.responseCode}" }
            return parse(c.inputStream.bufferedReader().use { it.readText() })
        } finally { c.disconnect() }
    }

    private fun download(url: String, out: File) {
        var u = url
        repeat(4) {
            val c = java.net.URI(u).toURL().openConnection() as HttpURLConnection
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = 6_000; c.readTimeout = 15_000
                c.setRequestProperty("User-Agent", "AVSP/1.0 (Android)")
                val code = c.responseCode
                if (code in 300..399) { u = c.getHeaderField("Location") ?: return; return@repeat }
                check(code in 200..299) { "Music HTTP $code" }
                val tmp = File(out.parentFile, out.name + ".part")
                c.inputStream.use { inp -> tmp.outputStream().use { o ->
                    val buf = ByteArray(32_768); var total = 0L
                    while (true) { val n = inp.read(buf); if (n < 0) break; total += n; check(total < MAX_BYTES) { "too big" }; o.write(buf, 0, n) }
                } }
                tmp.renameTo(out)
                return
            } finally { c.disconnect() }
        }
    }

    enum class Mood(val query: String) {
        CALM("calm piano instrumental"),
        UPBEAT("upbeat happy instrumental"),
        INSPIRING("inspiring instrumental"),
        SPIRITUAL("meditation instrumental"),
        NEWS("ambient background instrumental"),
        FUN("funny instrumental")
    }

    companion object {
        const val MAX_BYTES = 8_000_000L

        /** Jamendo serves a 96 kbps copy (format=mp31): ~2.5 MB instead of ~6 MB, plenty for background music. */
        fun lighter(url: String) = if (url.contains("jamendo.com") && url.contains("format=mp32")) url.replace("format=mp32", "format=mp31") else url

        /** The newest complete downloaded track in [musicDir] with its credit, if any. */
        fun cached(musicDir: File): Pair<File, String>? = musicDir.listFiles { f -> f.name.startsWith("ov_") && f.name.endsWith(".mp3") && f.length() >= 50_000 }
            ?.sortedByDescending { it.lastModified() }
            ?.firstNotNullOfOrNull { f -> File(musicDir, f.name + ".credit.txt").takeIf { it.exists() }?.let { f to it.readText().trim() } }

        fun licenseLabel(l: String) = when (l.lowercase()) { "cc0" -> "CC0"; "by" -> "CC BY 4.0"; else -> "CC ${l.uppercase()}" }

        /** Mood from what the video is about (any of EN / HI / BN keywords). */
        fun mood(text: String, category: String? = null): Mood {
            val t = (text + " " + (category ?: "")).lowercase()
            // English: whole words ("war" must not match "water"); a trailing * or an Indian script = word start.
            fun has(vararg w: String) = w.any { k ->
                val stem = k.removeSuffix("*")
                val prefix = k.endsWith("*") || stem.any { it.code >= 0x0900 }
                Regex("(^|[\\s\\p{Punct}])" + Regex.escape(stem) + (if (prefix) "" else "s?(?![\\p{L}])")).containsMatchIn(t)
            }
            return when {
                has("joke", "funny", "comedy", "मज़ाक", "चुटकुल", "জোক", "মজা") -> Mood.FUN
                has("rashifal", "horoscope", "zodiac", "puja", "temple", "god", "prayer", "राशि", "পূজা", "রাশি", "मंदिर", "মন্দির") -> Mood.SPIRITUAL
                has("news", "death", "died", "accident", "war", "flood", "attack", "समाचार", "খবর", "मृत्यु", "মৃত্যু") -> Mood.NEWS
                has("success", "motivat*", "inspir*", "dream", "goal", "win", "सफलता", "সাফল্য", "স্বপ্ন") -> Mood.INSPIRING
                has("festival", "celebrat*", "party", "travel", "food", "recipe", "happy", "त्योहार", "উৎসব", "ভ্রমণ") -> Mood.UPBEAT
                else -> Mood.CALM
            }
        }

        /** Openverse reply -> tracks short enough to download, instrumental-looking titles first. */
        fun parse(raw: String): List<Track> {
            val arr = JSONObject(raw).optJSONArray("results") ?: return emptyList()
            val out = mutableListOf<Track>()
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val url = o.optString("url")
                val lic = o.optString("license").lowercase()
                if (!url.startsWith("https://") || lic !in setOf("cc0", "by")) continue
                val size = o.optLong("filesize", 0)
                if (size > MAX_BYTES) continue
                val dur = (o.optLong("duration", 0) / 1000).toInt()
                if (dur in 1..29) continue // too short to loop nicely
                out += Track(o.optString("id"), o.optString("title").trim(), o.optString("creator").trim(), lic, o.optString("source"), url, dur)
            }
            val vocal = Regex("""\b(feat|ft\.|vocal|song|remix|lyrics)\b""", RegexOption.IGNORE_CASE)
            return out.sortedBy { if (vocal.containsMatchIn(it.title)) 1 else 0 }
        }
    }
}
