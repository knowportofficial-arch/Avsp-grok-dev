package com.avsp.pro.settings

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/**
 * P22.1 CHANNEL BRAND: the creator's channel name and logo. The spoken + on-screen call to
 * action says the channel name ("Follow Knowport for more!") and the logo is shown small in a
 * corner of every video. Plain settings (not secrets).
 */
object BrandKit {
    private const val PREFS = "avsp_brand"
    @Volatile var channel: String = ""
        private set
    @Volatile var watermark: Boolean = true
        private set
    @Volatile private var logoPath: String? = null
    @Volatile private var cached: Pair<Int, Bitmap>? = null

    fun load(context: Context) {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        channel = p.getString("channel", "").orEmpty().trim()
        watermark = p.getBoolean("watermark", true)
        logoPath = logoFile(context).takeIf { it.exists() && it.length() > 0 }?.absolutePath
        cached = null
    }

    fun save(context: Context, channelName: String, showLogo: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("channel", channelName.trim().take(40)).putBoolean("watermark", showLogo).apply()
        load(context)
    }

    fun logoFile(context: Context): File = File(context.filesDir, "brand/logo.png")

    /** Copies the chosen picture as the logo (square-ish PNG, max 512 px). */
    fun setLogo(context: Context, uri: android.net.Uri): Boolean = runCatching {
        val src = context.contentResolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it) } ?: return false
        val scale = 512f / maxOf(src.width, src.height).coerceAtLeast(1)
        val bmp = if (scale < 1f) Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true) else src
        val f = logoFile(context); f.parentFile?.mkdirs()
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        load(context); true
    }.getOrDefault(false)

    fun clearLogo(context: Context) { logoFile(context).delete(); load(context) }

    fun hasLogo(): Boolean = logoPath != null

    /** Logo sized for a frame [frameWidth] px wide (about 13 % of the width), or null. */
    fun logoFor(frameWidth: Int): Bitmap? {
        if (!watermark) return null
        val path = logoPath ?: return null
        cached?.let { (w, b) -> if (w == frameWidth) return b }
        val src = BitmapFactory.decodeFile(path) ?: return null
        val target = (frameWidth * 0.13f).toInt().coerceAtLeast(48)
        val s = target.toFloat() / maxOf(src.width, src.height)
        val b = Bitmap.createScaledBitmap(src, (src.width * s).toInt().coerceAtLeast(1), (src.height * s).toInt().coerceAtLeast(1), true)
        cached = frameWidth to b
        return b
    }

    /** P25.1: the logo at [size] px (for the branded ending card), whether or not the corner watermark is on. */
    fun logoAt(size: Int): Bitmap? {
        val path = logoPath ?: return null
        val src = BitmapFactory.decodeFile(path) ?: return null
        val s = size.toFloat() / maxOf(src.width, src.height)
        return Bitmap.createScaledBitmap(src, (src.width * s).toInt().coerceAtLeast(1), (src.height * s).toInt().coerceAtLeast(1), true)
    }

    /** Spoken call to action (≤ 5 words) with the channel name, or null when no name is set. */
    fun spokenCta(language: String, name: String = channel): String? {
        val n = name.trim().takeIf { it.isNotBlank() } ?: return null
        return when (language.lowercase()) {
            "bn" -> "$n ফলো করুন!"
            "hi" -> "$n को फ़ॉलो करें!"
            else -> "Follow $n for more!"
        }
    }

    /** On-screen CTA line with the channel name, or null. */
    fun ctaLine(language: String, name: String = channel): String? {
        val n = name.trim().takeIf { it.isNotBlank() } ?: return null
        return when (language.lowercase()) {
            "bn" -> "লাইক • ফলো @$n"
            "hi" -> "लाइक • फ़ॉलो @$n"
            else -> "Like • Follow @$n"
        }
    }
}
