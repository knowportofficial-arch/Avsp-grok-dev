﻿package com.avsp.pro.audio.voice

import com.avsp.pro.audio.engine.TtsEngine

/**
 * Provider-neutral catalog extension for the authoritative M3 voice models.
 *
 * VoiceProfile, VoiceGender, VoiceStyle and the selection models remain owned
 * by their existing source files. This file only supplies catalog discovery.
 */
interface VoiceCatalogProvider {
    fun voiceCatalog(): List<VoiceProfile>
}

object VoiceIntelligenceCatalog {
    fun catalogFor(engine: TtsEngine): List<VoiceProfile> {
        // Prefer an explicit provider catalog when the engine supplies one.
        // This is important because TtsEngine.voices() has a generic default
        // implementation that can otherwise hide a richer provider catalog.
        val supplied = (engine as? VoiceCatalogProvider)
            ?.voiceCatalog()
            ?.filter { it.available && it.supportsLanguageFromEngine(engine) }
            .orEmpty()

        if (supplied.isNotEmpty()) return supplied

        // If no explicit provider catalog exists, use voices discovered from
        // the actual engine. Android Local TTS exposes TextToSpeech.Voice here.
        val engineVoices = runCatching { engine.voices() }
            .getOrDefault(emptyList())
            .filter { it.available && it.supportsLanguageFromEngine(engine) }

        if (engineVoices.isNotEmpty()) return engineVoices

        // Safe deterministic fallback for providers with no catalog.
        return engine.supportedLanguages().map { language ->
            VoiceProfile(
                id = "default",
                providerId = engine.providerId,
                displayName = "${engine.displayName} Default",
                languageCodes = setOf(language),
                qualityScore = if (engine.providerId == "android_local") 0.75f else 0.40f
            )
        }
    }

    private fun VoiceProfile.supportsLanguageFromEngine(engine: TtsEngine): Boolean =
        engine.supportedLanguages().any { supportsLanguage(it) }
}

