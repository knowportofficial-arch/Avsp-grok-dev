package com.avsp.pro.screen.capture

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * AVSP FRAME-LOCAL PRIVACY MODEL (P0 motion-aware redaction)
 *
 * Replaces the fixed PRE_ROLL / POST_ROLL interval model.
 *
 * Old model:
 *   one finding -> one FIXED rectangle shown for [t-500ms, t+1500ms]
 *   => during scrolling the old rectangle stays behind (ghost mosaic)
 *      while the moved sensitive content can be briefly uncovered.
 *
 * New model:
 *   findings from successive OCR samples are associated into TRACKS.
 *   Each track is a list of (time, box) keyframes. At any video frame
 *   the censor box is computed locally from the track:
 *     - between keyframes: linear interpolation (follows scrolling)
 *     - before first / after last keyframe: extrapolated along the
 *       track's own velocity, and only until the neighbouring sample
 *       at which the content was NOT present.
 *   A track therefore never outlives its evidence by more than ONE
 *   sample step. With dense sampling around motion that is ~200 ms,
 *   instead of 1500 ms.
 *
 * Pure Kotlin: no Android types, so it is unit-testable on the JVM.
 * Coordinates are normalized 0..1 (same as OCR bounds).
 */
data class PrivacyBox(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
    val isValid: Boolean get() = right > left && bottom > top

    fun translated(dx: Float, dy: Float): PrivacyBox =
        PrivacyBox(left + dx, top + dy, right + dx, bottom + dy)

    fun inflated(horizontal: Float, vertical: Float): PrivacyBox =
        PrivacyBox(left - horizontal, top - vertical, right + horizontal, bottom + vertical)

    fun clamped(): PrivacyBox =
        PrivacyBox(
            left.coerceIn(0f, 1f),
            top.coerceIn(0f, 1f),
            right.coerceIn(0f, 1f),
            bottom.coerceIn(0f, 1f)
        )

    fun union(other: PrivacyBox): PrivacyBox =
        PrivacyBox(
            min(left, other.left),
            min(top, other.top),
            max(right, other.right),
            max(bottom, other.bottom)
        )

    fun iou(other: PrivacyBox): Float {
        val l = max(left, other.left)
        val t = max(top, other.top)
        val r = min(right, other.right)
        val b = min(bottom, other.bottom)
        if (r <= l || b <= t) return 0f
        val inter = (r - l) * (b - t)
        val uni = width * height + other.width * other.height - inter
        return if (uni <= 0f) 0f else inter / uni
    }

    /** Horizontal overlap relative to the narrower box (scroll is mostly vertical). */
    fun horizontalOverlapRatio(other: PrivacyBox): Float {
        val overlap = min(right, other.right) - max(left, other.left)
        val narrower = min(width, other.width)
        if (overlap <= 0f || narrower <= 0f) return 0f
        return overlap / narrower
    }

    companion object {
        fun lerp(a: PrivacyBox, b: PrivacyBox, f: Float): PrivacyBox =
            PrivacyBox(
                a.left + (b.left - a.left) * f,
                a.top + (b.top - a.top) * f,
                a.right + (b.right - a.right) * f,
                a.bottom + (b.bottom - a.bottom) * f
            )
    }
}

/** One sensitive detection at one successfully OCR'd sample time. */
data class PrivacyObservation(
    val timestampMs: Long,
    val type: SensitiveDataType,
    val box: PrivacyBox,
    /** Normalized match key used only for association. Never persisted. */
    val key: String
)

data class PrivacyKeyframe(
    val timestampMs: Long,
    val box: PrivacyBox
)

/**
 * P1 transition veil: a short time window (app switch / zoom animation)
 * during which content scales or jumps so fast that per-box tracking
 * cannot follow it. The renderer covers the whole frame for this window.
 */
data class PrivacyVeil(
    val startMs: Long,
    val endMs: Long,
    /** P3: null = whole frame; otherwise only this region (pop-up / dialer open animation). */
    val box: PrivacyBox? = null
)

data class PrivacyTrack(
    val id: Int,
    val type: SensitiveDataType,
    val keyframes: List<PrivacyKeyframe>,
    /** Coverage window: from the previous sample (content absent) to the next sample (content absent). */
    val coverStartMs: Long,
    val coverEndMs: Long
)

/**
 * Immutable frame-local privacy plan consumed by [ScreenRedactionRenderer].
 */
class ScreenPrivacyPlan(
    val tracks: List<PrivacyTrack>,
    val sampleTimesMs: List<Long>,
    val durationMs: Long,
    val denseSampleCount: Int = 0,
    val veils: List<PrivacyVeil> = emptyList()
) {

    private val sortedVeils: List<PrivacyVeil> = veils.filter { it.box == null }.sortedBy { it.startMs }
    private val regionVeils: List<PrivacyVeil> = veils.filter { it.box != null }.sortedBy { it.startMs }

    /** True when the whole frame at [timeMs] must be covered (P1 transition veil). */
    fun veilAt(timeMs: Long): Boolean {
        for (v in sortedVeils) {
            if (v.startMs > timeMs) return false
            if (timeMs <= v.endMs) return true
        }
        return false
    }

    private val byStart: List<PrivacyTrack> = tracks.sortedBy { it.coverStartMs }
    private val maxCoverLengthMs: Long =
        tracks.maxOfOrNull { it.coverEndMs - it.coverStartMs } ?: 0L

    val isEmpty: Boolean get() = tracks.isEmpty() && veils.isEmpty()

    /**
     * Censor boxes for one video frame. Frame-local: depends only on the
     * frame time and the tracks' own keyframes.
     */
    fun boxesAt(timeMs: Long): List<PrivacyBox> {
        val regions = regionVeils.filter { timeMs >= it.startMs && timeMs <= it.endMs }.mapNotNull { it.box }
        if (byStart.isEmpty()) return regions

        // Only tracks that could cover timeMs: coverStart in [timeMs - maxLen, timeMs].
        var lo = 0
        var hi = byStart.size
        val minStart = timeMs - maxCoverLengthMs
        while (lo < hi) {
            val mid = (lo + hi) ushr 1
            if (byStart[mid].coverStartMs < minStart) lo = mid + 1 else hi = mid
        }

        val out = ArrayList<PrivacyBox>(regions)
        var i = lo
        while (i < byStart.size && byStart[i].coverStartMs <= timeMs) {
            val box = ScreenPrivacyTracker.boxForTrackAt(byStart[i], timeMs)
            if (box != null) out += box
            i++
        }
        return out
    }

    companion object {
        val EMPTY = ScreenPrivacyPlan(emptyList(), emptyList(), 0L)
    }
}

object ScreenPrivacyTracker {

    /**
     * P3 REGION VEILS (dialer / pop-up open animation).
     *
     * A panel that zooms open changes only part of the screen, so no
     * whole-frame veil fires, and the text inside is still scaling when the
     * next sample finds it. For two consecutive samples a -> b (<= maxWindowMs)
     * where the changed region touches sensitive boxes found at a or b, the
     * changed region (joined with those boxes) is covered for [a, b].
     *
     * @param changed changed region between consecutive samples (null = none / tiny)
     */
    fun regionVeils(
        times: List<Long>,
        changed: (Long, Long) -> PrivacyBox?,
        boxesAt: (Long) -> List<PrivacyBox>,
        maxWindowMs: Long,
        margin: Float = 0.02f
    ): List<PrivacyVeil> {
        val out = mutableListOf<PrivacyVeil>()
        val sorted = times.distinct().sorted()
        for (i in 1 until sorted.size) {
            val a = sorted[i - 1]
            val b = sorted[i]
            if (b - a > maxWindowMs) continue
            val sensitive = boxesAt(a) + boxesAt(b)
            if (sensitive.isEmpty()) continue
            val region = changed(a, b) ?: continue
            if (region.width * region.height < 0.01f) continue
            val touched = sensitive.filter { intersects(it, region.inflated(margin, margin)) }
            if (touched.isEmpty()) continue
            var box = region
            touched.forEach { t ->
                box = PrivacyBox(
                    minOf(box.left, t.left), minOf(box.top, t.top),
                    maxOf(box.right, t.right), maxOf(box.bottom, t.bottom)
                )
            }
            box = PrivacyBox(
                (box.left - margin).coerceAtLeast(0f), (box.top - margin).coerceAtLeast(0f),
                (box.right + margin).coerceAtMost(1f), (box.bottom + margin).coerceAtMost(1f)
            )
            out += PrivacyVeil(a, b, box)
        }
        return out
    }

    private fun intersects(x: PrivacyBox, y: PrivacyBox): Boolean =
        x.left < y.right && y.left < x.right && x.top < y.bottom && y.top < x.bottom

    /** Maximum centre displacement accepted between two consecutive samples for the same text key. */
    const val MAX_KEYED_DISPLACEMENT = 0.60f

    /** Fallback association (text key differs, e.g. OCR noise): required IoU. */
    const val MIN_FALLBACK_IOU = 0.30f

    /** Motion safety margin: fraction of per-segment displacement added around the moving box. */
    const val MOTION_MARGIN_FACTOR = 0.25f

    /**
     * Upper bound of the motion margin (normalized).
     * P1: 0.06 -> 0.025. The P0 value produced tall "ghost columns" while
     * scrolling (box inflated by up to 6% of the screen on each side).
     */
    const val MAX_MOTION_MARGIN = 0.025f

    /**
     * P1 scroll-consistent association: when the screen as a whole moved
     * by (dx, dy) between two samples, a keyed match must land within this
     * distance of last position + (dx, dy). Prevents short repeated keys
     * ("26", "2026") from jumping to a different row.
     */
    const val SHIFT_TOLERANCE = 0.05f

    /** Same expansion the legacy renderer applied to OCR boxes (anti-aliased glyph edges). */
    const val BOUNDS_EXPANSION = 0.004f

    /**
     * P1: visual change between two square luminance signatures that is NOT
     * explained by a pure vertical or horizontal shift (scroll / page swipe).
     *
     * Scrolling a text list changes almost every cell (raw change ~0.2) but a
     * shifted comparison explains it (residual ~0.02). An app-switch / zoom
     * animation cannot be explained by a shift (residual stays high).
     *
     * Returns the minimum mean absolute difference over all shifts of up to
     * 3/4 of the signature size in either axis (overlap at least 1/4).
     */
    fun unexplainedChange(a: FloatArray, b: FloatArray, size: Int): Float {
        if (a.size != b.size || a.size != size * size || size <= 0) return 0f
        val maxShift = (size * 3) / 4
        var best = shiftedDifference(a, b, size, 0, 0)
        for (s in -maxShift..maxShift) {
            if (s == 0) continue
            best = min(best, shiftedDifference(a, b, size, 0, s))
            best = min(best, shiftedDifference(a, b, size, s, 0))
            if (best <= 0f) return 0f
        }
        return best
    }

    private fun shiftedDifference(a: FloatArray, b: FloatArray, size: Int, dx: Int, dy: Int): Float {
        var total = 0f
        var count = 0
        for (y in 0 until size) {
            val yy = y + dy
            if (yy < 0 || yy >= size) continue
            for (x in 0 until size) {
                val xx = x + dx
                if (xx < 0 || xx >= size) continue
                total += abs(a[y * size + x] - b[yy * size + xx])
                count++
            }
        }
        return if (count * 4 < size * size) Float.MAX_VALUE else total / count
    }

    fun normalizeKey(sourceText: String): String =
        sourceText.lowercase().filter { it.isLetterOrDigit() || it == '@' || it == '.' }

    /**
     * Build tracks.
     *
     * @param observations sensitive detections; every timestamp must be in [sampleTimesMs]
     * @param sampleTimesMs times at which OCR ran SUCCESSFULLY (absence at these times is evidence)
     * @param durationMs video duration; last coverage ends here at most
     */
    fun build(
        observations: List<PrivacyObservation>,
        sampleTimesMs: List<Long>,
        durationMs: Long,
        denseSampleCount: Int = 0,
        veils: List<PrivacyVeil> = emptyList()
    ): ScreenPrivacyPlan {

        val samples = (sampleTimesMs + observations.map { it.timestampMs })
            .distinct()
            .sorted()

        if (samples.isEmpty() || observations.isEmpty()) {
            return ScreenPrivacyPlan(emptyList(), samples, durationMs, denseSampleCount, veils)
        }

        val obsByTime: Map<Long, List<PrivacyObservation>> =
            observations
                .filter { it.box.isValid }
                .groupBy { it.timestampMs }
                .mapValues { (_, list) -> mergeDuplicates(list) }

        class Building(
            val id: Int,
            val type: SensitiveDataType,
            var key: String,
            val keyframes: MutableList<PrivacyKeyframe>
        )

        val finished = mutableListOf<Building>()
        var active = mutableListOf<Building>()
        var nextId = 1

        for (time in samples) {
            val current = obsByTime[time].orEmpty()

            // Candidate pairs (track, observation) with association cost.
            data class Candidate(val trackIndex: Int, val obsIndex: Int, val cost: Float)

            val pairs = mutableListOf<Candidate>()
            val shift = estimateShift(active.map { it.key to it.keyframes.last().box }, current)
            active.forEachIndexed { ti, track ->
                val last = track.keyframes.last().box
                current.forEachIndexed { oi, obs ->
                    val cost = associationCost(last, track.key, obs, shift)
                    if (cost != null) pairs += Candidate(ti, oi, cost)
                }
            }
            pairs.sortBy { it.cost }

            val trackUsed = BooleanArray(active.size)
            val obsUsed = BooleanArray(current.size)
            val continued = mutableListOf<Building>()

            for (p in pairs) {
                if (trackUsed[p.trackIndex] || obsUsed[p.obsIndex]) continue
                trackUsed[p.trackIndex] = true
                obsUsed[p.obsIndex] = true
                val track = active[p.trackIndex]
                val obs = current[p.obsIndex]
                track.keyframes += PrivacyKeyframe(time, obs.box)
                track.key = obs.key
                continued += track
            }

            // A track not observed at this successful sample has ended.
            active.forEachIndexed { ti, track ->
                if (!trackUsed[ti]) finished += track
            }

            current.forEachIndexed { oi, obs ->
                if (!obsUsed[oi]) {
                    continued += Building(
                        id = nextId++,
                        type = obs.type,
                        key = obs.key,
                        keyframes = mutableListOf(PrivacyKeyframe(time, obs.box))
                    )
                }
            }

            active = continued
        }
        finished += active

        val tracks = finished
            .map { b ->
                val first = b.keyframes.first().timestampMs
                val last = b.keyframes.last().timestampMs
                PrivacyTrack(
                    id = b.id,
                    type = b.type,
                    keyframes = b.keyframes.toList(),
                    coverStartMs = previousSample(samples, first) ?: 0L,
                    coverEndMs = nextSample(samples, last)
                        ?: max(durationMs, last)
                )
            }
            .sortedBy { it.id }

        return ScreenPrivacyPlan(tracks, samples, durationMs, denseSampleCount, veils)
    }

    /**
     * Global screen shift between the previous sample and this one, from
     * keys that are unique on both sides (median of their displacements).
     * Null when no reliable estimate exists.
     */
    internal fun estimateShift(
        previous: List<Pair<String, PrivacyBox>>,
        current: List<PrivacyObservation>
    ): Pair<Float, Float>? {
        val prevCounts = previous.groupingBy { it.first }.eachCount()
        val curCounts = current.groupingBy { it.key }.eachCount()
        val dxs = mutableListOf<Float>()
        val dys = mutableListOf<Float>()
        for ((key, box) in previous) {
            if (key.isEmpty() || key.startsWith("#")) continue
            if (prevCounts[key] != 1 || curCounts[key] != 1) continue
            val obs = current.first { it.key == key }
            val dx = obs.box.centerX - box.centerX
            val dy = obs.box.centerY - box.centerY
            if (abs(dx) > MAX_KEYED_DISPLACEMENT || abs(dy) > MAX_KEYED_DISPLACEMENT) continue
            dxs += dx
            dys += dy
        }
        if (dxs.isEmpty()) return null
        dxs.sort()
        dys.sort()
        return dxs[dxs.size / 2] to dys[dys.size / 2]
    }

    /**
     * Frame-local censor box for one track, or null when the track does not
     * cover [timeMs].
     */
    fun boxForTrackAt(track: PrivacyTrack, timeMs: Long): PrivacyBox? {
        if (timeMs < track.coverStartMs || timeMs > track.coverEndMs) return null

        val kf = track.keyframes
        if (kf.isEmpty()) return null

        val first = kf.first()
        val last = kf.last()

        val raw: PrivacyBox = when {
            kf.size == 1 -> first.box

            timeMs < first.timestampMs -> {
                // Lead-in: extrapolate backwards along the first segment's velocity.
                val next = kf[1]
                extrapolate(first, next, timeMs)
            }

            timeMs > last.timestampMs -> {
                // Tail: extrapolate forwards along the last segment's velocity.
                val prev = kf[kf.size - 2]
                extrapolate(last, prev, timeMs)
            }

            else -> {
                val idx = segmentIndex(kf, timeMs)
                val a = kf[idx]
                val b = kf[min(idx + 1, kf.size - 1)]
                val span = (b.timestampMs - a.timestampMs).toFloat()
                if (span <= 0f) {
                    a.box
                } else {
                    val f = ((timeMs - a.timestampMs) / span).coerceIn(0f, 1f)
                    motionInflate(PrivacyBox.lerp(a.box, b.box, f), a.box, b.box)
                }
            }
        }

        val result = raw
            .inflated(BOUNDS_EXPANSION, BOUNDS_EXPANSION)
            .clamped()

        return if (result.isValid) result else null
    }

    // ------------------------------------------------------------------

    /**
     * Box at [timeMs] outside the keyframe span, moving with the velocity
     * measured between [anchor] and [other], plus the motion margin.
     */
    private fun extrapolate(
        anchor: PrivacyKeyframe,
        other: PrivacyKeyframe,
        timeMs: Long
    ): PrivacyBox {
        val dt = (other.timestampMs - anchor.timestampMs).toFloat()
        if (dt == 0f) return anchor.box

        val vx = (other.box.centerX - anchor.box.centerX) / dt
        val vy = (other.box.centerY - anchor.box.centerY) / dt
        val offset = (timeMs - anchor.timestampMs).toFloat()

        val moved = anchor.box.translated(vx * offset, vy * offset)
        return motionInflate(moved, anchor.box, moved)
    }

    private fun motionInflate(box: PrivacyBox, a: PrivacyBox, b: PrivacyBox): PrivacyBox {
        val dx = abs(b.centerX - a.centerX)
        val dy = abs(b.centerY - a.centerY)
        if (dx == 0f && dy == 0f) return box
        return box.inflated(
            (dx * MOTION_MARGIN_FACTOR).coerceAtMost(MAX_MOTION_MARGIN),
            (dy * MOTION_MARGIN_FACTOR).coerceAtMost(MAX_MOTION_MARGIN)
        )
    }

    private fun segmentIndex(kf: List<PrivacyKeyframe>, timeMs: Long): Int {
        var lo = 0
        var hi = kf.size - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (kf[mid].timestampMs <= timeMs) lo = mid else hi = mid - 1
        }
        return lo
    }

    private fun associationCost(
        last: PrivacyBox,
        trackKey: String,
        obs: PrivacyObservation,
        shift: Pair<Float, Float>? = null
    ): Float? {
        val dx = obs.box.centerX - last.centerX
        val dy = obs.box.centerY - last.centerY
        val distance = sqrt(dx * dx + dy * dy)

        // Residual against the global screen motion (P1).
        val predicted = if (shift != null) last.translated(shift.first, shift.second) else last
        val rx = obs.box.centerX - predicted.centerX
        val ry = obs.box.centerY - predicted.centerY
        val residual = sqrt(rx * rx + ry * ry)

        if (
            trackKey.isNotEmpty() &&
            trackKey == obs.key &&
            abs(dx) <= MAX_KEYED_DISPLACEMENT &&
            abs(dy) <= MAX_KEYED_DISPLACEMENT &&
            (last.horizontalOverlapRatio(obs.box) >= 0.30f || abs(dy) < 0.02f) &&
            (shift == null || residual <= SHIFT_TOLERANCE)
        ) {
            return if (shift == null) distance else residual
        }

        if (last.iou(obs.box) >= MIN_FALLBACK_IOU) {
            return distance + 0.5f
        }

        if (shift != null && predicted.iou(obs.box) >= MIN_FALLBACK_IOU) {
            return residual + 0.5f
        }

        return null
    }

    /**
     * Latin and Devanagari OCR can report the same text with slightly
     * different boxes. Merge them into one observation (union box).
     */
    private fun mergeDuplicates(list: List<PrivacyObservation>): List<PrivacyObservation> {
        val merged = mutableListOf<PrivacyObservation>()
        for (obs in list) {
            val idx = merged.indexOfFirst {
                it.key == obs.key && it.box.iou(obs.box) >= 0.30f
            }
            if (idx >= 0) {
                val existing = merged[idx]
                merged[idx] = existing.copy(box = existing.box.union(obs.box))
            } else {
                merged += obs
            }
        }
        return merged
    }

    private fun previousSample(samples: List<Long>, time: Long): Long? {
        val i = samples.binarySearch(time)
        val idx = if (i >= 0) i - 1 else -i - 2
        return samples.getOrNull(idx)
    }

    private fun nextSample(samples: List<Long>, time: Long): Long? {
        val i = samples.binarySearch(time)
        val idx = if (i >= 0) i + 1 else -i - 1
        return samples.getOrNull(idx)
    }
}
