package com.avsp.pro.audio.engine

import android.content.Context
import android.util.Base64
import android.util.Log
import com.avsp.pro.settings.ApiKeyRing
import com.avsp.pro.settings.SecureConfigKeys
import com.avsp.pro.settings.SecureConfigStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection

/**
 * P21 BETTER VOICES. Natural cloud voices with automatic fallback, per scene:
 *   1. Gemini TTS     - uses the Gemini keys already saved (no new setup)
 *   2. Azure Speech   - best Indian voices (Hindi Swara/Madhur, Bengali Tanishaa/Bashkar), free tier
 *   3. Google Cloud TTS - needs its own key with the Text-to-Speech API enabled
 *   4. the phone voice (offline)
 * A service that refuses (no quota, wrong key) is skipped for the rest of the session.
 * Every scene comes out as WAV 24 kHz mono 16-bit, so scenes from different services join cleanly.
 */
class SmartVoiceEngine(
    context: Context,
    private val store: SecureConfigStore,
    private val fallback: () -> TtsEngine?
) : TtsEngine {

    override val providerId: String = PROVIDER_ID
    override val displayName: String = "Natural voice (cloud, falls back to phone)"
    override val mode: TtsProviderMode = TtsProviderMode.REMOTE
    private val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private val refused = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
    @Volatile private var geminiModels: List<String>? = null
    @Volatile var lastUsed: String = ""
        private set

    /** On when the user has not chosen "phone voice only" and at least one voice service has a key. */
    fun enabled(): Boolean = prefs.getString(KEY_MODE, MODE_AUTO) != MODE_PHONE &&
        (ApiKeyRing.keys(store, SecureConfigKeys.AI_API).isNotEmpty() || ApiKeyRing.keys(store, AZURE).isNotEmpty() || ApiKeyRing.keys(store, GOOGLE_TTS).isNotEmpty())

    override fun isAvailable(): Boolean = enabled()
    override fun supportedLanguages(): Set<String> = setOf("en", "hi", "bn")
    override fun supportsLanguage(languageCode: String): Boolean = languageCode.substringBefore('-').lowercase() in supportedLanguages()

    override suspend fun synthesize(request: TtsSynthesisRequest): TtsSynthesisResult = withContext(Dispatchers.IO) {
        val lang = request.language.substringBefore('-').lowercase()
        val male = prefs.getString(KEY_GENDER, "female") == "male"
        val text = request.text.trim()
        val attempts = listOf<Pair<String, () -> ByteArray?>>(
            "gemini" to { gemini(text, lang, male) },
            "azure" to { azure(text, lang, male) },
            "google" to { googleCloud(text, lang, male) }
        )
        if (text.isNotEmpty()) for ((name, call) in attempts) {
            if (name in refused) continue
            val wav = runCatching { call() }.onFailure { e ->
                Log.w("AVSP", "voice $name failed: ${e.message?.take(120)}")
                if (refusal(e.message)) refused += name
            }.getOrNull() ?: continue
            val fixed = runCatching { trimSilence(to24kMono(wav)) }.getOrNull() ?: continue
            val ms = durationMs(fixed)
            if (ms < 200) continue
            lastUsed = name
            return@withContext TtsSynthesisResult(fixed, ms, "audio/wav", "$PROVIDER_ID:$name", request.language, name)
        }
        // 4) Phone voice, converted to the same format.
        val phone = fallback() ?: error("No voice available")
        val r = phone.synthesize(request)
        val fixed = runCatching { trimSilence(to24kMono(r.audioBytes)) }.getOrElse { r.audioBytes }
        lastUsed = "phone"
        r.copy(audioBytes = fixed, durationMs = durationMs(fixed).takeIf { it > 0 } ?: r.durationMs, providerId = "$PROVIDER_ID:phone")
    }

    // ---------------- Gemini TTS ----------------
    private fun gemini(text: String, lang: String, male: Boolean): ByteArray? {
        val keys = ApiKeyRing.keys(store, SecureConfigKeys.AI_API).filter { "gemini:$it" !in refused }
        if (keys.isEmpty()) return null
        val voice = if (male) "Puck" else "Kore"
        // P22.3: ONLY the script text is sent - an instruction in front of it was read out aloud in every scene.
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
            .toString()
        for (key in keys.take(4)) {
            for (model in ttsModels(key)) {
                val raw = runCatching { http("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", body,
                    mapOf("x-goog-api-key" to key, "Content-Type" to "application/json; charset=utf-8"), 60_000) }
                    .onFailure { if (it.message?.contains("HTTP 429") == true || it.message?.contains("HTTP 403") == true) refused += "gemini:$key" }
                    .getOrNull() ?: continue
                val pcm = geminiPcm(String(raw, Charsets.UTF_8)) ?: continue
                return pcmToWav(pcm, 24_000)
            }
        }
        return null
    }

    /** TTS models this key can use (newest flash first), found once per session. */
    private fun ttsModels(key: String): List<String> {
        geminiModels?.let { return it }
        val found = runCatching {
            val raw = String(http("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200", null, mapOf("x-goog-api-key" to key), 15_000), Charsets.UTF_8)
            val arr = JSONObject(raw).optJSONArray("models") ?: JSONArray()
            (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("name")?.removePrefix("models/") }
                .filter { it.contains("tts") }
                .sortedWith(compareByDescending<String> { it.contains("flash") }.thenByDescending { it })
        }.getOrNull().orEmpty()
        val list = found.ifEmpty { listOf("gemini-2.5-flash-preview-tts", "gemini-2.5-flash-tts") }.take(3)
        geminiModels = list
        return list
    }

    // ---------------- Azure Speech ----------------
    private fun azure(text: String, lang: String, male: Boolean): ByteArray? {
        val keys = ApiKeyRing.keys(store, AZURE)
        if (keys.isEmpty()) return null
        val region = prefs.getString(KEY_AZURE_REGION, "centralindia")!!.trim().ifBlank { "centralindia" }
        val (locale, voice) = when (lang) {
            "hi" -> "hi-IN" to if (male) "hi-IN-MadhurNeural" else "hi-IN-SwaraNeural"
            "bn" -> "bn-IN" to if (male) "bn-IN-BashkarNeural" else "bn-IN-TanishaaNeural"
            else -> "en-IN" to if (male) "en-IN-PrabhatNeural" else "en-IN-NeerjaNeural"
        }
        val ssml = "<speak version='1.0' xml:lang='$locale'><voice name='$voice'>${xml(text)}</voice></speak>"
        for (key in keys) {
            val wav = runCatching {
                http("https://$region.tts.speech.microsoft.com/cognitiveservices/v1", ssml, mapOf(
                    "Ocp-Apim-Subscription-Key" to key,
                    "Content-Type" to "application/ssml+xml",
                    "X-Microsoft-OutputFormat" to "riff-24khz-16bit-mono-pcm",
                    "User-Agent" to "AVSP"
                ), 30_000)
            }.getOrNull()
            if (wav != null && wav.size > 1000) return wav
        }
        return null
    }

    // ---------------- Google Cloud Text-to-Speech ----------------
    private fun googleCloud(text: String, lang: String, male: Boolean): ByteArray? {
        val keys = ApiKeyRing.keys(store, GOOGLE_TTS)
        if (keys.isEmpty()) return null
        val locale = when (lang) { "hi" -> "hi-IN"; "bn" -> "bn-IN"; else -> "en-IN" }
        val body = JSONObject()
            .put("input", JSONObject().put("text", text))
            .put("voice", JSONObject().put("languageCode", locale).put("ssmlGender", if (male) "MALE" else "FEMALE"))
            .put("audioConfig", JSONObject().put("audioEncoding", "LINEAR16").put("sampleRateHertz", 24_000))
            .toString()
        for (key in keys) {
            val raw = runCatching { http("https://texttospeech.googleapis.com/v1/text:synthesize", body,
                mapOf("x-goog-api-key" to key, "Content-Type" to "application/json; charset=utf-8"), 30_000) }.getOrNull() ?: continue
            val b64 = runCatching { JSONObject(String(raw, Charsets.UTF_8)).optString("audioContent") }.getOrNull()
            if (!b64.isNullOrBlank()) return Base64.decode(b64, Base64.DEFAULT)
        }
        return null
    }

    private fun http(url: String, body: String?, headers: Map<String, String>, readTimeout: Int): ByteArray {
        val c = java.net.URI(url).toURL().openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000; c.readTimeout = readTimeout
            headers.forEach { (h, v) -> c.setRequestProperty(h, v) }
            if (body != null) {
                c.requestMethod = "POST"; c.doOutput = true
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            check(code in 200..299) { "HTTP $code" }
            return c.inputStream.use { it.readBytes() }
        } finally { c.disconnect() }
    }

    companion object {
        const val PROVIDER_ID = "smart_voice"
        const val PREFS = "avsp_voice"
        const val KEY_MODE = "mode"
        const val KEY_GENDER = "gender"
        const val KEY_AZURE_REGION = "azure_region"
        const val MODE_AUTO = "auto"
        const val MODE_PHONE = "phone"
        /** Key-ring names (encrypted store) for the extra voice services. */
        const val AZURE = "azure_speech_credential"
        const val GOOGLE_TTS = "google_tts_credential"

        private fun refusal(msg: String?) = msg != null && (msg.contains("HTTP 401") || msg.contains("HTTP 403"))

        fun xml(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&apos;").replace("\"", "&quot;")

        /** Base64 PCM from a Gemini audio reply (all inlineData parts joined). */
        fun geminiPcm(raw: String): ByteArray? = runCatching {
            val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            val out = ByteArrayOutputStream()
            for (i in 0 until parts.length()) {
                val data = parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data").orEmpty()
                if (data.isNotEmpty()) out.write(java.util.Base64.getDecoder().decode(data))
            }
            out.toByteArray().takeIf { it.size > 1000 }
        }.getOrNull()

        fun pcmToWav(pcm: ByteArray, rate: Int, channels: Int = 1): ByteArray {
            val out = ByteArrayOutputStream(44 + pcm.size)
            fun i32(v: Int) { out.write(v and 0xff); out.write((v shr 8) and 0xff); out.write((v shr 16) and 0xff); out.write((v shr 24) and 0xff) }
            fun i16(v: Int) { out.write(v and 0xff); out.write((v shr 8) and 0xff) }
            out.write("RIFF".toByteArray()); i32(36 + pcm.size); out.write("WAVE".toByteArray())
            out.write("fmt ".toByteArray()); i32(16); i16(1); i16(channels); i32(rate); i32(rate * channels * 2); i16(channels * 2); i16(16)
            out.write("data".toByteArray()); i32(pcm.size); out.write(pcm)
            return out.toByteArray()
        }

        /** Any 16-bit PCM WAV -> 24 kHz mono (channels averaged, linear resampling). */
        fun to24kMono(wav: ByteArray): ByteArray {
            var pos = 12; var rate = 0; var channels = 0; var bits = 0; var dataStart = -1; var dataLen = 0
            fun i32(o: Int) = (wav[o].toInt() and 0xff) or ((wav[o + 1].toInt() and 0xff) shl 8) or ((wav[o + 2].toInt() and 0xff) shl 16) or ((wav[o + 3].toInt() and 0xff) shl 24)
            fun i16(o: Int) = (wav[o].toInt() and 0xff) or ((wav[o + 1].toInt() and 0xff) shl 8)
            require(wav.size > 44 && String(wav, 0, 4) == "RIFF") { "not a WAV" }
            while (pos + 8 <= wav.size) {
                val id = String(wav, pos, 4); val len = i32(pos + 4)
                if (id == "fmt ") { channels = i16(pos + 10); rate = i32(pos + 12); bits = i16(pos + 22) }
                if (id == "data") { dataStart = pos + 8; dataLen = minOf(if (len <= 0) wav.size - dataStart else len, wav.size - dataStart); break }
                pos += 8 + len + (len and 1)
            }
            require(dataStart > 0 && bits == 16 && rate > 0 && channels > 0) { "unsupported WAV" }
            val frames = dataLen / (2 * channels)
            val mono = ShortArray(frames) { f ->
                var sum = 0
                for (ch in 0 until channels) sum += i16(dataStart + (f * channels + ch) * 2).toShort().toInt()
                (sum / channels).toShort()
            }
            val outFrames = (frames.toLong() * 24_000 / rate).toInt()
            val pcm = ByteArray(outFrames * 2)
            for (i in 0 until outFrames) {
                val src = i.toDouble() * rate / 24_000
                val a = src.toInt().coerceAtMost(frames - 1)
                val b = (a + 1).coerceAtMost(frames - 1)
                val t = src - a
                val v = (mono[a] * (1 - t) + mono[b] * t).toInt().coerceIn(-32768, 32767)
                pcm[i * 2] = (v and 0xff).toByte(); pcm[i * 2 + 1] = ((v shr 8) and 0xff).toByte()
            }
            return pcmToWav(pcm, 24_000)
        }

        /** P22.3: cuts silence before the first word and after the last (keeps 120 ms / 250 ms), 24 kHz mono WAV in and out. */
        fun trimSilence(wav: ByteArray, threshold: Int = 600): ByteArray {
            if (wav.size <= 44 + 4) return wav
            val n = (wav.size - 44) / 2
            fun sample(i: Int) = ((wav[44 + i * 2].toInt() and 0xff) or (wav[45 + i * 2].toInt() shl 8)).toShort().toInt()
            var first = 0; while (first < n && kotlin.math.abs(sample(first)) < threshold) first++
            var last = n - 1; while (last > first && kotlin.math.abs(sample(last)) < threshold) last--
            if (first >= last) return wav
            val from = (first - 24_000 * 120 / 1000).coerceAtLeast(0)
            val to = (last + 24_000 * 250 / 1000).coerceAtMost(n - 1)
            return pcmToWav(wav.copyOfRange(44 + from * 2, 44 + (to + 1) * 2), 24_000)
        }

        fun durationMs(wav: ByteArray): Long = ((wav.size - 44).coerceAtLeast(0).toLong() * 1000L) / (24_000 * 2)
    }
}
