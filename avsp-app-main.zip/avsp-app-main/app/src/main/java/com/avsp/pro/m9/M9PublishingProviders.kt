﻿package com.avsp.pro.m9

import java.io.File

enum class M9ProviderId {
    YOUTUBE,
    FACEBOOK,
    INSTAGRAM,
    TELEGRAM,
    WEB
}

enum class M9ProviderMode {
    REAL,
    NOT_CONFIGURED
}

enum class M9AuthState {
    NOT_CONFIGURED,
    AUTHENTICATING,
    AUTHENTICATED,
    EXPIRED,
    REVOKED,
    FAILED
}

enum class M9UploadState {
    NOT_STARTED,
    UPLOADING,
    PROCESSING,
    PUBLISHED,
    FAILED,
    PARTIAL
}

data class M9ProviderCapabilities(
    val provider: M9ProviderId,
    val supportsAuthentication: Boolean,
    val supportsUpload: Boolean,
    val supportsProcessingStatus: Boolean,
    val supportsPublicationConfirmation: Boolean,
    val supportsExternalId: Boolean,
    val mode: M9ProviderMode
)

data class M9ProviderAuth(
    val provider: M9ProviderId,
    val state: M9AuthState,
    val accountLabel: String? = null,
    val externalAccountId: String? = null,
    val message: String = ""
)

data class M9PublishRequest(
    val jobId: String,
    val projectId: String,
    val videoFile: File,
    val title: String,
    val provider: M9ProviderId
)

data class M9PublishResult(
    val provider: M9ProviderId,
    val state: M9UploadState,
    val externalId: String? = null,
    val message: String,
    val realOperationPerformed: Boolean
)

interface M9PublishingProvider {
    val id: M9ProviderId
    val capabilities: M9ProviderCapabilities

    fun authState(): M9ProviderAuth

    fun publish(request: M9PublishRequest): M9PublishResult
}

private class M9NotConfiguredProvider(
    override val id: M9ProviderId
) : M9PublishingProvider {

    override val capabilities = M9ProviderCapabilities(
        provider = id,
        supportsAuthentication = false,
        supportsUpload = false,
        supportsProcessingStatus = false,
        supportsPublicationConfirmation = false,
        supportsExternalId = false,
        mode = M9ProviderMode.NOT_CONFIGURED
    )

    override fun authState(): M9ProviderAuth {
        return M9ProviderAuth(
            provider = id,
            state = M9AuthState.NOT_CONFIGURED,
            message = "External authentication is not configured for $id."
        )
    }

    override fun publish(request: M9PublishRequest): M9PublishResult {
        return M9PublishResult(
            provider = id,
            state = M9UploadState.FAILED,
            message = "External publishing provider $id is not configured. No upload was performed.",
            realOperationPerformed = false
        )
    }
}

object M9PublishingProviderRegistry {

    private val providers: Map<M9ProviderId, M9PublishingProvider> =
        M9ProviderId.entries.associateWith { M9NotConfiguredProvider(it) }

    fun get(provider: M9ProviderId): M9PublishingProvider {
        return providers.getValue(provider)
    }

    fun all(): List<M9PublishingProvider> {
        return M9ProviderId.entries.map { providers.getValue(it) }
    }

    fun capabilities(): List<M9ProviderCapabilities> {
        return all().map { it.capabilities }
    }
}

data class M9ProviderExecutionResult(
    val provider: M9ProviderId,
    val jobStatus: M9Status,
    val publishResult: M9PublishResult
)

object M9PublishingExecutor {

    fun execute(
        job: M9Job,
        provider: M9ProviderId
    ): M9ProviderExecutionResult {

        require(job.status == M9Status.READY) {
            "M9 provider execution requires job status READY."
        }

        require(job.videoPath.isNotBlank()) {
            "M9 provider execution requires a video path."
        }

        val videoFile = File(job.videoPath)

        require(videoFile.exists()) {
            "M9 provider execution video does not exist."
        }

        require(videoFile.isFile) {
            "M9 provider execution video path is not a file."
        }

        M9StateMachine.transition(job, M9Status.UPLOADING)

        val request = M9PublishRequest(
            jobId = job.jobId,
            projectId = job.projectId,
            videoFile = videoFile,
            title = job.title,
            provider = provider
        )

        val result = M9PublishingProviderRegistry
            .get(provider)
            .publish(request)

        if (result.realOperationPerformed) {
            when (result.state) {
                M9UploadState.PROCESSING ->
                    M9StateMachine.transition(job, M9Status.PROCESSING)

                M9UploadState.PUBLISHED ->
                    M9StateMachine.transition(job, M9Status.PROCESSING)

                M9UploadState.PARTIAL ->
                    M9StateMachine.transition(job, M9Status.PARTIAL)

                M9UploadState.FAILED ->
                    M9StateMachine.transition(job, M9Status.FAILED)

                else -> {
                    M9StateMachine.transition(job, M9Status.FAILED)
                }
            }
        } else {
            M9StateMachine.transition(job, M9Status.FAILED)
        }

        return M9ProviderExecutionResult(
            provider = provider,
            jobStatus = job.status,
            publishResult = result
        )
    }
}
