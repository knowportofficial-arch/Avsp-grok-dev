package com.avsp.pro.video.engine

import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * P6 VIDEO POLISH - pure planning (no Android types, unit-tested).
 *
 *  - captions: the narration split into short chunks (2 lines max) timed to the voice
 *  - one fitting emoji per scene (topic keywords), CTA scene gets 👍 🔔 ↗
 *  - CTA scene text: "Like • Follow • Share"
 *  - background music: a soft, original synthesized pad (no file, no licence)
 */
object PolishPlanner {

    data class Chunk(val startMs: Long, val endMs: Long, val text: String)

    data class ScenePolish(
        val captions: List<Chunk>,
        val emoji: String?,
        val isCta: Boolean,
        val index: Int,
        val count: Int
    )

    const val MAX_WORDS_PER_CHUNK = 6

    fun plan(narration: String, durationMs: Long, index: Int, count: Int, isCta: Boolean, language: String = "en"): ScenePolish {
        val captions = if (isCta) {
            listOf(Chunk(0L, durationMs, ctaLine(language)))
        } else {
            chunks(narration, durationMs)
        }
        val emoji = if (isCta) "👍 🔔 ↗️" else emojiFor(narration)
        return ScenePolish(captions, emoji, isCta, index, count)
    }

    fun ctaLine(language: String): String = com.avsp.pro.settings.BrandKit.ctaLine(language) ?: when (language.lowercase()) {
        "bn" -> "লাইক • ফলো • শেয়ার"
        "hi" -> "लाइक • फ़ॉलो • शेयर"
        else -> "Like • Follow • Share"
    }

    /** "Hubballi , Gorakhpur ." -> "Hubballi, Gorakhpur." (punctuation is never a caption word of its own). */
    fun tidy(text: String): String =
        text.replace(Regex("""\s+([,.;:!?।)])"""), "$1")
            .replace(Regex("""\(\s+"""), "(")
            .replace(Regex("""\s+"""), " ")
            .trim()
            .trimStart(',', ';', ':', '.', ' ')

    /** Narration -> caption chunks timed by length (spoken time is ~ proportional to characters). */
    fun chunks(narration: String, durationMs: Long): List<Chunk> {
        val words = tidy(narration).split(Regex("""\s+""")).filter { it.isNotBlank() }
        if (words.isEmpty() || durationMs <= 0) return emptyList()
        val groups = mutableListOf<MutableList<String>>()
        var current = mutableListOf<String>()
        for (w in words) {
            current += w
            val sentenceEnd = w.last() in ".!?।"
            if (sentenceEnd && current.size < 3 && groups.isNotEmpty() &&
                groups.last().last().last() !in ".!?।" && groups.last().size + current.size <= MAX_WORDS_PER_CHUNK + 2
            ) {
                // P9: a sentence's last word(s) stay with their sentence ("…on weekends."), never start the next caption.
                groups.last() += current; current = mutableListOf()
            } else if (current.size >= MAX_WORDS_PER_CHUNK || (sentenceEnd && current.size >= 3)) {
                groups += current; current = mutableListOf()
            }
        }
        if (current.isNotEmpty()) {
            if (current.size <= 2 && groups.isNotEmpty()) groups.last() += current else groups += current
        }
        val weights = groups.map { g -> max(4, g.joinToString(" ").length) }
        val total = weights.sum().toDouble()
        val out = mutableListOf<Chunk>()
        var t = 0L
        groups.forEachIndexed { i, g ->
            val end = if (i == groups.lastIndex) durationMs else min(durationMs, t + (durationMs * weights[i] / total).roundToLong())
            out += Chunk(t, end, g.joinToString(" "))
            t = end
        }
        return out.filter { it.endMs > it.startMs }
    }

    private fun Double.roundToLong(): Long = kotlin.math.round(this).toLong()

    private val EMOJI_RULES: List<Pair<Regex, String>> = listOf(
        "rain|flood|monsoon|storm|cyclone|বৃষ্টি|बारिश" to "🌧️",
        "weather|temperature|heat|sunny|গরম|मौसम" to "🌤️",
        "gold|price|money|rupee|economy|market|stock|bank|দাম|कीमत" to "💰",
        "election|vote|minister|government|parliament|policy|নির্বাচন|चुनाव" to "🗳️",
        "police|crime|arrest|court|suspect|shot|murder|পুলিশ|पुलिस" to "🚨",
        "accident|fire|blast|disaster|died|death" to "⚠️",
        "school|student|exam|university|education|teacher|book|পরীক্ষা|छात्र" to "📚",
        "space|rocket|satellite|moon|mars|launch" to "🚀",
        "science|scientist|research|study|isro|nasa|lab" to "🔬",
        "cricket|football|sport|tournament|wins\\b|won\\b|player|খেলা|मैच" to "🏏",
        "health|doctor|hospital|sleep|water|fitness|diet|disease|स्वास्थ्य" to "💪",
        "food|recipe|cook|eat|restaurant|খাবার|खाना" to "🍲",
        "smartphone|technology|computer|internet|software|artificial intelligence|gadget" to "💻",
        "travel|train|railway|flight|tour|station|যাত্রা|यात्रा" to "🚆",
        "festival|celebrat|puja|diwali|eid|wedding|উৎসব|त्योहार" to "🎉",
        "india|indian|ভারত|भारत" to "🇮🇳",
        "love|family|friend|heart" to "❤️",
        "tips?\\b|ideas?\\b|how to|guide" to "💡"
    ).map { (k, e) -> Regex("""(?i)\b($k)""") to e } // ICU (Android) \b is Unicode-aware; no (?U) flag on Android

    fun emojiFor(text: String): String? = EMOJI_RULES.firstOrNull { it.first.containsMatchIn(text) }?.second

    // ------------------------------------------------------------------ music

    /**
     * Original ambient pad (C - G - Am - F, 2 s per chord), 16-bit mono WAV.
     * Quiet on purpose (about -24 dBFS): it sits under the voice like ducked music.
     */
    fun musicWav(seconds: Int = 16, sampleRate: Int = 44_100, peak: Double = 0.06): ByteArray {
        val chords = listOf(
            doubleArrayOf(261.63, 329.63, 392.00),
            doubleArrayOf(196.00, 246.94, 293.66),
            doubleArrayOf(220.00, 261.63, 329.63),
            doubleArrayOf(174.61, 220.00, 261.63)
        )
        val n = seconds * sampleRate
        val chordLen = 2 * sampleRate
        val pcm = ShortArray(n)
        for (i in 0 until n) {
            val c = chords[(i / chordLen) % chords.size]
            val pos = (i % chordLen).toDouble() / chordLen
            val env = min(1.0, pos / 0.25) * min(1.0, (1.0 - pos) / 0.25)    // soft attack / release
            val t = i.toDouble() / sampleRate
            var v = 0.0
            for ((k, f) in c.withIndex()) {
                v += sin(2 * PI * f * t) * (if (k == 0) 0.45 else 0.3)
                v += sin(2 * PI * f * 2 * t) * 0.05                            // gentle shimmer
            }
            pcm[i] = (v / 1.3 * env * peak * Short.MAX_VALUE).roundToInt().coerceIn(-32767, 32767).toShort()
        }
        return wav(pcm, sampleRate)
    }

    private fun wav(pcm: ShortArray, sampleRate: Int): ByteArray {
        val dataLen = pcm.size * 2
        val b = java.nio.ByteBuffer.allocate(44 + dataLen).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt(36 + dataLen); b.put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()); b.putInt(16); b.putShort(1); b.putShort(1)
        b.putInt(sampleRate); b.putInt(sampleRate * 2); b.putShort(2); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(dataLen)
        pcm.forEach { b.putShort(it) }
        return b.array()
    }
}
