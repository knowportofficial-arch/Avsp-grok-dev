﻿package com.avsp.pro.core.dailypost

object DailyPostProviderFactory {

    /**
     * Real provider is used by default.
     *
     * If a remote source is unavailable, that source returns no items.
     * The UI remains honest and does not fabricate fallback content.
     */
    fun create(): DailyPostProvider =
        LiveDailyPostProvider()
}
