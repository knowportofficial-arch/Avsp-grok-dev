package com.avsp.pro.video.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import androidx.media3.common.OverlaySettings
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.StaticOverlaySettings

/**
 * P10 motion: transitions and "auto animation" that cost almost nothing to
 * render - each overlay keeps ONE bitmap and only its alpha / position change
 * per frame (no per-frame drawing).
 */
object Motion {
    /** Fade in at scene start, fade out at scene end (a short dip-to-black between scenes). */
    const val FADE_IN_MS = 300L
    const val FADE_OUT_MS = 200L

    /** Black-overlay opacity at [sceneMs] of a scene lasting [sceneDurationMs]. */
    fun dipAlpha(sceneMs: Long, sceneDurationMs: Long, fadeIn: Boolean = true, fadeOut: Boolean = true): Float {
        if (sceneDurationMs <= 0) return 0f
        val inA = if (fadeIn && sceneMs < FADE_IN_MS) 1f - sceneMs.toFloat() / FADE_IN_MS else 0f
        val left = sceneDurationMs - sceneMs
        val outA = if (fadeOut && left < FADE_OUT_MS) 1f - left.coerceAtLeast(0).toFloat() / FADE_OUT_MS else 0f
        return maxOf(inA, outA).coerceIn(0f, 1f)
    }

    /**
     * P10.1: piece-local time. Media3 gives overlays the time on the WHOLE video's
     * clock (measured on the phone: fades fired mid-scene with the old guess, which
     * also shifted captions). A time before the piece start can only be a piece-local
     * clock, so it is used as is.
     */
    fun pieceMs(presentationTimeUs: Long, pieceDurationMs: Long, pieceAbsoluteStartMs: Long): Long {
        val t = presentationTimeUs / 1000L
        val local = if (t >= pieceAbsoluteStartMs) t - pieceAbsoluteStartMs else t
        return local.coerceIn(0, pieceDurationMs)
    }

    /** Scene-local time from a Media3 presentation time. */
    fun sceneMs(presentationTimeUs: Long, pieceDurationMs: Long, pieceAbsoluteStartMs: Long, pieceOffsetMs: Long): Long =
        pieceMs(presentationTimeUs, pieceDurationMs, pieceAbsoluteStartMs) + pieceOffsetMs

    /** Slow drifting path in normalised device coordinates (-1..1), different per [seed]. */
    fun drift(sceneMs: Long, seed: Int): Pair<Float, Float> {
        val t = sceneMs / 1000.0
        val a = 0.55 + 0.12 * (seed % 3)
        val x = (a * kotlin.math.sin(t * 0.45 + seed * 1.7)).toFloat()
        val y = (0.6 * kotlin.math.cos(t * 0.33 + seed * 2.3)).toFloat()
        return x to y
    }

    private val blackCache = HashMap<Long, Bitmap>()

    @Synchronized
    internal fun black(width: Int, height: Int): Bitmap =
        blackCache.getOrPut((width.toLong() shl 32) or height.toLong()) {
            Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply { eraseColor(Color.BLACK) }
        }

    private var glowCache: Bitmap? = null

    @Synchronized
    internal fun glow(size: Int): Bitmap = glowCache?.takeIf { it.width == size } ?: Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888).also { b ->
        val r = size / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(r, r, r, intArrayOf(Color.argb(255, 255, 255, 255), Color.argb(0, 255, 255, 255)), null, Shader.TileMode.CLAMP)
        }
        Canvas(b).drawCircle(r, r, r, p)
        glowCache = b
    }
}

/** Dip-to-black transition at both ends of a scene. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class FadeOverlay(
    private val sceneDurationMs: Long,
    private val pieceOffsetMs: Long,
    private val pieceDurationMs: Long,
    private val pieceAbsoluteStartMs: Long,
    private val width: Int,
    private val height: Int,
    private val fadeIn: Boolean,
    private val fadeOut: Boolean
) : BitmapOverlay() {
    override fun getBitmap(presentationTimeUs: Long): Bitmap = Motion.black(width, height)

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val ms = Motion.sceneMs(presentationTimeUs, pieceDurationMs, pieceAbsoluteStartMs, pieceOffsetMs)
        return StaticOverlaySettings.Builder()
            .setAlphaScale(Motion.dipAlpha(ms, sceneDurationMs, fadeIn, fadeOut))
            .build()
    }
}

/** "Auto animation" for scenes without a picture: soft lights drifting over the card. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class DriftGlowOverlay(
    private val seed: Int,
    private val pieceOffsetMs: Long,
    private val pieceDurationMs: Long,
    private val pieceAbsoluteStartMs: Long,
    private val size: Int,
    private val alpha: Float = 0.22f
) : BitmapOverlay() {
    override fun getBitmap(presentationTimeUs: Long): Bitmap = Motion.glow(size)

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val ms = Motion.sceneMs(presentationTimeUs, pieceDurationMs, pieceAbsoluteStartMs, pieceOffsetMs)
        val (x, y) = Motion.drift(ms, seed)
        return StaticOverlaySettings.Builder()
            .setBackgroundFrameAnchor(x, y)
            .setAlphaScale(alpha)
            .build()
    }
}
