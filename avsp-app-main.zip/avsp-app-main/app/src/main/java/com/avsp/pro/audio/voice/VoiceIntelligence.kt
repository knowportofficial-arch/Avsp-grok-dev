﻿package com.avsp.pro.audio.voice

import com.avsp.pro.audio.engine.TtsEngine

/**
 * M3 voice intelligence facade.
 *
 * Provider catalogs are assembled by VoiceIntelligenceCatalog.
 * Selection is delegated to the existing authoritative BestFitVoiceSelector
 * so M3 has one deterministic selection policy rather than two competing
 * scoring implementations.
 */
object VoiceIntelligence {

    fun catalogFor(engine: TtsEngine): List<VoiceProfile> =
        VoiceIntelligenceCatalog.catalogFor(engine)

    fun select(
        request: VoiceSelectionRequest,
        engines: List<TtsEngine>
    ): VoiceSelectionResult {
        val voices = engines
            .filter { it.isAvailable() && it.supportsLanguage(request.language) }
            .flatMap { catalogFor(it) }

        return try {
            BestFitVoiceSelector.select(request, voices)
        } catch (e: IllegalArgumentException) {
            throw IllegalStateException(e.message ?: "No compatible TTS voice is available.", e)
        }
    }
}

