package com.avsp.pro.ui.screens.publish

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.avsp.pro.AvspApplication
import com.avsp.pro.publish.SheetPublisher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun container(ctx: android.content.Context) = (ctx.applicationContext as AvspApplication).container

private fun open(ctx: android.content.Context, url: String) {
    runCatching { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }
}

/**
 * P16: "Send for approval" - the video goes to the user's Google Sheet; it is
 * posted only after they tick Approve there, at the chosen time.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SendForApprovalRow(videoUri: String, project: String, title: String, kit: com.avsp.pro.core.pipeline.PublishKit?, thumbnail: String?, projectId: String? = null) {
    val ctx = LocalContext.current
    val publisher = remember { container(ctx).publisher }
    val scope = rememberCoroutineScope()
    if (!publisher.isConfigured()) {
        Text("Auto-posting: connect your Google Sheet in Settings → Publishing (approve, schedule and results in one sheet).",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
        return
    }
    // P26: the channels picked last time are picked again
    val platformPrefs = remember { ctx.getSharedPreferences(AutoPost.PREFS, android.content.Context.MODE_PRIVATE) }
    var platforms by remember { mutableStateOf(platformPrefs.getStringSet("platforms", null)?.toSet() ?: setOf("YouTube")) }
    val options = remember { SheetPublisher.scheduleOptions(System.currentTimeMillis()) }
    var when_ by remember { mutableStateOf(options.first()) }
    var status by remember { mutableStateOf<String?>(null) }
    var sheetUrl by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var topic by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Post automatically (after your approval)", fontWeight = FontWeight.SemiBold)
        if (kit == null) {
            OutlinedTextField(value = topic, onValueChange = { topic = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("What is this video about? (optional)") },
                supportingText = { Text("Empty = AVSP listens to the video and writes title, description and hashtags itself") })
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SheetPublisher.PLATFORMS.forEach { p ->
                FilterChip(selected = p in platforms, onClick = { platforms = if (p in platforms) platforms - p else platforms + p; platformPrefs.edit().putStringSet("platforms", platforms).apply() }, label = { Text(p) })
            }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            options.forEach { o -> FilterChip(selected = o == when_, onClick = { when_ = o }, label = { Text(o.first) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button(enabled = !busy && platforms.isNotEmpty(), onClick = {
                busy = true; status = "Preparing title, description, hashtags and thumbnail…"
                scope.launch {
                    status = runCatching {
                        withContext(Dispatchers.IO) {
                            val cr = ctx.contentResolver
                            val auto = AutoPost.prepare(ctx, videoUri, title, kit, thumbnail, projectId, topic)
                            status = "Sending to your sheet…"
                            val video = cr.openInputStream(android.net.Uri.parse(videoUri))!!.use { it.readBytes() }
                            val thumb = auto.thumbnail?.let { t -> runCatching { cr.openInputStream(android.net.Uri.parse(t))!!.use { it.readBytes() } }.getOrNull() }
                            val sent = publisher.send(video, "${auto.title.take(40).replace(Regex("[^\\w-]+"), "_")}.mp4", thumb, (if (project.isBlank() || project == "AVSP video") auto.title else project),
                                auto.title, auto.description, auto.hashtags, SheetPublisher.PLATFORMS.filter { it in platforms }, when_.second, auto.extra)
                            sheetUrl = sent.sheetUrl
                            PostLog.remember(ctx, videoUri, sent.id)
                            "In your sheet ✓ - tick Approve there to post (${when_.first.lowercase()})."
                        }
                    }.getOrElse { "Not sent: ${it.message}" }
                    busy = false
                }
            }) { Text("Send for approval") }
            sheetUrl?.let { u -> TextButton(onClick = { open(ctx, u) }) { Text("Open sheet") } }
        }
        status?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

/** P16 Settings: the Google Sheet link + token, with a check. */
@Composable
fun PublishingSettings() {
    val ctx = LocalContext.current
    val publisher = remember { container(ctx).publisher }
    val scope = rememberCoroutineScope()
    var configured by remember { mutableStateOf(publisher.isConfigured()) }
    var url by remember { mutableStateOf("") }
    var token by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf<String?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Videos go to your own Google Sheet. Tick Approve there and they are posted at the chosen time to YouTube / Instagram / Facebook / Telegram; views and likes come back into the sheet.",
            style = MaterialTheme.typography.bodySmall)
        if (configured) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    msg = "Checking…"
                    scope.launch { msg = runCatching { "Connected to \"" + withContext(Dispatchers.IO) { publisher.ping() } + "\" ✓" }.getOrElse { "Not working: ${it.message}" } }
                }) { Text("Check connection") }
                TextButton(onClick = { publisher.clear(); configured = false; msg = "Disconnected" }) { Text("Disconnect") }
            }
        } else {
            OutlinedTextField(value = url, onValueChange = { url = it.trim() }, label = { Text("Web app link (…/exec)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = token, onValueChange = { token = it.trim() }, label = { Text("App token (from the sheet's AVSP menu)") }, singleLine = true,
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Button(enabled = url.isNotBlank() && token.isNotBlank(), onClick = {
                msg = "Checking…"
                scope.launch {
                    msg = runCatching {
                        publisher.save(url, token)
                        val name = withContext(Dispatchers.IO) { publisher.ping() }
                        configured = true; url = ""; token = ""
                        "Connected to \"$name\" ✓"
                    }.getOrElse { publisher.clear(); "Not saved: ${it.message}" }
                }
            }) { Text("Connect sheet") }
            TextButton(onClick = { open(ctx, "https://github.com/knowportofficial-arch/avsp-app/blob/main/tools/sheet-publisher/SETUP.md") }) { Text("How to make the sheet (5 min)") }
        }
        msg?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

/** P16 Settings: use matching photos/videos from the phone gallery (opt-in). */
@Composable
fun GallerySettings() {
    val ctx = LocalContext.current
    val gallery = remember { container(ctx).gallery }
    val scope = rememberCoroutineScope()
    var on by remember { mutableStateOf(gallery.enabled && gallery.hasPermission()) }
    var info by remember { mutableStateOf<String?>(null) }
    fun startIndex() {
        info = "Looking through your photos (on this phone only)…"
        scope.launch {
            val n = withContext(Dispatchers.IO) { runCatching { gallery.index(maxNew = 400, budgetMs = 90_000) }.getOrDefault(0) }
            info = "Ready: ${withContext(Dispatchers.IO) { gallery.size() }} photos/videos known (+$n new). Matching ones are used before internet pictures."
        }
    }
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted.values.any { it } && gallery.hasPermission()) { gallery.enabled = true; on = true; startIndex() }
        else { gallery.enabled = false; on = false; info = "Permission not given - gallery stays off." }
    }
    LaunchedEffect(Unit) { if (on) info = "${withContext(Dispatchers.IO) { gallery.size() }} photos/videos known." }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Use my phone gallery", fontWeight = FontWeight.SemiBold)
                Text("Photos/videos on this phone (incl. Google Photos copies) that match a scene are used first. Tagged on the phone - nothing is uploaded. Selfies and screenshots are skipped.",
                    style = MaterialTheme.typography.bodySmall)
            }
            Switch(checked = on, onCheckedChange = { want ->
                if (!want) { gallery.enabled = false; on = false; info = "Off" }
                else if (gallery.hasPermission()) { gallery.enabled = true; on = true; startIndex() }
                else launcher.launch(
                    if (android.os.Build.VERSION.SDK_INT >= 33) arrayOf(android.Manifest.permission.READ_MEDIA_IMAGES, android.Manifest.permission.READ_MEDIA_VIDEO)
                    else arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
                )
            })
        }
        info?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

/** P17 Settings: offline speech packs for captions + the PC option for long videos. */
@Composable
fun SpeechAndProcessingSettings() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var states by remember { mutableStateOf<Map<String, com.avsp.pro.edit.SpeechPacks.State>>(emptyMap()) }
    fun refresh() { scope.launch { states = com.avsp.pro.edit.SpeechPacks.LANGS.associate { (l, _) -> l to com.avsp.pro.edit.SpeechPacks.state(ctx, l) } } }
    LaunchedEffect(Unit) { refresh() }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Captions for your own videos use the phone's free offline speech packs.", style = MaterialTheme.typography.bodySmall)
        com.avsp.pro.edit.SpeechPacks.LANGS.forEach { (l, name) ->
            Text("$name: " + (states[l]?.let { com.avsp.pro.edit.SpeechPacks.label(it) } ?: "checking…"), style = MaterialTheme.typography.bodyMedium)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                com.avsp.pro.edit.SpeechPacks.LANGS.forEach { (l, _) ->
                    if (states[l] != com.avsp.pro.edit.SpeechPacks.State.READY) com.avsp.pro.edit.SpeechPacks.download(ctx, l)
                }
                scope.launch { kotlinx.coroutines.delay(4_000); refresh() }
            }) { Text("Download all") }
            OutlinedButton(onClick = { refresh() }) { Text("Refresh") }
        }
        androidx.compose.material3.HorizontalDivider()
        Text("Long videos (over 5 min) and long screen recordings", fontWeight = FontWeight.SemiBold)
        Text("Processing them on your PC (AVSP Desktop) is faster and more accurate - coming in the next update. Until then the phone does it; posting and results stay here and in your sheet.",
            style = MaterialTheme.typography.bodySmall)
    }
}

/** P20.1: one button checks the phone (camera, keys, storage, speech) and gives a report to copy to Claude. */
@Composable
fun SelfCheckSettings() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var running by remember { mutableStateOf(false) }
    var lines by remember { mutableStateOf<List<com.avsp.pro.diagnostics.SelfCheck.Line>>(emptyList()) }
    fun start(testKeys: Boolean) {
        if (running) return
        running = true; lines = emptyList()
        scope.launch {
            runCatching {
                com.avsp.pro.diagnostics.SelfCheck.run(ctx, container(ctx).secureConfigStore, testKeys) { l ->
                    scope.launch { lines = lines + l }
                }
            }.onSuccess { lines = it }
            running = false
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Checks your camera (0.5× lens, fps, slow motion, dual camera, manual ISO), keys, storage and speech packs. Copy the report and paste it to Claude.", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { start(testKeys = false) }, enabled = !running) { Text(if (running) "Checking…" else "Run self-check") }
            OutlinedButton(onClick = { start(testKeys = true) }, enabled = !running) { Text("+ test keys") }
        }
        lines.forEach { l ->
            Text(
                (when (l.ok) { true -> "✅ "; false -> "❌ "; null -> "• " }) + l.text,
                style = MaterialTheme.typography.bodySmall,
                color = if (l.ok == false) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
            )
        }
        if (lines.isNotEmpty() && !running) {
            Button(onClick = {
                val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                cm?.setPrimaryClip(android.content.ClipData.newPlainText("AVSP self-check", com.avsp.pro.diagnostics.SelfCheck.report(lines)))
                android.widget.Toast.makeText(ctx, "Copied - paste it to Claude", android.widget.Toast.LENGTH_LONG).show()
            }) { Text("Copy report") }
        }
    }
}

/** P21: which voice speaks the videos - natural cloud voices (with phone fallback) or the phone voice only. */
@Composable
fun VoiceSettings() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val E = com.avsp.pro.audio.engine.SmartVoiceEngine
    val prefs = remember { ctx.getSharedPreferences(E.PREFS, android.content.Context.MODE_PRIVATE) }
    var mode by remember { mutableStateOf(prefs.getString(E.KEY_MODE, E.MODE_AUTO) ?: E.MODE_AUTO) }
    var gender by remember { mutableStateOf(prefs.getString(E.KEY_GENDER, "female") ?: "female") }
    var region by remember { mutableStateOf(prefs.getString(E.KEY_AZURE_REGION, "centralindia") ?: "centralindia") }
    var testLang by remember { mutableStateOf("hi") }
    var status by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    LaunchedEffect(region) { com.avsp.pro.settings.KeyProviders.azureRegion = region }
    val store = remember { container(ctx).secureConfigStore }
    fun count(name: String) = com.avsp.pro.settings.ApiKeyRing.keys(store, name).size
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Natural voice is tried in this order: Gemini (your Gemini keys, ${count(com.avsp.pro.settings.SecureConfigKeys.AI_API)}) → Azure (${count(E.AZURE)}) → Google Cloud (${count(E.GOOGLE_TTS)}) → phone voice. Add Azure / Google keys under API keys.",
            style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = mode == E.MODE_AUTO, onClick = { mode = E.MODE_AUTO; prefs.edit().putString(E.KEY_MODE, mode).apply() }, label = { Text("Natural voice") })
            FilterChip(selected = mode == E.MODE_PHONE, onClick = { mode = E.MODE_PHONE; prefs.edit().putString(E.KEY_MODE, mode).apply() }, label = { Text("Phone voice only") })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = gender == "female", onClick = { gender = "female"; prefs.edit().putString(E.KEY_GENDER, gender).apply() }, label = { Text("Female") })
            FilterChip(selected = gender == "male", onClick = { gender = "male"; prefs.edit().putString(E.KEY_GENDER, gender).apply() }, label = { Text("Male") })
        }
        OutlinedTextField(
            value = region,
            onValueChange = { region = it.trim().lowercase(); prefs.edit().putString(E.KEY_AZURE_REGION, region).apply() },
            label = { Text("Azure region (e.g. centralindia, eastus)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            listOf("en" to "English", "hi" to "Hindi", "bn" to "Bengali").forEach { (c, n) ->
                FilterChip(selected = testLang == c, onClick = { testLang = c }, label = { Text(n) })
            }
        }
        Button(enabled = !busy, onClick = {
            busy = true; status = "Speaking…"
            scope.launch {
                val sample = when (testLang) {
                    "hi" -> "नमस्ते! यह आपकी AVSP आवाज़ है। आज का वीडियो शुरू करते हैं।"
                    "bn" -> "নমস্কার! এটা আপনার AVSP-এর কণ্ঠ। চলুন আজকের ভিডিও শুরু করি।"
                    else -> "Hello! This is your AVSP voice. Let's start today's video."
                }
                status = runCatching {
                    val reg = container(ctx).ttsEngineRegistry
                    val engine = reg.resolve(null)
                    val r = engine.synthesize(com.avsp.pro.audio.engine.TtsSynthesisRequest(sample, testLang, com.avsp.pro.audio.contract.VoiceSettings(language = testLang, voiceId = "default")))
                    val f = java.io.File(ctx.cacheDir, "voice_test.wav")
                    withContext(Dispatchers.IO) { f.writeBytes(r.audioBytes) }
                    android.media.MediaPlayer().apply {
                        setDataSource(f.absolutePath); prepare(); start()
                        setOnCompletionListener { it.release() }
                    }
                    "Spoken by: " + r.providerId.substringAfter(':').replaceFirstChar { it.uppercase() } + " (${r.durationMs / 100 / 10.0} s)"
                }.getOrElse { "Voice test failed: ${it.message?.take(100)}" }
                busy = false
            }
        }) { Text(if (busy) "Speaking…" else "Test voice") }
        status?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}


/**
 * P21.8 FULL AUTO POSTING: everything YouTube needs is filled in automatically -
 * SEO title, description, hashtags, search tags (Gemini, or on the phone), a thumbnail from the
 * video's best frame, category from the topic, made-for-kids and privacy from Settings, language
 * from the project. Videos made in AVSP keep the kit they already have.
 */
object AutoPost {
    data class Ready(val title: String, val description: String, val hashtags: List<String>, val thumbnail: String?, val extra: SheetPublisher.Extra)

    const val PREFS = "avsp_publish"

    /** Titles that say nothing about the video (never used as the topic). */
    private fun meaningless(t: String) = t.isBlank() || t.trim().equals("AVSP video", true) || t.startsWith("AVSP_")

    fun prepare(ctx: android.content.Context, videoUri: String, fallbackTitle: String, kit: com.avsp.pro.core.pipeline.PublishKit?, thumbnail: String?, projectId: String?, topicHint: String = ""): Ready {
        val c = container(ctx)
        val prefs = ctx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE)
        val project = projectId?.let { id -> runCatching { kotlinx.coroutines.runBlocking { c.projectRepository.openProject(id) } }.getOrNull() }
        val script = projectId?.let { id -> runCatching { kotlinx.coroutines.runBlocking { c.scriptRepository.load(id) } }.getOrNull() }
        val lang = project?.language?.code ?: script?.language ?: "en"
        val keys = com.avsp.pro.settings.ApiKeyRing.keys(c.secureConfigStore, com.avsp.pro.settings.SecureConfigKeys.AI_API)
        // P21.9: a video without a project: listen to what is said in it (phone speech, Gemini as backup).
        val heard = if (script == null && kit == null) runCatching {
            val l = java.util.Locale.getDefault().language.takeIf { it in setOf("en", "hi", "bn") } ?: "en"
            kotlinx.coroutines.runBlocking {
                com.avsp.pro.edit.SmartEditor(ctx, com.avsp.pro.edit.GeminiTranscriber { keys }).analyse(android.net.Uri.parse(videoUri), l).transcript
            }
        }.getOrDefault("").trim() else ""
        val baseTitle = topicHint.trim().takeIf { it.isNotBlank() }
            ?: script?.title?.takeIf { it.isNotBlank() } ?: project?.name?.takeIf { !meaningless(it) }
            ?: fallbackTitle.takeIf { !meaningless(it) } ?: ""
        if (kit == null && script == null && baseTitle.isBlank() && heard.split(' ').count { it.length > 2 } < 4)
            throw IllegalStateException("I can't tell what this video is about - type a short topic above and send again")
        var title = kit?.title ?: baseTitle
        var description = kit?.description.orEmpty()
        var hashtags = kit?.hashtags.orEmpty()
        var tags = hashtags.map { it.removePrefix("#") }
        var poll = ""
        if (kit == null || description.isBlank()) {
            val words = script?.scenes?.sortedBy { it.order }?.joinToString(" ") { it.narration }.orEmpty().ifBlank { heard }.ifBlank { baseTitle }
            val durS = (script?.estimatedDurationMs ?: 30_000L).div(1000).toInt()
            val seo = com.avsp.pro.publish.SeoKit.make(words, baseTitle, durS, project?.language?.displayName ?: "English", keys)
            title = seo.title; description = seo.kit().description; hashtags = seo.hashtags; tags = seo.tags; poll = seo.poll
        }
        val thumb = thumbnail ?: runCatching {
            val dur = runCatching {
                val r = android.media.MediaMetadataRetriever()
                try { r.setDataSource(ctx, android.net.Uri.parse(videoUri)); r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L } finally { r.release() }
            }.getOrDefault(0L)
            com.avsp.pro.edit.ThumbnailMaker(ctx).make(listOf(com.avsp.pro.edit.ThumbnailMaker.Source.Video(android.net.Uri.parse(videoUri), dur)), title,
                "AVSP_post_" + System.currentTimeMillis() / 1000)?.portrait?.toString()
        }.getOrNull()
        val categoryPref = prefs.getString("category", "auto") ?: "auto"
        val extra = SheetPublisher.Extra(
            tags = tags.take(15),
            categoryId = if (categoryPref == "auto") SheetPublisher.categoryFor("$title $description") else categoryPref,
            madeForKids = prefs.getBoolean("kids", false),
            privacy = prefs.getString("privacy", "public") ?: "public",
            language = lang,
            poll = if (!prefs.getBoolean("poll", true)) "" else poll.ifBlank { com.avsp.pro.publish.SeoKit.offlinePoll("$title ${script?.topic.orEmpty()}", lang) }
        )
        return Ready(title, description, hashtags, thumb, extra)
    }
}

/** P21.8 Settings -> Publishing: YouTube defaults used for every automatic post. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PostingDefaults() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences(AutoPost.PREFS, android.content.Context.MODE_PRIVATE) }
    var privacy by remember { mutableStateOf(prefs.getString("privacy", "public") ?: "public") }
    var kids by remember { mutableStateOf(prefs.getBoolean("kids", false)) }
    var category by remember { mutableStateOf(prefs.getString("category", "auto") ?: "auto") }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Every post gets an AI title, description, hashtags, tags and a thumbnail automatically. These settings apply too:", style = MaterialTheme.typography.bodySmall)
        Text("Visibility", fontWeight = FontWeight.SemiBold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("public" to "Public", "unlisted" to "Unlisted", "private" to "Private").forEach { (v, l) ->
                FilterChip(selected = privacy == v, onClick = { privacy = v; prefs.edit().putString("privacy", v).apply() }, label = { Text(l) })
            }
        }
        Text("Audience", fontWeight = FontWeight.SemiBold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = !kids, onClick = { kids = false; prefs.edit().putBoolean("kids", false).apply() }, label = { Text("Not made for kids") })
            FilterChip(selected = kids, onClick = { kids = true; prefs.edit().putBoolean("kids", true).apply() }, label = { Text("Made for kids") })
        }
        Text("Category", fontWeight = FontWeight.SemiBold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("auto" to "Auto (from topic)", "22" to "People & Blogs", "27" to "Education", "19" to "Travel & Events", "26" to "Howto & Style",
                "25" to "News", "24" to "Entertainment", "28" to "Science & Tech", "23" to "Comedy").forEach { (v, l) ->
                FilterChip(selected = category == v, onClick = { category = v; prefs.edit().putString("category", v).apply() }, label = { Text(l) })
            }
        }
        var poll by remember { mutableStateOf(prefs.getBoolean("poll", true)) }
        Text("Telegram poll", fontWeight = FontWeight.SemiBold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(selected = poll, onClick = { poll = true; prefs.edit().putBoolean("poll", true).apply() }, label = { Text("Add a poll under each video") })
            FilterChip(selected = !poll, onClick = { poll = false; prefs.edit().putBoolean("poll", false).apply() }, label = { Text("No poll") })
        }
        Text("Time: choose \"Best time (auto)\" when sending (7 PM until your sheet learns a better hour). Language follows the project.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
    }
}

/** P22.1 Settings -> Channel: channel name (used in the spoken + on-screen CTA) and logo (shown on videos). */
@Composable
fun ChannelSettings() {
    val ctx = LocalContext.current
    val B = com.avsp.pro.settings.BrandKit
    var name by remember { mutableStateOf(B.channel) }
    var showLogo by remember { mutableStateOf(B.watermark) }
    var hasLogo by remember { mutableStateOf(B.hasLogo()) }
    var msg by remember { mutableStateOf<String?>(null) }
    val pick = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) { hasLogo = B.setLogo(ctx, uri); msg = if (hasLogo) "Logo saved ✓" else "Could not read that picture" }
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
            label = { Text("Channel name (e.g. Knowport)") })
        Text("Ending of every video: \"" + (B.spokenCta("en", name) ?: "Like, share and follow!") + "\" · on screen: " + (B.ctaLine("en", name) ?: "Like • Follow • Share"),
            style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(onClick = { pick.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                Text(if (hasLogo) "Change logo" else "Choose logo")
            }
            if (hasLogo) TextButton(onClick = { B.clearLogo(ctx); hasLogo = false; msg = "Logo removed" }) { Text("Remove") }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = showLogo, onCheckedChange = { showLogo = it })
            Text("  Show the logo on videos (small, top-left)", style = MaterialTheme.typography.bodySmall)
        }
        Button(onClick = { B.save(ctx, name, showLogo); msg = "Saved ✓ - used in the next video" }) { Text("Save") }
        msg?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
    }
}


/** P22.1: which phone video went to the sheet as which row (so the Videos tab can show "Posted ✓"). */
object PostLog {
    private const val PREFS = "avsp_postlog"
    fun remember(ctx: android.content.Context, videoUri: String, rowId: String) {
        if (rowId.isBlank()) return
        ctx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().putString(videoUri, rowId).apply()
    }
    fun rowId(ctx: android.content.Context, videoUri: String): String? =
        ctx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).getString(videoUri, null)
    fun forget(ctx: android.content.Context, videoUri: String) =
        ctx.getSharedPreferences(PREFS, android.content.Context.MODE_PRIVATE).edit().remove(videoUri).apply()

    /** Sheet rows by id (empty when the sheet isn't connected or can't be reached). Blocking. */
    fun rows(ctx: android.content.Context): Map<String, SheetPublisher.Row> = runCatching {
        val p = container(ctx).publisher
        if (!p.isConfigured()) emptyMap() else p.rows().second.associateBy { it.id }
    }.getOrDefault(emptyMap())
}
