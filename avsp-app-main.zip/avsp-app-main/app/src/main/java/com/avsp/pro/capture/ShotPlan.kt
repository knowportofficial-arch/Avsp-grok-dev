package com.avsp.pro.capture

import com.avsp.pro.script.contract.ScriptScene
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection

/**
 * P20 PLAN & SHOOT: one camera task per script scene, for ANY topic ("I'm at Kharagpur
 * railway platform", "chicken soup recipe", "review of my phone"...). Each shot says what
 * to film and how: framing, photo/video, seconds, lens, movement, fps / slow motion,
 * resolution, stabilisation. Gemini writes it (all saved keys); without a key or offline
 * a rule-based plan is made on the phone. The CTA outro is not filmed (designed card).
 */
enum class Framing(val label: String) {
    WIDE("Wide"), MEDIUM("Medium"), CLOSE("Close-up"), EXTREME_CLOSE("Extreme close-up"),
    SELFIE("Selfie"), OVER_SHOULDER("Over the shoulder")
}

enum class Lens(val label: String, val zoom: Float, val front: Boolean = false) {
    ULTRA_WIDE("0.5×", 0.5f), MAIN("1×", 1f), TELE_2("2×", 2f), TELE_3("3×", 3f), FRONT("Front", 1f, true)
}

enum class Movement(val label: String) {
    STATIC("Hold still"), PAN("Slow pan"), TILT("Tilt up/down"), WALK("Walk forward"), FOLLOW("Follow the subject"), ORBIT("Move around")
}

enum class TopicKind { PLACE, RECIPE, REVIEW, EVENT, TEACH, GENERAL }

data class ShotSpec(
    val sceneId: String,
    val instruction: String,
    val framing: Framing = Framing.MEDIUM,
    val video: Boolean = true,
    val seconds: Int = 5,
    val lens: Lens = Lens.MAIN,
    val movement: Movement = Movement.STATIC,
    val fps: Int = 30,
    val slowMotion: Boolean = false,
    val uhd: Boolean = false,
    val stabilize: Boolean = true
) {
    /** One line for the shot card: "Wide · 0.5× · Video 6 s · Slow pan · 30 fps". */
    fun summary(): String = listOfNotNull(
        framing.label, lens.label,
        if (video) "Video ${seconds} s" else "Photo",
        movement.label.takeIf { video && movement != Movement.STATIC },
        when { !video -> null; slowMotion -> "Slow motion"; else -> "$fps fps" },
        "4K".takeIf { uhd }
    ).joinToString(" · ")
}

object ShotPlanner {

    private val SLOW = Regex("(?i)\\b(arriv\\w*|pour\\w*|splash\\w*|run\\w*|jump\\w*|fall\\w*|boil\\w*|sizzl\\w*|dance\\w*|throw\\w*|wave\\w*|rush\\w*|speed\\w*|train passes|steam\\w*|flip\\w*|toss\\w*|drop\\w*)\\b")
    private val PHOTO = Regex("(?i)\\b(board|sign|signboard|name ?plate|menu|label|poster|notice|map|logo|certificate|price list|ticket)\\b")
    private val SELF = Regex("(?i)(\\b(i am|i'm|i was|my|me|welcome|hello|namaste|join me|with me)\\b|আমি|मैं|मेरा|नमस्ते|নমস্কার)")
    private val CLOSE_WORDS = Regex("(?i)\\b(detail\\w*|close|texture|ingredient\\w*|spice\\w*|button\\w*|screen|wheel\\w*|hand\\w*|face|food|dish|plate|bowl|cup|tea|coin|flower\\w*)\\b")

    fun kind(topic: String): TopicKind {
        val t = topic.lowercase()
        return when {
            Regex("recipe|cook|bake|soup|curry|dish|kitchen|রান্না|रेसिपी|बनाने").containsMatchIn(t) -> TopicKind.RECIPE
            Regex("review|unbox|vs\\b|compare|gadget|phone|laptop|product").containsMatchIn(t) -> TopicKind.REVIEW
            Regex("wedding|birthday|festival|puja|pujo|pandal|aarti|dhak|ashtami|saptami|navami|dashami|sandhi|live event|event|match|concert|party|function|mela|fair").containsMatchIn(t) -> TopicKind.EVENT
            Regex("how to|explain|learn|lesson|tutorial|class|teach|what is").containsMatchIn(t) -> TopicKind.TEACH
            Regex("platform|station|temple|beach|market|city|village|fort|park|river|museum|i am at|i'm at|visit|trip|tour|railway").containsMatchIn(t) -> TopicKind.PLACE
            else -> TopicKind.GENERAL
        }
    }

    /** Scenes that get a camera task: all except the CTA outro (last of 2+). */
    fun shootable(scenes: List<ScriptScene>): List<ScriptScene> {
        val ordered = scenes.sortedBy { it.order }
        return if (ordered.size > 1) ordered.dropLast(1) else ordered
    }

    /** Phone-only plan: wide opener, then medium / close variety, slow motion for action, selfie for "I / me". */
    fun offline(topic: String, scenes: List<ScriptScene>): List<ShotSpec> {
        val k = kind(topic)
        val list = shootable(scenes)
        return list.mapIndexed { i, s ->
            val text = listOf(s.visualDescription, s.bRollSuggestion, s.cameraDirection, s.narration).joinToString(" ")
            val idea = listOf(s.visualDescription, s.bRollSuggestion, s.cameraDirection).firstOrNull { it.isNotBlank() }
                ?: s.onScreenText.ifBlank { s.narration.take(90) }
            val secs = ((s.durationMs / 1000).toInt() + 1).coerceIn(3, 8)
            val selfie = (i == 0 && k in setOf(TopicKind.PLACE, TopicKind.EVENT) && SELF.containsMatchIn(s.narration)) ||
                (i == list.lastIndex && list.size > 2 && k in setOf(TopicKind.REVIEW, TopicKind.TEACH))
            when {
                selfie -> ShotSpec(s.sceneId, "Talk to the camera: \"${s.narration.take(80)}\" - keep the place behind you",
                    Framing.SELFIE, true, secs, Lens.FRONT, Movement.STATIC)
                i == 0 -> ShotSpec(s.sceneId, "Opening wide view: $idea",
                    Framing.WIDE, true, secs.coerceAtLeast(5), if (k == TopicKind.RECIPE || k == TopicKind.REVIEW) Lens.MAIN else Lens.ULTRA_WIDE,
                    if (k == TopicKind.RECIPE || k == TopicKind.REVIEW) Movement.STATIC else Movement.PAN)
                PHOTO.containsMatchIn(text) -> ShotSpec(s.sceneId, "Photo, straight and sharp: $idea", Framing.MEDIUM, false, 0, Lens.MAIN)
                SLOW.containsMatchIn(text) -> ShotSpec(s.sceneId, "Slow motion - start before the action happens: $idea",
                    Framing.MEDIUM, true, secs.coerceAtMost(4), Lens.MAIN, Movement.STATIC, 60, slowMotion = true)
                k == TopicKind.RECIPE || CLOSE_WORDS.containsMatchIn(text) -> ShotSpec(s.sceneId, "Close-up, fill the frame: $idea",
                    Framing.CLOSE, true, secs.coerceAtMost(5), Lens.TELE_2, Movement.STATIC, 60)
                i % 2 == 0 -> ShotSpec(s.sceneId, "Medium shot: $idea", Framing.MEDIUM, true, secs, Lens.MAIN, Movement.FOLLOW)
                else -> ShotSpec(s.sceneId, "Show the details: $idea", Framing.CLOSE, true, secs.coerceAtMost(5), Lens.TELE_2, Movement.STATIC)
            }
        }
    }

    fun prompt(topic: String, scenes: List<ScriptScene>, language: String) = buildString {
        append("You are a film director planning a phone shoot for a vertical social-media video. The creator is on location and films each scene themselves.\n")
        append("Topic: ").append(topic.take(400)).append('\n')
        append("Write the camera instruction text in $language (short, practical, max 20 words).\n")
        append("Scenes (number: voice-over):\n")
        shootable(scenes).forEachIndexed { i, s -> append(i + 1).append(": ").append(s.narration.take(220)).append('\n') }
        append("\nReply ONLY with a JSON array, one object per scene, in order: ")
        append("{\"scene\":1,\"instruction\":\"what to film and how\",\"framing\":\"WIDE|MEDIUM|CLOSE|EXTREME_CLOSE|SELFIE|OVER_SHOULDER\",")
        append("\"video\":true,\"seconds\":3-8,\"lens\":\"ULTRA_WIDE|MAIN|TELE_2|TELE_3|FRONT\",\"movement\":\"STATIC|PAN|TILT|WALK|FOLLOW|ORBIT\",")
        append("\"fps\":30 or 60,\"slow_motion\":true only for fast action (pouring, train arriving, jumping),\"uhd\":true only for big scenic views}. ")
        append("Start with a WIDE establishing shot, vary framing (wide -> medium -> close), use photos for signs/boards/menus, SELFIE with FRONT lens when the creator speaks about themselves. ")
        append("Never ask to film private documents, number plates up close, or people who did not agree.")
    }

    fun parse(text: String, scenes: List<ScriptScene>): List<ShotSpec>? = runCatching {
        val t = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val arr = JSONArray(t.substring(t.indexOf('['), t.lastIndexOf(']') + 1))
        val list = shootable(scenes)
        val fallback = offline("", scenes).associateBy { it.sceneId }
        val objects = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
        val numbered = objects.any { it.has("scene") }
        val out = list.mapIndexed { i, s ->
            val o = if (numbered) objects.firstOrNull { it.optInt("scene") == i + 1 } else objects.getOrNull(i)
            if (o == null) fallback.getValue(s.sceneId) else spec(o, s.sceneId, fallback.getValue(s.sceneId))
        }
        out.takeIf { it.isNotEmpty() && objects.isNotEmpty() }
    }.getOrNull()

    private fun spec(o: JSONObject, sceneId: String, fb: ShotSpec): ShotSpec {
        fun <E : Enum<E>> enumOf(values: Array<E>, key: String, def: E): E =
            values.firstOrNull { it.name.equals(o.optString(key).trim().replace(' ', '_'), ignoreCase = true) } ?: def
        val video = if (o.has("video")) o.optBoolean("video", true) else fb.video
        val framing = enumOf(Framing.values(), "framing", fb.framing)
        val lens = enumOf(Lens.values(), "lens", if (framing == Framing.SELFIE) Lens.FRONT else fb.lens)
        val slow = video && o.optBoolean("slow_motion", false)
        return ShotSpec(
            sceneId = sceneId,
            instruction = o.optString("instruction").trim().ifBlank { fb.instruction }.take(200),
            framing = framing,
            video = video,
            seconds = if (!video) 0 else o.optInt("seconds", fb.seconds).coerceIn(2, 12),
            lens = lens,
            movement = enumOf(Movement.values(), "movement", fb.movement),
            fps = if (slow) 60 else if (o.optInt("fps", 30) >= 60) 60 else 30,
            slowMotion = slow,
            uhd = video && o.optBoolean("uhd", false),
            stabilize = true
        )
    }

    /** Gemini first (all saved keys), then the phone-only plan. Blocking - call off the main thread. */
    fun make(topic: String, scenes: List<ScriptScene>, language: String, keys: List<String>): Pair<List<ShotSpec>, Boolean> {
        if (shootable(scenes).isEmpty()) return emptyList<ShotSpec>() to false
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt(topic, scenes, language))))))
            .put("generationConfig", JSONObject().put("temperature", 0.5).put("responseMimeType", "application/json"))
            .toString()
        for (key in keys.take(4)) for (model in listOf("gemini-flash-latest", "gemini-flash-lite-latest")) {
            val plan = runCatching { parse(extract(post(model, key, body)), scenes) }.getOrNull()
            if (plan != null) return plan to true
        }
        return offline(topic, scenes) to false
    }

    private fun extract(raw: String): String = runCatching {
        val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
    }.getOrDefault("")

    private fun post(model: String, key: String, body: String): String {
        val c = java.net.URI("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").toURL().openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 8_000; c.readTimeout = 30_000
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            check(c.responseCode in 200..299) { "HTTP ${c.responseCode}" }
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }

    /** Playback speed for a slow-motion clip recorded at [recordedFps] (smooth only when filmed fast). */
    fun slowSpeed(recordedFps: Int): Float = when {
        recordedFps >= 110 -> 0.25f
        recordedFps >= 50 -> 0.5f
        else -> 0.7f
    }
}
