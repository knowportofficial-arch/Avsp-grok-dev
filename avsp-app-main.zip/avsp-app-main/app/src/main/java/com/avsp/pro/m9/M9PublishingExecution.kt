﻿package com.avsp.pro.m9

/**
 * M9.9
 *
 * Execution orchestration after the M9.8 local preflight gate.
 *
 * This module does NOT:
 * - launch OAuth
 * - exchange tokens
 * - refresh tokens
 * - transmit credentials
 * - perform real external uploads
 * - claim external publication
 *
 * It delegates provider execution to the existing M9 executor.
 */
enum class M9ExecutionStatus {
    EXECUTED,
    BLOCKED,
    FAILED
}

data class M9PlatformExecutionResult(
    val platform: M9Platform,
    val status: M9ExecutionStatus,
    val jobStatus: M9Status?,
    val providerResult: M9PublishResult?,
    val message: String
)

data class M9PublishingExecutionResult(
    val projectId: String,
    val jobId: String,
    val status: M9ExecutionStatus,
    val platforms: List<M9PlatformExecutionResult>,
    val executedPlatforms: List<M9Platform>,
    val failedPlatforms: List<M9Platform>,
    val blockedPlatforms: List<M9Platform>,
    val message: String
)

object M9PublishingExecution {

    fun execute(
        job: M9Job,
        configurations: Map<String, M9ProviderAuthConfiguration>,
        credentialStore: M9CredentialStore
    ): M9PublishingExecutionResult {

        val preflight =
            M9PublishingPreflight.evaluate(
                job = job,
                configurations = configurations,
                credentialStore = credentialStore
            )

        if (preflight.status != M9PreflightStatus.READY) {

            val blocked =
                preflight.blockedPlatforms
                    .distinct()
                    .sortedBy { it.name }

            val blockedResults =
                blocked.map { platform ->
                    M9PlatformExecutionResult(
                        platform = platform,
                        status = M9ExecutionStatus.BLOCKED,
                        jobStatus = job.status,
                        providerResult = null,
                        message = "Platform blocked by M9.8 preflight."
                    )
                }

            return M9PublishingExecutionResult(
                projectId = job.projectId,
                jobId = job.jobId,
                status = M9ExecutionStatus.BLOCKED,
                platforms = blockedResults,
                executedPlatforms = emptyList(),
                failedPlatforms = emptyList(),
                blockedPlatforms = blocked,
                message = preflight.message
            )
        }

        val selectedPlatforms =
            job.platforms
                .distinct()
                .sortedBy { it.name }

        val results =
            mutableListOf<M9PlatformExecutionResult>()

        for (platform in selectedPlatforms) {

            val providerId =
                M9ProviderId.valueOf(platform.name)

            try {

                val execution =
                    M9PublishingExecutor.execute(
                        job = job,
                        provider = providerId
                    )

                if (execution.publishResult.realOperationPerformed) {
                    results += M9PlatformExecutionResult(
                        platform = platform,
                        status = M9ExecutionStatus.EXECUTED,
                        jobStatus = execution.jobStatus,
                        providerResult = execution.publishResult,
                        message = execution.publishResult.message
                    )
                }

                if (!execution.publishResult.realOperationPerformed) {
                    results += M9PlatformExecutionResult(
                        platform = platform,
                        status = M9ExecutionStatus.FAILED,
                        jobStatus = execution.jobStatus,
                        providerResult = execution.publishResult,
                        message = execution.publishResult.message
                    )
                }

            } catch (error: Exception) {

                results += M9PlatformExecutionResult(
                    platform = platform,
                    status = M9ExecutionStatus.FAILED,
                    jobStatus = job.status,
                    providerResult = null,
                    message = error.message ?: "Provider execution failed."
                )
            }
        }

        val executed =
            results
                .filter { it.status == M9ExecutionStatus.EXECUTED }
                .map { it.platform }
                .distinct()
                .sortedBy { it.name }

        val failed =
            results
                .filter { it.status == M9ExecutionStatus.FAILED }
                .map { it.platform }
                .distinct()
                .sortedBy { it.name }

        val blocked =
            results
                .filter { it.status == M9ExecutionStatus.BLOCKED }
                .map { it.platform }
                .distinct()
                .sortedBy { it.name }

        var overallStatus = M9ExecutionStatus.FAILED

        if (executed.isNotEmpty()) {
            overallStatus = M9ExecutionStatus.EXECUTED
        }

        if (executed.isEmpty() && failed.isEmpty() && blocked.isNotEmpty()) {
            overallStatus = M9ExecutionStatus.BLOCKED
        }

        var message = "No provider execution succeeded."

        if (executed.isNotEmpty() && failed.isEmpty() && blocked.isEmpty()) {
            message = "Provider execution completed without claiming external publication."
        }

        if (executed.isNotEmpty() && (failed.isNotEmpty() || blocked.isNotEmpty())) {
            message = "Execution completed with partial provider results."
        }

        return M9PublishingExecutionResult(
            projectId = job.projectId,
            jobId = job.jobId,
            status = overallStatus,
            platforms = results.sortedBy { it.platform.name },
            executedPlatforms = executed,
            failedPlatforms = failed,
            blockedPlatforms = blocked,
            message = message
        )
    }
}
