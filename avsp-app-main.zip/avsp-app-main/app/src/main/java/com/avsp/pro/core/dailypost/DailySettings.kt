package com.avsp.pro.core.dailypost

import android.content.Context
import android.content.SharedPreferences

/** P11: Daily Post choices kept on the phone (weather city). */
object DailySettings {
    @Volatile private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs == null) prefs = context.applicationContext.getSharedPreferences("avsp_daily", Context.MODE_PRIVATE)
    }

    fun city(): DailyTopics.City {
        val p = prefs ?: return DailyTopics.DEFAULT_CITY
        val name = p.getString("city_name", null) ?: return DailyTopics.DEFAULT_CITY
        return DailyTopics.City(name, p.getFloat("city_lat", 0f).toDouble(), p.getFloat("city_lon", 0f).toDouble())
    }

    fun setCity(c: DailyTopics.City) {
        prefs?.edit()?.putString("city_name", c.name)?.putFloat("city_lat", c.lat.toFloat())?.putFloat("city_lon", c.lon.toFloat())?.apply()
    }
}
