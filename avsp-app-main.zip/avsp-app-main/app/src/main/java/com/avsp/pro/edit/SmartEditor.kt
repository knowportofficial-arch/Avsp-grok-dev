package com.avsp.pro.edit

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.avsp.pro.video.engine.PolishPlanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * P12 SMART EDIT for a video the user gives (talking video, vlog, lecture…):
 *   1. take the sound out of the video, find where someone speaks
 *   2. read the words (offline recogniser) with their times
 *   3. score the picture (dark / blurry / frozen / shaky)
 *   4. keep the speech, cut dead air, long pauses, fillers and retakes
 *   5. render the cut video with the ORIGINAL voice and captions in sync
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class SmartEditor(private val context: Context, private val online: GeminiTranscriber? = null) {

    data class Analysis(
        val durationMs: Long,
        val speech: List<SpeechSegmenter.Segment>,
        val heard: List<EditPlanner.Heard>,
        val quality: List<ClipQuality.Score>,
        val keeps: List<EditPlanner.Keep>,
        val note: String?,
        val voiceGain: Float = 1f
    ) {
        val editedMs get() = keeps.sumOf { it.durationMs }
        val transcript get() = heard.joinToString(" ") { it.text }
    }

    data class Caption(val startMs: Long, val endMs: Long, val text: String)

    /** Cut times on the edited timeline (between kept parts). */
    fun cuts(a: Analysis): List<Long> {
        var t = 0L
        return a.keeps.dropLast(1).map { k -> t += k.durationMs; t }
    }

    /** Spoken parts on the edited timeline (for ducking the music). */
    fun speechOnEdit(a: Analysis): List<LongRange> {
        val out = mutableListOf<LongRange>()
        var t = 0L
        for (k in a.keeps) {
            for (s in a.speech) {
                val from = maxOf(s.startMs, k.startMs); val to = minOf(s.endMs, k.endMs)
                if (to > from) out += (t + from - k.startMs)..(t + to - k.startMs)
            }
            t += k.durationMs
        }
        return out
    }

    suspend fun analyse(uri: Uri, language: String, onStep: (String) -> Unit = {}, targetMs: Long? = null): Analysis = withContext(Dispatchers.IO) {
        val duration = MediaAnalysis.durationMs(context, uri)
        require(duration > 0) { "Could not read this video" }
        onStep("Listening to the video…")
        val audio = MediaAnalysis.extractAudio(context, uri)
        val speech = audio?.let { SpeechSegmenter.segments(SpeechSegmenter.frameLevels(it.pcm, it.sampleRate)) }.orEmpty()
        onStep("Checking the picture…")
        val quality = runCatching { ClipQuality.score(MediaAnalysis.sampleFrames(context, uri, duration)) }.getOrDefault(emptyList())
        var note: String? = null
        var heard = emptyList<EditPlanner.Heard>()
        if (audio != null && speech.isNotEmpty()) {
            onStep("Reading the words…")
            val r = Transcriber(context, online).transcribe(audio, speech, language)
            heard = r.heard
            note = r.note
        }
        val keeps = when {
            speech.isNotEmpty() -> EditPlanner.talkingCut(speech, duration, heard, quality)
            else -> {
                note = (note ?: "") + " No speech found - kept the best-looking part."
                listOf(EditPlanner.bestWindow(quality, duration, minOf(duration, 30_000)))
            }
        }.ifEmpty { listOf(EditPlanner.Keep(0, duration)) }.let { k ->
            // P18: "make a short" - the best 30 / 60 s of the cleaned video.
            if (targetMs != null && k.sumOf { it.durationMs } > targetMs) {
                onStep("Picking the best ${targetMs / 1000} s…")
                EditPlanner.highlight(k, targetMs, heard, quality)
            } else k
        }
        val gain = audio?.let { SoundBed.voiceGain(it.pcm, it.sampleRate, speech) } ?: 1f
        Analysis(duration, speech, heard, quality, keeps, note?.trim(), gain)
    }

    /** Captions on the EDITED timeline: each heard piece split into short chunks. */
    fun captions(a: Analysis): List<Caption> = a.heard.flatMap { h ->
        val start = EditPlanner.mapTime(a.keeps, h.startMs) ?: EditPlanner.mapTime(a.keeps, h.startMs + 200) ?: return@flatMap emptyList()
        val dur = (h.endMs - h.startMs).coerceAtLeast(400)
        PolishPlanner.chunks(h.text, dur).map { c -> Caption(start + c.startMs, start + c.endMs, c.text) }
    }

    /** Renders the kept parts (picture + original sound) with captions, at [width] x [height]. */
    suspend fun render(uri: Uri, a: Analysis, width: Int, height: Int, output: File, hook: ThumbnailText.Line? = null): File {
        val caps = captions(a)
        // P14: voice levelled to a steady loudness (same gain for every part, so no jumps).
        fun gainProcessor() = androidx.media3.common.audio.ChannelMixingAudioProcessor().apply {
            putChannelMixingMatrix(androidx.media3.common.audio.ChannelMixingMatrix.create(1, 1).scaleBy(a.voiceGain))
            putChannelMixingMatrix(androidx.media3.common.audio.ChannelMixingMatrix.create(2, 2).scaleBy(a.voiceGain))
        }
        val items = a.keeps.mapIndexed { i, k ->
            val item = MediaItem.Builder().setUri(uri)
                .setClippingConfiguration(MediaItem.ClippingConfiguration.Builder().setStartPositionMs(k.startMs).setEndPositionMs(k.endMs).build())
                .build()
            val effects = mutableListOf<androidx.media3.common.Effect>(
                Presentation.createForWidthAndHeight(width, height, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
            )
            // P14: jump cuts hidden by alternating a gentle punch-in (100 % / 110 %).
            if (i % 2 == 1) effects += androidx.media3.effect.ScaleAndRotateTransformation.Builder().setScale(1.1f, 1.1f).build()
            if (caps.isNotEmpty() || hook != null) effects += OverlayEffect(listOf(CaptionTrackOverlay(caps, width, height, hook)))
            val audio = if (kotlin.math.abs(a.voiceGain - 1f) > 0.05f) listOf<androidx.media3.common.audio.AudioProcessor>(gainProcessor()) else emptyList()
            EditedMediaItem.Builder(item).setEffects(Effects(audio, effects)).build()
        }
        val sequences = mutableListOf(EditedMediaItemSequence.Builder(items).build())
        // P14: quiet original music ducked under the voice + a whoosh on every cut (made on the phone).
        if (a.editedMs in 1..600_000) runCatching {
            val bed = File(output.parentFile, "smart_edit_bed.wav")
            bed.parentFile?.mkdirs()
            bed.writeBytes(SoundBed.wav(SoundBed.bed(a.editedMs, speechOnEdit(a), cuts(a))))
            sequences += EditedMediaItemSequence.Builder(listOf(EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(bed))).build())).build()
        }
        val composition = Composition.Builder(sequences).build()
        output.parentFile?.mkdirs()
        if (output.exists()) output.delete()
        val main = Handler(Looper.getMainLooper())
        suspendCancellableCoroutine<ExportResult> { cont ->
            main.post {
                try {
                    Transformer.Builder(context)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .setAudioMimeType(MimeTypes.AUDIO_AAC)
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) { if (cont.isActive) cont.resume(exportResult) }
                            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                if (cont.isActive) cont.resumeWithException(exportException)
                            }
                        })
                        .build()
                        .start(composition, output.absolutePath)
                } catch (t: Throwable) {
                    if (cont.isActive) cont.resumeWithException(t)
                }
            }
        }
        return output
    }
}

/**
 * Captions on the edited video's own clock (Media3 gives overlays whole-video
 * time). P14: word-by-word highlight (the word being spoken in yellow), placed
 * inside the social-media safe zone (above the Reels/Shorts buttons), and a
 * bold hook title for the first 2.2 s.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class CaptionTrackOverlay(
    private val captions: List<SmartEditor.Caption>,
    private val width: Int,
    private val height: Int,
    private val hook: ThumbnailText.Line? = null
) : BitmapOverlay() {
    private val timed = captions.map { c -> c to SoundBed.wordTimes(c.text, c.startMs, c.endMs) }
    private var lastKey: String? = "\u0000"
    private var last: Bitmap? = null

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000
        val cap = timed.firstOrNull { ms >= it.first.startMs && ms < it.first.endMs }
        val word = cap?.second?.indexOfFirst { ms >= it.second && ms < it.third } ?: -1
        val showHook = hook != null && ms < HOOK_MS
        val key = "${cap?.first?.startMs}|$word|$showHook"
        last?.let { if (key == lastKey) return it }
        val b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        if (showHook) drawHook(c, hook!!)
        if (cap != null) drawCaption(c, cap.second.map { it.first }, word)
        lastKey = key
        last = b
        return b
    }

    private fun drawCaption(c: Canvas, words: List<String>, current: Int) {
        val u = width / 1080f
        val text = android.text.SpannableStringBuilder()
        words.forEachIndexed { i, w ->
            if (i > 0) text.append(' ')
            val st = text.length
            text.append(w)
            if (i == current) text.setSpan(android.text.style.ForegroundColorSpan(Color.rgb(255, 214, 0)), st, text.length, 0)
        }
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; textSize = 66f * u; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val maxW = (width - 160f * u).toInt()
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, tp, maxW).setAlignment(Layout.Alignment.ALIGN_CENTER).setMaxLines(3).build()
        var lw = 0f
        for (i in 0 until layout.lineCount) lw = maxOf(lw, layout.getLineWidth(i))
        val top = height * CAPTION_TOP
        val box = RectF((width - lw) / 2f - 34f * u, top, (width + lw) / 2f + 34f * u, top + layout.height + 44f * u)
        c.drawRoundRect(box, 28f * u, 28f * u, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(200, 12, 12, 12) })
        c.save(); c.translate((width - maxW) / 2f, top + 22f * u); layout.draw(c); c.restore()
    }

    private fun drawHook(c: Canvas, line: ThumbnailText.Line) {
        val u = minOf(width, height) / 1080f
        val text = android.text.SpannableStringBuilder()
        line.words.forEachIndexed { i, w ->
            if (i > 0) text.append(' ')
            val st = text.length
            text.append(w)
            if (i == line.highlight) text.setSpan(android.text.style.ForegroundColorSpan(Color.rgb(255, 214, 0)), st, text.length, 0)
        }
        val size = 96f * u * (if (text.length > 26) 0.82f else 1f)
        val maxW = (width * 0.84f).toInt()
        fun layout(p: TextPaint) = StaticLayout.Builder.obtain(text, 0, text.length, p, maxW).setAlignment(Layout.Alignment.ALIGN_CENTER).setMaxLines(3).build()
        val fill = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = size; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val stroke = TextPaint(fill).apply { style = Paint.Style.STROKE; strokeWidth = size * 0.13f; color = Color.BLACK; strokeJoin = Paint.Join.ROUND }
        c.save(); c.translate((width - maxW) / 2f, height * 0.14f); layout(stroke).draw(c); layout(fill).draw(c); c.restore()
    }

    companion object {
        const val HOOK_MS = 2_200L
        /** Top of the caption box: inside the safe zone (Reels UI covers the bottom ~35 %). */
        const val CAPTION_TOP = 0.58f
    }
}
