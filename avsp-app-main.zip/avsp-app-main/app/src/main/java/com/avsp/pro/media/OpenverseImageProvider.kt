package com.avsp.pro.media

import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URLEncoder

/**
 * P8: free pictures with NO key - Openverse (openly licensed images from
 * Wikimedia Commons, Flickr and more). Used when there is no working Pexels
 * key, so every scene can still get a real picture instead of a title card.
 * Credit (creator + licence) is kept with each picture.
 */
class OpenverseImageProvider(
    private val httpGet: (String) -> String = ::getJson,
    private val download: (String, File) -> Unit = ::downloadTo
) {
    data class Picture(
        val id: String,
        val url: String,
        val width: Int,
        val height: Int,
        val creator: String,
        val license: String
    ) {
        val credit: String get() = when (license) {
            "pixabay" -> "${creator.ifBlank { "Pixabay" }} (Pixabay License)"
            "unsplash" -> "${creator.ifBlank { "Unsplash" }} (Unsplash License)"
            else -> listOf(creator.ifBlank { "Unknown" }, "CC ${license.uppercase()}").joinToString(" · ")
        }
    }

    fun search(query: String, portrait: Boolean): Picture? = candidates(query, portrait).firstOrNull()

    /**
     * Best matches first: pictures whose title/tags share the most words with the query.
     * P8.2: tries strict (commercial licence, phone shape, photographs) first, then
     * photographs of any shape, then any category - most Wikimedia Commons pictures
     * (places, towns, landmarks) carry no "photograph" category and were missed.
     * Throws only if every request failed, so the caller can log why.
     */
    fun candidates(query: String, portrait: Boolean): List<Picture> {
        if (query.isBlank()) return emptyList()
        val q = URLEncoder.encode(query.take(80), "UTF-8")
        val aspect = if (portrait) "tall" else "wide"
        val base = "https://api.openverse.org/v1/images/?q=$q&page_size=20&mature=false"
        val urls = listOf(
            "$base&category=photograph&license_type=commercial&aspect_ratio=$aspect",
            "$base&category=photograph",
            base
        )
        var lastError: Throwable? = null
        var anyOk = false
        for (u in urls) {
            val raw = try { httpGet(u) } catch (e: Exception) {
                lastError = e
                if (e.message?.contains("429") == true) throw e   // rate limited: caller waits
                continue
            }
            anyOk = true
            val found = pickAll(raw, query)
            if (found.isNotEmpty()) return found
        }
        if (!anyOk && lastError != null) throw lastError
        return emptyList()
    }

    internal fun pick(raw: String): Picture? = pickAll(raw, "").firstOrNull()

    internal fun pickAll(raw: String, query: String): List<Picture> {
        val words = query.lowercase().split(Regex("""[^\p{L}\p{N}]+""")).filter { it.length > 2 }.toSet()
        val results = JSONObject(raw).optJSONArray("results") ?: return emptyList()
        val out = mutableListOf<Pair<Int, Picture>>()
        for (i in 0 until results.length()) {
            val r = results.getJSONObject(i)
            val url = r.optString("url")
            val w = r.optInt("width"); val h = r.optInt("height")
            if (!url.startsWith("https://")) continue
            if (url.endsWith(".svg", ignoreCase = true) || url.endsWith(".gif", ignoreCase = true)) continue
            if (w in 1 until 600 || h in 1 until 600) continue
            val text = buildString {
                append(r.optString("title").lowercase())
                val tags = r.optJSONArray("tags")
                if (tags != null) for (t in 0 until tags.length()) append(' ').append(tags.optJSONObject(t)?.optString("name").orEmpty().lowercase())
            }
            val score = words.count { text.contains(it) } * 100 - i   // relevance first, then Openverse order
            out += score to Picture(r.optString("id"), url, w, h, r.optString("creator"), r.optString("license"))
        }
        val best = out.sortedByDescending { it.first }
        // With a query, drop results that match none of its words (unrelated pictures look wrong).
        return (if (words.isNotEmpty()) best.filter { it.first > 0 } else best).map { it.second }
    }

    fun fetch(p: Picture, target: File): File {
        target.parentFile?.mkdirs()
        val tmp = File(target.parentFile, target.name + ".part")
        download(p.url, tmp)
        check(tmp.exists() && tmp.length() > 5_000) { "Picture download failed" }
        // Keep pictures phone-sized (max 2160 px) so rendering stays fast.
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(tmp.absolutePath, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 2160) sample *= 2
        val bmp = android.graphics.BitmapFactory.decodeFile(tmp.absolutePath, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
            ?: error("Picture could not be decoded")
        target.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
        bmp.recycle()
        tmp.delete()
        return target
    }

    companion object {
        private fun getJson(url: String): String {
            val c = java.net.URI(url).toURL().openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 10_000
                c.readTimeout = 20_000
                c.setRequestProperty("User-Agent", "AVSP/1.0 (Android video studio)")
                check(c.responseCode in 200..299) { "Openverse HTTP ${c.responseCode}" }
                return c.inputStream.bufferedReader().use { it.readText() }
            } finally {
                c.disconnect()
            }
        }

        private fun downloadTo(url: String, target: File) {
            var current = url
            repeat(4) {
                val c = java.net.URI(current).toURL().openConnection() as HttpURLConnection
                try {
                    c.connectTimeout = 10_000
                    c.readTimeout = 30_000
                    c.instanceFollowRedirects = false
                    c.setRequestProperty("User-Agent", "AVSP/1.0 (Android video studio)")
                    val code = c.responseCode
                    if (code in 300..399) { current = c.getHeaderField("Location") ?: error("Redirect without location"); return@repeat }
                    check(code in 200..299) { "Download HTTP $code" }
                    check(c.contentLengthLong <= 15_000_000L) { "Picture too large" }
                    c.inputStream.use { input -> target.outputStream().use { input.copyTo(it) } }
                    return
                } finally {
                    c.disconnect()
                }
            }
            error("Too many redirects")
        }
    }
}
