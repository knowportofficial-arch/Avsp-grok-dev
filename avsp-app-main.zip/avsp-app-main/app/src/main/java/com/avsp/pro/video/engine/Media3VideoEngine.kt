package com.avsp.pro.video.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.SpannableString
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextOverlay
import com.avsp.pro.video.engine.TimedTextOverlay
import com.avsp.pro.video.engine.TimedEmojiOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.avsp.pro.core.integration.ProjectPaths
import com.avsp.pro.storage.AvspStorage
import com.avsp.pro.storage.StorageArea
import com.avsp.pro.video.contract.VideoRenderPlan
import com.avsp.pro.video.contract.VideoRenderResult
import com.avsp.pro.video.validation.VideoValidator
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

@OptIn(UnstableApi::class)
class Media3VideoEngine(
    private val context: Context,
    private val storage: AvspStorage
) : VideoEngine {
    private val progress = MutableSharedFlow<Int>(replay = 1, onBufferOverflow = BufferOverflow.DROP_OLDEST)
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var transformer: Transformer? = null
    @Volatile private var cancelled = false

    override fun observeProgress(): Flow<Int> = progress

    override fun cancel() {
        cancelled = true
        mainHandler.post {
            transformer?.cancel()
        }
    }

    override suspend fun render(plan: VideoRenderPlan): VideoRenderResult {
        val validation = VideoValidator.validatePlan(plan)
        require(validation.isValid) { validation.errors.joinToString("; ") }
        cancelled = false
        progress.emit(0)
        storage.ensureProjectLayout(plan.projectId)

        val placeholder = createPlaceholder(plan)
        val videoItems = mutableListOf<EditedMediaItem>()
        val usedWindows = mutableMapOf<String, MutableList<com.avsp.pro.edit.EditPlanner.Keep>>()
        val cardBitmaps = plan.scenes.mapNotNull { scene ->
            scene.cardRelativePath?.let { relative ->
                val file = File(storage.resolve(StorageArea.PROJECT_DATA, relative, plan.projectId))
                android.graphics.BitmapFactory.decodeFile(file.absolutePath)?.let { scene.sceneId to it }
            }
        }.toMap()
        // P18: transition kind per scene, from what the scenes say.
        val ordered = plan.scenes.sortedBy { it.order }
        val kinds = runCatching {
            Transitions.plan(ordered.map { it.narration }, ordered.indexOfFirst { it.isCta }.takeIf { it >= 0 }, ordered.map { it.doodle != null })
        }.getOrDefault(ordered.map { Transitions.Kind.FADE })
        plan.scenes.sortedBy { it.order }.forEach { scene ->
            val kindIndex = ordered.indexOf(scene)
            val kind = if (plan.polish) kinds.getOrElse(kindIndex) { Transitions.Kind.FADE } else Transitions.Kind.FADE
            val nextKind = kinds.getOrElse(kindIndex + 1) { Transitions.Kind.FADE }
            check(!cancelled) { "M4 render cancelled" }
            var visual = scene.visualRelativePath?.let { File(storage.resolve(StorageArea.PROJECT_DATA, it, plan.projectId)) }
                ?.takeIf { it.exists() } ?: placeholder
            var isVideo = scene.visualMimeType?.startsWith("video/") == true
            // P16: an unreadable clip (cut-off download) must not break the whole video - use the plain background.
            if (isVideo && runCatching { inspectSourceDuration(visual) }.isFailure) {
                android.util.Log.w("AVSP", "unreadable clip ${visual.name} - scene ${scene.sceneId} uses the background")
                visual = placeholder; isVideo = false
            }
            val uri = Uri.fromFile(visual)

            // P20: slow motion - a shorter part of the clip is played slower to fill the scene.
            val speed = if (isVideo) scene.speed.coerceIn(0.25f, 1f) else 1f
            val videoPieces = if (isVideo && speed < 0.99f) {
                val sourceDurationMs = inspectSourceDuration(visual)
                val sourceSpan = (scene.durationMs * speed).toLong().coerceAtLeast(1L)
                VideoClipPlanner.slowPieces(
                    VideoClipPlanner.pieces(sourceDurationMs, sourceSpan, bestStart(visual, sourceDurationMs, sourceSpan, usedWindows)),
                    speed, scene.durationMs
                )
            } else if (isVideo) {
                val sourceDurationMs = inspectSourceDuration(visual)
                VideoClipPlanner.pieces(sourceDurationMs, scene.durationMs, bestStart(visual, sourceDurationMs, scene.durationMs, usedWindows))
            } else {
                listOf(VideoClipPlanner.Piece(0L, scene.durationMs, scene.durationMs))
            }

            var pieceOffset = 0L
            val scenePolish = if (plan.polish && (scene.narration.isNotBlank() || scene.isCta)) {
                // Polish is decoration: if it ever fails, render the plain scene instead of failing the video.
                runCatching {
                    PolishPlanner.plan(scene.narration, scene.durationMs, scene.order, plan.scenes.size, scene.isCta, plan.language)
                }.getOrNull()
            } else null
            videoPieces.forEach { piece ->
                val thisOffset = pieceOffset
                pieceOffset += piece.durationMs
                val item = if (isVideo) {
                    MediaItem.Builder()
                        .setUri(uri)
                        .setClippingConfiguration(
                            MediaItem.ClippingConfiguration.Builder()
                                .setStartPositionMs(piece.startMs)
                                .setEndPositionMs(piece.endMs)
                                .build()
                        )
                        .build()
                } else {
                    MediaItem.Builder()
                        .setUri(uri)
                        .setImageDurationMs(piece.durationMs)
                        .build()
                }
                val videoEffects = mutableListOf<androidx.media3.common.Effect>(
                    Presentation.createForWidthAndHeight(
                        plan.width,
                        plan.height,
                        Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
                    )
                )
                val card = cardBitmaps[scene.sceneId]
                val doodle = scene.doodle
                if (doodle != null) {
                    /* P11: paper (card, or the base image itself) + hand-drawn doodle being drawn. */
                    videoEffects += OverlayEffect(
                        listOfNotNull(
                            card?.let { KenBurnsCardOverlay(it, thisOffset, scene.durationMs, piece.durationMs, scene.startMs + thisOffset) },
                            com.avsp.pro.video.doodle.DoodleOverlay(doodle, scene.order * 97 + 13, thisOffset, piece.durationMs, scene.startMs + thisOffset, plan.width, plan.height)
                        )
                    )
                } else if (card != null) {
                    /* P2.2 card; P7: slow zoom so the picture is alive ("auto animation"). */
                    videoEffects += OverlayEffect(
                        listOf(KenBurnsCardOverlay(card, thisOffset, scene.durationMs, piece.durationMs, scene.startMs + thisOffset))
                    )
                } else if (!isVideo && plan.polish) {
                    /* P7: photos get a gentle Ken Burns zoom instead of a frozen still. */
                    val from = thisOffset.toFloat() / scene.durationMs.coerceAtLeast(1)
                    val span = piece.durationMs.toFloat() / scene.durationMs.coerceAtLeast(1)
                    videoEffects += androidx.media3.effect.MatrixTransformation { presentationTimeUs ->
                        val t = Motion.pieceMs(presentationTimeUs, piece.durationMs, scene.startMs + thisOffset)
                        val p = (from + span * (t.toFloat() / piece.durationMs.coerceAtLeast(1))).coerceIn(0f, 1f)
                        // P22.2: every photo moves like a clip - zoom in, pan right, zoom out, pan left (by scene).
                        android.graphics.Matrix().apply {
                            when (scene.order % 4) {
                                0 -> { val z = 1f + 0.12f * p; setScale(z, z) }
                                1 -> { setScale(1.15f, 1.15f); postTranslate(-0.12f + 0.24f * p, 0f) }
                                2 -> { val z = 1.14f - 0.12f * p; setScale(z, z) }
                                else -> { setScale(1.15f, 1.15f); postTranslate(0.12f - 0.24f * p, 0.02f * p) }
                            }
                        }
                    }
                }
                if (kind != Transitions.Kind.FADE && thisOffset == 0L) {
                    /* P18: zoom / slide into this scene (picture only - captions stay put). */
                    val pieceStart = scene.startMs
                    val pieceLen = piece.durationMs
                    videoEffects += androidx.media3.effect.MatrixTransformation { presentationTimeUs ->
                        val t = Motion.pieceMs(presentationTimeUs, pieceLen, pieceStart)
                        val (z, dx) = Transitions.motion(kind, t)
                        android.graphics.Matrix().apply { setScale(z, z); postTranslate(dx, 0f) }
                    }
                }
                if (scenePolish != null) {
                    /* P6: synced captions + emoji + progress bar + border (+ CTA). */
                    videoEffects += OverlayEffect(
                        listOf(
                            PolishOverlay(
                                polish = scenePolish,
                                pieceOffsetMs = thisOffset,
                                pieceDurationMs = piece.durationMs,
                                pieceAbsoluteStartMs = scene.startMs + thisOffset,
                                width = plan.width,
                                height = plan.height
                            )
                        )
                    )
                } else if (card != null) {
                    // card only
                } else if (scene.captions.isNotEmpty()) {
                    videoEffects += OverlayEffect(
                        listOf(TimedTextOverlay(scene.captions))
                    )
                } else {
                    scene.overlayText?.takeIf { it.isNotBlank() }?.let { text ->
                        videoEffects += OverlayEffect(
                            listOf(TextOverlay.createStaticTextOverlay(SpannableString(text)))
                        )
                    }
                }
                if (scenePolish == null && scene.emojis.isNotEmpty()) {
                    videoEffects += OverlayEffect(
                        listOf(TimedEmojiOverlay(scene.emojis))
                    )
                }
                if (plan.polish) {
                    // P10 motion: drifting lights on picture-less cards (under the captions would be nicer,
                    // but on top keeps it one cheap pass) and a short dip-to-black between scenes.
                    runCatching {
                        val motion = mutableListOf<androidx.media3.effect.TextureOverlay>()
                        if (card != null && !scene.isCta && scene.doodle == null) {
                            val glow = (plan.width * 0.9f).toInt()
                            motion += DriftGlowOverlay(scene.order * 2, thisOffset, piece.durationMs, scene.startMs + thisOffset, glow)
                            motion += DriftGlowOverlay(scene.order * 2 + 1, thisOffset, piece.durationMs, scene.startMs + thisOffset, glow, 0.16f)
                        }
                        motion += FadeOverlay(
                            sceneDurationMs = scene.durationMs,
                            pieceOffsetMs = thisOffset,
                            pieceDurationMs = piece.durationMs,
                            pieceAbsoluteStartMs = scene.startMs + thisOffset,
                            width = plan.width,
                            height = plan.height,
                            fadeIn = scene.order > 0 && kind == Transitions.Kind.FADE,
                            fadeOut = scene.order < plan.scenes.size - 1 && nextKind == Transitions.Kind.FADE
                        )
                        videoEffects += OverlayEffect(motion)
                    }
                }
                // P22.1: the channel logo, small, top-left (clear of the Reels/Shorts buttons on the right).
                com.avsp.pro.settings.BrandKit.logoFor(plan.width)?.let { logo ->
                    runCatching {
                        videoEffects += OverlayEffect(listOf(androidx.media3.effect.BitmapOverlay.createStaticBitmapOverlay(
                            logo,
                            androidx.media3.effect.StaticOverlaySettings.Builder()
                                .setAlphaScale(0.85f)
                                .setBackgroundFrameAnchor(-0.80f, 0.86f)
                                .build()
                        )))
                    }
                }
                videoItems += EditedMediaItem.Builder(item)
                    .setFrameRate(plan.fps)
                    .setEffects(Effects(emptyList(), videoEffects))
                    .apply { if (speed < 0.99f) setSpeed(ConstantSpeed(speed)) }
                    .build()
            }
        }
        val audioItems = plan.scenes.sortedBy { it.order }.map { scene ->
            val audio = File(storage.resolve(StorageArea.PROJECT_DATA, scene.audioRelativePath, plan.projectId))
            require(audio.exists()) { "Missing audio: ${scene.audioRelativePath}" }
            EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(audio))).build()
        }

        val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)
        val audioSequence = EditedMediaItemSequence.withAudioFrom(audioItems)

        val compositionSequences = mutableListOf<EditedMediaItemSequence>(
            videoSequence,
            audioSequence
        )

        plan.musicRelativePath
            ?.takeIf { it.isNotBlank() }
            ?.let { musicRelativePath ->
                val music = File(
                    storage.resolve(
                        StorageArea.PROJECT_DATA,
                        musicRelativePath,
                        plan.projectId
                    )
                )
                require(music.exists()) {
            "Missing background music: $musicRelativePath"
        }

                val musicGain = plan.musicGain
                val musicItem = EditedMediaItem.Builder(
                    MediaItem.fromUri(Uri.fromFile(music))
                ).apply {
                    if (kotlin.math.abs(musicGain - 1f) > 0.01f) {
                        val p = androidx.media3.common.audio.ChannelMixingAudioProcessor().apply {
                            putChannelMixingMatrix(androidx.media3.common.audio.ChannelMixingMatrix.create(1, 1).scaleBy(musicGain))
                            putChannelMixingMatrix(androidx.media3.common.audio.ChannelMixingMatrix.create(2, 2).scaleBy(musicGain))
                        }
                        setEffects(Effects(listOf(p), emptyList()))
                    }
                }.build()

                val musicSequence = EditedMediaItemSequence.Builder(
                    listOf(musicItem)
                )
                    .setIsLooping(true)
                    .build()

                compositionSequences += musicSequence
            }

        val composition = Composition.Builder(compositionSequences).build()
        val outputRelative = "${ProjectPaths.VIDEO}/final.mp4"
        val output = File(storage.resolve(StorageArea.PROJECT_DATA, outputRelative, plan.projectId))
        output.parentFile?.mkdirs()
        if (output.exists()) output.delete()

        val result = suspendCancellableCoroutine<ExportResult> { continuation: CancellableContinuation<ExportResult> ->
            val listener = object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    transformer = null
                    if (continuation.isActive) {
                        continuation.resume(exportResult)
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    transformer = null
                    if (continuation.isActive) {
                        continuation.resumeWithException(exportException)
                    }
                }
            }

            mainHandler.post {
                if (cancelled || !continuation.isActive) {
                    return@post
                }
                try {
                    val t = Transformer.Builder(context)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .setAudioMimeType(MimeTypes.AUDIO_AAC)
                        // Never silently change the project-selected output resolution.
                        // If the device cannot encode it, fail explicitly so the user gets
                        // a real M4 error instead of an unexpected fallback canvas.
                        .setEncoderFactory(
                            DefaultEncoderFactory.Builder(context)
                                .setEnableFallback(false)
                                // P22.3 HIGH QUALITY: ~0.18 bits per pixel per frame (1080x1920 @30 = 11 Mbps)
                                .setRequestedVideoEncoderSettings(
                                    androidx.media3.transformer.VideoEncoderSettings.Builder()
                                        .setBitrate(outputBitrate(plan.width, plan.height, plan.fps))
                                        .build()
                                )
                                .build()
                        )
                        .addListener(listener)
                        .build()

                    transformer = t
                    t.start(composition, output.absolutePath)
                } catch (error: Throwable) {
                    transformer = null
                    if (continuation.isActive) {
                        continuation.resumeWithException(error)
                    }
                }
            }
        }
        progress.emit(100)
        val actual = inspectOutput(output)
        val outputValidation = VideoValidator.validateOutput(
            plan.width, plan.height, plan.totalDurationMs,
            actual.width, actual.height, actual.durationMs,
            actual.hasVideo, actual.hasAudio, actual.rotationDegrees
        )
        require(outputValidation.isValid) { outputValidation.errors.joinToString("; ") }
        return VideoRenderResult(
            projectId = plan.projectId,
            outputRelativePath = outputRelative,
            outputAbsolutePath = output.absolutePath,
            durationMs = actual.durationMs,
            width = actual.displayWidth,
            height = actual.displayHeight,
            videoCodec = actual.videoCodec,
            audioCodec = actual.audioCodec,
            status = "SUCCESS"
        )
    }

    /**
     * P13 SMART CLIP: for a clip longer than its scene, play its best-looking
     * part (sharp, well exposed, steady, not frozen) instead of its first
     * seconds; a clip used twice shows a different part the second time.
     */
    private fun bestStart(file: File, sourceMs: Long, targetMs: Long, used: MutableMap<String, MutableList<com.avsp.pro.edit.EditPlanner.Keep>>): Long {
        if (sourceMs <= targetMs) return 0L
        val t0 = System.currentTimeMillis()
        val window = runCatching {
            val quality = qualityCache.getOrPut(file.absolutePath) {
                com.avsp.pro.edit.ClipQuality.score(
                    com.avsp.pro.edit.MediaAnalysis.sampleFrames(context, Uri.fromFile(file), sourceMs, stepMs = maxOf(800L, sourceMs / 24), maxSamples = 24)
                )
            }
            val avoid = used.getOrPut(file.absolutePath) { mutableListOf() }
            com.avsp.pro.edit.EditPlanner.bestWindow(quality, sourceMs, targetMs, edgeMs = 300, avoid = avoid).also { avoid += it }
        }.getOrNull()
        android.util.Log.i("AVSP", "smart clip ${file.name}: ${window?.startMs ?: 0}..${window?.endMs ?: targetMs} of $sourceMs ms in ${System.currentTimeMillis() - t0} ms")
        return window?.startMs ?: 0L
    }

    private val qualityCache = java.util.concurrent.ConcurrentHashMap<String, List<com.avsp.pro.edit.ClipQuality.Score>>()

    private fun inspectSourceDuration(file: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull()
                ?.takeIf { it > 0L }
                ?: error("Unable to determine source video duration: ${file.name}")
        } finally {
            retriever.release()
        }
    }

    private fun createPlaceholder(plan: VideoRenderPlan): File {
        val dir = File(context.cacheDir, "m4")
        dir.mkdirs()
        val file = File(dir, "placeholder_${plan.width}x${plan.height}.png")
        if (file.exists()) return file
        val bitmap = Bitmap.createBitmap(plan.width, plan.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(android.graphics.Color.BLACK)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.WHITE
            textSize = plan.width * 0.055f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("AVSP", plan.width / 2f, plan.height / 2f, paint)
        file.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        bitmap.recycle()
        return file
    }

    private data class OutputInfo(
        val durationMs: Long,
        val width: Int,
        val height: Int,
        val hasVideo: Boolean,
        val hasAudio: Boolean,
        val rotationDegrees: Int,
        val videoCodec: String,
        val audioCodec: String
    ) {
        val displayWidth: Int
            get() = if (rotationDegrees == 90 || rotationDegrees == 270) height else width
        val displayHeight: Int
            get() = if (rotationDegrees == 90 || rotationDegrees == 270) width else height
    }

    private fun inspectOutput(file: File): OutputInfo {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: 0L
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
                ?.toIntOrNull() ?: 0
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
                ?.toIntOrNull() ?: 0
            // Media3 may encode a portrait canvas as width×height in the
            // codec's natural orientation and carry the presentation
            // orientation separately as 90°/270° metadata. Validation must
            // use display dimensions, not raw encoded dimensions.
            val rotationDegrees = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
                ?.toIntOrNull() ?: 0
            val normalizedRotation = ((rotationDegrees % 360) + 360) % 360
            val hasVideo = width > 0 && height > 0
            val hasAudio = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
            val videoCodec = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "unknown"
            val audioCodec = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_MIMETYPE) ?: "unknown"
            OutputInfo(
                durationMs = duration,
                width = width,
                height = height,
                hasVideo = hasVideo,
                hasAudio = hasAudio,
                rotationDegrees = normalizedRotation,
                videoCodec = videoCodec,
                audioCodec = audioCodec
            )
        } finally {
            retriever.release()
        }
    }
}

/** P20: one constant playback speed for a whole clip (slow motion). */
private class ConstantSpeed(private val speed: Float) : androidx.media3.common.audio.SpeedProvider {
    override fun getSpeed(timeUs: Long): Float = speed
    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long = androidx.media3.common.C.TIME_UNSET
}

/** P22.3: target video bitrate for a crisp upload (YouTube re-encodes; give it a clean source). */
internal fun outputBitrate(width: Int, height: Int, fps: Int): Int =
    (width.toLong() * height * fps.coerceIn(24, 60) * 0.18).toLong().coerceIn(4_000_000L, 16_000_000L).toInt()
