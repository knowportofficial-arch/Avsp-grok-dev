package com.avsp.pro.ui.screens.projects

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.background
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.avsp.pro.ui.viewmodel.ManualViewModel
import com.avsp.pro.ui.viewmodel.SceneVisual

private val CTA_PRESETS = listOf(
    "Like, share and follow!",
    "Subscribe for daily updates!",
    "Follow for more!"
)

/** P7 MANUAL MODE: Topic -> Script -> Scenes & pictures -> Video. */
@Composable
fun ManualScreen(projectId: String, viewModel: ManualViewModel, onBack: () -> Unit) {
    val st by viewModel.state.collectAsState()
    val context = LocalContext.current
    LaunchedEffect(projectId) { viewModel.load(projectId) }

    var pickingFor by remember { mutableStateOf<String?>(null) }
    var cameraFor by remember { mutableStateOf<String?>(null) }
    var cameraUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var cameraIsVideo by remember { mutableStateOf(false) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val scene = pickingFor
        if (uri != null && scene != null) {
            val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
            viewModel.chooseVisual(scene, SceneVisual.Picked(uri, mime, fromCamera = false))
        }
        pickingFor = null
    }
    val takePhoto = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val scene = cameraFor; val uri = cameraUri
        if (ok && scene != null && uri != null) viewModel.chooseVisual(scene, SceneVisual.Picked(uri, "image/jpeg", fromCamera = true))
        cameraFor = null
    }
    val takeVideo = rememberLauncherForActivityResult(ActivityResultContracts.CaptureVideo()) { ok ->
        val scene = cameraFor; val uri = cameraUri
        if (ok && scene != null && uri != null) viewModel.chooseVisual(scene, SceneVisual.Picked(uri, "video/mp4", fromCamera = true))
        cameraFor = null
    }
    var askCamera by remember { mutableStateOf<String?>(null) }
    // P23 own voice: microphone permission, then the recording dialog.
    var voiceFor by remember { mutableStateOf<String?>(null) }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val sc = voiceFor; voiceFor = null
        if (granted && sc != null) viewModel.startVoice(sc)
        else if (!granted) android.widget.Toast.makeText(context, "Microphone permission is needed to record your voice", android.widget.Toast.LENGTH_LONG).show()
    }
    // P19: the system camera needs AVSP's camera permission first (without it Android closes the app).
    var pendingShot by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    fun shoot(sceneId: String, video: Boolean) {
        val u = viewModel.newCameraUri(video = video)
        if (u == null) { android.widget.Toast.makeText(context, "Could not prepare a place to save the shot", android.widget.Toast.LENGTH_LONG).show(); return }
        cameraFor = sceneId; cameraUri = u; cameraIsVideo = video
        runCatching { if (video) takeVideo.launch(u) else takePhoto.launch(u) }
            .onFailure { android.widget.Toast.makeText(context, "Camera could not open: ${it.message?.take(80)}", android.widget.Toast.LENGTH_LONG).show(); cameraFor = null }
    }
    val cameraPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val p = pendingShot; pendingShot = null
        if (granted && p != null) shoot(p.first, p.second)
        else if (!granted) android.widget.Toast.makeText(context, "Camera permission is needed to shoot a scene", android.widget.Toast.LENGTH_LONG).show()
    }
    fun shootWithPermission(sceneId: String, video: Boolean) {
        if (androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED) shoot(sceneId, video)
        else { pendingShot = sceneId to video; cameraPermission.launch(android.Manifest.permission.CAMERA) }
    }

    // P20 Plan & shoot: the guided camera walks through the shot list, scene by scene.
    if (st.shooting) {
        val template = remember(st.shots) { viewModel.shootTemplate() }
        if (template != null) {
            androidx.activity.compose.BackHandler { viewModel.stopShooting() }
            com.avsp.pro.m7.capture.camera.guided.GuidedCaptureScreen(
                template = template,
                onFinished = { clips -> viewModel.onShots(clips) },
                onExit = { viewModel.stopShooting() }
            )
            return
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { if (st.step in 2..3 && st.busy == null) viewModel.back() else onBack() }) { Text("← Back") }
            Text("Manual mode", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
        }
        Text(
            listOf("1 Topic", "2 Script", "3 Pictures & clips", "4 Video").mapIndexed { i, s -> if (i + 1 == st.step) "● $s" else s }.joinToString("   "),
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.primary
        )
        st.busy?.let {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Text(it, style = MaterialTheme.typography.bodyMedium)
        }
        st.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }

        when (st.step) {
            1 -> {
                Text("What is the video about?", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Filled in from your sources. Change anything, then write the script.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                OutlinedTextField(
                    value = st.topic,
                    onValueChange = viewModel::setTopic,
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 6,
                    label = { Text("Topic and facts") }
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())) {
                    listOf(0, 30, 60, 90, 180, 300).forEach { s ->
                        FilterChip(selected = st.seconds == s, onClick = { viewModel.setSeconds(s) }, label = { Text(when { s == 0 -> "Auto"; s >= 120 -> "${s / 60} min"; else -> "${s}s" }) })
                    }
                }
                Button(
                    onClick = viewModel::writeScript,
                    enabled = st.busy == null && st.topic.isNotBlank(),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Write script →") }
            }

            2 -> st.script?.let { script ->
                Text("Your script", style = MaterialTheme.typography.titleLarge)
                OutlinedTextField(
                    value = script.title,
                    onValueChange = viewModel::setTitle,
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Title") },
                    singleLine = true
                )
                val ordered = script.scenes.sortedBy { it.order }
                ordered.forEachIndexed { i, scene ->
                    val isIntro = i == 0
                    val isOutro = i == ordered.lastIndex && ordered.size > 1
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                when {
                                    isIntro -> "Intro (hook)"
                                    isOutro -> "Outro: call to action (under 5 s)"
                                    else -> "Scene $i"
                                },
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (isOutro) {
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                                    CTA_PRESETS.take(2).forEach { p ->
                                        FilterChip(selected = scene.narration == p, onClick = { viewModel.setCta(p) }, label = { Text(p, maxLines = 1) })
                                    }
                                }
                                OutlinedTextField(
                                    value = scene.narration,
                                    onValueChange = { viewModel.setCta(it) },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Call to action") },
                                    supportingText = { Text("${scene.narration.split(' ').count { it.isNotBlank() }} words · keep it under 10") }
                                )
                            } else {
                                OutlinedTextField(
                                    value = scene.narration,
                                    onValueChange = { viewModel.editScene(scene.sceneId, narration = it) },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Voice-over") },
                                    minLines = 2
                                )
                                OutlinedTextField(
                                    value = scene.onScreenText,
                                    onValueChange = { viewModel.editScene(scene.sceneId, onScreen = it) },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("On-screen text") },
                                    singleLine = true
                                )
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = viewModel::writeScript, enabled = st.busy == null, modifier = Modifier.weight(1f)) { Text("Rewrite") }
                    Button(onClick = viewModel::toScenes, enabled = st.busy == null, modifier = Modifier.weight(1f)) { Text("Next: pictures & clips →") }
                }
            }

            3 -> st.script?.let { script ->
                Text("Pictures & clips for each scene", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Choose where each scene's picture comes from. \"Auto\" makes an animated title card.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                )
                st.eventLabel?.let { Text(it, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary) }
                PlanAndShootCard(
                    shots = st.shots,
                    byAi = st.shotsByAi,
                    busy = st.busy != null,
                    onPlan = viewModel::planShots,
                    onShoot = viewModel::startShooting
                )
                // P22.4: see each scene's picture before the video is made, and swap the ones that don't fit.
                OutlinedButton(onClick = { viewModel.previewPictures(all = true) }, enabled = st.busy == null, modifier = Modifier.fillMaxWidth()) {
                    Text(if (st.pictures.isEmpty()) "🖼 Show a picture for every scene" else "🖼 Find pictures again for empty scenes")
                }
                st.note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                val shotFor = st.shots.orEmpty().associateBy { it.sceneId }
                val ordered = script.scenes.sortedBy { it.order }
                ordered.forEachIndexed { i, scene ->
                    val isOutro = i == ordered.lastIndex && ordered.size > 1
                    val v = st.visuals[scene.sceneId] ?: SceneVisual.Auto
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                when { i == 0 -> "Intro"; isOutro -> "Outro (CTA)"; else -> "Scene $i" } + " · " + v.label,
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(scene.narration, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                            // P23: say this scene in your own voice (intro / outro especially).
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                if (scene.sceneId in st.ownVoiceScenes) {
                                    Text("🎙 Your own voice", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                    TextButton(onClick = { viewModel.removeMyVoice(scene.sceneId) }) { Text("Use AI voice") }
                                    TextButton(onClick = { voiceFor = scene.sceneId; micPermission.launch(android.Manifest.permission.RECORD_AUDIO) }) { Text("Record again") }
                                } else {
                                    TextButton(onClick = { voiceFor = scene.sceneId; micPermission.launch(android.Manifest.permission.RECORD_AUDIO) }) {
                                        Text(if (i == 0 || isOutro) "🎙 Say it in my voice" else "🎙 My voice")
                                    }
                                }
                            }
                            if (isOutro) {
                                Text("Shows Like • Follow • Share with icons.", style = MaterialTheme.typography.bodySmall)
                            } else {
                                val shot = shotFor[scene.sceneId]
                                if (shot != null) {
                                    Text("🎥 " + shot.summary(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                                    Text(shot.instruction, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
                                } else {
                                    val idea = listOf(scene.visualDescription, scene.bRollSuggestion).firstOrNull { it.isNotBlank() }
                                    idea?.let { Text("Shot idea: $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)) }
                                }
                                if (v == SceneVisual.Stock) ScenePictureRow(
                                    picture = st.pictures[scene.sceneId],
                                    words = scene.bRollSuggestion,
                                    swapping = st.swapping == scene.sceneId,
                                    enabled = st.busy == null && st.swapping == null,
                                    onWords = { viewModel.editScene(scene.sceneId, bRoll = it) },
                                    onAnother = { viewModel.anotherPicture(scene.sceneId) },
                                    onFind = { viewModel.previewPictures(all = false) }
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FilterChip(selected = v == SceneVisual.Stock, onClick = { viewModel.chooseVisual(scene.sceneId, SceneVisual.Stock) }, label = { Text("Free stock") })
                                    FilterChip(selected = v is SceneVisual.Picked && !v.fromCamera, onClick = {
                                        pickingFor = scene.sceneId
                                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                                    }, label = { Text("Phone") })
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    FilterChip(selected = v is SceneVisual.Picked && v.fromCamera, onClick = { askCamera = scene.sceneId }, label = { Text("Camera") })
                                    FilterChip(selected = v == SceneVisual.Auto, onClick = { viewModel.chooseVisual(scene.sceneId, SceneVisual.Auto) }, label = { Text("Auto") })
                                }
                            }
                        }
                    }
                }
                Button(onClick = viewModel::make, enabled = st.busy == null, modifier = Modifier.fillMaxWidth()) { Text("Make video →") }
            }

            else -> {
                val done = st.result
                if (done == null) {
                    Text("Making your video…", style = MaterialTheme.typography.titleLarge)
                    Text("Voice-over, pictures and music are being put together. This takes about a minute.", style = MaterialTheme.typography.bodyMedium)
                } else {
                    Text("Video ready: ${done.title}", style = MaterialTheme.typography.titleLarge)
                    Text("${done.durationMs / 1000}s · ${done.displayName ?: "saved"}", style = MaterialTheme.typography.bodySmall)
                    done.note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                    done.uri?.let { uri ->
                        Button(onClick = {
                            com.avsp.pro.ui.screens.videos.playVideo(context, android.net.Uri.parse(uri))
                        }, modifier = Modifier.fillMaxWidth()) { Text("Play") }
                        PublishKitSection(uri = uri, title = done.title, kit = done.kit, thumbnail = done.thumbnail)
                        com.avsp.pro.ui.screens.publish.SendForApprovalRow(videoUri = uri, project = done.title, title = done.title, kit = done.kit, thumbnail = done.thumbnail, projectId = projectId)
                    }
                    OutlinedButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Back to project") }
                }
            }
        }
    }

    st.voiceTake?.let { take -> OwnVoiceDialog(take, viewModel) }

    askCamera?.let { sceneId ->
        AlertDialog(
            onDismissRequest = { askCamera = null },
            title = { Text("Shoot this scene now?") },
            text = { Text("Your camera opens. Film a short clip (5–10 s) or take a photo for this scene.") },
            confirmButton = {
                TextButton(onClick = {
                    askCamera = null
                    shootWithPermission(sceneId, video = true)
                }) { Text("Video") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = {
                        askCamera = null
                        shootWithPermission(sceneId, video = false)
                    }) { Text("Photo") }
                    TextButton(onClick = { askCamera = null }) { Text("No") }
                }
            }
        )
    }
}

/** P20: "Plan & shoot" - an AI shot list for the script, then the guided camera scene by scene. */
@Composable
private fun PlanAndShootCard(
    shots: List<com.avsp.pro.capture.ShotSpec>?,
    byAi: Boolean,
    busy: Boolean,
    onPlan: () -> Unit,
    onShoot: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🎬 Plan & shoot", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (shots.isNullOrEmpty()) {
                Text(
                    "Get a camera task for every scene - what to film, wide / medium / close, lens (0.5× to 3×), seconds, " +
                        "movement, slow motion - then film them one by one. Scenes you skip are filled from your phone, free pictures or an animated card.",
                    style = MaterialTheme.typography.bodySmall
                )
                Button(onClick = onPlan, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Make shot list") }
            } else {
                val videos = shots.count { it.video }
                val secs = shots.sumOf { it.seconds }
                Text(
                    "${shots.size} shots ($videos video, ${shots.size - videos} photo, about ${secs}s of filming) · " +
                        if (byAi) "planned by Gemini" else "planned on the phone",
                    style = MaterialTheme.typography.bodySmall
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedButton(onClick = onPlan, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Re-plan") }
                    Button(onClick = onShoot, enabled = !busy, modifier = Modifier.weight(1f)) { Text("Start shooting") }
                }
            }
        }
    }
}

/** P22.4: the scene's picture (or clip frame), where it is from, and "Another picture". */
@Composable
private fun ScenePictureRow(
    picture: com.avsp.pro.core.pipeline.AutoProducer.ScenePicture?,
    words: String,
    swapping: Boolean,
    enabled: Boolean,
    onWords: (String) -> Unit,
    onAnother: () -> Unit,
    onFind: () -> Unit
) {
    val bmp by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, picture?.path) {
        value = picture?.let { p ->
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching {
                    val f = java.io.File(p.path)
                    if (p.video) {
                        if (android.os.Build.VERSION.SDK_INT >= 29) android.media.ThumbnailUtils.createVideoThumbnail(f, android.util.Size(360, 640), null)
                        else android.media.MediaMetadataRetriever().let { r -> try { r.setDataSource(f.absolutePath); r.getFrameAtTime(1_000_000) } finally { r.release() } }
                    } else {
                        val o = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        android.graphics.BitmapFactory.decodeFile(f.absolutePath, o)
                        val sample = maxOf(1, maxOf(o.outWidth, o.outHeight) / 640)
                        android.graphics.BitmapFactory.decodeFile(f.absolutePath, android.graphics.BitmapFactory.Options().apply { inSampleSize = sample })
                    }
                }.getOrNull()
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
        androidx.compose.foundation.layout.Box(
            modifier = Modifier.size(width = 72.dp, height = 112.dp)
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = androidx.compose.ui.Alignment.Center
        ) {
            val b = bmp
            when {
                swapping -> androidx.compose.material3.CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                b != null -> androidx.compose.foundation.Image(b.asImageBitmap(), contentDescription = "Scene picture",
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop, modifier = Modifier.fillMaxSize())
                else -> Text(if (picture == null) "No picture yet" else "…", style = MaterialTheme.typography.labelSmall,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(4.dp))
            }
        }
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedTextField(value = words, onValueChange = onWords, singleLine = true,
                label = { Text("Picture search words") }, modifier = Modifier.fillMaxWidth())
            picture?.let { Text((if (it.video) "Video clip" else "Photo") + (it.credit?.let { c -> " · $c" } ?: ""),
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)) }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (picture != null) OutlinedButton(onClick = onAnother, enabled = enabled) { Text("Another") }
                else OutlinedButton(onClick = onFind, enabled = enabled) { Text("Find") }
            }
        }
    }
}

/** P23: record -> words read from the recording -> keep my voice, or keep the words for the AI voice. */
@Composable
private fun OwnVoiceDialog(take: com.avsp.pro.ui.viewmodel.VoiceTake, viewModel: ManualViewModel) {
    AlertDialog(
        onDismissRequest = { if (!take.recording) viewModel.cancelVoice() },
        title = { Text(when { take.recording -> "🔴 Recording… ${take.seconds}s"; take.reading -> "Reading your words…"; else -> "Your voice" }) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                when {
                    take.recording -> Text("Speak now, phone 20–30 cm from your mouth. Tap Stop when done (silence at the start and end is cut).")
                    take.reading -> LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    else -> {
                        take.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                        if (take.seconds > 0) Text("${take.seconds}s recorded. Words (used for the captions):", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(value = take.text, onValueChange = viewModel::setVoiceText, minLines = 2, modifier = Modifier.fillMaxWidth())
                        Text("“Use my voice” keeps your recording. “AI voice” keeps only the words and the AI reads them.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    }
                }
            }
        },
        confirmButton = {
            when {
                take.recording -> Button(onClick = viewModel::stopVoice) { Text("Stop") }
                take.reading -> {}
                take.seconds > 0 -> Button(onClick = viewModel::useMyVoice) { Text("Use my voice") }
                else -> Button(onClick = { viewModel.startVoice(take.sceneId) }) { Text("Record") }
            }
        },
        dismissButton = {
            if (!take.recording && !take.reading) Row {
                if (take.seconds > 0) TextButton(onClick = viewModel::useWordsWithAiVoice) { Text("AI voice") }
                TextButton(onClick = viewModel::cancelVoice) { Text("Cancel") }
            }
        }
    )
}
