package com.avsp.pro.video.engine

import com.avsp.pro.video.contract.VideoCaptionInput

/**
 * Pure timeline partitioning for M4 timed captions.
 * The returned ranges cover the requested duration exactly and carry
 * the captions active during each range.
 */
object VideoCaptionTimelinePlanner {
    data class Range(
        val startMs: Long,
        val endMs: Long,
        val captions: List<VideoCaptionInput>
    ) {
        val durationMs: Long get() = endMs - startMs
    }

    fun partition(
        durationMs: Long,
        captions: List<VideoCaptionInput>
    ): List<Range> {
        require(durationMs > 0L) { "durationMs must be > 0" }
        val normalized = captions
            .filter { it.endMs > it.startMs && it.text.isNotBlank() }
            .map {
                it.copy(
                    startMs = it.startMs.coerceIn(0L, durationMs),
                    endMs = it.endMs.coerceIn(0L, durationMs)
                )
            }
            .filter { it.endMs > it.startMs }

        val boundaries = buildList {
            add(0L)
            add(durationMs)
            normalized.forEach { add(it.startMs); add(it.endMs) }
        }.distinct().sorted()

        return boundaries.zipWithNext().mapNotNull { (start, end) ->
            if (end <= start) return@mapNotNull null
            val active = normalized.filter { it.endMs > start && it.startMs < end }
            Range(start, end, active)
        }
    }
}