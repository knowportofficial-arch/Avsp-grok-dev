package com.avsp.pro.edit

import android.content.Context
import android.net.Uri
import com.avsp.pro.logs.AvspLogger
import com.avsp.pro.repository.ProjectRepository
import com.avsp.pro.storage.AvspStorage
import com.avsp.pro.storage.StorageArea
import com.avsp.pro.video.export.VideoMediaStoreExporter
import java.io.File

/** P12: "Smart edit my video" for a project - analyse, cut, render, save to the gallery. */
class SmartEditService(
    private val context: Context,
    private val projectRepository: ProjectRepository,
    private val storage: AvspStorage,
    private val logger: AvspLogger,
    private val geminiKeys: () -> List<String> = { emptyList() }
) {
    data class Outcome(
        val uri: String,
        val displayName: String,
        val originalMs: Long,
        val editedMs: Long,
        val cuts: Int,
        val transcript: String,
        val note: String?,
        val thumbnail: String? = null
    )

    suspend fun hasVideo(projectId: String): Boolean = ownVideo(projectId) != null

    private suspend fun ownVideo(projectId: String) = projectRepository.listMediaAssets(projectId)
        .filter { a -> a.mimeType.startsWith("video/") && !a.tags.contains("m4-test") && !a.tags.contains("stock") }
        .maxByOrNull { it.createdAt }

    suspend fun run(projectId: String, targetMs: Long? = null, onStep: (String) -> Unit): Outcome {
        val project = projectRepository.openProject(projectId)
        val asset = ownVideo(projectId) ?: error("Add a video to this project first")
        val file = File(storage.resolve(StorageArea.PROJECT_DATA, asset.relativePath, projectId))
        require(file.exists()) { "The video file is missing" }
        val uri = Uri.fromFile(file)
        val started = System.currentTimeMillis()
        val editor = SmartEditor(context, GeminiTranscriber(geminiKeys))
        val a = editor.analyse(uri, project.language.code, onStep, targetMs)
        logger.info(
            "EDIT",
            "Smart edit plan: ${a.durationMs} ms -> ${a.editedMs} ms, ${a.keeps.size} parts, ${a.speech.size} speech segments, ${a.heard.size} transcribed",
            details = a.note,
            projectId = projectId
        )
        onStep("Cutting and adding captions…")
        val out = File(storage.resolve(StorageArea.PROJECT_DATA, "video/smart_edit.mp4", projectId))
        // P14 hook: the video's title in big letters for the first 2 s (file-like names are skipped).
        // P18.1: the first thing actually said is the best hook; a picture-label name ("Cake, Food, Leisure") is not.
        val firstLine = a.heard.firstOrNull { it.startMs >= (a.keeps.firstOrNull()?.startMs ?: 0) - 500 }?.text
            ?: a.transcript.split(Regex("""(?<=[.!?।])\s+""")).firstOrNull()
        val hookTitle = firstLine?.takeIf { it.split(' ').count { w -> w.isNotBlank() } >= 2 }
            ?: project.name.takeIf { n -> n.isNotBlank() && !n.contains('_') && !n.contains(", ") && !n.endsWith(".mp4", true) }
        editor.render(uri, a, project.aspectRatio.width, project.aspectRatio.height, out, hookTitle?.let { ThumbnailText.make(it, maxWords = 6) })
        val exported = VideoMediaStoreExporter(context).export(sourceFile = out, projectId = projectId)
        // Keep the words: they become the script source for "make a new video from it".
        if (a.transcript.isNotBlank()) {
            runCatching {
                projectRepository.updateProject(project.copy(metadata = project.metadata + ("smartedit.transcript" to a.transcript.take(6000))))
            }
        }
        onStep("Making the thumbnail…")
        val thumb = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { runCatching {
            ThumbnailMaker(context).make(listOf(ThumbnailMaker.Source.Video(uri, a.durationMs)), hookTitle ?: project.name, "AVSP_edit_" + System.currentTimeMillis() / 1000)?.portrait?.toString()
        }.getOrNull() }
        logger.info("EDIT", "Smart edit done in ${System.currentTimeMillis() - started} ms", projectId = projectId)
        return Outcome(
            uri = exported.uri.toString(),
            displayName = exported.displayName,
            originalMs = a.durationMs,
            editedMs = a.editedMs,
            cuts = (a.keeps.size - 1).coerceAtLeast(0) + (if (a.keeps.firstOrNull()?.startMs ?: 0 > 0) 1 else 0) + (if ((a.keeps.lastOrNull()?.endMs ?: a.durationMs) < a.durationMs) 1 else 0),
            transcript = a.transcript,
            note = a.note,
            thumbnail = thumb
        )
    }
}
