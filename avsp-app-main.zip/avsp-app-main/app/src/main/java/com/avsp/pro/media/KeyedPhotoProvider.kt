package com.avsp.pro.media

import com.avsp.pro.settings.ApiKeyRing
import com.avsp.pro.settings.KeyProviders
import com.avsp.pro.settings.SecureConfigStore
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URLEncoder

/**
 * P17: free stock photos from services that need your own free key - Pixabay
 * and Unsplash. Each provider rotates through all its saved keys (a refused or
 * out-of-quota key is skipped for the rest of the session).
 */
class KeyedPhotoProvider(private val store: SecureConfigStore) {

    private val refused = java.util.concurrent.ConcurrentHashMap.newKeySet<String>()

    fun isConfigured(): Boolean = listOf(KeyProviders.PIXABAY, KeyProviders.UNSPLASH).any { ApiKeyRing.keys(store, it).isNotEmpty() }

    /** Best matches from Pixabay first, then Unsplash. Never throws. */
    fun candidates(query: String, portrait: Boolean): List<OpenverseImageProvider.Picture> {
        if (query.isBlank()) return emptyList()
        val q = URLEncoder.encode(query.take(90), "UTF-8")
        for (provider in listOf(KeyProviders.PIXABAY, KeyProviders.UNSPLASH)) {
            for (key in ApiKeyRing.keys(store, provider)) {
                if (key in refused) continue
                val result = runCatching {
                    when (provider) {
                        KeyProviders.PIXABAY -> parsePixabay(get("https://pixabay.com/api/?key=$key&q=$q&image_type=photo&orientation=${if (portrait) "vertical" else "horizontal"}&safesearch=true&per_page=20", emptyMap()))
                        else -> parseUnsplash(get("https://api.unsplash.com/search/photos?query=$q&per_page=20&content_filter=high&orientation=${if (portrait) "portrait" else "landscape"}",
                            mapOf("Authorization" to "Client-ID $key", "Accept-Version" to "v1")))
                    }
                }
                result.onFailure { if (ApiKeyRing.isKeyProblem(it.message)) refused += key }
                val list = result.getOrNull()
                if (list != null) { if (list.isNotEmpty()) return list; break }
            }
        }
        return emptyList()
    }

    /** P19: free VIDEO clips from Pixabay (needs the free Pixabay key); best fit first. Never throws. */
    fun clipCandidates(query: String, portrait: Boolean): List<Clip> {
        if (query.isBlank()) return emptyList()
        val q = URLEncoder.encode(query.take(90), "UTF-8")
        for (key in ApiKeyRing.keys(store, KeyProviders.PIXABAY)) {
            if (key in refused) continue
            val r = runCatching { parsePixabayVideos(get("https://pixabay.com/api/videos/?key=$key&q=$q&safesearch=true&per_page=15", emptyMap()), portrait) }
            r.onFailure { if (ApiKeyRing.isKeyProblem(it.message)) refused += key }
            r.getOrNull()?.let { return it }
        }
        return emptyList()
    }

    data class Clip(val id: String, val url: String, val width: Int, val height: Int, val durationS: Int, val credit: String)

    fun fetchClip(c: Clip, target: File) {
        target.parentFile?.mkdirs()
        val conn = java.net.URI(c.url).toURL().openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 10_000; conn.readTimeout = 40_000
            check(conn.responseCode in 200..299) { "Clip HTTP ${conn.responseCode}" }
            conn.inputStream.use { i -> target.outputStream().use { o ->
                val buf = ByteArray(65_536); var total = 0L
                while (true) { val n = i.read(buf); if (n < 0) break; total += n; check(total < 25_000_000) { "clip too big" }; o.write(buf, 0, n) }
            } }
        } finally { conn.disconnect() }
        check(target.length() > 50_000) { "Clip download failed" }
    }

    fun fetch(p: OpenverseImageProvider.Picture, target: File) {
        target.parentFile?.mkdirs()
        val c = java.net.URI(p.url).toURL().openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000; c.readTimeout = 30_000
            check(c.responseCode in 200..299) { "Photo HTTP ${c.responseCode}" }
            c.inputStream.use { i -> target.outputStream().use { o -> i.copyTo(o) } }
        } finally { c.disconnect() }
        check(target.length() > 10_000) { "Photo download failed" }
    }

    private fun get(url: String, headers: Map<String, String>): String {
        val c = java.net.URI(url).toURL().openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8_000; c.readTimeout = 12_000
            headers.forEach { (h, v) -> c.setRequestProperty(h, v) }
            val code = c.responseCode
            check(code in 200..299) { "HTTP $code" }
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    companion object {
        fun parsePixabay(raw: String): List<OpenverseImageProvider.Picture> {
            val hits = JSONObject(raw).optJSONArray("hits") ?: return emptyList()
            return (0 until hits.length()).mapNotNull { i ->
                val h = hits.optJSONObject(i) ?: return@mapNotNull null
                val url = h.optString("largeImageURL").ifBlank { h.optString("webformatURL") }
                if (!url.startsWith("https://")) return@mapNotNull null
                OpenverseImageProvider.Picture("pixabay:" + h.optLong("id"), url, h.optInt("imageWidth"), h.optInt("imageHeight"),
                    h.optString("user").ifBlank { "Pixabay" } + " / Pixabay", "pixabay")
            }
        }

        /** Pixabay video reply -> clips (3-60 s), the phone's shape first, ~720p file (not 4K). */
        fun parsePixabayVideos(raw: String, portrait: Boolean): List<Clip> {
            val hits = JSONObject(raw).optJSONArray("hits") ?: return emptyList()
            val out = mutableListOf<Clip>()
            for (i in 0 until hits.length()) {
                val h = hits.optJSONObject(i) ?: continue
                val dur = h.optInt("duration")
                if (dur !in 3..60) continue
                val v = h.optJSONObject("videos") ?: continue
                val pick = listOf("medium", "small", "large").mapNotNull { v.optJSONObject(it) }
                    .firstOrNull { it.optString("url").startsWith("https://") && it.optInt("size", 0) in 1..25_000_000 }
                    ?: listOf("medium", "small").mapNotNull { v.optJSONObject(it) }.firstOrNull { it.optString("url").startsWith("https://") } ?: continue
                out += Clip("pixabay-video:" + h.optLong("id"), pick.optString("url"), pick.optInt("width"), pick.optInt("height"), dur,
                    "${h.optString("user").ifBlank { "Pixabay" }} / Pixabay (Pixabay License)")
            }
            return out.sortedByDescending { c -> if ((c.height > c.width) == portrait) 1 else 0 }
        }

        fun parseUnsplash(raw: String): List<OpenverseImageProvider.Picture> {
            val res = JSONObject(raw).optJSONArray("results") ?: return emptyList()
            return (0 until res.length()).mapNotNull { i ->
                val r = res.optJSONObject(i) ?: return@mapNotNull null
                val url = r.optJSONObject("urls")?.optString("regular").orEmpty()
                if (!url.startsWith("https://")) return@mapNotNull null
                val name = r.optJSONObject("user")?.optString("name").orEmpty()
                OpenverseImageProvider.Picture("unsplash:" + r.optString("id"), url, r.optInt("width"), r.optInt("height"),
                    "Photo by ${name.ifBlank { "Unsplash" }} on Unsplash", "unsplash")
            }
        }
    }
}
