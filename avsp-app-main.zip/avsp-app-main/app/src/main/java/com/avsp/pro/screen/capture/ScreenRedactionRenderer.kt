package com.avsp.pro.screen.capture

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.RectF
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.CanvasOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * AVSP V2.3 privacy renderer.
 *
 * V2.2 device evidence proved that the CanvasOverlay renderer was executing,
 * but portrait recordings were encoded by Media3 in landscape orientation.
 *
 * V2.3:
 *  - explicitly enables portrait encoding
 *  - keeps normalized OCR coordinates aligned with portrait video
 *  - replaces black censor blocks with an opaque mosaic censor
 *  - keeps output video-only
 *
 * IMPORTANT:
 * This is an OPAQUE MOSAIC CENSOR, not a true sampled-pixel mosaic.
 * It deliberately does not expose any underlying sensitive pixel.
 */
@OptIn(UnstableApi::class)
object ScreenRedactionRenderer {

    data class RedactionInterval(
        val startMs: Long,
        val endMs: Long,
        val bounds: RectF,
        val type: SensitiveDataType
    )

    data class InteractionMarker(
        val timestampMs: Long,
        val bounds: RectF
    )

    private const val PRE_ROLL_MS = 500L
    private const val POST_ROLL_MS = 1500L

    /*
     * Expand OCR bounds slightly.
     *
     * ML Kit line boxes can be tight around glyphs. A small normalized
     * expansion protects anti-aliased edges and OCR box rounding without
     * hiding an unnecessarily large portion of the screen.
     */
    private const val BOUNDS_EXPANSION = 0.004f

    fun buildIntervals(
        findings: List<SensitiveFinding>,
        durationMs: Long
    ): List<RedactionInterval> {

        if (findings.isEmpty() || durationMs <= 0L) {
            return emptyList()
        }

        return findings
            .map { finding ->
                val start = (finding.timestampMs - PRE_ROLL_MS)
                    .coerceAtLeast(0L)

                val end = (finding.timestampMs + POST_ROLL_MS)
                    .coerceAtMost(durationMs)

                RedactionInterval(
                    startMs = start,
                    endMs = end,
                    bounds = expandAndNormalizeBounds(finding.bounds),
                    type = finding.type
                )
            }
            .filter { it.endMs > it.startMs }
            .sortedWith(
                compareBy<RedactionInterval> { it.startMs }
                    .thenBy { it.endMs }
            )
    }

    private fun expandAndNormalizeBounds(bounds: RectF): RectF {
        return RectF(
            (bounds.left - BOUNDS_EXPANSION).coerceIn(0f, 1f),
            (bounds.top - BOUNDS_EXPANSION).coerceIn(0f, 1f),
            (bounds.right + BOUNDS_EXPANSION).coerceIn(0f, 1f),
            (bounds.bottom + BOUNDS_EXPANSION).coerceIn(0f, 1f)
        )
    }

    suspend fun render(
        context: Context,
        inputFile: File,
        outputFile: File,
        findings: List<SensitiveFinding>,
        durationMs: Long,
        interactionMarkers: List<InteractionMarker> = emptyList(),
        /*
         * P0 frame-local privacy plan. When present it replaces the
         * fixed PRE_ROLL/POST_ROLL intervals. Legacy intervals remain
         * the fallback (null plan, or empty plan while findings exist).
         */
        privacyPlan: ScreenPrivacyPlan? = null
    ): File {

        require(inputFile.exists()) {
            "Screen redaction input does not exist: ${inputFile.absolutePath}"
        }

        outputFile.parentFile?.mkdirs()

        if (outputFile.exists()) {
            outputFile.delete()
        }

        val useFrameLocalPlan =
            privacyPlan != null &&
                !(privacyPlan.isEmpty && findings.isNotEmpty())

        val intervals =
            if (useFrameLocalPlan) emptyList()
            else buildIntervals(findings, durationMs)

        val overlay =
            PrivacyMosaicOverlay(
                intervals = intervals,
                interactionMarkers = interactionMarkers,
                privacyPlan = if (useFrameLocalPlan) privacyPlan else null
            )

        val input = MediaItem.fromUri(Uri.fromFile(inputFile))

        /*
         * Original screen-recording audio is never copied.
         */
        val edited = EditedMediaItem.Builder(input)
            .setRemoveAudio(true)
            .setEffects(
                Effects(
                    emptyList(),
                    listOf(
                        OverlayEffect(listOf(overlay))
                    )
                )
            )
            .build()

        withContext(Dispatchers.Main.immediate) {
            suspendCancellableCoroutine<Unit> { continuation ->

                val listener = object : Transformer.Listener {

                    override fun onCompleted(
                        composition: Composition,
                        exportResult: ExportResult
                    ) {
                        if (continuation.isActive) {
                            continuation.resume(Unit)
                        }
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        if (continuation.isActive) {
                            continuation.resumeWithException(exportException)
                        }
                    }
                }

                /*
                 * CRITICAL V2.3 FIX:
                 *
                 * Media3 defaults portrait encoding to false.
                 * That can rotate portrait content before encoding.
                 *
                 * Our OCR bounds are based on the portrait frame.
                 * Keep portrait encoding enabled so the overlay coordinate
                 * system remains aligned with the OCR coordinate system.
                 */
                val transformer = Transformer.Builder(context)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setPortraitEncodingEnabled(true)
                    .addListener(listener)
                    .build()

                continuation.invokeOnCancellation {
                    try {
                        transformer.cancel()
                    } catch (_: Throwable) {
                    }
                }

                transformer.start(
                    edited,
                    outputFile.absolutePath
                )
            }
        }

        check(outputFile.exists()) {
            "Redaction renderer completed without output file"
        }

        check(outputFile.length() > 0L) {
            "Redaction renderer produced an empty output"
        }

        return outputFile
    }

    /**
     * Opaque mosaic censor.
     *
     * Each sensitive region is completely covered by opaque tiles.
     * No original sensitive pixel remains visible underneath the tiles.
     */
    @OptIn(UnstableApi::class)
    private class PrivacyMosaicOverlay(
        private val intervals: List<RedactionInterval>,
        private val interactionMarkers: List<InteractionMarker>,
        private val privacyPlan: ScreenPrivacyPlan? = null
    ) : CanvasOverlay(true) {

        private val paint = Paint().apply {
            style = Paint.Style.FILL
            isAntiAlias = false
        }

        override fun onDraw(
            canvas: Canvas,
            presentationTimeUs: Long
        ) {
            canvas.drawColor(
                Color.TRANSPARENT,
                PorterDuff.Mode.CLEAR
            )

            /*
             * NOTE: no early return here any more. Previously an empty
             * interval list returned before the interaction black spot
             * was drawn, so recordings without sensitive findings lost
             * every interaction dot.
             */
            val timestampMs = presentationTimeUs / 1000L
            val width = canvas.width.toFloat()
            val height = canvas.height.toFloat()

            /*
             * The black-spot code below switches the shared paint to
             * anti-aliased. Reset it every frame so mosaic tile edges stay
             * hard/opaque and never blend with underlying pixels.
             */
            paint.style = Paint.Style.FILL
            paint.isAntiAlias = false

            /*
             * P1 TRANSITION VEIL: during app-switch / zoom animations the
             * content scales faster than any box can follow. Cover the
             * whole frame for that short window (looks like a quick dip
             * to dark) instead of leaking scaled-down sensitive text.
             */
            val veiled = privacyPlan?.veilAt(timestampMs) == true
            if (veiled) {
                paint.color = Color.rgb(24, 24, 24)
                paint.alpha = 255
                canvas.drawRect(0f, 0f, width, height, paint)
            }

            /* P0 FRAME-LOCAL PRIVACY: boxes computed for THIS frame only. */
            if (!veiled) privacyPlan?.boxesAt(timestampMs)?.forEach { box ->
                val left = box.left * width
                val top = box.top * height
                val right = box.right * width
                val bottom = box.bottom * height

                if (right > left && bottom > top) {
                    drawMosaic(
                        canvas = canvas,
                        left = left,
                        top = top,
                        right = right,
                        bottom = bottom
                    )
                }
            }


            /* Legacy interval fallback (empty when the plan is in use). */
            for (interval in intervals) {

                if (
                    timestampMs < interval.startMs ||
                    timestampMs > interval.endMs
                ) {
                    continue
                }

                val left = interval.bounds.left * width
                val top = interval.bounds.top * height
                val right = interval.bounds.right * width
                val bottom = interval.bounds.bottom * height

                if (right <= left || bottom <= top) {
                    continue
                }

                drawMosaic(
                    canvas = canvas,
                    left = left,
                    top = top,
                    right = right,
                    bottom = bottom
                )
            }

            /* INTERACTION BLACK SPOT: small, opaque, no zoom */
            if (interactionMarkers.isNotEmpty()) {
                val dotRadius = (minOf(width, height) * 0.0075f).coerceIn(4f, 12f)
                for (marker in interactionMarkers) {
                    val delta = timestampMs - marker.timestampMs
                    if (delta < -180L || delta > 520L) continue
                    val centerX = ((marker.bounds.left + marker.bounds.right) / 2f).coerceIn(0f, 1f) * width
                    val centerY = ((marker.bounds.top + marker.bounds.bottom) / 2f).coerceIn(0f, 1f) * height
                    paint.style = Paint.Style.FILL
                    paint.color = Color.BLACK
                    paint.alpha = 255
                    paint.isAntiAlias = true
                    canvas.drawCircle(centerX, centerY, dotRadius, paint)
                }
            }
        }

        private fun drawMosaic(
            canvas: Canvas,
            left: Float,
            top: Float,
            right: Float,
            bottom: Float
        ) {
            /*
             * Tile size adapts to the region.
             * Minimum 6 px ensures that small OCR text still gets a
             * visibly mosaic appearance.
             */
            val regionWidth = (right - left).coerceAtLeast(1f)
            val regionHeight = (bottom - top).coerceAtLeast(1f)

            val tile = (
                regionWidth.coerceAtMost(regionHeight) / 4f
            ).coerceIn(6f, 18f)

            var row = 0
            var y = top

            while (y < bottom) {
                var col = 0
                var x = left

                while (x < right) {

                    /*
                     * P1.1 opaque pink / green mosaic palette.
                     * The underlying sensitive pixels are never visible.
                     */
                    val pattern = (row % 2) * 2 + ((col + row / 2) % 2)

                    paint.color = when (pattern) {
                        0 -> Color.rgb(236, 64, 122)   // pink
                        1 -> Color.rgb(102, 187, 106)  // green
                        2 -> Color.rgb(46, 125, 50)    // dark green
                        else -> Color.rgb(248, 152, 190) // light pink
                    }

                    canvas.drawRect(
                        x,
                        y,
                        (x + tile).coerceAtMost(right),
                        (y + tile).coerceAtMost(bottom),
                        paint
                    )

                    x += tile
                    col++
                }

                y += tile
                row++
            }
        }
    }
}
