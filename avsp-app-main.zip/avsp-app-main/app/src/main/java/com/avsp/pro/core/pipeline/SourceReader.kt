package com.avsp.pro.core.pipeline

import com.avsp.pro.core.pipeline.SourceText.cleanSpaces
import com.avsp.pro.core.pipeline.SourceText.metaContent
import com.avsp.pro.core.pipeline.SourceText.parseArticle
import com.avsp.pro.core.pipeline.SourceText.parseCaptions
import com.avsp.pro.core.pipeline.SourceText.parseOEmbed
import com.avsp.pro.core.pipeline.SourceText.titleFromText
import com.avsp.pro.core.pipeline.SourceText.youTubeCaptionUrl
import com.avsp.pro.core.pipeline.SourceText.youTubeDescription

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.media.MediaMetadataRetriever
import android.net.Uri
import com.avsp.pro.m5.UnifiedInputKind
import com.avsp.pro.m5.UnifiedInputResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URLEncoder

/**
 * UNDERSTAND step (RAW INPUT -> UNDERSTAND -> ORGANIZE -> SCRIPT ...).
 *
 * Before P5 a YouTube or website link reached the script writer as a bare
 * URL, and files only as a file name, so the script was about "https://..."
 * or "IMG_1234.jpg". Now every source is read first:
 *  - YouTube: real title + channel (oEmbed), description and captions
 *  - Website: headline, summary and the article paragraphs
 *  - Text: first line becomes the title
 *  - Photo: text in the picture (OCR) + what is in it (labels)
 *  - PDF: text of the first pages (OCR)
 *  - Video / screen recording: text and objects seen in a few frames
 * No API key; network only for links. Every reader fails soft: the source
 * keeps what it had.
 */
class SourceReader(
    private val context: Context?,
    private val httpGet: (String) -> String = SourceText::get,
    /** P18.1: the user's Gemini keys, to explain pictures whose text can't be read well. */
    private val geminiKeys: () -> List<String> = { emptyList() }
) {

    suspend fun understand(source: UnifiedInputResult): UnifiedInputResult = withContext(Dispatchers.IO) {
        runCatching {
            when (source.kind) {
                UnifiedInputKind.YOUTUBE -> readYouTube(source)
                UnifiedInputKind.URL -> readWebsite(source)
                UnifiedInputKind.TEXT -> readText(source)
                else -> readLocal(source)
            }
        }.getOrElse {
            val local = source.kind !in setOf(UnifiedInputKind.YOUTUBE, UnifiedInputKind.URL, UnifiedInputKind.TEXT)
            source.copy(
                title = if (local) friendlyFileTitle(source.title, source.mimeType.orEmpty()) else source.title,
                warnings = source.warnings + "Could not read source: ${it.javaClass.simpleName} ${it.message}"
            )
        }
    }

    // ------------------------------------------------------------------ links

    private fun readYouTube(s: UnifiedInputResult): UnifiedInputResult {
        val id = s.youtubeId ?: return s
        val watchUrl = "https://www.youtube.com/watch?v=$id"
        val oembed = runCatching {
            parseOEmbed(httpGet("https://www.youtube.com/oembed?format=json&url=" + URLEncoder.encode(watchUrl, "UTF-8")))
        }.getOrNull()
        val html = runCatching { httpGet("$watchUrl&hl=en") }.getOrNull().orEmpty()
        val description = youTubeDescription(html, id)
        val captions = youTubeCaptionUrl(html, id)?.let { url ->
            runCatching { parseCaptions(httpGet(url)) }.getOrNull()
        }.orEmpty()
        val title = oembed?.first ?: metaContent(html, "og:title") ?: s.title
        val body = listOf(description, captions).filter { it.isNotBlank() }.joinToString("\n\n")
        return s.copy(
            title = cleanSpaces(title),
            text = buildString {
                append(cleanSpaces(title))
                oembed?.second?.takeIf { it.isNotBlank() }?.let { append("\nChannel: ").append(it) }
                if (body.isNotBlank()) append("\n\n").append(body.take(MAX_TEXT))
            }
        )
    }

    private fun readWebsite(s: UnifiedInputResult): UnifiedInputResult {
        val html = httpGet(s.reference)
        val article = parseArticle(html)
        if (article.title.isBlank() && article.body.isBlank()) return s
        return s.copy(
            title = article.title.ifBlank { s.title },
            text = listOf(article.title, article.summary, article.body)
                .filter { it.isNotBlank() }
                .distinct()
                .joinToString("\n\n")
                .take(MAX_TEXT)
        )
    }

    private fun readText(s: UnifiedInputResult): UnifiedInputResult {
        val text = s.reference.trim()
        return s.copy(title = titleFromText(text), text = text)
    }

    // ------------------------------------------------------------------ files

    private fun readLocal(s: UnifiedInputResult): UnifiedInputResult {
        val ctx = context ?: return s
        val uri = runCatching { Uri.parse(s.reference) }.getOrNull() ?: return s
        val mime = s.mimeType?.takeIf { it.isNotBlank() }
            ?: runCatching { ctx.contentResolver.getType(uri) }.getOrNull().orEmpty()
        if (mime.startsWith("text/")) {
            val text = ctx.contentResolver.openInputStream(uri)?.use { it.reader().readText() }.orEmpty().take(MAX_TEXT)
            return if (text.isBlank()) s else s.copy(title = titleFromText(text), text = text)
        }
        val bitmaps: List<Bitmap> = when {
            mime.startsWith("image/") || s.kind == UnifiedInputKind.IMAGE ->
                listOfNotNull(ctx.contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) })
            mime == "application/pdf" -> pdfPages(ctx, uri, 3)
            mime.startsWith("video/") || s.kind == UnifiedInputKind.VIDEO || s.kind == UnifiedInputKind.SCREEN_RECORDING ->
                videoFrames(ctx, uri, s.durationSeconds)
            else -> emptyList()
        }
        val fallbackTitle = friendlyFileTitle(s.title, mime)
        if (bitmaps.isEmpty()) {
            return s.copy(
                title = fallbackTitle,
                mimeType = mime.ifBlank { s.mimeType },
                warnings = s.warnings + "Could not open the file to read it (type '${mime.ifBlank { "unknown" }}')"
            )
        }
        val texts = mutableListOf<String>()
        val labels = linkedSetOf<String>()
        bitmaps.forEach { bmp ->
            ocr(bmp)?.let { if (it.isNotBlank()) texts += it }
            labels += imageLabels(bmp)
        }
        // P18.1: keep only readable lines, never private details (ids, passwords, IPs, numbers).
        val cleaned = OcrCleaner.clean(texts.joinToString("\n"))
        val ocrText = cleaned.text.take(MAX_TEXT)
        val isVideo = mime.startsWith("video/") || s.kind == UnifiedInputKind.VIDEO || s.kind == UnifiedInputKind.SCREEN_RECORDING
        // Hard-to-read picture (notes, diagram, poster): let Gemini explain it, if the user has a key.
        val described = if (!isVideo && (ocrText.length < 80 || cleaned.readable < 0.6f))
            runCatching { GeminiVision.describe(bitmaps.first(), geminiKeys()) }.getOrNull() else null
        val warnings = buildList {
            if (cleaned.privateLinesDropped > 0) add("${cleaned.privateLinesDropped} line(s) with private details (IDs, passwords, IP or account numbers) were left out of the script")
            if (cleaned.noiseLinesDropped > 0 && described == null) add("Some text in the picture could not be read clearly and was skipped")
        }
        val nameTitle = fallbackTitle
        val title = described?.let { titleFromText(it) }?.takeIf { it.split(' ').size >= 3 }
            ?: titleFromText(ocrText).takeIf { it.split(' ').size >= 3 }
            // Labels ("Cake, Food, Leisure") make a poor title for a video - its words decide later.
            ?: labels.take(3).joinToString(", ").takeIf { it.isNotBlank() && !isVideo }
            ?: nameTitle
        return s.copy(
            mimeType = mime.ifBlank { s.mimeType },
            title = title,
            warnings = s.warnings + warnings,
            text = buildString {
                if (!described.isNullOrBlank()) append(described)
                if (ocrText.isNotBlank()) { if (isNotEmpty()) append("\n\n"); append(ocrText) }
                if (labels.isNotEmpty()) {
                    if (isNotEmpty()) append("\n\n")
                    append("Shows: ").append(labels.joinToString(", "))
                }
            }
        )
    }

    private fun pdfPages(ctx: Context, uri: Uri, max: Int): List<Bitmap> {
        val out = mutableListOf<Bitmap>()
        ctx.contentResolver.openFileDescriptor(uri, "r")?.use { pfd ->
            PdfRenderer(pfd).use { renderer ->
                for (i in 0 until minOf(max, renderer.pageCount)) {
                    renderer.openPage(i).use { page ->
                        val scale = 1600f / maxOf(page.width, page.height)
                        val bmp = Bitmap.createBitmap(
                            (page.width * scale).toInt().coerceAtLeast(1),
                            (page.height * scale).toInt().coerceAtLeast(1),
                            Bitmap.Config.ARGB_8888
                        )
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        out += bmp
                    }
                }
            }
        }
        return out
    }

    private fun videoFrames(ctx: Context, uri: Uri, durationSeconds: Long): List<Bitmap> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?: (durationSeconds * 1000)
            listOf(0.15, 0.5, 0.85).mapNotNull { f ->
                r.getFrameAtTime((durMs * f * 1000).toLong(), MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
            }
        } catch (_: Exception) {
            emptyList()
        } finally {
            r.release()
        }
    }

    private fun ocr(bmp: Bitmap): String? = runCatching {
        val client = com.google.mlkit.vision.text.TextRecognition.getClient(
            com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS
        )
        try {
            com.google.android.gms.tasks.Tasks.await(
                client.process(com.google.mlkit.vision.common.InputImage.fromBitmap(bmp, 0)),
                20, java.util.concurrent.TimeUnit.SECONDS
            ).text
        } finally {
            client.close()
        }
    }.getOrNull()

    private fun imageLabels(bmp: Bitmap): List<String> = runCatching {
        val labeler = com.google.mlkit.vision.label.ImageLabeling.getClient(
            com.google.mlkit.vision.label.defaults.ImageLabelerOptions.DEFAULT_OPTIONS
        )
        try {
            com.google.android.gms.tasks.Tasks.await(
                labeler.process(com.google.mlkit.vision.common.InputImage.fromBitmap(bmp, 0)),
                20, java.util.concurrent.TimeUnit.SECONDS
            ).filter { it.confidence >= 0.7f }.map { it.text.lowercase() }
        } finally {
            labeler.close()
        }
    }.getOrDefault(emptyList())

    companion object {
        const val MAX_TEXT = SourceText.MAX_TEXT
    }
}
