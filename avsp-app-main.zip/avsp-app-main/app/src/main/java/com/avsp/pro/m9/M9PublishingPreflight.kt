﻿package com.avsp.pro.m9

/**
 * M9.8
 *
 * Local publishing preflight.
 *
 * This module answers:
 * "Is this READY M9 job locally prepared for every selected platform?"
 *
 * It does NOT:
 * - launch OAuth
 * - exchange tokens
 * - refresh tokens
 * - transmit credentials
 * - upload media
 * - publish externally
 * - claim external publication
 */
enum class M9PreflightStatus {
    READY,
    AUTHENTICATION_REQUIRED,
    CONFIGURATION_REQUIRED,
    INVALID
}

data class M9PlatformPreflight(
    val platform: M9Platform,
    val status: M9PreflightStatus,
    val readiness: M9AuthReadiness?,
    val credentialPresent: Boolean,
    val message: String
)

data class M9PublishingPreflightResult(
    val projectId: String,
    val jobId: String,
    val status: M9PreflightStatus,
    val platforms: List<M9PlatformPreflight>,
    val readyPlatforms: Set<M9Platform>,
    val blockedPlatforms: Set<M9Platform>,
    val message: String
)

object M9PublishingPreflight {

    fun evaluate(
        job: M9Job,
        configurations: Map<String, M9ProviderAuthConfiguration>,
        credentialStore: M9CredentialStore
    ): M9PublishingPreflightResult {

        if (job.projectId.isBlank()) {
            return invalid(job, "Project ID is required.")
        }

        if (job.videoPath.isBlank()) {
            return invalid(job, "Video path is required.")
        }

        if (job.title.isBlank()) {
            return invalid(job, "Publish title is required.")
        }

        if (job.platforms.isEmpty()) {
            return invalid(job, "At least one publishing platform is required.")
        }

        if (job.status != M9Status.READY) {
            return invalid(
                job,
                "Publishing preflight requires M9 READY status."
            )
        }

        val video = java.io.File(job.videoPath)

        if (!video.exists()) {
            return invalid(job, "Video file does not exist.")
        }

        if (!video.isFile) {
            return invalid(job, "Video path is not a file.")
        }

        if (!video.canRead()) {
            return invalid(job, "Video file is not readable.")
        }

        val results = mutableListOf<M9PlatformPreflight>()
        val ready = linkedSetOf<M9Platform>()
        val blocked = linkedSetOf<M9Platform>()

        for (platform in job.platforms) {

            val providerId = platform.name
            val configuration = configurations[providerId]

            if (configuration == null) {
                results += M9PlatformPreflight(
                    platform = platform,
                    status = M9PreflightStatus.CONFIGURATION_REQUIRED,
                    readiness = null,
                    credentialPresent = false,
                    message = "No authentication configuration exists for $providerId."
                )

                blocked += platform
            }

            if (configuration != null) {

                val auth =
                    M9AuthenticationCoordinator.resolve(
                        configuration = configuration,
                        credentialStore = credentialStore
                    )

                val status =
                    when (auth.readiness) {
                        M9AuthReadiness.NOT_REQUIRED ->
                            M9PreflightStatus.READY

                        M9AuthReadiness.AUTHENTICATED ->
                            M9PreflightStatus.READY

                        M9AuthReadiness.READY_FOR_AUTH ->
                            M9PreflightStatus.AUTHENTICATION_REQUIRED

                        M9AuthReadiness.CONFIGURATION_REQUIRED ->
                            M9PreflightStatus.CONFIGURATION_REQUIRED

                        M9AuthReadiness.EXPIRED ->
                            M9PreflightStatus.AUTHENTICATION_REQUIRED

                        M9AuthReadiness.INVALID ->
                            M9PreflightStatus.INVALID
                    }

                results += M9PlatformPreflight(
                    platform = platform,
                    status = status,
                    readiness = auth.readiness,
                    credentialPresent = auth.credentialPresent,
                    message = auth.message
                )

                if (status == M9PreflightStatus.READY) {
                    ready += platform
                }

                if (status != M9PreflightStatus.READY) {
                    blocked += platform
                }
            }
        }

        if (blocked.isEmpty()) {
            return M9PublishingPreflightResult(
                projectId = job.projectId,
                jobId = job.jobId,
                status = M9PreflightStatus.READY,
                platforms = results,
                readyPlatforms = ready,
                blockedPlatforms = blocked,
                message = "All selected platforms passed local preflight. External publishing has not occurred."
            )
        }

        val configurationBlocked =
            results.any {
                it.status == M9PreflightStatus.CONFIGURATION_REQUIRED ||
                    it.status == M9PreflightStatus.INVALID
            }

        if (configurationBlocked) {
            return M9PublishingPreflightResult(
                projectId = job.projectId,
                jobId = job.jobId,
                status = M9PreflightStatus.CONFIGURATION_REQUIRED,
                platforms = results,
                readyPlatforms = ready,
                blockedPlatforms = blocked,
                message = "One or more selected platforms require configuration."
            )
        }

        return M9PublishingPreflightResult(
            projectId = job.projectId,
            jobId = job.jobId,
            status = M9PreflightStatus.AUTHENTICATION_REQUIRED,
            platforms = results,
            readyPlatforms = ready,
            blockedPlatforms = blocked,
            message = "One or more selected platforms require authentication."
        )
    }

    private fun invalid(
        job: M9Job,
        message: String
    ): M9PublishingPreflightResult {

        return M9PublishingPreflightResult(
            projectId = job.projectId,
            jobId = job.jobId,
            status = M9PreflightStatus.INVALID,
            platforms = emptyList(),
            readyPlatforms = emptySet(),
            blockedPlatforms = job.platforms,
            message = message
        )
    }
}
