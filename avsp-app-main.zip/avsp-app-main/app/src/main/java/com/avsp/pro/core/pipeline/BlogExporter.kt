package com.avsp.pro.core.pipeline

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import com.avsp.pro.logs.AvspLogger
import com.avsp.pro.repository.ProjectRepository
import com.avsp.pro.script.contract.ScriptPackage
import com.avsp.pro.script.repository.ScriptRepository
import com.avsp.pro.storage.AvspStorage
import com.avsp.pro.storage.StorageArea
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * P10 BLOG: turns a project into a TEXT BLOG (self-contained HTML article +
 * Markdown) and a PHOTO BLOG (1080x1350 carousel slides), saved to the phone:
 *   Download/AVSP/Blogs/<title>.html      Pictures/AVSP/Blog/<title>_01.jpg ...
 * Uses the project's script (written now if there is none) and its pictures
 * (own photos first, then the free pictures; fetched now if missing).
 */
class BlogExporter(
    private val context: Context,
    private val projectRepository: ProjectRepository,
    private val scriptRepository: ScriptRepository,
    private val storage: AvspStorage,
    private val autoProducer: AutoProducer,
    private val logger: AvspLogger
) {
    data class TextBlog(val title: String, val uri: Uri, val markdown: String)
    data class PhotoBlog(val title: String, val slides: List<Uri>, val caption: String)

    private suspend fun prepare(projectId: String, onStep: (String) -> Unit): Triple<ScriptPackage, Blog, List<Bitmap>> {
        val project = projectRepository.openProject(projectId)
        onStep("Getting the story…")
        val script = scriptRepository.load(projectId)
            ?: autoProducer.writeScript(projectId, AutoProducer.topicFor(project), 60)
        onStep("Finding pictures…")
        autoProducer.ensurePictures(projectId, script)
        val pictures = picturesFor(projectId, script)
        val credits = runCatching {
            projectRepository.listMediaAssets(projectId)
                .filter { a -> a.tags.any { it.startsWith("stock:${script.scriptId}:") } }
                .mapNotNull { a -> a.tags.firstOrNull { it.startsWith("credit:") }?.removePrefix("credit:") }
        }.getOrDefault(emptyList())
        val sourceText = (0 until (project.metadata["source.bundle.count"]?.toIntOrNull() ?: 0))
            .joinToString("\n") { project.metadata["source.$it.text"].orEmpty() }
        val kit = runCatching { PublishKit.from(script, portrait = false) }.getOrNull()
        val blog = BlogContent.build(
            title = script.title.ifBlank { project.name },
            scenes = script.scenes.sortedBy { it.order }.map { BlogContent.SceneText(it.narration, it.onScreenText) },
            sourceText = sourceText,
            cta = script.scenes.maxByOrNull { it.order }?.narration ?: script.cta,
            pictureCount = pictures.size,
            credits = credits,
            hashtags = kit?.hashtags?.filterNot { it.equals("#Shorts", true) }.orEmpty()
        )
        return Triple(script, blog, pictures)
    }

    suspend fun makeTextBlog(projectId: String, onStep: (String) -> Unit = {}): TextBlog = withContext(Dispatchers.IO) {
        val (script, blog, pictures) = prepare(projectId, onStep)
        onStep("Writing the blog…")
        val jpegs = pictures.map { bmp ->
            val w = minOf(1080, bmp.width)
            val scaled = if (bmp.width > w) Bitmap.createScaledBitmap(bmp, w, (bmp.height * w.toFloat() / bmp.width).toInt(), true) else bmp
            ByteArrayOutputStream().also { scaled.compress(Bitmap.CompressFormat.JPEG, 80, it) }.toByteArray()
        }
        pictures.forEach { it.recycle() }
        val html = BlogContent.html(blog, jpegs, script.language)
        val uri = saveDownload("${fileStem(blog.title)}.html", "text/html", html.toByteArray(Charsets.UTF_8))
        logger.info("BLOG", "Text blog saved (${blog.sections.size} sections, ${jpegs.size} pictures)", projectId = projectId)
        TextBlog(blog.title, uri, blog.markdown())
    }

    suspend fun makePhotoBlog(projectId: String, onStep: (String) -> Unit = {}): PhotoBlog = withContext(Dispatchers.IO) {
        val (_, blog, pictures) = prepare(projectId, onStep)
        onStep("Designing the slides…")
        val slides = mutableListOf<Bitmap>()
        val total = 2 + blog.sections.size
        slides += cover(blog.title, pictures.firstOrNull(), total)
        blog.sections.forEachIndexed { i, s ->
            // The cover already shows picture 1: slides start from picture 2 when there are enough.
            val shift = if (pictures.size > blog.sections.size) 1 else 0
            val pic = s.pictureIndex?.let { pictures.getOrNull(it + shift) } ?: pictures.getOrNull((i + shift) % maxOf(1, pictures.size))
            slides += slide(s.heading, s.body, pic, i + 2, total)
        }
        slides += ctaSlide(blog.cta.ifBlank { "Like, share and follow!" }, total)
        pictures.forEach { it.recycle() }
        val stem = fileStem(blog.title)
        val uris = slides.mapIndexed { i, bmp ->
            val bytes = ByteArrayOutputStream().also { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }.toByteArray()
            bmp.recycle()
            saveImage("${stem}_%02d.jpg".format(i + 1), bytes)
        }
        logger.info("BLOG", "Photo blog saved (${uris.size} slides)", projectId = projectId)
        val caption = buildString {
            append(blog.title).append("\n\n")
            if (blog.intro.isNotBlank()) append(blog.intro).append("\n\n")
            if (blog.hashtags.isNotEmpty()) append(blog.hashtags.joinToString(" "))
        }.trim()
        PhotoBlog(blog.title, uris, caption)
    }

    // ------------------------------------------------------------------ pictures

    private suspend fun picturesFor(projectId: String, script: ScriptPackage): List<Bitmap> {
        val assets = projectRepository.listMediaAssets(projectId).filterNot { it.tags.contains("m4-test") }
        val own = assets.filter { a -> a.tags.contains("own") && a.tags.none { it.startsWith("scene:") } }
        val byScene = script.scenes.sortedBy { it.order }.mapNotNull { sc ->
            assets.firstOrNull { a -> a.tags.contains("scene:${script.scriptId}:${sc.sceneId}") }
                ?: assets.firstOrNull { a -> a.tags.contains("stock:${script.scriptId}:${sc.sceneId}") }
        }
        return (own + byScene).distinctBy { it.relativePath }.take(10).mapNotNull { a ->
            val f = File(storage.resolve(StorageArea.PROJECT_DATA, a.relativePath, projectId))
            runCatching {
                if (a.mimeType.startsWith("video/")) frameOf(f) else decode(f, 1440)
            }.getOrNull()
        }
    }

    private fun decode(f: File, max: Int): Bitmap? {
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, b)
        var sample = 1
        while (maxOf(b.outWidth, b.outHeight) / (sample * 2) >= max) sample *= 2
        return BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private fun frameOf(f: File): Bitmap? {
        val r = android.media.MediaMetadataRetriever()
        return try {
            r.setDataSource(f.absolutePath)
            r.getFrameAtTime(1_000_000L, android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } finally { r.release() }
    }

    // ------------------------------------------------------------------ slides (1080x1350, 4:5)

    private val W = 1080
    private val H = 1350
    private val teal = Color.rgb(15, 118, 110)

    private fun coverCrop(c: Canvas, pic: Bitmap, dst: RectF) {
        val s = maxOf(dst.width() / pic.width, dst.height() / pic.height)
        val w = dst.width() / s; val h = dst.height() / s
        val left = ((pic.width - w) / 2f).toInt(); val top = ((pic.height - h) / 2f).toInt()
        c.save(); c.clipRect(dst)
        c.drawBitmap(pic, android.graphics.Rect(left, top, (left + w).toInt(), (top + h).toInt()), dst, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
    }

    private fun text(c: Canvas, s: String, x: Float, y: Float, width: Int, size: Float, color: Int, bold: Boolean, maxLines: Int, center: Boolean = false): Float {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color; textSize = size
            typeface = Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        val layout = StaticLayout.Builder.obtain(s, 0, s.length, tp, width)
            .setAlignment(if (center) Layout.Alignment.ALIGN_CENTER else Layout.Alignment.ALIGN_NORMAL)
            .setLineSpacing(0f, 1.15f).setMaxLines(maxLines).setEllipsize(TextUtils.TruncateAt.END).build()
        c.save(); c.translate(x, y); layout.draw(c); c.restore()
        return y + layout.height
    }

    private fun pageMark(c: Canvas, n: Int, total: Int, color: Int) {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; textSize = 30f; textAlign = Paint.Align.RIGHT }
        c.drawText("$n / $total", W - 48f, H - 44f, p)
    }

    private fun gradient(c: Canvas) {
        val p = Paint().apply { shader = LinearGradient(0f, 0f, W.toFloat(), H.toFloat(), Color.rgb(15, 118, 110), Color.rgb(30, 64, 120), Shader.TileMode.CLAMP) }
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p)
    }

    private fun cover(title: String, pic: Bitmap?, total: Int): Bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888).also { b ->
        val c = Canvas(b)
        if (pic != null) coverCrop(c, pic, RectF(0f, 0f, W.toFloat(), H.toFloat())) else gradient(c)
        val shade = Paint().apply { shader = LinearGradient(0f, H * 0.35f, 0f, H.toFloat(), Color.TRANSPARENT, Color.argb(225, 0, 0, 0), Shader.TileMode.CLAMP) }
        c.drawRect(0f, H * 0.35f, W.toFloat(), H.toFloat(), shade)
        c.drawRoundRect(RectF(64f, H - 470f, 64f + 150f, H - 420f), 25f, 25f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = teal })
        text(c, "SWIPE →", 78f, H - 462f, 140, 26f, Color.WHITE, true, 1)
        text(c, title, 64f, H - 390f, W - 128, 78f, Color.WHITE, true, 4)
        pageMark(c, 1, total, Color.argb(200, 255, 255, 255))
    }

    private fun slide(heading: String, body: String, pic: Bitmap?, n: Int, total: Int): Bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888).also { b ->
        val c = Canvas(b)
        c.drawColor(Color.WHITE)
        val split = H * 0.58f
        if (pic != null) coverCrop(c, pic, RectF(0f, 0f, W.toFloat(), split)) else {
            c.save(); c.clipRect(0f, 0f, W.toFloat(), split); gradient(c); c.restore()
        }
        var y = split + 48f
        if (heading.isNotBlank()) y = text(c, heading, 64f, y, W - 128, 50f, teal, true, 2) + 18f
        text(c, body, 64f, y, W - 128, if (body.length > 160) 38f else 44f, Color.rgb(29, 35, 43), false, if (heading.isNotBlank()) 6 else 8)
        pageMark(c, n, total, Color.rgb(120, 128, 138))
    }

    private fun ctaSlide(cta: String, total: Int): Bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888).also { b ->
        val c = Canvas(b)
        gradient(c)
        text(c, "👍  🔔  📣", 0f, H * 0.30f, W, 120f, Color.WHITE, false, 1, center = true)
        text(c, cta, 80f, H * 0.50f, W - 160, 72f, Color.WHITE, true, 3, center = true)
        pageMark(c, total, total, Color.argb(200, 255, 255, 255))
    }

    // ------------------------------------------------------------------ saving

    private fun fileStem(title: String): String {
        val t = title.replace(Regex("""[^\p{L}\p{N} _-]"""), "").trim().replace(Regex("""\s+"""), "_").take(40).ifBlank { "AVSP_blog" }
        return t + "_" + SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
    }

    private fun saveDownload(name: String, mime: String, bytes: ByteArray): Uri {
        check(Build.VERSION.SDK_INT >= 29) { "Saving blogs needs Android 10 or newer" }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/AVSP/Blogs")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        return write(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values, bytes)
    }

    private fun saveImage(name: String, bytes: ByteArray): Uri {
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/AVSP/Blog")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }
        return write(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values, bytes)
    }

    private fun write(collection: Uri, values: ContentValues, bytes: ByteArray): Uri {
        val r = context.contentResolver
        val uri = r.insert(collection, values) ?: error("Could not create the file")
        try {
            r.openOutputStream(uri, "w")?.use { it.write(bytes) } ?: error("Could not write the file")
            if (Build.VERSION.SDK_INT >= 29) r.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            return uri
        } catch (e: Exception) {
            runCatching { r.delete(uri, null, null) }
            throw e
        }
    }
}
