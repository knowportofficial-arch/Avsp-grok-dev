package com.avsp.pro.video.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File

/**
 * P2: designed scene cards used as visuals when the project has no own
 * photos/videos (instead of a black "AVSP" placeholder).
 *
 * Each card: colour gradient, scene headline (on-screen text), the spoken
 * narration as a caption box, and scene progress dots. Output is a PNG at
 * the exact render size, so M4 renders it like any image asset.
 */
object SceneCardRenderer {

    private val palettes = listOf(
        intArrayOf(0xFF1A2A6C.toInt(), 0xFFB21F1F.toInt()),
        intArrayOf(0xFF0F2027.toInt(), 0xFF2C7744.toInt()),
        intArrayOf(0xFF42275A.toInt(), 0xFF734B6D.toInt()),
        intArrayOf(0xFF134E5E.toInt(), 0xFF71B280.toInt()),
        intArrayOf(0xFF614385.toInt(), 0xFF516395.toInt()),
        intArrayOf(0xFFEB5757.toInt(), 0xFF000000.toInt()),
        intArrayOf(0xFF0B486B.toInt(), 0xFFF56217.toInt()),
        intArrayOf(0xFF2B5876.toInt(), 0xFF4E4376.toInt())
    )

    data class Card(
        val title: String,
        val headline: String,
        val narration: String,
        val index: Int,
        val count: Int,
        /** P8: the video's progress bar replaces these dots. */
        val showDots: Boolean = false,
        /** P25.1: the ending shows the channel's logo and name (when set in Settings -> Channel). */
        val brandOutro: Boolean = false
    )

    fun render(card: Card, width: Int, height: Int, output: File): File {
        output.parentFile?.mkdirs()
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        try {
            val canvas = Canvas(bitmap)
            val brand = card.brandOutro && (com.avsp.pro.settings.BrandKit.hasLogo() || com.avsp.pro.settings.BrandKit.channel.isNotBlank())
            val colors = if (brand) intArrayOf(0xFF14184A.toInt(), 0xFF0EB2AA.toInt()) else palettes[card.index % palettes.size]
            val bg = Paint().apply {
                shader = LinearGradient(0f, 0f, width * 0.3f, height.toFloat(), colors[0], colors[1], Shader.TileMode.CLAMP)
            }
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)

            // Soft decorative circles.
            val deco = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; alpha = 22 }
            canvas.drawCircle(width * 0.85f, height * 0.12f, width * 0.35f, deco)
            canvas.drawCircle(width * 0.1f, height * 0.88f, width * 0.45f, deco)

            val margin = width * 0.08f
            val textWidth = (width - 2 * margin).toInt()

            if (brand) {
                // Logo + channel name above the Like • Follow • Share line (drawn later at ~42-50 % height).
                val size = (minOf(width, height) * 0.30f).toInt()
                com.avsp.pro.settings.BrandKit.logoAt(size)?.let { logo ->
                    canvas.drawBitmap(logo, (width - logo.width) / 2f, height * 0.10f, Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG))
                }
                val name = com.avsp.pro.settings.BrandKit.channel
                if (name.isNotBlank()) {
                    val np = textPaint(width * 0.085f, bold = true).apply { setShadowLayer(10f, 0f, 3f, 0x88000000.toInt()) }
                    drawBlock(canvas, name, np, margin, height * 0.10f + size + height * 0.02f, textWidth, 1)
                }
                output.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
                return output
            }

            // Title (small, top).
            if (card.title.isNotBlank()) {
                val tp = textPaint(width * 0.040f, bold = true, alpha = 210)
                drawBlock(canvas, card.title.uppercase(), tp, margin, height * 0.08f, textWidth, 2)
            }

            // Headline (big, centre).
            val headline = card.headline.ifBlank { card.narration.split(Regex("(?<=[.!?])\\s+")).firstOrNull().orEmpty() }
            val hp = textPaint(width * 0.095f, bold = true).apply { setShadowLayer(12f, 0f, 4f, 0x99000000.toInt()) }
            val hl = layout(headline, hp, textWidth, 4, Layout.Alignment.ALIGN_CENTER)
            canvas.save()
            canvas.translate(margin, height * 0.36f - hl.height / 2f)
            hl.draw(canvas)
            canvas.restore()

            // Narration caption box (lower third).
            if (card.narration.isNotBlank()) {
                val np = textPaint(width * 0.046f, bold = false)
                val pad = width * 0.04f
                val nl = layout(card.narration, np, textWidth - (2 * pad).toInt(), 7, Layout.Alignment.ALIGN_CENTER)
                val boxTop = height * 0.60f
                val box = RectF(margin, boxTop, width - margin, boxTop + nl.height + 2 * pad)
                val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; alpha = 120 }
                canvas.drawRoundRect(box, width * 0.04f, width * 0.04f, boxPaint)
                canvas.save()
                canvas.translate(margin + pad, boxTop + pad)
                nl.draw(canvas)
                canvas.restore()
            }

            // Progress dots.
            if (card.count > 1 && card.showDots) {
                val r = width * 0.011f
                val gap = r * 3.2f
                val total = gap * (card.count - 1)
                val y = height * 0.93f
                val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
                for (i in 0 until card.count) {
                    dot.alpha = if (i == card.index) 255 else 90
                    canvas.drawCircle(width / 2f - total / 2f + i * gap, y, r, dot)
                }
            }

            output.outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } finally {
            bitmap.recycle()
        }
        return output
    }

    private fun textPaint(size: Float, bold: Boolean, alpha: Int = 255) =
        TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            this.alpha = alpha
            textSize = size
            typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

    private fun layout(text: String, paint: TextPaint, width: Int, maxLines: Int, align: Layout.Alignment): StaticLayout =
        StaticLayout.Builder.obtain(text, 0, text.length, paint, width.coerceAtLeast(50))
            .setAlignment(align)
            .setMaxLines(maxLines)
            .setEllipsize(android.text.TextUtils.TruncateAt.END)
            .setLineSpacing(0f, 1.1f)
            .build()

    private fun drawBlock(canvas: Canvas, text: String, paint: TextPaint, x: Float, y: Float, width: Int, maxLines: Int) {
        val l = layout(text, paint, width, maxLines, Layout.Alignment.ALIGN_CENTER)
        canvas.save()
        canvas.translate(x, y)
        l.draw(canvas)
        canvas.restore()
    }
}
