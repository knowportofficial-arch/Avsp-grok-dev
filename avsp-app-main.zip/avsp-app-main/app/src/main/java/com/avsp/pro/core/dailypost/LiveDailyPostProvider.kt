package com.avsp.pro.core.dailypost
import android.text.Html

import android.util.Xml
import com.avsp.pro.ui.screens.dailypost.DailyPostCategory
import com.avsp.pro.ui.screens.dailypost.DailyPostGeography
import com.avsp.pro.ui.screens.dailypost.DailyPostItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.time.LocalDate
import java.time.ZoneId

/**
 * Real network-backed Daily Post provider.
 *
 * Sources:
 * 1. Google News RSS search feeds for current news discovery.
 * 2. Wikipedia REST On-This-Day feed for historical events.
 * 3. Wikimedia Pageviews top endpoint for most-viewed/trending discovery.
 *
 * No article is fabricated. If a remote source fails, that source contributes
 * zero items and the remaining sources continue.
 */
class LiveDailyPostProvider : DailyPostProvider {

    override suspend fun load(): List<DailyPostItem> = withContext(Dispatchers.IO) {
        // P11: every source in parallel, each with its own cap, so no category is crowded out.
        kotlinx.coroutines.coroutineScope {
            val jobs = listOf(
                async { loadNews("Kharagpur West Bengal when:1d", DailyPostGeography.LOCAL).take(6) },
                async { safe { loadWeather() } },
                async { safe { loadWhyToday() }.take(8) },
                async { safe { loadTrending() }.take(8) },
                async { loadNews("India when:1d", DailyPostGeography.NATIONAL).take(6) },
                async { safe { loadHistory() }.take(8) },
                async { safe { loadRashifal() } },
                async { safe { loadJokes() }.take(8) },
                async { loadNews("world when:1d", DailyPostGeography.INTERNATIONAL).take(6) }
            )
            jobs.flatMap { it.await() }
        }
        .filter {
            it.title.isNotBlank() &&
            it.date.isNotBlank() &&
            it.source.isNotBlank()
        }
        .distinctBy { it.id }
        .take(MAX_ITEMS)
    }

    private inline fun safe(block: () -> List<DailyPostItem>): List<DailyPostItem> = runCatching(block).getOrDefault(emptyList())

    private fun today(): LocalDate = LocalDate.now(ZoneId.of("Asia/Kolkata"))
    private fun dateLabel(d: LocalDate = today()) = "${d.dayOfMonth}/${d.monthValue}/${d.year}"

    /** P11: weather for the chosen city (Open-Meteo, no key). */
    private fun loadWeather(): List<DailyPostItem> {
        val city = DailySettings.city()
        val w = DailyTopics.weatherReport(readText(DailyTopics.forecastUrl(city)), city.name)
        return listOf(
            DailyPostItem(
                id = "weather:${city.name}:${today()}",
                title = w.title,
                category = DailyPostCategory.WEATHER,
                geography = DailyPostGeography.LOCAL,
                date = dateLabel(),
                source = "Open-Meteo forecast",
                summary = w.text,
                relevance = "Today's forecast for ${city.name}.",
                videoAngle = "Short, friendly weather update with a practical tip."
            )
        )
    }

    /** P11: today's rashifal - all signs in one video, and each sign separately. Made on the phone, for entertainment. */
    private fun loadRashifal(): List<DailyPostItem> {
        val d = today()
        val all = DailyPostItem(
            id = "rashifal:all:$d",
            title = "Today's Rashifal: all 12 signs",
            category = DailyPostCategory.RASHIFAL,
            geography = DailyPostGeography.NATIONAL,
            date = dateLabel(d),
            source = "AVSP daily horoscope (for entertainment)",
            summary = DailyTopics.rashifalAll(d),
            relevance = "Daily horoscope - for entertainment only.",
            videoAngle = "Quick sign-by-sign horoscope, light and positive."
        )
        return listOf(all) + DailyTopics.SIGNS.indices.map { i ->
            val s = DailyTopics.SIGNS[i]
            DailyPostItem(
                id = "rashifal:${s.en}:$d",
                title = "${s.glyph} ${s.en} (${s.hi} / ${s.bn}) - today's rashifal",
                category = DailyPostCategory.RASHIFAL,
                geography = DailyPostGeography.NATIONAL,
                date = dateLabel(d),
                source = "AVSP daily horoscope (for entertainment)",
                summary = DailyTopics.rashifal(d, i),
                relevance = "Daily horoscope - for entertainment only.",
                videoAngle = "Friendly horoscope for one sign with lucky colour and number."
            )
        }
    }

    /** P11: clean jokes (JokeAPI safe-mode) + a built-in set that also works offline. */
    private fun loadJokes(): List<DailyPostItem> {
        val online = runCatching { DailyTopics.parseJokes(readText(DailyTopics.JOKE_URL)) }.getOrDefault(emptyList())
        val d = today()
        val builtIn = DailyTopics.BUILT_IN_JOKES.let { list -> list.indices.map { list[(it + d.dayOfYear) % list.size] } }
        return (online.map { it to "JokeAPI (safe mode)" } + builtIn.map { it to "AVSP joke collection" }).distinctBy { it.first }
            .mapIndexed { i, (joke, source) ->
                DailyPostItem(
                    id = "joke:$d:${joke.hashCode()}",
                    title = "Joke of the day ${i + 1}: " + joke.take(48).let { if (joke.length > 48) "$it…" else it },
                    category = DailyPostCategory.JOKES,
                    geography = DailyPostGeography.INTERNATIONAL,
                    date = dateLabel(d),
                    source = source,
                    summary = joke,
                    relevance = "Light entertainment.",
                    videoAngle = "Tell the joke with good timing; the punchline gets its own scene."
                )
            }
    }



    private fun normalizeRssText(raw: String): String {
        if (raw.isBlank()) return ""

        return Html.fromHtml(
            raw,
            Html.FROM_HTML_MODE_LEGACY
        )
            .toString()
            .replace('\u00A0', ' ')
            .replace(Regex("""\s+"""), " ")
            .trim()
    }
    private fun loadNews(
        query: String,
        geography: DailyPostGeography
    ): List<DailyPostItem> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val url =
            "https://news.google.com/rss/search?q=$encoded&hl=en-IN&gl=IN&ceid=IN:en"

        return runCatching {
            val connection = open(url)

            try {
                if (connection.responseCode !in 200..299) return emptyList()

                val parser = Xml.newPullParser()
                parser.setInput(connection.inputStream, "UTF-8")

                val items = mutableListOf<DailyPostItem>()

                var event = parser.eventType
                var insideItem = false
                var currentTag = ""

                var title = ""
                var link = ""
                var date = ""
                var description = ""
                var source = ""

                while (event != XmlPullParser.END_DOCUMENT) {
                    when (event) {
                        XmlPullParser.START_TAG -> {
                            currentTag = parser.name

                            if (
                                parser.name.equals("item", true) ||
                                parser.name.equals("entry", true)
                            ) {
                                insideItem = true
                                title = ""
                                link = ""
                                date = ""
                                description = ""
                                source = ""
                            }
                        }

                        XmlPullParser.TEXT -> {
                            if (insideItem) {
                                when (currentTag.lowercase()) {
                                    "title" -> title += parser.text
                                    "link" -> link += parser.text
                                    "pubdate",
                                    "published",
                                    "updated",
                                    "dc:date" -> date += parser.text
                                    "description",
                                    "summary",
                                    "content" -> description += parser.text
                                    "source" -> source += parser.text
                                }
                            }
                        }

                        XmlPullParser.END_TAG -> {
                            val tag = parser.name.lowercase()

                            if (
                                (tag == "item" || tag == "entry") &&
                                insideItem
                            ) {
                                val cleanTitle = normalizeRssText(title)
                                val cleanDescription = normalizeRssText(description)
                                val cleanSource = normalizeRssText(source)

                                if (
                                    cleanTitle.isNotBlank() &&
                                    date.trim().isNotBlank() &&
                                    cleanSource.isNotBlank()
                                ) {
                                    items += DailyPostItem(
                                        id = "news:${geography.name}:${cleanTitle.hashCode()}",
                                        title = cleanTitle,
                                        category = DailyPostCategory.NEWS,
                                        geography = geography,
                                        date = date.trim(),
                                        source = cleanSource,
                                        summary = cleanDescription.take(900),
                                        relevance = when (geography) {
                                            DailyPostGeography.LOCAL ->
                                                "Regional relevance for Kharagpur / West Bengal."
                                            DailyPostGeography.NATIONAL ->
                                                "Potential relevance to India."
                                            DailyPostGeography.INTERNATIONAL ->
                                                "Potential international relevance."
                                        },
                                        videoAngle =
                                            "Explain what happened, the verified source, why it matters, and the key visual evidence."
                                    )
                                }

                                insideItem = false
                            }

                            currentTag = ""
                        }
                    }

                    event = parser.next()
                }

                items.take(MAX_NEWS_PER_FEED)
            } finally {
                connection.disconnect()
            }
        }.getOrDefault(emptyList())
    }

    private fun loadHistory(): List<DailyPostItem> {
        val date = LocalDate.now(ZoneId.of("Asia/Kolkata"))
        val month = "%02d".format(date.monthValue)
        val day = "%02d".format(date.dayOfMonth)

        val url =
            "https://en.wikipedia.org/api/rest_v1/feed/onthisday/events/$month/$day"

        return runCatching {
            val json = JSONObject(readText(url))
            val events = json.optJSONArray("events") ?: return emptyList()

            buildList {
                for (i in 0 until minOf(events.length(), 10)) {
                    val event = events.optJSONObject(i) ?: continue
                    val year = event.optInt("year", 0)
                    val text = clean(event.optString("text"))

                    if (text.isBlank()) continue

                    val pages = event.optJSONArray("pages")
                    val firstPage = pages?.optJSONObject(0)
                    val extract = clean(
                        firstPage?.optString("extract").orEmpty()
                    )

                    add(
                        DailyPostItem(
                            id = "history:$month-$day:$year:$i",
                            title = text,
                            category = DailyPostCategory.HISTORY,
                            geography = DailyPostGeography.INTERNATIONAL,
                            date = "${date.dayOfMonth}/${date.monthValue}/${date.year}",
                            source = "Wikipedia On This Day",
                            summary = extract.ifBlank {
                                "Historical event recorded for this date in Wikipedia."
                            }.take(900),
                            relevance =
                                "This event occurred on this calendar date and is included as a historical reference.",
                            videoAngle =
                                "Explain what happened in $year, the historical context, and why this date is remembered."
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    /** P11: today's observances (World Post Day, national days…) first, then selected anniversaries. */
    private fun loadWhyToday(): List<DailyPostItem> {
        val d = today()
        val days = runCatching { DailyTopics.rankObservances(DailyTopics.parseHolidays(readText(DailyTopics.holidaysUrl(d)))) }.getOrDefault(emptyList())
        val observances = days.take(5).mapIndexed { i, o ->
            DailyPostItem(
                id = "observance:$d:$i",
                title = "Today is ${o.name}",
                category = DailyPostCategory.WHY_TODAY,
                geography = if (o.name.contains("India", true)) DailyPostGeography.NATIONAL else DailyPostGeography.INTERNATIONAL,
                date = dateLabel(d),
                source = "Wikipedia - holidays and observances",
                summary = (if (o.about.isNotBlank()) "Today is ${o.name}. ${o.about}" else "Today is ${o.name}.").take(900),
                relevance = "Observed on this date.",
                videoAngle = "Explain what this day is, why it is observed and one thing viewers can do today."
            )
        }
        return observances + runCatching { loadSelectedAnniversaries() }.getOrDefault(emptyList())
    }

    private fun loadSelectedAnniversaries(): List<DailyPostItem> {
        val date = LocalDate.now(ZoneId.of("Asia/Kolkata"))
        val month = "%02d".format(date.monthValue)
        val day = "%02d".format(date.dayOfMonth)

        val url =
            "https://en.wikipedia.org/api/rest_v1/feed/onthisday/selected/$month/$day"

        return runCatching {
            val json = JSONObject(readText(url))
            val selected = json.optJSONArray("selected") ?: return emptyList()

            buildList {
                for (i in 0 until minOf(selected.length(), 6)) {
                    val event = selected.optJSONObject(i) ?: continue
                    val year = event.optInt("year", 0)
                    val text = clean(event.optString("text"))

                    if (text.isBlank()) continue

                    val pages = event.optJSONArray("pages")
                    val firstPage = pages?.optJSONObject(0)
                    val extract = clean(
                        firstPage?.optString("extract").orEmpty()
                    )

                    add(
                        DailyPostItem(
                            id = "why:${month}-${day}:$year:$i",
                            title = text,
                            category = DailyPostCategory.WHY_TODAY,
                            geography = DailyPostGeography.INTERNATIONAL,
                            date = "${date.dayOfMonth}/${date.monthValue}/${date.year}",
                            source = "Wikipedia Selected Anniversaries",
                            summary = extract.ifBlank {
                                "Selected anniversary/event associated with this date."
                            }.take(900),
                            relevance =
                                "This date has a documented historical significance.",
                            videoAngle =
                                "Tell the story behind this date, explain its significance, and connect the historical event to today."
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    /** P11: what India is searching today (Google Trends daily RSS); Wikipedia most-viewed as fallback. */
    private fun loadTrending(): List<DailyPostItem> {
        val d = today()
        val trends = runCatching { DailyTopics.parseTrends(readText(DailyTopics.TRENDS_URL)) }.getOrDefault(emptyList())
        if (trends.isEmpty()) return loadWikiMostViewed()
        return trends.take(10).map { t ->
            DailyPostItem(
                id = "trend:$d:${t.title}",
                title = t.title + (if (t.traffic.isNotBlank()) " (${t.traffic} searches)" else ""),
                category = DailyPostCategory.TRENDING,
                geography = DailyPostGeography.NATIONAL,
                date = dateLabel(d),
                source = "Google Trends India" + (if (t.newsSource.isNotBlank()) " · ${t.newsSource}" else ""),
                summary = listOf(t.newsTitle, t.newsSnippet).filter { it.isNotBlank() }.joinToString(". ")
                    .ifBlank { "${t.title} is trending in India today." },
                relevance = "Trending search in India today - verify details before posting.",
                videoAngle = "Say why people are searching for this today, using only the reported facts."
            )
        }
    }

    private fun loadWikiMostViewed(): List<DailyPostItem> {
        /*
         * Wikimedia Pageviews data is generally delayed, so use the previous
         * completed day rather than falsely claiming today's counts.
         */
        val date = LocalDate.now(ZoneId.of("Asia/Kolkata")).minusDays(1)

        val year = date.year
        val month = "%02d".format(date.monthValue)
        val day = "%02d".format(date.dayOfMonth)

        val url =
            "https://wikimedia.org/api/rest_v1/metrics/pageviews/top/en.wikipedia/all-access/$year/$month/$day"

        return runCatching {
            val json = JSONObject(readText(url))
            val items = json.optJSONArray("items")
                ?: return emptyList()

            val dayItem = items.optJSONObject(0)
                ?: return emptyList()

            val articles = dayItem.optJSONArray("articles")
                ?: return emptyList()

            buildList {
                for (i in 0 until minOf(articles.length(), 10)) {
                    val article = articles.optJSONObject(i) ?: continue
                    val title = clean(article.optString("article"))
                    val views = article.optLong("views", 0)

                    if (
                        title.isBlank() ||
                        title == "Main_Page" ||
                        title.startsWith("Special:")
                    ) continue

                    add(
                        DailyPostItem(
                            id = "trending:$year-$month-$day:$title",
                            title = title.replace('_', ' '),
                            category = DailyPostCategory.TRENDING,
                            geography = DailyPostGeography.INTERNATIONAL,
                            date = "$day/$month/$year",
                            source = "Wikimedia Pageviews",
                            summary =
                                "Most-viewed English Wikipedia page in the completed reporting period. Pageviews: $views.",
                            relevance =
                                "This is a measurable attention signal, not a claim that the topic is factual news.",
                            videoAngle =
                                "Use the topic as a discovery lead, verify the underlying facts independently, then explain the key story."
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    private fun readText(url: String): String {
        val connection = open(url)

        return try {
            if (connection.responseCode !in 200..299) {
                throw IllegalStateException(
                    "HTTP ${connection.responseCode}"
                )
            }

            connection.inputStream.bufferedReader(Charsets.UTF_8).use {
                it.readText()
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun open(url: String): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            requestMethod = "GET"
            setRequestProperty(
                "User-Agent",
                "AVSP/1.0 (AI Video Studio Pro; Daily Post)"
            )
            setRequestProperty("Accept", "*/*")
        }

    private fun clean(value: String): String =
        value
            .replace(Regex("<[^>]*>"), " ")
            .replace("&amp;", "&")
            .replace("&quot;", "\"")
            .replace("&#39;", "'")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace(Regex("\\s+"), " ")
            .trim()

    companion object {
        private const val CONNECT_TIMEOUT_MS = 8000
        private const val READ_TIMEOUT_MS = 12000
        private const val MAX_NEWS_PER_FEED = 8
        private const val MAX_ITEMS = 90
    }
}
