package com.avsp.pro.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avsp.pro.core.contracts.MediaAsset
import com.avsp.pro.core.pipeline.AutoProducer
import com.avsp.pro.core.pipeline.PublishKit
import com.avsp.pro.logs.AvspLogger
import com.avsp.pro.repository.ProjectRepository
import com.avsp.pro.script.contract.ScriptPackage
import com.avsp.pro.script.contract.ScriptScene
import com.avsp.pro.script.repository.ScriptRepository
import com.avsp.pro.storage.AvspStorage
import com.avsp.pro.storage.StorageArea
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Where a scene's picture comes from (manual mode, step 3). */
sealed class SceneVisual(val label: String) {
    data object Auto : SceneVisual("Auto animation")
    data object Stock : SceneVisual("Free stock video")
    data class Picked(val uri: Uri, val mime: String, val fromCamera: Boolean, val speed: Float = 1f) :
        SceneVisual(if (fromCamera) "Your camera shot" else "From your phone")
}

data class ManualState(
    val step: Int = 1,                       // 1 topic, 2 script, 3 scenes/visuals, 4 making / done
    val topic: String = "",
    val seconds: Int = 60,
    val script: ScriptPackage? = null,
    val visuals: Map<String, SceneVisual> = emptyMap(),
    val busy: String? = null,
    val error: String? = null,
    val result: AutoProduceState.Done? = null,
    // P20 Plan & shoot
    val shots: List<com.avsp.pro.capture.ShotSpec>? = null,
    val shotsByAi: Boolean = false,
    val shooting: Boolean = false,
    val portrait: Boolean = true,
    val language: String = "English",
    // P22.4 picture preview: the picture each "Free stock" scene will show, before the video is made.
    val pictures: Map<String, AutoProducer.ScenePicture> = emptyMap(),
    val swapping: String? = null,
    val note: String? = null,
    // P23 own voice
    val voiceTake: VoiceTake? = null,
    val ownVoiceScenes: Set<String> = emptySet(),
    val languageCode: String = "en",
    // P28 event mode: "📍 ABC pandal, Kumartuli · Maha Ashtami"
    val eventLabel: String? = null
)

/** P23: one own-voice take for a scene - recording, then reading the words, then the choice. */
data class VoiceTake(val sceneId: String, val recording: Boolean, val reading: Boolean = false,
                     val text: String = "", val seconds: Int = 0, val error: String? = null)

/**
 * P7 MANUAL MODE: topic -> script (prefilled, editable) -> scene by scene:
 * intro from the topic, outro = short CTA (< 5 s), each scene's picture from
 * free stock, the phone (gallery / Google Photos), the camera, or an automatic
 * animation -> voice -> video.
 */
class ManualViewModel(
    private val projectRepository: ProjectRepository,
    private val scriptRepository: ScriptRepository,
    private val storage: AvspStorage,
    private val logger: AvspLogger,
    private val autoProducer: AutoProducer,
    private val appContext: Context,
    private val geminiKeys: () -> List<String> = { emptyList() }
) : ViewModel() {

    private val _state = MutableStateFlow(ManualState())
    val state: StateFlow<ManualState> = _state.asStateFlow()
    private var projectId: String = ""

    fun load(projectId: String) {
        if (this.projectId == projectId) return
        this.projectId = projectId
        viewModelScope.launch {
            runCatching { projectRepository.openProject(projectId) }.onSuccess { p ->
                event = com.avsp.pro.capture.EventInfo.fromMetadata(p.metadata)
                com.avsp.pro.capture.EventLocation.forCapture = event?.let { e ->
                    if (e.latitude == null || e.longitude == null) null
                    else android.location.Location("avsp").apply { latitude = e.latitude; longitude = e.longitude; time = System.currentTimeMillis() }
                }
                _state.update { it.copy(topic = AutoProducer.topicFor(p), portrait = p.aspectRatio.height >= p.aspectRatio.width, language = p.language.displayName, languageCode = p.language.code,
                    eventLabel = event?.let { e -> "📍 " + listOf(e.what, e.place).filter { s -> s.isNotBlank() }.joinToString(", ") + (e.day?.let { d -> " · $d" } ?: "") }) }
            }
        }
    }

    fun setTopic(t: String) = _state.update { it.copy(topic = t) }
    fun setSeconds(s: Int) = _state.update { it.copy(seconds = s) }
    fun back() = _state.update { it.copy(step = (it.step - 1).coerceAtLeast(1), error = null) }
    fun clearError() = _state.update { it.copy(error = null) }

    /** Step 1 -> 2 */
    fun writeScript() = work("Writing the script…") {
        val s = _state.value
        val script = autoProducer.writeScript(projectId, s.topic, s.seconds)
        _state.update { it.copy(script = script, step = 2, visuals = script.scenes.associate { sc -> sc.sceneId to SceneVisual.Auto },
            pictures = emptyMap(), ownVoiceScenes = emptySet(), voiceTake = null) }
    }

    fun editScene(sceneId: String, narration: String? = null, onScreen: String? = null, bRoll: String? = null) {
        _state.update { st ->
            val script = st.script ?: return@update st
            st.copy(script = script.copy(scenes = script.scenes.map { sc ->
                if (sc.sceneId != sceneId) sc
                else sc.copy(
                    narration = narration ?: sc.narration,
                    onScreenText = onScreen ?: sc.onScreenText,
                    bRollSuggestion = bRoll ?: sc.bRollSuggestion
                )
            }))
        }
    }

    fun setTitle(title: String) = _state.update { st -> st.copy(script = st.script?.copy(title = title)) }

    /** Outro is only the call to action. */
    fun setCta(text: String) {
        val script = _state.value.script ?: return
        val last = script.scenes.maxByOrNull { it.order } ?: return
        editScene(last.sceneId, narration = text, onScreen = text.trimEnd('.', '!'))
        _state.update { st -> st.copy(script = st.script?.copy(cta = text)) }
    }

    /** P20: a camera task for every scene (Gemini, or made on the phone). */
    fun planShots() = work("Planning the shoot…") {
        val st = _state.value
        val script = st.script ?: error("No script")
        val (plan, byAi) = withContext(Dispatchers.IO) {
            com.avsp.pro.capture.ShotPlanner.make(st.topic.ifBlank { script.topic }, script.scenes, st.language, runCatching { geminiKeys() }.getOrDefault(emptyList()))
        }
        // P21.3: fit the plan to THIS phone - no 0.5x ultra-wide open to apps -> main lens + step back.
        val fitted = if (hasUltraWide()) plan else plan.map { sh ->
            if (sh.lens != com.avsp.pro.capture.Lens.ULTRA_WIDE) sh
            else sh.copy(lens = com.avsp.pro.capture.Lens.MAIN, instruction = sh.instruction + " (step back to fit more in)")
        }
        logger.info("MANUAL", "Shot list: ${fitted.size} shots (${if (byAi) "Gemini" else "phone"})", projectId = projectId)
        _state.update { it.copy(shots = fitted, shotsByAi = byAi) }
    }

    private fun hasUltraWide(): Boolean = runCatching {
        if (android.os.Build.VERSION.SDK_INT < 30) return@runCatching false
        val m = appContext.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
        m.cameraIdList.any { id ->
            val c = m.getCameraCharacteristics(id)
            c.get(android.hardware.camera2.CameraCharacteristics.LENS_FACING) == android.hardware.camera2.CameraCharacteristics.LENS_FACING_BACK &&
                (c.get(android.hardware.camera2.CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)?.lower ?: 1f) < 0.99f
        }
    }.getOrDefault(false)

    fun startShooting() = _state.update { if (it.shots.isNullOrEmpty()) it else it.copy(shooting = true) }
    fun stopShooting() = _state.update { it.copy(shooting = false) }

    /** The shot list as a guided-camera session (one clip per scene, in order). */
    fun shootTemplate(): com.avsp.pro.m7.capture.camera.guided.GuidedCaptureTemplate? {
        val st = _state.value
        val shots = st.shots?.takeIf { it.isNotEmpty() } ?: return null
        val order = st.script?.scenes?.sortedBy { it.order }?.map { it.sceneId }.orEmpty()
        val aspect = if (st.portrait) com.avsp.pro.m7.capture.camera.model.CameraAspectRatio.PORTRAIT_9_16 else com.avsp.pro.m7.capture.camera.model.CameraAspectRatio.LANDSCAPE_16_9
        val orientation = if (st.portrait) com.avsp.pro.m7.capture.camera.model.CaptureOrientation.PORTRAIT else com.avsp.pro.m7.capture.camera.model.CaptureOrientation.LANDSCAPE
        return com.avsp.pro.m7.capture.camera.guided.GuidedCaptureTemplate(
            templateName = "Plan & shoot",
            clips = shots.map { s ->
                val n = order.indexOf(s.sceneId)
                com.avsp.pro.m7.capture.camera.guided.GuidedClipSpec(
                    clipId = "scene_${s.sceneId}",
                    clipName = if (n == 0) "Intro" else "Scene $n",
                    category = s.framing.label,
                    targetDurationSeconds = s.seconds.coerceAtLeast(1),
                    aspectRatio = aspect,
                    orientation = orientation,
                    resolution = if (s.uhd) com.avsp.pro.m7.capture.camera.model.CameraResolution.UHD_4K else com.avsp.pro.m7.capture.camera.model.CameraResolution.FULL_HD_1080,
                    frameRate = if (s.fps >= 60) com.avsp.pro.m7.capture.camera.model.CameraFrameRate.FPS_60 else com.avsp.pro.m7.capture.camera.model.CameraFrameRate.FPS_30,
                    mediaType = if (s.video) com.avsp.pro.m7.capture.camera.guided.GuidedClipMediaType.VIDEO else com.avsp.pro.m7.capture.camera.guided.GuidedClipMediaType.PHOTO,
                    timerSeconds = if (s.lens.front) 3 else 0,
                    sceneId = s.sceneId,
                    instruction = s.instruction,
                    zoomRatio = if (s.lens.front) null else s.lens.zoom,
                    frontCamera = s.lens.front,
                    movement = s.movement.label,
                    slowMotion = s.slowMotion,
                    stabilize = s.stabilize
                )
            }
        )
    }

    /**
     * P20: shots come back from the guided camera. Filmed scenes use the shot; scenes not
     * filmed get the automatic chain (your phone gallery if on -> free clips/photos -> card).
     * The originals are also kept in the phone gallery (Movies/AVSP/Shoot, Pictures/AVSP/Shoot).
     */
    fun onShots(clips: List<com.avsp.pro.m7.capture.camera.guided.ClipMetadata>) {
        _state.update { it.copy(shooting = false, busy = "Checking your shots…") }
        viewModelScope.launch {
            val st = _state.value
            val shots = st.shots.orEmpty()
            val found = shots.associate { s ->
                val clip = clips.firstOrNull { it.clipId == "scene_${s.sceneId}" }
                s.sceneId to (clip to clip?.file?.let { java.io.File(it) }?.takeIf { it.exists() && it.length() > 0 })
            }
            // P21.6: a black shot (lens covered / phone face down) is not used - the scene is filled automatically.
            val dark = withContext(Dispatchers.IO) { found.filterValues { (_, f) -> f != null && tooDark(f) }.keys }
            shots.forEach { s ->
                val (clip, file) = found[s.sceneId] ?: (null to null)
                if (clip != null && file != null && s.sceneId !in dark) {
                    val video = file.extension.equals("mp4", true)
                    val speed = if (video && s.slowMotion) com.avsp.pro.capture.ShotPlanner.slowSpeed(clip.fps) else 1f
                    chooseVisual(s.sceneId, SceneVisual.Picked(Uri.fromFile(file), if (video) "video/mp4" else "image/jpeg", fromCamera = true, speed = speed))
                } else if (st.visuals[s.sceneId] !is SceneVisual.Picked) {
                    chooseVisual(s.sceneId, SceneVisual.Stock)
                }
            }
            if (dark.isNotEmpty()) logger.warning("MANUAL", "${dark.size} shot(s) too dark - filled automatically", projectId = projectId)
            _state.update { it.copy(busy = null, error = if (dark.isNotEmpty()) "${dark.size} shot(s) were too dark (lens covered?) - those scenes are filled automatically. Film again to replace them." else null) }
            val files = clips.mapNotNull { c -> java.io.File(c.file).takeIf { it.exists() } }
            if (files.isNotEmpty()) launch(Dispatchers.IO) { files.forEach { keepInGallery(it) } }
            logger.info("MANUAL", "Shoot done: ${clips.size - dark.size} of ${shots.size} scenes filmed", projectId = projectId)
        }
    }

    /** Average brightness of a few frames (or the photo) below ~6 %: lens covered or pointing at a dark surface. */
    private fun tooDark(file: java.io.File): Boolean = runCatching {
        val frames = if (file.extension.equals("mp4", true)) {
            val r = android.media.MediaMetadataRetriever()
            try {
                r.setDataSource(file.absolutePath)
                val dur = r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                listOf(0.2, 0.5, 0.8).mapNotNull { f -> r.getFrameAtTime((dur * f * 1000).toLong(), android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { android.graphics.Bitmap.createScaledBitmap(it, 64, 64, false) } }
            } finally { r.release() }
        } else listOfNotNull(android.graphics.BitmapFactory.decodeFile(file.absolutePath, android.graphics.BitmapFactory.Options().apply { inSampleSize = 16 }))
        if (frames.isEmpty()) return@runCatching false
        val mean = frames.map { b ->
            var sum = 0L; var n = 0
            for (y in 0 until b.height step 4) for (x in 0 until b.width step 4) {
                val c = b.getPixel(x, y); sum += ((c shr 16 and 0xff) * 3 + (c shr 8 and 0xff) * 6 + (c and 0xff)) / 10; n++
            }
            if (n == 0) 255.0 else sum.toDouble() / n
        }.average()
        mean < 15.0
    }.getOrDefault(false)

    private var event: com.avsp.pro.capture.EventInfo? = null
    private var eventShotNo = 0

    private fun keepInGallery(file: java.io.File) {
        runCatching {
            val video = file.extension.equals("mp4", true)
            val ev = event
            // P28: event shots are named and filed by date, festival day and place.
            val name = ev?.fileName(++eventShotNo, video) ?: "AVSP_shoot_${System.currentTimeMillis()}.${if (video) "mp4" else "jpg"}"
            val folder = ev?.let { (if (video) "Movies" else "Pictures") + "/AVSP/Events/" + it.folder } ?: (if (video) "Movies/AVSP/Shoot" else "Pictures/AVSP/Shoot")
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, if (video) "video/mp4" else "image/jpeg")
                if (android.os.Build.VERSION.SDK_INT >= 29) put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, folder)
                ev?.let { e -> put(android.provider.MediaStore.MediaColumns.TITLE, listOfNotNull(e.what.ifBlank { null }, e.place.ifBlank { null }, e.day).joinToString(" · ")) }
            }
            if (android.os.Build.VERSION.SDK_INT < 29) return
            val uri = appContext.contentResolver.insert(
                if (video) android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI else android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
            ) ?: return
            appContext.contentResolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
        }.onFailure { logger.warning("MANUAL", "Shot not copied to the gallery", details = it.message, projectId = projectId) }
    }

    /** Step 2 -> 3 */
    fun toScenes() = _state.update { it.copy(step = 3) }

    fun chooseVisual(sceneId: String, v: SceneVisual) = _state.update { it.copy(visuals = it.visuals + (sceneId to v)) }

    // ---------------- P23 own voice ----------------
    private var recorder: com.avsp.pro.audio.OwnVoice.Recorder? = null
    private var takeWav: ByteArray? = null

    fun startVoice(sceneId: String) {
        if (_state.value.script == null) return
        val r = com.avsp.pro.audio.OwnVoice.Recorder()
        if (!r.start()) { _state.update { it.copy(voiceTake = VoiceTake(sceneId, false, error = "Microphone could not start - allow the microphone for AVSP.")) }; return }
        recorder = r; takeWav = null
        _state.update { it.copy(voiceTake = VoiceTake(sceneId, recording = true)) }
        viewModelScope.launch {
            while (recorder === r && _state.value.voiceTake?.recording == true) {
                _state.update { st -> st.copy(voiceTake = st.voiceTake?.copy(seconds = (r.elapsedMs / 1000).toInt())) }
                kotlinx.coroutines.delay(250)
            }
        }
    }

    /** Stop -> the words are read from the recording (Gemini) so captions match what was said. */
    fun stopVoice() {
        val r = recorder ?: return
        recorder = null
        val take = _state.value.voiceTake ?: return
        _state.update { it.copy(voiceTake = take.copy(recording = false, reading = true)) }
        viewModelScope.launch {
            val wav = withContext(Dispatchers.IO) { r.stop() }
            if (wav == null) { _state.update { it.copy(voiceTake = take.copy(recording = false, reading = false, error = "Nothing was heard - try again, closer to the phone.")) }; return@launch }
            takeWav = wav
            val text = withContext(Dispatchers.IO) {
                runCatching { com.avsp.pro.audio.OwnVoice.transcribe(wav, _state.value.languageCode, geminiKeys) }.getOrNull()
            }
            val current = _state.value.script?.scenes?.firstOrNull { it.sceneId == take.sceneId }?.narration.orEmpty()
            _state.update { it.copy(voiceTake = take.copy(recording = false, reading = false,
                seconds = (com.avsp.pro.audio.engine.SmartVoiceEngine.durationMs(wav) / 1000).toInt(),
                text = text ?: current,
                error = if (text == null) "Words could not be read (no Gemini key or no internet) - type them below so the captions match." else null)) }
        }
    }

    fun setVoiceText(t: String) = _state.update { it.copy(voiceTake = it.voiceTake?.copy(text = t)) }

    /** Keep the recording as this scene's voice; the words become its narration + caption. */
    fun useMyVoice() = finishTake(keepRecording = true)
    /** Keep only the words; the AI voice reads them. */
    fun useWordsWithAiVoice() = finishTake(keepRecording = false)

    fun cancelVoice() {
        recorder?.stop(); recorder = null; takeWav = null
        _state.update { it.copy(voiceTake = null) }
    }

    /** Back to the AI voice for a scene that had the creator's recording. */
    fun removeMyVoice(sceneId: String) {
        val script = _state.value.script ?: return
        viewModelScope.launch(Dispatchers.IO) { com.avsp.pro.audio.OwnVoice.delete(storage, projectId, script.scriptId, sceneId) }
        _state.update { it.copy(ownVoiceScenes = it.ownVoiceScenes - sceneId) }
    }

    private fun finishTake(keepRecording: Boolean) {
        val take = _state.value.voiceTake ?: return
        val script = _state.value.script ?: return
        val words = take.text.trim()
        if (words.isNotBlank()) editScene(take.sceneId, narration = words, onScreen = words.split(Regex("\\s+")).take(6).joinToString(" "))
        val wav = takeWav
        viewModelScope.launch(Dispatchers.IO) {
            if (keepRecording && wav != null) com.avsp.pro.audio.OwnVoice.save(storage, projectId, script.scriptId, take.sceneId, wav)
            else com.avsp.pro.audio.OwnVoice.delete(storage, projectId, script.scriptId, take.sceneId)
        }
        takeWav = null
        _state.update { st -> st.copy(voiceTake = null,
            ownVoiceScenes = if (keepRecording && wav != null) st.ownVoiceScenes + take.sceneId else st.ownVoiceScenes - take.sceneId) }
    }

    override fun onCleared() { recorder?.stop(); recorder = null; com.avsp.pro.capture.EventLocation.forCapture = null; super.onCleared() }

    /** P22.4: every scene set to "Free stock" (all of them with one tap) gets its picture now, so the user sees it first. */
    fun previewPictures(all: Boolean) = work("Finding a picture for each scene…") {
        val st = _state.value
        val saved = scriptRepository.updateEdited(st.script ?: error("No script"))
        val ordered = saved.scenes.sortedBy { it.order }
        val outro = ordered.lastOrNull()?.sceneId.takeIf { ordered.size > 1 }
        val visuals = if (!all) st.visuals else st.visuals + ordered.filter { it.sceneId != outro && st.visuals[it.sceneId] !is SceneVisual.Picked }
            .associate { it.sceneId to SceneVisual.Stock }
        val scenes = visuals.filterValues { it == SceneVisual.Stock }.keys
        val pics = autoProducer.previewPictures(projectId, saved, scenes)
        val missing = scenes.count { it !in pics }
        _state.update { it.copy(script = saved, visuals = visuals, pictures = pics,
            note = if (missing > 0) "$missing scene(s) found no picture - they get an animated card, or pick your own photo." else null) }
    }

    /** P22.4: a different picture for one scene (the old one is never offered again). */
    fun anotherPicture(sceneId: String) {
        val script = _state.value.script ?: return
        if (_state.value.swapping != null) return
        _state.update { it.copy(swapping = sceneId, note = null) }
        viewModelScope.launch {
            val pic = runCatching { autoProducer.anotherPicture(projectId, script, sceneId) }.getOrNull()
            _state.update { st ->
                st.copy(swapping = null,
                    pictures = if (pic != null) st.pictures + (sceneId to pic) else st.pictures,
                    note = if (pic == null) "No other matching picture - edit the shot words or use your own photo." else null)
            }
        }
    }

    /** Camera target for a scene: a gallery entry the system camera writes into. */
    fun newCameraUri(video: Boolean): Uri? = runCatching {
        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "AVSP_shot_${System.currentTimeMillis()}.${if (video) "mp4" else "jpg"}")
            put(android.provider.MediaStore.MediaColumns.MIME_TYPE, if (video) "video/mp4" else "image/jpeg")
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, if (video) "Movies/AVSP/Camera" else "Pictures/AVSP")
            }
        }
        val collection = if (video) android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        else android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        appContext.contentResolver.insert(collection, values)
    }.getOrNull()

    /** Step 3 -> 4: save the edited script, attach chosen media to scenes, then voice + video. */
    fun make() = work("Saving your script…") {
        val st = _state.value
        val edited = st.script ?: error("No script")
        val saved = scriptRepository.updateEdited(edited)
        val scriptId = saved.scriptId
        _state.update { it.copy(step = 4, busy = "Adding your pictures…") }
        withContext(Dispatchers.IO) {
            saved.scenes.forEach { scene ->
                val v = st.visuals[scene.sceneId] as? SceneVisual.Picked ?: return@forEach
                attach(scene, v, scriptId)
            }
        }
        val stockScenes = st.visuals.filterValues { it == SceneVisual.Stock }.keys
        // P22.4: a picture found in the preview is dropped when the scene was switched to own media / animation.
        autoProducer.dropPictures(projectId, scriptId, st.pictures.keys - stockScenes)
        val r = autoProducer.finish(projectId, saved, stockScenes) { p ->
            _state.update { it.copy(busy = "${p.step.label}…") }
        }
        _state.update {
            it.copy(
                result = AutoProduceState.Done(
                    title = r.title,
                    provider = r.scriptProvider,
                    uri = r.video.exportedUri,
                    displayName = r.video.exportedDisplayName,
                    durationMs = r.video.durationMs,
                    note = r.stockNote,
                    kit = r.kit ?: runCatching { PublishKit.from(saved) }.getOrNull(),
                    thumbnail = r.thumbnail
                )
            )
        }
    }

    private suspend fun attach(scene: ScriptScene, v: SceneVisual.Picked, scriptId: String) {
        val ext = when {
            v.mime.startsWith("video/") -> "mp4"
            v.mime == "image/png" -> "png"
            else -> "jpg"
        }
        val relative = "media/scenes/${scriptId}_${scene.sceneId}.$ext"
        var size = 0L
        storage.openOutput(StorageArea.PROJECT_DATA, relative, projectId).use { out ->
            appContext.contentResolver.openInputStream(v.uri)?.use { size = it.copyTo(out) }
        }
        if (size <= 0) return
        projectRepository.addMediaAsset(
            MediaAsset(
                assetId = "scene_${scriptId}_${scene.sceneId}",
                projectId = projectId,
                fileName = relative.substringAfterLast('/'),
                relativePath = relative,
                mimeType = if (v.mime.startsWith("video/")) "video/mp4" else v.mime.ifBlank { "image/jpeg" },
                sizeBytes = size,
                createdAt = System.currentTimeMillis(),
                tags = listOfNotNull("own", "scene:$scriptId:${scene.sceneId}", if (v.fromCamera) "camera" else "phone",
                    "speed:${v.speed}".takeIf { v.speed < 0.99f })
            )
        )
    }

    private fun work(label: String, block: suspend () -> Unit) {
        if (_state.value.busy != null) return
        viewModelScope.launch {
            _state.update { it.copy(busy = label, error = null) }
            try {
                block()
            } catch (e: Throwable) {
                logger.error("MANUAL", "Manual step failed", details = e.message, projectId = projectId)
                _state.update { it.copy(error = e.message ?: "Something went wrong", step = if (it.step == 4 && it.result == null) 3 else it.step) }
            } finally {
                _state.update { it.copy(busy = null) }
            }
        }
    }
}
