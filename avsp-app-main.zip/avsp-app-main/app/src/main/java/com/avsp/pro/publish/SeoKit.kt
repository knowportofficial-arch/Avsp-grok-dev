package com.avsp.pro.publish

import com.avsp.pro.core.pipeline.PublishKit
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection

/**
 * P19 SEO for any video (your own finished video, or a made one): a search-friendly
 * title, a description whose first lines hook the viewer, search tags, hashtags and
 * - for videos over a minute - chapters. Your Gemini key writes it; without a key
 * (or offline) a plain version is built on the phone from the words in the video.
 */
object SeoKit {
    data class Seo(
        val title: String,
        val description: String,
        val tags: List<String>,
        val hashtags: List<String>,
        val chapters: List<String> = emptyList(),
        val byAi: Boolean = false,
        /** P23.1: "Question|answer|answer|…" for a Telegram poll under the video ("" = none). */
        val poll: String = ""
    ) {
        /** As a publish kit (description carries chapters and the search tags line). */
        fun kit(): PublishKit = PublishKit(
            title = title,
            description = buildString {
                append(description.trim())
                if (chapters.isNotEmpty()) append("\n\n").append(chapters.joinToString("\n"))
                if (tags.isNotEmpty()) append("\n\nTags: ").append(tags.joinToString(", "))
            },
            hashtags = hashtags
        )
    }

    fun prompt(words: String, topic: String, durationS: Int, language: String) = buildString {
        append("You are a YouTube Shorts / Instagram Reels SEO expert. Write the publishing text for this video in $language.\n")
        append("Topic / name: ").append(topic.take(200)).append('\n')
        append("Length: ").append(durationS).append(" seconds\n")
        append("What is said in the video (may be imperfect speech-to-text):\n").append(words.take(4000)).append("\n\n")
        append("Reply ONLY with JSON: {\"title\": \"max 70 characters, main keyword first, curiosity, no clickbait lies\", ")
        append("\"description\": \"2-4 short sentences; first line is the hook; include the main keywords naturally\", ")
        append("\"tags\": [\"12-15 search phrases people type\"], \"hashtags\": [\"5 hashtags with #, mix broad and specific, include #shorts\"], ")
        append("\"chapters\": [\"00:00 Intro\", ...] (only if longer than 60 seconds, else []), ")
        append("\"poll\": {\"question\": \"one fun question for viewers about this video, max 80 characters\", \"options\": [\"2-4 short answers, max 30 characters each\"]}}. ")
        append("Never include private details such as phone numbers, addresses, ids or passwords.")
    }

    fun parse(text: String): Seo? = runCatching {
        val t = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val o = JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
        fun list(k: String) = (o.optJSONArray(k) ?: JSONArray()).let { a -> (0 until a.length()).map { a.optString(it).trim() }.filter { it.isNotBlank() } }
        val title = o.optString("title").trim().take(100)
        if (title.isBlank()) return null
        Seo(
            title = title,
            description = o.optString("description").trim(),
            tags = list("tags").take(15),
            hashtags = list("hashtags").map { if (it.startsWith("#")) it else "#" + it }.map { it.replace(" ", "") }.distinct().take(8),
            chapters = list("chapters").take(10),
            byAi = true,
            poll = o.optJSONObject("poll")?.let { p ->
                val q = p.optString("question").trim().take(250)
                val opts = (p.optJSONArray("options") ?: JSONArray()).let { a -> (0 until a.length()).map { a.optString(it).trim().replace("|", "/").take(90) }.filter { it.isNotBlank() } }.distinct().take(4)
                if (q.isNotBlank() && opts.size >= 2) (listOf(q.replace("|", "/")) + opts).joinToString("|") else ""
            }.orEmpty()
        )
    }.getOrNull()

    private val STOP = setOf("the", "and", "for", "with", "this", "that", "are", "was", "you", "your", "from", "have", "has", "will", "can", "its",
        "into", "about", "more", "also", "here", "what", "they", "their", "them", "there", "which", "been", "were", "one", "all", "our", "how",
        "who", "just", "very", "like", "then", "than", "when", "some", "out", "now", "get", "got", "she", "his", "her", "him", "yes")

    /** P23.1: a simple poll that fits the kind of video (used when the AI wrote none). */
    fun offlinePoll(topic: String, language: String): String {
        val kind = com.avsp.pro.capture.ShotPlanner.kind(topic)
        val t = topic.lowercase()
        val news = Regex("news|election|minister|government|police|court|accident|খবর|समाचार").containsMatchIn(t)
        return when (language.lowercase()) {
            "bn" -> when {
                kind == com.avsp.pro.capture.TopicKind.RECIPE -> "বাড়িতে বানাবেন?|আজই!|এই সপ্তাহে|শুধু দেখছি 😄"
                news -> "আপনার কী মনে হয়?|ভালো খবর|চিন্তার বিষয়|আরও জানতে চাই"
                kind == com.avsp.pro.capture.TopicKind.PLACE -> "এখানে গেছেন?|হ্যাঁ!|এখনও না|যাওয়ার ইচ্ছে আছে"
                else -> "আগে জানতেন?|হ্যাঁ|না, নতুন জানলাম!"
            }
            "hi" -> when {
                kind == com.avsp.pro.capture.TopicKind.RECIPE -> "घर पर बनाएँगे?|आज ही!|इस हफ़्ते|बस देख रहे हैं 😄"
                news -> "आपकी क्या राय है?|अच्छी ख़बर|चिंता की बात|और जानना है"
                kind == com.avsp.pro.capture.TopicKind.PLACE -> "यहाँ गए हैं?|हाँ!|अभी नहीं|जाना है"
                else -> "पहले पता था?|हाँ|नहीं, नया पता चला!"
            }
            else -> when {
                kind == com.avsp.pro.capture.TopicKind.RECIPE -> "Will you cook this at home?|Yes, today!|This weekend|Just watching 😄"
                news -> "What do you think?|Good news|Worrying|Need more details"
                kind == com.avsp.pro.capture.TopicKind.PLACE -> "Have you been here?|Yes!|Not yet|It's on my list"
                else -> "Did you know this?|Yes|No, new to me!"
            }
        }
    }

    /** Phone-only version: title from the first sentence, tags from the most used words. */
    fun offline(words: String, topic: String): Seo {
        val clean = words.replace(Regex("\\s+"), " ").trim()
        val first = clean.split(Regex("(?<=[.!?।])\\s+")).firstOrNull { it.split(' ').size >= 3 }.orEmpty()
        val title = (topic.takeIf { it.isNotBlank() && !it.contains(", ") && !it.contains('_') } ?: first.ifBlank { "My video" })
            .trim().trimEnd('.').let { if (it.length > 70) it.take(67).substringBeforeLast(' ') + "…" else it }
            .replaceFirstChar { it.uppercase() }
        val counts = clean.lowercase().split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 3 && it !in STOP }.groupingBy { it }.eachCount()
        val top = counts.entries.sortedByDescending { it.value }.map { it.key }.take(10)
        return Seo(
            title = title,
            description = listOf(first, clean.drop(first.length).trim().take(220)).filter { it.isNotBlank() }.joinToString(" ").take(300),
            tags = top,
            hashtags = (top.take(4).map { "#" + it.replace(Regex("[^\\p{L}\\p{N}]"), "") } + "#shorts").distinct()
        )
    }

    /** Gemini first (all saved keys), then the phone-only version. Blocking - call off the main thread. */
    fun make(words: String, topic: String, durationS: Int, language: String, keys: List<String>): Seo {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt(words, topic, durationS, language))))))
            .put("generationConfig", JSONObject().put("temperature", 0.6).put("responseMimeType", "application/json"))
            .toString()
        for (key in keys.take(4)) for (model in listOf("gemini-flash-latest", "gemini-flash-lite-latest")) {
            val seo = runCatching { parse(extract(post(model, key, body))) }.getOrNull()
            if (seo != null) return seo
        }
        return offline(words, topic)
    }

    private fun extract(raw: String): String = runCatching {
        val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
    }.getOrDefault("")

    private fun post(model: String, key: String, body: String): String {
        val c = java.net.URI("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").toURL().openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 8_000; c.readTimeout = 25_000
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            check(c.responseCode in 200..299) { "HTTP ${c.responseCode}" }
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }
}
