package com.avsp.pro.video.engine

import android.graphics.Bitmap
import androidx.media3.effect.BitmapOverlay
import androidx.media3.common.OverlaySettings
import androidx.media3.effect.StaticOverlaySettings

/**
 * P7 "auto animation": the designed scene card slowly zooms in over its scene
 * (1.00 -> 1.08), so a scene without photos/clips still feels alive.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class KenBurnsCardOverlay(
    private val card: Bitmap,
    private val pieceOffsetMs: Long,
    private val sceneDurationMs: Long,
    private val pieceDurationMs: Long,
    private val pieceAbsoluteStartMs: Long
) : BitmapOverlay() {

    override fun getBitmap(presentationTimeUs: Long): Bitmap = card

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val t = Motion.pieceMs(presentationTimeUs, pieceDurationMs, pieceAbsoluteStartMs)
        val p = ((t + pieceOffsetMs).toFloat() / sceneDurationMs.coerceAtLeast(1)).coerceIn(0f, 1f)
        val z = 1f + 0.08f * p
        return StaticOverlaySettings.Builder().setScale(z, z).build()
    }
}
