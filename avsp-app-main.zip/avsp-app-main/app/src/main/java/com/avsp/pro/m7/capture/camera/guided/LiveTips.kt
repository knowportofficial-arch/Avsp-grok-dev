package com.avsp.pro.m7.capture.camera.guided

import org.json.JSONArray
import org.json.JSONObject

/**
 * P25 LIVE CAMERA TIPS while filming a scene:
 *  - every half second, on the phone: too dark / too bright / blurry / tilted (no internet, no key);
 *  - once per scene, AI (the user's Gemini key) looks at one frame and says whether it shows
 *    what the scene needs, with one short tip ("Move closer to the pan", "Onions are out of frame").
 */
object LiveTips {
    data class Stats(val mean: Double, val sharpness: Double)

    /** Brightness and sharpness from the camera's grey (Y) plane, sampled every [step] pixels. */
    fun stats(y: ByteArray, width: Int, height: Int, rowStride: Int, step: Int = 4): Stats {
        var sum = 0L; var n = 0; var edge = 0L; var en = 0
        var row = height / 8
        while (row < height - height / 8) {
            val base = row * rowStride
            var x = width / 8
            while (x < width - width / 8 - step) {
                val v = y[base + x].toInt() and 0xff
                val r = y[base + x + step].toInt() and 0xff
                val d = if (row + step < height) y[base + step * rowStride + x].toInt() and 0xff else v
                sum += v; n++
                edge += kotlin.math.abs(v - r) + kotlin.math.abs(v - d); en++
                x += step
            }
            row += step
        }
        return Stats(if (n == 0) 128.0 else sum.toDouble() / n, if (en == 0) 0.0 else edge.toDouble() / en)
    }

    /** One plain tip for what the camera sees right now, or null when the shot looks fine. */
    fun tip(s: Stats, tiltDegrees: Float, front: Boolean): String? = when {
        s.mean < 45 -> if (front) "Too dark - face a window or a light" else "Too dark - add light or turn on the torch"
        s.mean > 215 -> "Too bright - step out of direct sun or lower exposure"
        s.sharpness < 4.0 -> "Blurry - tap the subject to focus, hold steady, wipe the lens"
        kotlin.math.abs(tiltDegrees) in 6f..40f -> "Tilted - level the phone (watch the grid)"
        else -> null
    }

    // ---------------- AI look at one frame ----------------
    data class AiTip(val ok: Boolean, val tip: String)

    fun prompt(instruction: String, scene: String) = buildString {
        append("You are a camera coach for a short-video creator filming on a phone. ")
        append("The shot they must film now: \"").append(instruction.take(300)).append("\"")
        if (scene.isNotBlank()) append(" (the voice-over says: \"").append(scene.take(200)).append("\")")
        append(". Look at this camera frame. Does it show that shot well (subject, framing, light)? ")
        append("Reply ONLY JSON: {\"ok\": true|false, \"tip\": \"one practical instruction, max 12 words\"}. ")
        append("If it is good, tip is a short encouragement like 'Good - start recording'.")
    }

    fun parse(text: String): AiTip? = runCatching {
        val t = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val o = JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
        val tip = o.optString("tip").trim().take(90)
        if (tip.isBlank()) null else AiTip(o.optBoolean("ok", false), tip)
    }.getOrNull()

    /** Blocking; null when there is no key, no internet or no answer. */
    fun askAi(jpeg: ByteArray, instruction: String, scene: String, keys: List<String>): AiTip? {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", java.util.Base64.getEncoder().encodeToString(jpeg))))
                .put(JSONObject().put("text", prompt(instruction, scene))))))
            .put("generationConfig", JSONObject().put("temperature", 0.3).put("responseMimeType", "application/json"))
            .toString()
        for (key in keys.take(3)) for (model in listOf("gemini-flash-latest", "gemini-2.5-flash", "gemini-flash-lite-latest")) {
            val r = runCatching { post(model, key, body) }.getOrNull() ?: continue
            val text = runCatching {
                val parts = JSONObject(r).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
            }.getOrNull() ?: continue
            parse(text)?.let { return it }
        }
        return null
    }

    private fun post(model: String, key: String, body: String): String {
        val c = java.net.URI("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").toURL().openConnection() as java.net.HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 6_000; c.readTimeout = 15_000
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            check(c.responseCode in 200..299) { "HTTP ${c.responseCode}" }
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }
}
