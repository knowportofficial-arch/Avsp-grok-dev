package com.avsp.pro.ui.screens.publish

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * P26 CONNECT CHANNELS: Telegram, Facebook (Reels), Instagram (Reels) and Threads are connected
 * from the phone. The values go straight into the creator's own Google Sheet (its script settings);
 * AVSP does not keep them and the sheet never sends them back - only "connected" or not.
 */
private data class Channel(
    val id: String, val title: String, val help: String,
    val fields: List<Triple<String, String, Boolean>>   // (sheet key, label, secret)
)

private val CHANNELS = listOf(
    Channel("telegram", "Telegram channel",
        "1) In Telegram open @BotFather → /newbot → copy the token. 2) Add the bot to your Knowport channel as admin (Post messages). 3) Channel: @yourchannel (public) or its -100… id.",
        listOf(Triple("TELEGRAM_BOT_TOKEN", "Bot token", true), Triple("TELEGRAM_CHAT_ID", "Channel (@name)", false))),
    Channel("facebook", "Facebook Page (Reels / Shorts)",
        "Needs a Meta access token with pages_manage_posts + pages_read_engagement (developers.facebook.com → Graph API Explorer → your Page) and the Page ID (Page → About → Page transparency).",
        listOf(Triple("META_TOKEN", "Meta access token", true), Triple("FB_PAGE_ID", "Page ID", false))),
    Channel("instagram", "Instagram (Reels)",
        "Instagram must be a Professional account linked to the Facebook Page. Same Meta token (add instagram_content_publish); account ID: Graph API Explorer → me/accounts → instagram_business_account.",
        listOf(Triple("META_TOKEN", "Meta access token (same as Facebook)", true), Triple("IG_USER_ID", "Instagram account ID", false))),
    Channel("threads", "Threads",
        "Needs a Threads access token (developers.facebook.com → Threads API, permissions threads_basic + threads_content_publish). User ID is optional.",
        listOf(Triple("THREADS_TOKEN", "Threads access token", true), Triple("THREADS_USER_ID", "Threads user ID (optional)", false)))
)

@Composable
fun ConnectChannels() {
    val ctx = LocalContext.current
    val publisher = remember { (ctx.applicationContext as com.avsp.pro.AvspApplication).container.publisher }
    val scope = rememberCoroutineScope()
    var state by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    var note by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf<String?>(null) }
    var open by remember { mutableStateOf<String?>(null) }
    val values = remember { mutableStateOf(mapOf<String, String>()) }

    if (!publisher.isConfigured()) {
        Text("Connect your Google Sheet first (Publishing, above).", style = MaterialTheme.typography.bodySmall)
        return
    }
    LaunchedEffect(Unit) {
        busy = "status"
        runCatching { withContext(Dispatchers.IO) { publisher.connect(emptyMap()) } }
            .onSuccess { state = it }.onFailure { note = "Sheet: ${it.message} - update the sheet script if this keeps failing" }
        busy = null
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("YouTube posts with your Google account. Connect the others once - the details are saved in your own sheet, not in AVSP. WhatsApp channels can't be posted to automatically (use Share).",
            style = MaterialTheme.typography.bodySmall)
        note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
        CHANNELS.forEach { ch ->
            HorizontalDivider()
            val connected = state[ch.id] == true
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text((if (connected) "✅ " else "⚪ ") + ch.title, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                OutlinedButton(onClick = { open = if (open == ch.id) null else ch.id }) { Text(if (open == ch.id) "Close" else if (connected) "Change" else "Connect") }
            }
            if (open == ch.id) {
                Text(ch.help, style = MaterialTheme.typography.bodySmall)
                ch.fields.forEach { (key, label, secret) ->
                    OutlinedTextField(
                        value = values.value[key].orEmpty(),
                        onValueChange = { v -> values.value = values.value + (key to v.trim()) },
                        label = { Text(label) }, singleLine = true,
                        visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(enabled = busy == null, onClick = {
                        val send = ch.fields.mapNotNull { (k, _, _) -> values.value[k]?.takeIf { it.isNotBlank() }?.let { k to it } }.toMap()
                        if (send.isEmpty()) { note = "Type the details first"; return@Button }
                        busy = ch.id
                        scope.launch {
                            val r = runCatching { withContext(Dispatchers.IO) { publisher.connect(send); publisher.test(ch.id) } }
                            r.onSuccess { (msg, st) -> state = st; note = "✅ $msg"; values.value = values.value - ch.fields.map { it.first }.toSet() }
                                .onFailure { note = "${ch.title}: ${it.message}" }
                            busy = null
                        }
                    }) { Text(if (busy == ch.id) "Saving…" else "Save & test") }
                    OutlinedButton(enabled = busy == null, onClick = {
                        busy = ch.id
                        scope.launch {
                            runCatching { withContext(Dispatchers.IO) { publisher.test(ch.id) } }
                                .onSuccess { (msg, st) -> state = st; note = "✅ $msg" }.onFailure { note = "${ch.title}: ${it.message}" }
                            busy = null
                        }
                    }) { Text("Test") }
                }
            }
        }
    }
}

