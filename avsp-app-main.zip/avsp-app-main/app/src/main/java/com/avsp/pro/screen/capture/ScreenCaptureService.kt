package com.avsp.pro.screen.capture

import kotlinx.coroutines.runBlocking

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.util.Log
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.content.ContentValues
import android.provider.MediaStore
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Surface
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.avsp.pro.R
import com.avsp.pro.core.integration.ProjectPaths
import com.avsp.pro.storage.FileAvspStorage
import com.avsp.pro.storage.StorageArea
import org.json.JSONObject
import java.io.File

class ScreenCaptureService : Service() {

    private val logTag = "AVSP-V2"

    companion object {
        const val ACTION_START = "com.avsp.pro.screen.capture.START"
        const val ACTION_STOP = "com.avsp.pro.screen.capture.STOP"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_PROJECT_ID = "extra_project_id"
        const val EXTRA_WIDTH = "extra_width"
        const val EXTRA_HEIGHT = "extra_height"
        const val EXTRA_DPI = "extra_dpi"

        private const val CHANNEL_ID = "avsp_screen_capture"
        private const val NOTIFICATION_ID = 2001
        private const val MIME_TYPE = "video/avc"
        private const val FPS = 30
        private const val BITRATE = 8_000_000
        private const val I_FRAME_INTERVAL_SECONDS = 1
        private const val COLOR_FORMAT_SURFACE = MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private var captureThread: Thread? = null

    @Volatile
    private var stopRequested = false

    @Volatile
    private var projectionStopped = false

    private var mediaProjection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var encoder: MediaCodec? = null
    private var encoderSurface: Surface? = null
    private var muxer: MediaMuxer? = null

    private var currentOutputFile: File? = null
    private var currentMetadataRelativePath: String? = null
    private var currentOutputRelativePath: String? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> requestStop()
        }

        return START_NOT_STICKY
    }

    private fun handleStart(intent: Intent) {
        if (captureThread?.isAlive == true) {
            return
        }

        val resultCode =
            intent.getIntExtra(EXTRA_RESULT_CODE, Int.MIN_VALUE)

        val resultData = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(
                EXTRA_RESULT_DATA,
                Intent::class.java
            )
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        val projectId =
            intent.getStringExtra(EXTRA_PROJECT_ID)

        val width =
            intent.getIntExtra(EXTRA_WIDTH, 0)

        val height =
            intent.getIntExtra(EXTRA_HEIGHT, 0)

        val dpi =
            intent.getIntExtra(EXTRA_DPI, 0)

        if (
            resultCode == Int.MIN_VALUE ||
            resultData == null ||
            projectId.isNullOrBlank() ||
            width <= 0 ||
            height <= 0 ||
            dpi <= 0
        ) {
            ScreenCaptureStateStore.update(
                ScreenCaptureState(
                    status = ScreenCaptureStatus.ERROR,
                    projectId = projectId,
                    errorMessage = "Invalid screen-capture session parameters"
                )
            )
            stopSelf()
            return
        }

        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        )

        stopRequested = false
        projectionStopped = false
        ScreenCaptureStateStore.startedAt = System.currentTimeMillis()
        showStopBubble()

        ScreenCaptureStateStore.update(
            ScreenCaptureState(
                status = ScreenCaptureStatus.STARTING,
                projectId = projectId,
                width = width,
                height = height,
                fps = FPS
            )
        )

        captureThread = Thread {
            runCapture(
                resultCode = resultCode,
                resultData = resultData,
                projectId = projectId,
                width = width,
                height = height,
                dpi = dpi
            )
        }.apply {
            name = "AVSP-ScreenCapture"
            start()
        }
    }

    private fun runCapture(
        resultCode: Int,
        resultData: Intent,
        projectId: String,
        width: Int,
        height: Int,
        dpi: Int
    ) {
        val storage = FileAvspStorage(applicationContext)
        val baseName = ScreenCaptureFileNamer.createBaseName()

        val outputRelative =
            "${ProjectPaths.SCREEN}/${ScreenCaptureFileNamer.videoName(baseName)}"

        val metadataRelative =
            "${ProjectPaths.SCREEN}/${ScreenCaptureFileNamer.metadataName(baseName)}"

        currentOutputRelativePath = outputRelative
        currentMetadataRelativePath = metadataRelative

        var muxerStarted = false
        var videoTrack = -1
        var encodedSampleCount = 0L

        val startedAtEpochMs = System.currentTimeMillis()
        val startedElapsedMs = SystemClock.elapsedRealtime()

        try {
            storage.ensureProjectLayout(projectId)

            val outputPath =
                storage.resolve(
                    StorageArea.PROJECT_DATA,
                    outputRelative,
                    projectId
                )

            currentOutputFile = File(outputPath)

            if (currentOutputFile!!.exists()) {
                currentOutputFile!!.delete()
            }

            val projectionManager =
                getSystemService(
                    Context.MEDIA_PROJECTION_SERVICE
                ) as MediaProjectionManager

            val projection =
                projectionManager.getMediaProjection(
                    resultCode,
                    resultData
                ) ?: error("MediaProjection could not be created")

            mediaProjection = projection

            val callback =
                object : MediaProjection.Callback() {
                    override fun onStop() {
                        projectionStopped = true
                        // P31: Android ended it (the recorded app closed / "Stop sharing") - keep what was recorded.
                        if (!stopRequested) ScreenCaptureStateStore.note("Recording ended because the recorded app was closed or sharing was stopped. What was recorded is saved and being cleaned.")
                        requestStop()
                    }
                }

            projectionCallback = callback

            projection.registerCallback(
                callback,
                mainHandler
            )

            val format =
                MediaFormat.createVideoFormat(
                    MIME_TYPE,
                    width,
                    height
                ).apply {
                    setInteger(
                        MediaFormat.KEY_COLOR_FORMAT,
                        COLOR_FORMAT_SURFACE
                    )
                    setInteger(
                        MediaFormat.KEY_BIT_RATE,
                        BITRATE
                    )
                    setInteger(
                        MediaFormat.KEY_FRAME_RATE,
                        FPS
                    )
                    setInteger(
                        MediaFormat.KEY_I_FRAME_INTERVAL,
                        I_FRAME_INTERVAL_SECONDS
                    )
                }

            val codec =
                MediaCodec.createEncoderByType(MIME_TYPE)

            encoder = codec

            codec.configure(
                format,
                null,
                null,
                MediaCodec.CONFIGURE_FLAG_ENCODE
            )

            val inputSurface =
                codec.createInputSurface()

            encoderSurface = inputSurface

            codec.start()

            val virtualDisplayResult =
                projection.createVirtualDisplay(
                    "AVSP Screen Capture",
                    width,
                    height,
                    dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    inputSurface,
                    object : VirtualDisplay.Callback() {},
                    mainHandler
                )

            virtualDisplay =
                virtualDisplayResult
                    ?: error("VirtualDisplay could not be created")

            muxer =
                MediaMuxer(
                    outputPath,
                    MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
                )

            ScreenCaptureStateStore.update(
                ScreenCaptureState(
                    status = ScreenCaptureStatus.RECORDING,
                    projectId = projectId,
                    outputRelativePath = outputRelative,
                    metadataRelativePath = metadataRelative,
                    width = width,
                    height = height,
                    fps = FPS
                )
            )

            val bufferInfo = MediaCodec.BufferInfo()
            var endOfStreamSignalled = false
            var completedNormally = false

            while (true) {
                if (
                    stopRequested &&
                    !endOfStreamSignalled
                ) {
                    virtualDisplay?.release()
                    virtualDisplay = null

                    try {
                        codec.signalEndOfInputStream()
                    } catch (_: IllegalStateException) {
                    }

                    endOfStreamSignalled = true

                    ScreenCaptureStateStore.update(
                        ScreenCaptureStateStore.state.value.copy(
                            status = ScreenCaptureStatus.STOPPING
                        )
                    )
                }

                val outputIndex =
                    codec.dequeueOutputBuffer(
                        bufferInfo,
                        10_000L
                    )

                when {
                    outputIndex ==
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {

                        if (muxerStarted) {
                            error("Encoder output format changed more than once")
                        }

                        videoTrack =
                            muxer!!.addTrack(codec.outputFormat)

                        muxer!!.start()
                        muxerStarted = true
                    }

                    outputIndex >= 0 -> {
                        val outputBuffer =
                            codec.getOutputBuffer(outputIndex)

                        if (
                            outputBuffer != null &&
                            bufferInfo.size > 0 &&
                            muxerStarted &&
                            (bufferInfo.flags and
                                MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                        ) {
                            muxer!!.writeSampleData(
                                videoTrack,
                                outputBuffer,
                                bufferInfo
                            )
                            encodedSampleCount++
                        }

                        val eos =
                            (bufferInfo.flags and
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0

                        codec.releaseOutputBuffer(
                            outputIndex,
                            false
                        )

                        if (eos) {
                            completedNormally = true
                            break
                        }
                    }
                }
            }

            if (!completedNormally) {
                error("Screen capture ended without encoder EOS")
            }

            if (!muxerStarted || videoTrack < 0) {
                error("No encoded video track was produced")
            }

            if (encodedSampleCount <= 0) {
                error("No encoded video samples were produced")
            }

            val durationMs =
                SystemClock.elapsedRealtime() - startedElapsedMs

            try {
                codec.stop()
            } catch (_: Exception) {
            }

            try {
                codec.release()
            } catch (_: Exception) {
            }

            encoder = null

            /*
             * ------------------------------------------------
             * FINALIZE MP4 CONTAINER
             * ------------------------------------------------
             *
             * MediaMuxer.stop() finalizes the MPEG-4 container
             * and writes the required MP4 metadata/index.
             *
             * Do NOT swallow this failure. A recording is not
             * considered complete until muxer.stop() succeeds.
             */
            var muxerFinalized = false

            try {
                if (muxerStarted) {
                    muxer!!.stop()
                    muxerFinalized = true
                }
            } catch (t: Throwable) {
                throw IllegalStateException(
                    "MP4 muxer finalization failed: " +
                        (t.message ?: t.javaClass.simpleName),
                    t
                )
            } finally {
                try {
                    muxer?.release()
                } catch (_: Exception) {
                }

                muxer = null
            }

            if (!muxerFinalized) {
                throw IllegalStateException(
                    "MP4 muxer was not finalized"
                )
            }

            val finalizedFile = currentOutputFile
                ?: error("Recording output file is missing")

            if (!finalizedFile.exists()) {
                throw IllegalStateException(
                    "Finalized MP4 file does not exist"
                )
            }
            // ========================================================

            val finalizedSize = finalizedFile.length()

            if (finalizedSize <= 0L) {
                throw IllegalStateException(
                    "Finalized MP4 file is empty"
                )
            }

            writeMetadata(
                storage = storage,
                projectId = projectId,
                outputRelative = outputRelative,
                metadataRelative = metadataRelative,
                startedAtEpochMs = startedAtEpochMs,
                durationMs = durationMs,
                width = width,
                height = height,
                sampleCount = encodedSampleCount,
                outputFile = currentOutputFile!!
            )

            val size =
                currentOutputFile!!.length()

            ScreenCaptureStateStore.update(
                ScreenCaptureState(
                    status = ScreenCaptureStatus.COMPLETED,
                    projectId = projectId,
                    outputRelativePath = outputRelative,
                    metadataRelativePath = metadataRelative,
                    durationMs = durationMs,
                    fileSizeBytes = size,
                    width = width,
                    height = height,
                    fps = FPS,
                    analysisStatus = ScreenAnalysisStatus.RUNNING
                )
            )

            runV2Analysis(storage, projectId, outputRelative, durationMs, size, width, height)

        } catch (t: Throwable) {

            currentOutputFile?.let {
                if (it.exists()) {
                    it.delete()
                }
            }

            ScreenCaptureStateStore.update(
                ScreenCaptureState(
                    status = ScreenCaptureStatus.ERROR,
                    projectId = projectId,
                    outputRelativePath = currentOutputRelativePath,
                    metadataRelativePath = currentMetadataRelativePath,
                    width = width,
                    height = height,
                    fps = FPS,
                    errorMessage =
                        t.message ?: t.javaClass.simpleName
                )
            )

        } finally {
            cleanupProjection()

            try {
                encoderSurface?.release()
            } catch (_: Exception) {
            }

            encoderSurface = null
            encoder = null

            try {
                muxer?.release()
            } catch (_: Exception) {
            }

            muxer = null
            currentOutputFile = null
            currentOutputRelativePath = null
            currentMetadataRelativePath = null

            stopForegroundCompat()
            stopSelf()
        }
    }

    private fun requestStop() {
        stopRequested = true
        mainHandler.post { hideStopBubble() }

        mainHandler.post {
            try {
                virtualDisplay?.release()
            } catch (_: Exception) {
            }

            virtualDisplay = null
        }
    }

    private fun cleanupProjection() {
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {
        }

        virtualDisplay = null

        val projection = mediaProjection
        val callback = projectionCallback

        if (projection != null && callback != null) {
            try {
                projection.unregisterCallback(callback)
            } catch (_: Exception) {
            }
        }

        if (
            projection != null &&
            !projectionStopped
        ) {
            try {
                projection.stop()
            } catch (_: Exception) {
            }
        }

        projectionCallback = null
        mediaProjection = null
        projectionStopped = true
    }

    private fun runV2Analysis(storage: FileAvspStorage, projectId: String, outputRelative: String, durationMs: Long, size: Long, width: Int, height: Int) {
        Log.i(logTag, "V2 analysis START project=$projectId video=$outputRelative durationMs=$durationMs size=$size")
        try {
            Log.i(logTag, "V2 analyzer invoking")
            val result = ScreenIntelligenceAnalyzer().analyze(
                applicationContext, projectId,
                File(storage.resolve(StorageArea.PROJECT_DATA, outputRelative, projectId)),
                outputRelative
            )
            val base = ScreenCaptureFileNamer.createBaseName()
            val analysis = "${ProjectPaths.SCREEN}/${base}_analysis.json"
            val redaction = "${ProjectPaths.SCREEN}/${base}_redaction.json"
            val script = "${ProjectPaths.SCREEN}/${base}_script.txt"

            val events = org.json.JSONArray()
            result.events.forEach { e ->
                val eventJson = org.json.JSONObject()
                    .put("timestampMs", e.timestampMs)
                    .put("type", e.type.name)
                    .put("title", e.title)
                    .put("summary", e.summary)
                    .put("confidence", e.confidence)
                    .put("sensitive", e.sensitive)

                e.bounds?.let { b ->
                    eventJson
                        .put("normalizedLeft", b.left)
                        .put("normalizedTop", b.top)
                        .put("normalizedRight", b.right)
                        .put("normalizedBottom", b.bottom)
                }

                events.put(eventJson)
            }
            val frames = org.json.JSONArray()
            result.frames.forEach { f ->
                val frameJson = org.json.JSONObject()
                    .put("timestampMs", f.timestampMs)
                    .put("visualChangeScore", f.visualChangeScore)

                f.visualChangeBounds?.let { b ->
                    frameJson
                        .put("normalizedLeft", b.left)
                        .put("normalizedTop", b.top)
                        .put("normalizedRight", b.right)
                        .put("normalizedBottom", b.bottom)
                }

                frames.put(frameJson)
            }

            val cuts = org.json.JSONArray()
            result.cutSuggestions.forEach { c -> cuts.put(org.json.JSONObject()
                .put("startMs",c.startMs).put("endMs",c.endMs).put("reason",c.reason).put("confidence",c.confidence)) }
            val analysisJson=org.json.JSONObject().put("schemaVersion",2).put("projectId",projectId)
                .put("sourceVideoRelativePath",outputRelative).put("durationMs",result.durationMs)
                .put("sampledFrameCount",result.sampledFrameCount).put("frames",frames)
                .put("events",events).put("cutSuggestions",cuts)
                .put("sensitiveFindingCount",result.sensitiveFindings.size).put("generatedAtEpochMs",result.generatedAtEpochMs)
            val findings=org.json.JSONArray()
            result.sensitiveFindings.forEach { f -> findings.put(org.json.JSONObject()
                .put("timestampMs",f.timestampMs).put("type",f.type.name).put("maskedText",f.maskedText)
                .put("confidence",f.confidence).put("normalizedLeft",f.bounds.left).put("normalizedTop",f.bounds.top)
                .put("normalizedRight",f.bounds.right).put("normalizedBottom",f.bounds.bottom).put("rendererAction","MOSAIC_OPAQUE")) }
            val sourceFile = File(
    storage.resolve(
        StorageArea.PROJECT_DATA,
        outputRelative,
        projectId
    )
)

val redactedVideoRelative =
    "${ProjectPaths.SCREEN}/${base}_redacted.mp4"

val redactedVideoFile = File(
    storage.resolve(
        StorageArea.PROJECT_DATA,
        redactedVideoRelative,
        projectId
    )
)

Log.i(
    logTag,
    "V2.2 redaction render START findings=${result.sensitiveFindings.size}"
)

runBlocking {
    ScreenRedactionRenderer.render(
        context = applicationContext,
        inputFile = sourceFile,
        outputFile = redactedVideoFile,
        findings = result.sensitiveFindings,
        durationMs = result.durationMs,
        interactionMarkers = result.events.filter { it.type == ScreenEventType.INFERRED_INTERACTION }.mapNotNull { event -> event.bounds?.let { bounds -> ScreenRedactionRenderer.InteractionMarker(event.timestampMs, android.graphics.RectF(bounds)) } },
        privacyPlan = result.privacyPlan
    )
}

Log.i(
    logTag,
    "V2.2 redaction render COMPLETE path=$redactedVideoRelative size=${redactedVideoFile.length()}"
)

            // ========================================================
            // PUBLIC MP4 EXPORT — FINAL PROCESSED VIDEO
            // Export ONLY the rendered/redacted output.
            // Original private AVSP recording remains untouched.
            // ========================================================
            val publicVideoUri =
                exportFinalizedVideoToMovies(redactedVideoFile)

            if (publicVideoUri != null) {
                Log.i(
                    logTag,
                    "FINAL PROCESSED VIDEO available in Movies/AVSP: $publicVideoUri"
                )
            } else {
                Log.w(
                    logTag,
                    "FINAL PROCESSED VIDEO export failed"
                )
            }


/*
 * P0 frame-local privacy tracks (positions/times only; never source text).
 */
val privacyTracksJson = org.json.JSONArray()
result.privacyPlan.tracks.forEach { track ->
    val keyframesJson = org.json.JSONArray()
    track.keyframes.forEach { kf ->
        keyframesJson.put(
            org.json.JSONObject()
                .put("timestampMs", kf.timestampMs)
                .put("normalizedLeft", kf.box.left.toDouble())
                .put("normalizedTop", kf.box.top.toDouble())
                .put("normalizedRight", kf.box.right.toDouble())
                .put("normalizedBottom", kf.box.bottom.toDouble())
        )
    }
    privacyTracksJson.put(
        org.json.JSONObject()
            .put("trackId", track.id)
            .put("type", track.type.name)
            .put("coverStartMs", track.coverStartMs)
            .put("coverEndMs", track.coverEndMs)
            .put("keyframes", keyframesJson)
    )
}

val redactionJson =
    org.json.JSONObject()
        .put("schemaVersion", 3)
        .put("privacyModel", "FRAME_LOCAL_TRACKS_V1")
        .put("privacySampleCount", result.privacyPlan.sampleTimesMs.size)
        .put("privacyDenseSampleCount", result.privacyPlan.denseSampleCount)
        .put("privacyTracks", privacyTracksJson)
        .put("sourceVideoRelativePath", outputRelative)
        .put("redactedVideoRelativePath", redactedVideoRelative)
        .put("renderer", "MEDIA3_CANVAS_OVERLAY")
        .put("rendererAction","MOSAIC_OPAQUE")
        .put("audioIncluded", false)
        .put("findings", findings)

storage.save(
    StorageArea.PROJECT_DATA,
    analysis,
    analysisJson.toString(2),
    projectId
)

storage.save(
    StorageArea.PROJECT_DATA,
    redaction,
    redactionJson.toString(2),
    projectId
)

storage.save(StorageArea.PROJECT_DATA, script, buildPrivacySafeScript(result), projectId)
            Log.i(logTag, "V2 analysis COMPLETE frames=${result.sampledFrameCount} events=${result.events.size} sensitive=${result.sensitiveFindings.size} cuts=${result.cutSuggestions.size}")
            ScreenCaptureStateStore.update(ScreenCaptureState(
                ScreenCaptureStatus.COMPLETED,projectId,outputRelative,currentMetadataRelativePath,durationMs,size,width,height,FPS,
                ScreenAnalysisStatus.COMPLETED,analysis,redaction,script,
                result.events.count{it.type!=ScreenEventType.START&&it.type!=ScreenEventType.END},
                result.sensitiveFindings.size,result.cutSuggestions.size
            ))
        } catch (e: Throwable) {
            Log.e(logTag, "V2 analysis FAILED", e)
            ScreenCaptureStateStore.update(ScreenCaptureStateStore.state.value.copy(
                analysisStatus=ScreenAnalysisStatus.ERROR,
                errorMessage="Recording saved; V2 analysis failed: ${e.message ?: e.javaClass.simpleName}"
            ))
        }
    }

    private fun buildPrivacySafeScript(
        result: ScreenIntelligenceResult
    ): String {

        val sensitiveTypes =
            result.sensitiveFindings
                .map { it.type.name }
                .distinct()
                .joinToString(", ")

        return buildString {

            appendLine("SCREEN CONTENT INTELLIGENCE SCRIPT")
            appendLine("Duration: ${result.durationMs / 1000}s")
            appendLine(
                "Privacy policy: Original screen-recording audio is analysis-only. " +
                    "It must not be used as final narration. " +
                    "Sensitive OCR content is sanitized before script/TTS."
            )

            if (sensitiveTypes.isNotBlank()) {
                appendLine("Sensitive data detected: $sensitiveTypes")
                appendLine("Sensitive values have been removed from narration.")
            }

            result.events
                .filter {
                    it.type == ScreenEventType.TEXT_CHANGED ||
                        it.type == ScreenEventType.VISUAL_CHANGE ||
                        it.type == ScreenEventType.SENSITIVE_DATA
                }
                .take(80)
                .forEach { event ->

                    var safeSummary =
                        ScreenSensitiveSanitizer.privacySafeForNarration(
                            event.summary
                        )

                    /*
                     * Defence in depth:
                     * remove every exact sensitive OCR source string from
                     * narration even if a future sanitizer rule misses it.
                     */
                    result.sensitiveFindings.forEach { finding ->
                        if (finding.sourceText.isNotBlank()) {
                            safeSummary =
                                safeSummary.replace(
                                    finding.sourceText,
                                    "[${finding.type.name}]"
                                )
                        }
                    }

                    appendLine(
                        "[${event.timestampMs / 1000}s] " +
                            "${event.title}: $safeSummary"
                    )
                }

            if (result.sensitiveFindings.isNotEmpty()) {
                appendLine()
                appendLine(
                    "PRIVACY NOTE: Sensitive regions must remain redacted " +
                        "before publication."
                )
            }
        }
    }
    /**
     * Export the finalized AVSP recording to the user's normal Movies/AVSP folder.
     *
     * IMPORTANT:
     * This runs only after MediaMuxer.stop() has successfully finalized
     * the private AVSP MP4. The private file remains the source of truth
     * for the AVSP analysis pipeline.
     */
    private fun exportFinalizedVideoToMovies(
        finalizedFile: File
    ): String? {
        if (!finalizedFile.exists() || finalizedFile.length() <= 0L) {
            Log.e(logTag, "PUBLIC MP4 EXPORT skipped: source file invalid")
            return null
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            Log.w(
                logTag,
                "PUBLIC MP4 EXPORT skipped: MediaStore pending workflow requires Android 10+"
            )
            return null
        }

        val resolver = contentResolver

        val values = ContentValues().apply {
            put(
                MediaStore.Video.Media.DISPLAY_NAME,
                finalizedFile.name
            )
            put(
                MediaStore.Video.Media.MIME_TYPE,
                "video/mp4"
            )
            put(
                MediaStore.Video.Media.RELATIVE_PATH,
                "${Environment.DIRECTORY_MOVIES}/AVSP"
            )
            put(
                MediaStore.Video.Media.IS_PENDING,
                1
            )
        }

        val collection =
            MediaStore.Video.Media.getContentUri(
                MediaStore.VOLUME_EXTERNAL_PRIMARY
            )

        val uri = resolver.insert(collection, values)

        if (uri == null) {
            Log.e(logTag, "PUBLIC MP4 EXPORT failed: MediaStore insert returned null")
            return null
        }

        try {
            resolver.openOutputStream(uri)?.use { output ->
                finalizedFile.inputStream().use { input ->
                    input.copyTo(output)
                }
            } ?: throw IllegalStateException(
                "Could not open MediaStore output stream"
            )

            val completedValues = ContentValues().apply {
                put(MediaStore.Video.Media.IS_PENDING, 0)
            }

            resolver.update(
                uri,
                completedValues,
                null,
                null
            )

            Log.i(
                logTag,
                "PUBLIC MP4 EXPORT SUCCESS uri=$uri size=${finalizedFile.length()}"
            )

            return uri.toString()
        } catch (t: Throwable) {
            try {
                resolver.delete(uri, null, null)
            } catch (_: Exception) {
            }

            Log.e(
                logTag,
                "PUBLIC MP4 EXPORT FAILED: ${t.message}",
                t
            )

            return null
        }
    }
    private fun writeMetadata(
        storage: FileAvspStorage,
        projectId: String,
        outputRelative: String,
        metadataRelative: String,
        startedAtEpochMs: Long,
        durationMs: Long,
        width: Int,
        height: Int,
        sampleCount: Long,
        outputFile: File
    ) {
        val json =
            JSONObject()
                .put("schemaVersion", 1)
                .put("source", "AVSP_SCREEN_CAPTURE")
                .put("projectId", projectId)
                .put("outputRelativePath", outputRelative)
                .put("mimeType", MIME_TYPE)
                .put("videoCodec", "H.264/AVC")
                .put("audioIncluded", false)
                .put("width", width)
                .put("height", height)
                .put("fps", FPS)
                .put("bitrate", BITRATE)
                .put("startedAtEpochMs", startedAtEpochMs)
                .put("durationMs", durationMs)
                .put("fileSizeBytes", outputFile.length())
                .put("encodedSampleCount", sampleCount)
                .put("status", "COMPLETED")
                .toString(2)

        storage.save(
            StorageArea.PROJECT_DATA,
            metadataRelative,
            json,
            projectId
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) {
            return
        }

        val channel =
            NotificationChannel(
                CHANNEL_ID,
                "AVSP Screen Capture",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description =
                    "Status for AVSP native screen recording"
            }

        getSystemService(
            NotificationManager::class.java
        ).createNotificationChannel(channel)
    }

    // P31: the notification has a Stop button and a running timer; tapping it opens AVSP.
    private fun buildNotification(): Notification {
        val stop = android.app.PendingIntent.getService(this, 1,
            Intent(this, ScreenCaptureService::class.java).setAction(ACTION_STOP),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
        val open = packageManager.getLaunchIntentForPackage(packageName)?.let {
            android.app.PendingIntent.getActivity(this, 2, it, android.app.PendingIntent.FLAG_IMMUTABLE)
        }
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("AVSP is recording your screen")
            .setContentText("Tap Stop when you are done - private info is blurred automatically")
            .setUsesChronometer(true)
            .setWhen(System.currentTimeMillis())
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "■ Stop", stop)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    // P31: a small floating Stop button over every app (only when "Display over other apps" is allowed).
    private var bubble: android.view.View? = null

    private fun showStopBubble() {
        mainHandler.post {
            if (bubble != null || Build.VERSION.SDK_INT < 26 || !android.provider.Settings.canDrawOverlays(this)) return@post
            runCatching {
                val wm = getSystemService(WINDOW_SERVICE) as android.view.WindowManager
                val d = resources.displayMetrics.density
                val v = android.widget.TextView(this).apply {
                    text = "■ Stop"
                    setTextColor(android.graphics.Color.WHITE)
                    textSize = 15f
                    setPadding((14 * d).toInt(), (9 * d).toInt(), (14 * d).toInt(), (9 * d).toInt())
                    background = android.graphics.drawable.GradientDrawable().apply { cornerRadius = 40 * d; setColor(0xE6D32F2F.toInt()) }
                    elevation = 8 * d
                }
                val lp = android.view.WindowManager.LayoutParams(
                    android.view.WindowManager.LayoutParams.WRAP_CONTENT, android.view.WindowManager.LayoutParams.WRAP_CONTENT,
                    android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    android.graphics.PixelFormat.TRANSLUCENT
                ).apply { gravity = android.view.Gravity.TOP or android.view.Gravity.END; x = (12 * d).toInt(); y = (160 * d).toInt() }
                // Drag up/down to move it; a tap stops the recording.
                var downY = 0f; var startY = 0; var moved = false
                v.setOnTouchListener { _, e ->
                    when (e.action) {
                        android.view.MotionEvent.ACTION_DOWN -> { downY = e.rawY; startY = lp.y; moved = false; true }
                        android.view.MotionEvent.ACTION_MOVE -> {
                            val dy = (e.rawY - downY).toInt()
                            if (kotlin.math.abs(dy) > 10 * d) moved = true
                            if (moved) { lp.y = (startY + dy).coerceAtLeast(0); runCatching { wm.updateViewLayout(v, lp) } }
                            true
                        }
                        android.view.MotionEvent.ACTION_UP -> { if (!moved) requestStop(); true }
                        else -> false
                    }
                }
                wm.addView(v, lp)
                bubble = v
            }
        }
    }

    private fun hideStopBubble() {
        val v = bubble ?: return
        bubble = null
        runCatching { (getSystemService(WINDOW_SERVICE) as android.view.WindowManager).removeView(v) }
    }

    private fun stopForegroundCompat() {
        ServiceCompat.stopForeground(
            this,
            ServiceCompat.STOP_FOREGROUND_REMOVE
        )
    }

    override fun onDestroy() {
        hideStopBubble()
        /*
         * Recording lifecycle is owned by the capture loop.
         *
         * Do NOT stop/release the encoder here.
         * requestStop() causes the loop to:
         *   1. release VirtualDisplay
         *   2. signal encoder EOS
         *   3. drain EOS
         *   4. stop/release encoder
         *   5. finalize MediaMuxer
         *
         * Stopping the encoder from onDestroy() can race with that
         * sequence and leave the MP4 container unfinalized.
         */
        requestStop()

        try {
            encoderSurface?.release()
        } catch (_: Exception) {
        }

        encoderSurface = null

        cleanupProjection()

        super.onDestroy()
    }
}




