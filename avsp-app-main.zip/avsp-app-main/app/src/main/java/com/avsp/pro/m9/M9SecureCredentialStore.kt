﻿package com.avsp.pro.m9

import android.content.Context
import android.util.Base64
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * M9.6 Android Keystore-backed credential storage.
 *
 * Secrets are encrypted before being written to SharedPreferences.
 * The AES key itself is generated and retained by Android Keystore.
 *
 * This module does NOT:
 * - perform OAuth authorization
 * - exchange authorization codes for tokens
 * - transmit credentials
 * - upload videos
 * - publish externally
 *
 * It only provides secure local credential storage.
 */
class M9SecureCredentialStore(
    context: Context,
    private val preferencesName: String = DEFAULT_PREFERENCES_NAME
) : M9CredentialStore {

    private val appContext = context.applicationContext

    private val preferences =
        appContext.getSharedPreferences(
            preferencesName,
            Context.MODE_PRIVATE
        )

    override fun put(
        key: M9CredentialKey,
        secret: String
    ) {
        validateKey(key)
        require(secret.isNotEmpty()) {
            "Credential secret must not be empty."
        }

        val encrypted = encrypt(secret)

        preferences.edit()
            .putString(storageKey(key), encrypted)
            .apply()
    }

    override fun get(
        key: M9CredentialKey
    ): String? {
        validateKey(key)

        val encrypted = preferences.getString(
            storageKey(key),
            null
        ) ?: return null

        return decrypt(encrypted)
    }

    override fun remove(
        key: M9CredentialKey
    ) {
        validateKey(key)

        preferences.edit()
            .remove(storageKey(key))
            .apply()
    }

    override fun clearProvider(
        providerId: String
    ) {
        val normalized = providerId.trim()

        require(normalized.isNotEmpty()) {
            "Provider ID is required."
        }

        val editor = preferences.edit()

        preferences.all.keys
            .filter { it.startsWith("$KEY_PREFIX$normalized|") }
            .forEach { editor.remove(it) }

        editor.apply()
    }

    override fun contains(
        key: M9CredentialKey
    ): Boolean {
        validateKey(key)

        return preferences.contains(
            storageKey(key)
        )
    }

    override fun presence(
        providerId: String
    ): M9CredentialPresence {
        val normalized = providerId.trim()

        require(normalized.isNotEmpty()) {
            "Provider ID is required."
        }

        return M9CredentialPresence(
            providerId = normalized,
            accessTokenPresent = contains(
                M9CredentialKey(
                    normalized,
                    M9CredentialType.OAUTH_ACCESS_TOKEN
                )
            ),
            refreshTokenPresent = contains(
                M9CredentialKey(
                    normalized,
                    M9CredentialType.OAUTH_REFRESH_TOKEN
                )
            ),
            apiKeyPresent = contains(
                M9CredentialKey(
                    normalized,
                    M9CredentialType.API_KEY
                )
            )
        )
    }

    private fun validateKey(
        key: M9CredentialKey
    ) {
        require(key.providerId.trim().isNotEmpty()) {
            "Provider ID is required."
        }
    }

    private fun storageKey(
        key: M9CredentialKey
    ): String {
        return "$KEY_PREFIX${key.providerId.trim()}|${key.type.name}"
    }

    private fun encrypt(
        plaintext: String
    ): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)

        cipher.init(
            Cipher.ENCRYPT_MODE,
            getOrCreateSecretKey()
        )

        val ciphertext = cipher.doFinal(
            plaintext.toByteArray(StandardCharsets.UTF_8)
        )

        val iv = cipher.iv

        val combined = ByteArray(
            iv.size + ciphertext.size
        )

        System.arraycopy(
            iv,
            0,
            combined,
            0,
            iv.size
        )

        System.arraycopy(
            ciphertext,
            0,
            combined,
            iv.size,
            ciphertext.size
        )

        return Base64.encodeToString(
            combined,
            Base64.NO_WRAP
        )
    }

    private fun decrypt(
        encoded: String
    ): String {
        val combined = Base64.decode(
            encoded,
            Base64.NO_WRAP
        )

        require(combined.size > GCM_IV_LENGTH_BYTES) {
            "Stored credential data is invalid."
        }

        val iv = combined.copyOfRange(
            0,
            GCM_IV_LENGTH_BYTES
        )

        val ciphertext = combined.copyOfRange(
            GCM_IV_LENGTH_BYTES,
            combined.size
        )

        val cipher = Cipher.getInstance(TRANSFORMATION)

        cipher.init(
            Cipher.DECRYPT_MODE,
            getOrCreateSecretKey(),
            GCMParameterSpec(
                GCM_TAG_LENGTH_BITS,
                iv
            )
        )

        return String(
            cipher.doFinal(ciphertext),
            StandardCharsets.UTF_8
        )
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(
            ANDROID_KEYSTORE
        ).apply {
            load(null)
        }

        val existing = keyStore.getKey(
            KEY_ALIAS,
            null
        )

        if (existing is SecretKey) {
            return existing
        }

        val generator = KeyGenerator.getInstance(
            AES_ALGORITHM,
            ANDROID_KEYSTORE
        )

        generator.init(
            android.security.keystore.KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                    android.security.keystore.KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(
                    android.security.keystore.KeyProperties.BLOCK_MODE_GCM
                )
                .setEncryptionPaddings(
                    android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE
                )
                .setKeySize(AES_KEY_SIZE_BITS)
                .build()
        )

        return generator.generateKey()
    }

    companion object {
        private const val ANDROID_KEYSTORE = "AndroidKeyStore"
        private const val AES_ALGORITHM = "AES"
        private const val TRANSFORMATION = "AES/GCM/NoPadding"

        private const val KEY_ALIAS =
            "avsp_m9_publishing_credentials_v1"

        private const val DEFAULT_PREFERENCES_NAME =
            "avsp_m9_secure_credentials"

        private const val KEY_PREFIX =
            "credential|"

        private const val AES_KEY_SIZE_BITS = 256
        private const val GCM_TAG_LENGTH_BITS = 128
        private const val GCM_IV_LENGTH_BYTES = 12
    }
}
