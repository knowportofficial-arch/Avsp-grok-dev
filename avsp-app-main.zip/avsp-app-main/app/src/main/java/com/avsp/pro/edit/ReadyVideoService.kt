package com.avsp.pro.edit

import android.content.Context
import android.net.Uri
import com.avsp.pro.core.pipeline.PublishKit
import com.avsp.pro.logs.AvspLogger
import com.avsp.pro.publish.SeoKit
import com.avsp.pro.repository.ProjectRepository
import com.avsp.pro.storage.AvspStorage
import com.avsp.pro.storage.StorageArea
import com.avsp.pro.video.export.VideoMediaStoreExporter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * P19 "My video is already edited - just get it ready to post": the video is
 * not changed. AVSP listens to it (for the words), writes SEO title /
 * description / tags / hashtags (+ chapters), makes a thumbnail from its best
 * moment and puts a copy in the gallery so it can be shared or sent for approval.
 */
class ReadyVideoService(
    private val context: Context,
    private val projectRepository: ProjectRepository,
    private val storage: AvspStorage,
    private val logger: AvspLogger,
    private val geminiKeys: () -> List<String> = { emptyList() }
) {
    data class Outcome(val uri: String, val kit: PublishKit, val thumbnail: String?, val byAi: Boolean, val durationMs: Long)

    /** [editedUri]: post the smart-edited copy (already in the gallery) instead of the original. */
    suspend fun run(projectId: String, editedUri: String? = null, onStep: (String) -> Unit): Outcome = withContext(Dispatchers.IO) {
        val project = projectRepository.openProject(projectId)
        val asset = projectRepository.listMediaAssets(projectId)
            .filter { a -> a.mimeType.startsWith("video/") && !a.tags.contains("m4-test") && !a.tags.contains("stock") }
            .maxByOrNull { it.createdAt } ?: error("Add your video to this project first")
        val file = File(storage.resolve(StorageArea.PROJECT_DATA, asset.relativePath, projectId))
        require(file.exists()) { "The video file is missing" }
        val uri = editedUri?.let { Uri.parse(it) } ?: Uri.fromFile(file)
        val durationMs = MediaAnalysis.durationMs(context, uri)
        var words = project.metadata["smartedit.transcript"].orEmpty()
        if (words.isBlank()) {
            onStep("Listening to your video…")
            words = runCatching { SmartEditor(context, GeminiTranscriber(geminiKeys)).analyse(uri, project.language.code).transcript }.getOrDefault("")
        }
        onStep("Writing title, description and tags…")
        val topic = project.name
        val seo = SeoKit.make(words.ifBlank { project.description }, topic, (durationMs / 1000).toInt(), languageName(project.language.code), geminiKeys())
        logger.info("SEO", "Ready-to-post kit made (${if (seo.byAi) "Gemini" else "on the phone"}), ${seo.tags.size} tags", projectId = projectId)
        runCatching {
            projectRepository.updateProject(project.copy(metadata = project.metadata + mapOf(
                "seo.title" to seo.title, "seo.tags" to seo.tags.joinToString(", "), "seo.hashtags" to seo.hashtags.joinToString(" ")
            ) + (if (words.isNotBlank()) mapOf("smartedit.transcript" to words.take(6000)) else emptyMap())))
        }
        onStep("Making the thumbnail…")
        val thumb = runCatching {
            ThumbnailMaker(context).make(listOf(ThumbnailMaker.Source.Video(uri, durationMs)), seo.title, "AVSP_ready_" + System.currentTimeMillis() / 1000)?.portrait?.toString()
        }.getOrNull()
        onStep("Saving to your gallery…")
        val shareUri = editedUri ?: VideoMediaStoreExporter(context).export(sourceFile = file, projectId = projectId).uri.toString()
        Outcome(shareUri, seo.kit(), thumb, seo.byAi, durationMs)
    }

    private fun languageName(code: String) = when (code.lowercase()) { "bn" -> "Bengali"; "hi" -> "Hindi"; else -> "English" }
}
