package com.avsp.pro.video.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.effect.BitmapOverlay

/**
 * P6: one full-frame overlay per scene piece:
 *  - story-style progress bar on top (which scene of how many)
 *  - thin rounded border
 *  - caption chunk in sync with the voice (bottom third, white on dark pill)
 *  - emoji "pop" for the first 2.5 s of the scene (CTA: 👍 🔔 ↗ all scene long)
 *
 * The bitmap is rebuilt only when what is shown changes (Media3 uploads a
 * new texture only for a new Bitmap instance), so a scene costs a handful of
 * redraws, not one per frame.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class PolishOverlay(
    private val polish: PolishPlanner.ScenePolish,
    /** Where this piece starts inside its scene (a long scene can be several clip pieces). */
    private val pieceOffsetMs: Long,
    private val pieceDurationMs: Long,
    /** Absolute start of this piece in the whole video (used if the player reports absolute time). */
    private val pieceAbsoluteStartMs: Long,
    private val width: Int,
    private val height: Int,
    private val accent: Int = Color.rgb(20, 184, 166)
) : BitmapOverlay() {

    private var lastKey: String? = null
    private var lastBitmap: Bitmap? = null

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val sceneMs = Motion.sceneMs(presentationTimeUs, pieceDurationMs, pieceAbsoluteStartMs, pieceOffsetMs)
        val caption = polish.captions.firstOrNull { sceneMs >= it.startMs && sceneMs < it.endMs }
            ?: polish.captions.lastOrNull()?.takeIf { sceneMs >= it.endMs }
        val showEmoji = polish.emoji != null && (polish.isCta || sceneMs < 2500)
        // P14: the word being spoken is highlighted (karaoke style); CTA stays plain.
        val word = if (caption == null || polish.isCta) -1 else
            com.avsp.pro.edit.SoundBed.wordTimes(caption.text, caption.startMs, caption.endMs).indexOfFirst { sceneMs >= it.second && sceneMs < it.third }
        val key = "${caption?.text}|$showEmoji|$word"
        lastBitmap?.let { if (key == lastKey) return it }
        val bmp = draw(caption?.text, if (showEmoji) polish.emoji else null, word)
        lastKey = key
        lastBitmap = bmp
        return bmp
    }

    private fun draw(caption: String?, emoji: String?, word: Int = -1): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val u = width / 1080f

        // Border
        val border = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 10f * u
            color = Color.argb(150, 255, 255, 255)
        }
        val inset = 18f * u
        c.drawRoundRect(RectF(inset, inset, width - inset, height - inset), 36f * u, 36f * u, border)

        // Progress bar (one segment per scene)
        val n = polish.count.coerceAtLeast(1)
        val gap = 8f * u
        val top = 44f * u
        val left = 48f * u
        val segW = (width - 2 * left - gap * (n - 1)) / n
        val segPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        for (i in 0 until n) {
            segPaint.color = when {
                i < polish.index -> Color.WHITE
                i == polish.index -> accent
                else -> Color.argb(90, 255, 255, 255)
            }
            val x = left + i * (segW + gap)
            c.drawRoundRect(RectF(x, top, x + segW, top + 9f * u), 5f * u, 5f * u, segPaint)
        }

        // Emoji pop (top right) or CTA (centre)
        if (emoji != null) {
            val ep = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                textSize = (if (polish.isCta) 150f else 120f) * u
                textAlign = Paint.Align.CENTER
            }
            val ex = if (polish.isCta) width / 2f else width - 150f * u
            val ey = if (polish.isCta) height * 0.42f else 230f * u
            c.drawText(emoji, ex, ey, ep)
        }

        // Caption
        if (!caption.isNullOrBlank()) {
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = (if (polish.isCta) 76f else 64f) * u
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                setShadowLayer(6f * u, 0f, 2f * u, Color.argb(160, 0, 0, 0))
            }
            val maxW = (width - 160f * u).toInt()
            val shown: CharSequence = if (word < 0) caption else android.text.SpannableString(caption).also { sp ->
                Regex("\\S+").findAll(caption).elementAtOrNull(word)?.let { m ->
                    sp.setSpan(android.text.style.ForegroundColorSpan(Color.rgb(255, 214, 0)), m.range.first, m.range.last + 1, 0)
                }
            }
            val layout = StaticLayout.Builder.obtain(shown, 0, shown.length, tp, maxW)
                .setAlignment(Layout.Alignment.ALIGN_CENTER)
                .setMaxLines(3)
                .setEllipsize(android.text.TextUtils.TruncateAt.END)
                .build()
            val padX = 34f * u
            val padY = 22f * u
            var lineW = 0f
            for (i in 0 until layout.lineCount) lineW = maxOf(lineW, layout.getLineWidth(i))
            val boxW = lineW + 2 * padX
            val boxH = layout.height + 2 * padY
            // P14: inside the Reels/Shorts safe zone (their buttons cover the bottom ~35 %).
            val cy = if (polish.isCta) height * 0.50f else if (height > width) height * 0.58f else height * 0.74f
            val box = RectF((width - boxW) / 2f, cy, (width + boxW) / 2f, cy + boxH)
            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = if (polish.isCta) accent else Color.argb(170, 0, 0, 0)
            }
            c.drawRoundRect(box, 28f * u, 28f * u, bg)
            c.save()
            c.translate((width - maxW) / 2f, cy + padY)
            layout.draw(c)
            c.restore()
        }
        return bmp
    }
}
