﻿package com.avsp.pro.audio.voice

/**
 * Deterministic best-fit voice selector.
 *
 * Hard constraints are applied before scoring:
 * - language compatibility
 * - availability
 * - requested speech-rate range
 *
 * Manual voice selection is an explicit override when that voice is valid.
 * Otherwise the highest-scoring candidate wins with stable ID/provider
 * tie-breaks, making selection reproducible in tests and production logs.
 */
object BestFitVoiceSelector {

    fun select(
        request: VoiceSelectionRequest,
        voices: List<VoiceProfile>
    ): VoiceSelectionResult {
        require(request.language.isNotBlank()) { "language must not be blank" }

        val eligible = voices
            .asSequence()
            .filter { it.available }
            .filter { it.supportsLanguage(request.language) }
            .filter { it.supportsRate(request.speechRate) }
            .sortedWith(compareBy<VoiceProfile> { it.providerId }.thenBy { it.id })
            .toList()

        if (eligible.isEmpty()) {
            throw IllegalArgumentException(
                "No available voice supports language=${request.language} at speechRate=${request.speechRate}"
            )
        }

        val preferredId = request.preferredVoiceId?.trim().orEmpty()
        if (preferredId.isNotEmpty() && preferredId != "default") {
            val manual = eligible.firstOrNull { it.id == preferredId }
            if (manual != null) {
                val candidate = VoiceSelectionCandidate(
                    manual,
                    Int.MAX_VALUE,
                    listOf("manual voice preference")
                )
                return VoiceSelectionResult(manual, listOf(candidate), automatic = false)
            }
        }

        val scored = eligible.map { voice ->
            score(request, voice)
        }.sortedWith(
            compareByDescending<VoiceSelectionCandidate> { it.score }
                .thenBy { it.voice.providerId }
                .thenBy { it.voice.id }
        )

        return VoiceSelectionResult(
            selected = scored.first().voice,
            candidates = scored,
            automatic = true
        )
    }

    private fun score(
        request: VoiceSelectionRequest,
        voice: VoiceProfile
    ): VoiceSelectionCandidate {
        var score = (voice.qualityScore.coerceIn(0f, 1f) * 30f).toInt()
        val reasons = mutableListOf<String>()

        /* P2.1: the MOCK tone voice is only a last resort, never a best fit. */
        if (voice.providerId.equals("mock", ignoreCase = true) &&
            !request.preferredProviderId.equals("mock", ignoreCase = true)
        ) {
            score -= 1000
            reasons += "mock last resort"
        }

        if (request.preferredProviderId != null &&
            request.preferredProviderId.equals(voice.providerId, ignoreCase = true)
        ) {
            score += 25
            reasons += "preferred provider"
        }

        val style = styleFor(request.contentType)
        if (style != null && style in voice.styles) {
            score += 25
            reasons += "content/style match"
        }

        val gender = request.preferredGender
        if (gender != null && gender == voice.gender) {
            score += 15
            reasons += "gender preference"
        }

        val rate = request.speechRate
        val midpoint = (voice.minSpeechRate + voice.maxSpeechRate) / 2f
        val distance = kotlin.math.abs(rate - midpoint)
        if (distance <= 0.15f) {
            score += 5
            reasons += "speech-rate fit"
        }

        if (reasons.isEmpty()) reasons += "language-compatible fallback"
        return VoiceSelectionCandidate(voice, score, reasons)
    }

    private fun styleFor(type: VoiceContentType): VoiceStyle? = when (type) {
        VoiceContentType.GENERAL -> null
        VoiceContentType.NEWS -> VoiceStyle.NEWS
        VoiceContentType.DEVOTIONAL -> VoiceStyle.DEVOTIONAL
        VoiceContentType.SHORTS -> VoiceStyle.ENERGETIC
        VoiceContentType.EDUCATION -> VoiceStyle.EDUCATIONAL
        VoiceContentType.LOCAL -> VoiceStyle.CONVERSATIONAL
        VoiceContentType.STORY -> VoiceStyle.STORYTELLING
        VoiceContentType.FORMAL -> VoiceStyle.FORMAL
    }
}
