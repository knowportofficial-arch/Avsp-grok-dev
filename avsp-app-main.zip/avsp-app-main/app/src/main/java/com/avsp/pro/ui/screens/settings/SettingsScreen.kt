package com.avsp.pro.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.avsp.pro.core.model.AspectRatio
import com.avsp.pro.core.model.ProjectLanguage
import com.avsp.pro.core.ui.UiState
import com.avsp.pro.logs.LogLevel
import com.avsp.pro.settings.ConfigState
import com.avsp.pro.settings.ThemePreference
import com.avsp.pro.ui.components.ErrorState
import com.avsp.pro.ui.components.LoadingState
import com.avsp.pro.ui.viewmodel.SettingsViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onOpenModules: () -> Unit = {},
    onOpenLogs: () -> Unit = {}
) {
    val state by viewModel.state.collectAsState()
    val saved by viewModel.saved.collectAsState()

    LaunchedEffect(saved) {
        if (saved) {
            delay(1500)
            viewModel.clearSavedFlag()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)

        when (val s = state) {
            is UiState.Idle, is UiState.Loading -> LoadingState("Loading settings…")
            is UiState.Error -> ErrorState(s.message, onRetry = viewModel::refresh)
            is UiState.Success -> {
                val settings = s.data

                // ---------- AI & stock video ----------
                SettingsSection("API keys", "All free and optional - add several per service; AVSP switches to the next key when one fails. Without keys it still works offline.") {
                    val keyMessage by viewModel.keyMessage.collectAsState()
                    keyMessage?.let { Text(it, color = MaterialTheme.colorScheme.primary) }
                    // P21.5: the result also pops up, since the key box is often far below this line.
                    val toastCtx = androidx.compose.ui.platform.LocalContext.current
                    androidx.compose.runtime.LaunchedEffect(keyMessage) {
                        keyMessage?.let { android.widget.Toast.makeText(toastCtx, it, android.widget.Toast.LENGTH_LONG).show() }
                    }
                    val keys by viewModel.keys.collectAsState()
                    val tests by viewModel.testResult.collectAsState()
                    com.avsp.pro.settings.KeyProviders.all.forEachIndexed { pi, p ->
                        if (pi > 0) androidx.compose.material3.HorizontalDivider()
                        KeyRingEditor(
                            title = p.title,
                            name = p.id,
                            masked = keys[p.id].orEmpty(),
                            tests = tests,
                            newLabel = "${p.title} key(s) - one per line",
                            help = "${p.use}. Free key: ${p.getAt}",
                            onAdd = { viewModel.addKey(p.id, it) },
                            onTest = { viewModel.testKey(p.id, it) },
                            onTestAll = { viewModel.testAll(p.id) },
                            onRemove = { viewModel.removeKey(p.id, it) }
                        )
                    }
                }

                // ---------- P16: own gallery + auto-posting ----------
                SettingsSection("Your photos", null) { com.avsp.pro.ui.screens.publish.GallerySettings() }
                SettingsSection("Channel", "Your channel name and logo - used in the video ending and on every video") { com.avsp.pro.ui.screens.publish.ChannelSettings() }
                SettingsSection("Voice", "Natural voice for videos (Gemini / Azure / Google), phone voice as backup") { com.avsp.pro.ui.screens.publish.VoiceSettings() }
                SettingsSection("Self-check", "Test this phone and copy the report") { com.avsp.pro.ui.screens.publish.SelfCheckSettings() }
                SettingsSection("Speech & long videos", null) { com.avsp.pro.ui.screens.publish.SpeechAndProcessingSettings() }
                SettingsSection("Publishing", "Approve, schedule and see results in your Google Sheet") { com.avsp.pro.ui.screens.publish.PublishingSettings() }
                SettingsSection("Connect channels", "Telegram, Facebook Reels, Instagram Reels, Threads - posted together with YouTube") { com.avsp.pro.ui.screens.publish.ConnectChannels() }
                SettingsSection("Posting defaults", "Visibility, audience (kids), category - title, hashtags and thumbnail are automatic") { com.avsp.pro.ui.screens.publish.PostingDefaults() }

                // ---------- Video defaults ----------
                SettingsSection("New videos", null) {
                    EnumDropdown(
                        label = "Language",
                        options = ProjectLanguage.entries,
                        selected = settings.defaultLanguage,
                        labelFor = { it.displayName },
                        onSelected = viewModel::updateLanguage
                    )
                    EnumDropdown(
                        label = "Shape",
                        options = AspectRatio.entries,
                        selected = settings.defaultAspectRatio,
                        labelFor = { "${it.label} (${it.width}×${it.height})" },
                        onSelected = viewModel::updateAspect
                    )
                    EnumDropdown(
                        label = "Theme",
                        options = ThemePreference.entries,
                        selected = settings.themePreference,
                        labelFor = { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } },
                        onSelected = viewModel::updateTheme
                    )
                    Button(
                        onClick = { viewModel.save(settings) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (saved) "Saved ✓" else "Save")
                    }
                }

                // ---------- Advanced ----------
                SettingsSection("Advanced", "For checking problems.") {
                    androidx.compose.material3.OutlinedButton(onClick = onOpenModules, modifier = Modifier.fillMaxWidth()) {
                        Text("Studio tools status")
                    }
                    androidx.compose.material3.OutlinedButton(onClick = onOpenLogs, modifier = Modifier.fillMaxWidth()) {
                        Text("Activity log")
                    }
                    EnumDropdown(
                        label = "Log detail",
                        options = LogLevel.entries,
                        selected = settings.loggingLevel,
                        labelFor = { it.name },
                        onSelected = viewModel::updateLogLevel
                    )
                    Text(
                        "Videos are saved to your gallery in Movies/AVSP.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}

/**
 * P9: a provider's saved keys - masked (••••ABCD), each with Test and Remove -
 * plus a field to add one more. Full keys are never shown.
 */
@Composable
private fun KeyRingEditor(
    title: String,
    name: String,
    masked: List<String>,
    tests: Map<String, String>,
    newLabel: String,
    help: String,
    onAdd: (String) -> Unit,
    onTest: (Int) -> Unit,
    onTestAll: () -> Unit = {},
    onRemove: (Int) -> Unit
) {
    Text(title, style = MaterialTheme.typography.titleMedium)
    Text(
        if (masked.isEmpty()) "Not set" else "${masked.size} key${if (masked.size > 1) "s" else ""} saved - used in order, the next one takes over when a key fails",
        style = MaterialTheme.typography.bodySmall,
        color = if (masked.isEmpty()) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f) else MaterialTheme.colorScheme.primary
    )
    if (masked.size > 1) androidx.compose.material3.OutlinedButton(onClick = onTestAll) { Text("Test all ${masked.size}") }
    masked.forEachIndexed { i, m ->
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = androidx.compose.ui.Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("Key ${i + 1}  $m", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                androidx.compose.material3.TextButton(onClick = { onTest(i) }) { Text("Test") }
                androidx.compose.material3.TextButton(onClick = { onRemove(i) }) { Text("Remove") }
            }
            tests["$name#$i"]?.let {
                Text(
                    it,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (it.startsWith("✓")) MaterialTheme.colorScheme.primary
                    else if (it.startsWith("✗")) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
    if (masked.size < com.avsp.pro.settings.ApiKeyRing.MAX_KEYS) {
        var key by remember(name, masked.size) { mutableStateOf("") }
        var show by remember(name) { mutableStateOf(false) }
        val ctx = androidx.compose.ui.platform.LocalContext.current
        // P21.5: a normal (non-password) text box so the keyboard allows paste and new lines; hidden by default.
        OutlinedTextField(
            value = key,
            onValueChange = { key = it },
            label = { Text(if (masked.isEmpty()) newLabel else "Add more keys - one per line") },
            singleLine = false,
            minLines = 2,
            maxLines = 8,
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                keyboardType = androidx.compose.ui.text.input.KeyboardType.Text,
                autoCorrect = false,
                imeAction = androidx.compose.ui.text.input.ImeAction.Default
            ),
            visualTransformation = if (show) androidx.compose.ui.text.input.VisualTransformation.None else KeyMask,
            modifier = Modifier.fillMaxWidth(),
            supportingText = { Text(help) }
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { onAdd(key); key = "" }, enabled = key.isNotBlank()) { Text("Save key(s)") }
            androidx.compose.material3.OutlinedButton(onClick = {
                // Paste straight from the clipboard (works even when the keyboard offers no paste).
                val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                val t = cm?.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                if (t.isNotBlank()) onAdd(t) else android.widget.Toast.makeText(ctx, "Clipboard is empty - copy the key first", android.widget.Toast.LENGTH_LONG).show()
            }) { Text("Paste & save") }
            androidx.compose.material3.TextButton(onClick = { show = !show }) { Text(if (show) "Hide" else "Show") }
        }
    }
}

@Composable
private fun KeyTestRow(result: String?, onTest: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
    ) {
        androidx.compose.material3.OutlinedButton(onClick = onTest) { Text("Test key") }
        result?.let {
            Text(
                it,
                style = MaterialTheme.typography.bodySmall,
                color = if (it.startsWith("✓")) MaterialTheme.colorScheme.primary
                else if (it.startsWith("✗")) MaterialTheme.colorScheme.error
                else MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
private fun SettingsSection(title: String, subtitle: String?, content: @Composable () -> Unit) {
    androidx.compose.material3.Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge)
            subtitle?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f))
            }
            content()
        }
    }
}

/** P2: Gemini API key entry. The saved key is never displayed. */
@Composable
private fun AiKeyEditor(
    configured: Boolean,
    onSave: (String) -> Unit,
    onClear: () -> Unit,
    newLabel: String = "Gemini AI key (free at aistudio.google.com)",
    replaceLabel: String = "Replace Gemini AI key",
    help: String = "Used for AI script writing. Stored encrypted on this phone only."
) {
    var key by remember { mutableStateOf("") }
    OutlinedTextField(
        value = key,
        onValueChange = { key = it },
        label = { Text(if (configured) replaceLabel else newLabel) },
        singleLine = true,
        visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
        modifier = Modifier.fillMaxWidth(),
        supportingText = { Text(help) }
    )
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = { onSave(key); key = "" }, enabled = key.isNotBlank()) { Text("Save key") }
        if (configured) {
            androidx.compose.material3.OutlinedButton(onClick = onClear) { Text("Remove key") }
        }
    }
}

@Composable
private fun ConfigStateRow(label: String, state: ConfigState) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, style = MaterialTheme.typography.bodyLarge)
        Text(
            if (state == ConfigState.CONFIGURED) "Connected" else "Not set",
            style = MaterialTheme.typography.titleMedium,
            color = if (state == ConfigState.CONFIGURED) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun <T> EnumDropdown(
    label: String,
    options: List<T>,
    selected: T,
    labelFor: (T) -> String,
    onSelected: (T) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
        OutlinedTextField(
            value = labelFor(selected),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier
                .menuAnchor()
                .fillMaxWidth()
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(
                    text = { Text(labelFor(option)) },
                    onClick = {
                        onSelected(option)
                        expanded = false
                    }
                )
            }
        }
    }
}

/** P21.5: hides key characters (dots) but keeps line breaks, so several pasted keys stay visible as lines. */
private val KeyMask = androidx.compose.ui.text.input.VisualTransformation { text ->
    val masked = text.text.map { c -> if (c == '\n') '\n' else '•' }.joinToString("")
    androidx.compose.ui.text.input.TransformedText(androidx.compose.ui.text.AnnotatedString(masked), androidx.compose.ui.text.input.OffsetMapping.Identity)
}
