package com.avsp.pro.video.ui

import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.io.File

@Composable
fun VideoScreen(
    projectId: String,
    viewModel: VideoViewModel,
    onBack: () -> Unit,
    initialSource: String = ""
) {
    val state by viewModel.state.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(projectId, initialSource) {
        if (initialSource.isBlank()) {
            viewModel.prepare(projectId)
        } else {
            runCatching {
                val uri = Uri.parse(initialSource)
                val resolver = context.contentResolver
                val mimeType = resolver.getType(uri) ?: "video/mp4"
                val extension = when {
                    mimeType.contains("webm", ignoreCase = true) -> ".webm"
                    mimeType.contains("3gpp", ignoreCase = true) -> ".3gp"
                    else -> ".mp4"
                }
                val tempFile = File.createTempFile("m5_video_", extension, context.cacheDir)
                resolver.openInputStream(uri)?.use { input ->
                    tempFile.outputStream().use { output -> input.copyTo(output) }
                } ?: error("Unable to open M5 video source")
                val displayName = resolver.query(
                    uri,
                    arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
                    null,
                    null,
                    null
                )?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        cursor.getString(
                            cursor.getColumnIndexOrThrow(
                                android.provider.OpenableColumns.DISPLAY_NAME
                            )
                        )
                    } else null
                } ?: tempFile.name
                viewModel.importVideoFile(projectId, tempFile, displayName, mimeType)
            }.onFailure {
                viewModel.showError(it.message ?: "M5 video import failed")
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "M4 Video Engine",
            style = MaterialTheme.typography.headlineMedium
        )

        Text(
            if (initialSource.isBlank()) {
                "Android backend: Media3 Transformer"
            } else {
                "M5 video source imported into M4"
            },
            style = MaterialTheme.typography.bodyMedium
        )

        when (val s = state) {
            VideoUiState.Idle -> Text("Preparing…")

            is VideoUiState.Ready -> {
                Text("Scenes: ${s.plan.scenes.size}")
                Text("Audio duration: ${s.plan.totalDurationMs} ms")
                Text("Output: ${s.plan.width} × ${s.plan.height} @ ${s.plan.fps}fps")

                Button(
                    onClick = { viewModel.render(projectId) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Render Video")
                }
            }

            is VideoUiState.Rendering -> {
                Text("Rendering… ${s.progress}%")
            }

            is VideoUiState.Success -> {
                Text(
                    "M4 render SUCCESS",
                    color = MaterialTheme.colorScheme.primary
                )
                Text("Duration: ${s.durationMs} ms")
                Text("Output: ${s.width} × ${s.height}")
                Text("Project master:")
                Text(s.outputPath)

                s.exportedDisplayName?.let {
                    Text("Exported video:")
                    Text(it)
                }

                s.exportedPath?.let {
                    Text("Saved to: $it")
                }

                s.exportedUri?.let {
                    Text("MediaStore URI:")
                    Text(it)
                }
            }

            is VideoUiState.Error -> {
                Text(
                    "M4 ERROR",
                    color = MaterialTheme.colorScheme.error
                )
                Text(s.message)

                Button(
                    onClick = { viewModel.prepare(projectId) }
                ) {
                    Text("Retry")
                }
            }
        }

        Button(onClick = onBack) {
            Text("Back")
        }
    }
}
