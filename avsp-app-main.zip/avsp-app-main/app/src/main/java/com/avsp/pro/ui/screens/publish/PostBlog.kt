package com.avsp.pro.ui.screens.publish

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.avsp.pro.publish.SheetPublisher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * P29: a blog (photo slides or text) or a Telegram poll goes through the same approval queue as
 * videos: channels, time, optional poll; "Post now" sends it at once.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PostBlogDialog(
    project: String, title: String, text: String, hashtags: List<String>, images: List<android.net.Uri>,
    language: String, onDismiss: () -> Unit
) {
    val ctx = LocalContext.current
    val publisher = remember { (ctx.applicationContext as com.avsp.pro.AvspApplication).container.publisher }
    val prefs = remember { ctx.getSharedPreferences(AutoPost.PREFS, android.content.Context.MODE_PRIVATE) }
    val choices = listOf("Telegram", "Facebook", "Instagram", "Threads")
    var platforms by remember { mutableStateOf(prefs.getStringSet("blog_platforms", null)?.toSet() ?: setOf("Telegram", "Facebook")) }
    val options = remember { SheetPublisher.scheduleOptions(System.currentTimeMillis()) }
    var whenOpt by remember { mutableStateOf(options.first()) }
    var withPoll by remember { mutableStateOf(prefs.getBoolean("poll", true)) }
    var poll by remember { mutableStateOf(com.avsp.pro.publish.SeoKit.offlinePoll(title, language).replace("|", "\n")) }
    var caption by remember { mutableStateOf((text + if (hashtags.isEmpty()) "" else "\n\n" + hashtags.joinToString(" ")).trim()) }
    var busy by remember { mutableStateOf(false) }
    var note by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun go(now: Boolean) {
        busy = true; note = null
        scope.launch {
            val r = withContext(Dispatchers.IO) {
                runCatching {
                    val pics = images.take(10).mapNotNull { u -> jpeg(ctx, u) }
                    val pollLine = if (withPoll) poll.lines().map { it.trim() }.filter { it.isNotBlank() }.joinToString("|") else ""
                    val sent = publisher.sendPost(if (pics.isEmpty() && caption.isBlank()) "poll" else "blog", project, title, caption, emptyList(), pics,
                        choices.filter { it in platforms }, if (now) null else whenOpt.second, pollLine)
                    if (now) publisher.approve(sent.id, now = true) else "Waiting approval"
                }
            }
            busy = false
            r.onSuccess { s -> note = if (now) "✅ $s" else "✅ In the queue - approve it in Videos / Publish"; if (!now) onDismiss() }
                .onFailure { note = "Could not send: ${it.message}" }
        }
    }

    AlertDialog(
        onDismissRequest = { if (!busy) onDismiss() },
        title = { Text("Post: " + title.take(60)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (images.isEmpty()) "Text post" else "${images.size} picture(s)", style = MaterialTheme.typography.bodySmall)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    choices.forEach { p ->
                        FilterChip(selected = p in platforms, onClick = {
                            platforms = if (p in platforms) platforms - p else platforms + p
                            prefs.edit().putStringSet("blog_platforms", platforms).apply()
                        }, label = { Text(p) })
                    }
                }
                if ("Instagram" in platforms && images.isEmpty()) Text("Instagram needs pictures - make a Photo blog for it.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = caption, onValueChange = { caption = it }, minLines = 3, maxLines = 8, modifier = Modifier.fillMaxWidth(), label = { Text("Caption") })
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Switch(checked = withPoll, onCheckedChange = { withPoll = it })
                    Text("Telegram poll (only Telegram allows polls from apps)", style = MaterialTheme.typography.bodySmall)
                }
                if (withPoll) OutlinedTextField(value = poll, onValueChange = { poll = it }, minLines = 3, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Question, then one answer per line") })
                Text("When", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    options.forEach { o -> FilterChip(selected = o == whenOpt, onClick = { whenOpt = o }, label = { Text(o.first) }) }
                }
                note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary) }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                OutlinedButton(enabled = !busy && platforms.isNotEmpty(), onClick = { go(now = false) }) { Text("Queue") }
                Button(enabled = !busy && platforms.isNotEmpty(), onClick = { go(now = true) }) { Text(if (busy) "Sending…" else "Post now") }
            }
        },
        dismissButton = { TextButton(enabled = !busy, onClick = onDismiss) { Text("Close") } }
    )
}

/** A picture as a JPEG of at most 1440 px (keeps the sheet upload small). */
private fun jpeg(ctx: android.content.Context, uri: android.net.Uri): ByteArray? = runCatching {
    val src = ctx.contentResolver.openInputStream(uri)!!.use { android.graphics.BitmapFactory.decodeStream(it) } ?: return null
    val s = minOf(1f, 1440f / maxOf(src.width, src.height))
    val b = if (s < 1f) android.graphics.Bitmap.createScaledBitmap(src, (src.width * s).toInt(), (src.height * s).toInt(), true) else src
    java.io.ByteArrayOutputStream().also { b.compress(android.graphics.Bitmap.CompressFormat.JPEG, 88, it) }.toByteArray()
}.getOrNull()
