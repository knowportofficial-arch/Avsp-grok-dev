package com.avsp.pro.edit

import kotlin.math.abs

/**
 * P12 SMART EDIT: how usable each moment of a clip is (pure, testable).
 * Works on tiny grey-scale thumbnails (e.g. 64 x 36) sampled every [stepMs]:
 * too dark / too bright, blurry (low edge detail), frozen (no change) or
 * shaky (everything changes) moments score low.
 */
object ClipQuality {
    data class Sample(val timeMs: Long, val luma: IntArray, val width: Int, val height: Int)

    data class Score(val timeMs: Long, val score: Float, val brightness: Float, val sharpness: Float, val motion: Float)

    fun brightness(s: Sample): Float = s.luma.average().toFloat() / 255f

    /** Mean absolute Laplacian: edge detail (blur -> low). */
    fun sharpness(s: Sample): Float {
        val w = s.width; val h = s.height
        if (w < 3 || h < 3) return 0f
        var sum = 0L
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val c = s.luma[y * w + x]
            val lap = 4 * c - s.luma[y * w + x - 1] - s.luma[y * w + x + 1] - s.luma[(y - 1) * w + x] - s.luma[(y + 1) * w + x]
            sum += abs(lap)
        }
        return sum.toFloat() / ((w - 2) * (h - 2)) / 255f
    }

    /** Mean absolute change from the previous sample (0 = frozen, high = cut / shake). */
    fun motion(a: Sample?, b: Sample): Float {
        if (a == null || a.luma.size != b.luma.size) return 0.05f
        var sum = 0L
        for (i in b.luma.indices) sum += abs(b.luma[i] - a.luma[i])
        return sum.toFloat() / b.luma.size / 255f
    }

    fun score(samples: List<Sample>): List<Score> {
        var prev: Sample? = null
        return samples.map { s ->
            val br = brightness(s)
            val sh = sharpness(s)
            val mo = motion(prev, s)
            prev = s
            // 1.0 = ideal. Exposure: best around 0.25..0.8.
            val exposure = when {
                br < 0.08f -> 0f
                br < 0.22f -> (br - 0.08f) / 0.14f
                br > 0.93f -> 0f
                br > 0.82f -> (0.93f - br) / 0.11f
                else -> 1f
            }
            val detail = (sh / 0.06f).coerceIn(0f, 1f)
            // A little movement is alive; none is frozen; a lot is shake or a hard cut.
            val life = when {
                mo < 0.004f -> 0.45f
                mo < 0.12f -> 1f
                mo < 0.25f -> 1f - (mo - 0.12f) / 0.13f * 0.7f
                else -> 0.2f
            }
            Score(s.timeMs, exposure * (0.35f + 0.65f * detail) * life, br, sh, mo)
        }
    }
}
