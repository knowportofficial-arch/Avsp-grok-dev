﻿package com.avsp.pro.screen.capture

import android.graphics.RectF
import java.util.Locale
import java.util.regex.Pattern

object ScreenSensitiveSanitizer {

    data class Match(
        val type: SensitiveDataType,
        val sourceText: String,
        val maskedText: String,
        val start: Int,
        val end: Int
    )

    private val aadhaar = Pattern.compile(
        "(?<!\\d)\\d{4}[-\\s]\\d{4}[-\\s]\\d{4}(?!\\d)"
    )

    private val pan = Pattern.compile(
        "\\b[A-Z]{5}[0-9]{4}[A-Z]\\b",
        Pattern.CASE_INSENSITIVE
    )

    private val email = Pattern.compile(
        "[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,}",
        Pattern.CASE_INSENSITIVE
    )

    private val phone = Pattern.compile(
        "(?<!\\d)(?:\\+?91[-\\s]?)?[6-9]\\d{9}(?!\\d)"
    )

    private val card = Pattern.compile(
        "(?<!\\d)(?:\\d[ -]?){13,19}(?!\\d)"
    )

    /*
     * P17 SENSITIVE-ONLY NUMBER PRIVACY (replaces "every number is private"):
     * a plain number is hidden only when it looks like personal data -
     *  - a long run of 6+ digits (account / customer / reference / ID numbers), or
     *  - any number right after a sensitive label (balance, a/c, PIN, CVV, UPI,
     *    IFSC, customer id, policy, txn, roll/reg no, vehicle, DOB ...).
     * Times, dates, prices, percentages, battery, counts and small numbers stay clear.
     * Phone / card / OTP / Aadhaar / PAN / e-mail have their own rules above and below.
     */
    private val number = Pattern.compile(
        "(?<!\\d)\\d+(?!\\d)"
    )
    private val ip = Pattern.compile(
        "\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b"
    )

    private val url = Pattern.compile(
        "(?i)\\b(?:https?://|www\\.)[^\\s]+"
    )

    /*
     * OTP can appear in either direction:
     *
     * OTP: 949147
     * OTP = 949147
     * 949147 is the OTP
     * verification code 949147
     */
    private val otpForward = Pattern.compile(
        "(?i)\\b(?:otp|one[- ]?time password|verification code|security code)\\b" +
            "\\s*[:=\\-]?\\s*\\d{4,8}\\b"
    )

    private val otpReverse = Pattern.compile(
        "(?i)\\b\\d{4,8}\\b\\s*" +
            "(?:is|was|=|-)?" +
            "\\s*(?:the\\s*)?" +
            "\\b(?:otp|one[- ]?time password|verification code|security code)\\b"
    )

    /*
     * Deliberately context-based.
     * We do NOT treat every capitalized word as a person's name.
     */
    private val labelledName = Pattern.compile(
        "(?i)\\b(?:name|customer name|applicant name|user name)\\b" +
            "\\s*[:=\\-]\\s*" +
            "([A-Za-z]+(?:\\s+[A-Za-z]+){0,3})"
    )

    private fun priority(type: SensitiveDataType): Int =
        when (type) {
            SensitiveDataType.AADHAAR -> 100
            SensitiveDataType.OTP -> 95
            SensitiveDataType.PAN -> 90
            SensitiveDataType.CARD -> 85
            SensitiveDataType.PHONE -> 80
            SensitiveDataType.EMAIL -> 75
            SensitiveDataType.IP_ADDRESS -> 70
            SensitiveDataType.URL -> 65
            SensitiveDataType.NUMBER -> 50
            SensitiveDataType.NAME -> 60
            /* P1 context types are produced by ScreenContextPrivacy, not by scan(). */
            SensitiveDataType.FACE -> 40
            SensitiveDataType.ID_FIELD -> 40
            SensitiveDataType.CONTACT_NAME -> 40
        }

    /*
     * P1 false-positive filter for the universal NUMBER rule.
     *
     * "V2", "4G", "H2O": a 1-2 digit run glued to a letter is a product /
     * version token, not personal data. Longer runs ("ID12345678") are
     * still treated as sensitive.
     */
    private fun isShortAlphanumericToken(text: String, start: Int, end: Int): Boolean {
        if (end - start > 2) return false
        val before = text.getOrNull(start - 1)
        val after = text.getOrNull(end)
        return (before != null && before.isLetter()) || (after != null && after.isLetter())
    }

    /*
     * P1 visual false-positive filter (findings only, narration unchanged).
     *
     * OCR reads icon glyphs, navigation buttons and dial-pad keys as single
     * digits ("0", "1", "2"). A NUMBER of at most 2 digits is ignored when
     * its OCR line is tiny (a key / badge / glyph, at most 3 visible
     * characters) or icon-sized (line taller than normal text).
     */
    private const val ICON_LINE_HEIGHT = 0.035f

    private val sensitiveLabel = Regex(
        "(?i)\\b(balance|bal\\b|avl|a/?c\\b|acct|account|ac no|cvv|cvc|m?pin\\b|upi|ifsc|micr|customer id|cust(omer)? ?id|client id|" +
            "user ?id|login id|policy|txn|transaction|utr|ref(erence)?( no| id)?|roll no|reg(istration)? no|enrol|application no|" +
            "age\\b|code\\b|vehicle|licen[cs]e|passport|voter|epic|dob|date of birth|ration|consumer no|ca no|meter no|salary|income|" +
            "बैलेंस|खाता|ব্যালেন্স|অ্যাকাউন্ট)[^\\n]{0,18}$"
    )

    /** Times (10:45), dates (09/10/2026, 2026-10-09), money amounts, percentages and versions are not private by themselves. */
    internal fun isSensitiveNumber(text: String, start: Int, end: Int): Boolean {
        val digits = end - start
        val before = text.substring(maxOf(0, start - 28), start)
        if (sensitiveLabel.containsMatchIn(before)) return true
        val prev = text.getOrNull(start - 1); val next = text.getOrNull(end)
        // Part of a time, date, decimal, version or percentage.
        if (prev == ':' || next == ':' || prev == '/' || next == '/' || next == '%' || prev == '.' || next == '.' && text.getOrNull(end + 1)?.isDigit() == true) return false
        if (next == '-' && text.getOrNull(end + 1)?.isDigit() == true && digits <= 4) return false
        if (prev == '-' && text.getOrNull(start - 2)?.isDigit() == true && digits <= 4) return false
        // Years shown alone (2026) are dates, not personal data.
        if (digits == 4 && text.substring(start, end).toInt() in 1900..2100) return false
        if (digits >= 6) return true
        // A line that is only a number (being typed in the dialer, a code on screen) is private from 4 digits.
        val line = text.substring(text.lastIndexOf('\n', start - 1) + 1, text.indexOf('\n', end).let { if (it < 0) text.length else it })
        return digits >= 4 && line.all { it.isDigit() || it.isWhitespace() || it == '+' || it == '-' }
    }

    internal fun isVisualNoise(match: Match, lineText: String, lineHeight: Float): Boolean {
        if (match.type != SensitiveDataType.NUMBER) return false
        if (match.sourceText.count(Char::isDigit) > 2) return false
        val visible = lineText.count { !it.isWhitespace() }
        return visible <= 3 || lineHeight > ICON_LINE_HEIGHT
    }

    fun scan(text: String): List<Match> {
        if (text.isBlank()) return emptyList()

        val all = mutableListOf<Match>()

        fun collect(
            pattern: Pattern,
            type: SensitiveDataType,
            masked: (String) -> String
        ) {
            val matcher = pattern.matcher(text)

            while (matcher.find()) {
                val raw = matcher.group()
                all += Match(
                    type = type,
                    sourceText = raw,
                    maskedText = masked(raw),
                    start = matcher.start(),
                    end = matcher.end()
                )
            }
        }

        collect(aadhaar, SensitiveDataType.AADHAAR) {
            val digits = it.filter(Char::isDigit)
            "XXXX XXXX ${digits.takeLast(4)}"
        }

        collect(pan, SensitiveDataType.PAN) {
            if (it.length >= 4) {
                "${it.take(2)}***${it.takeLast(2)}"
            } else {
                "[PAN REDACTED]"
            }
        }

        collect(email, SensitiveDataType.EMAIL) {
            val at = it.indexOf('@')
            if (at > 0) {
                "${it.first()}***${it.substring(at)}"
            } else {
                "[EMAIL REDACTED]"
            }
        }

        collect(phone, SensitiveDataType.PHONE) {
            val digits = it.filter(Char::isDigit)
            if (digits.length >= 4) {
                "******${digits.takeLast(4)}"
            } else {
                "[PHONE REDACTED]"
            }
        }

        collect(card, SensitiveDataType.CARD) {
            val digits = it.filter(Char::isDigit)
            if (digits.length >= 4) {
                "**** **** **** ${digits.takeLast(4)}"
            } else {
                "[CARD REDACTED]"
            }
        }

        collect(number, SensitiveDataType.NUMBER) {
            "[NUMBER REDACTED]"
        }
        all.removeAll {
            it.type == SensitiveDataType.NUMBER &&
                (isShortAlphanumericToken(text, it.start, it.end) || !isSensitiveNumber(text, it.start, it.end))
        }
        collect(ip, SensitiveDataType.IP_ADDRESS) {
            "[IP REDACTED]"
        }

        collect(url, SensitiveDataType.URL) {
            "[URL REDACTED]"
        }

        collect(otpForward, SensitiveDataType.OTP) {
            "[OTP]"
        }

        collect(otpReverse, SensitiveDataType.OTP) {
            "[OTP]"
        }

        

        val nameMatcher = labelledName.matcher(text)

        while (nameMatcher.find()) {
            val raw = nameMatcher.group(1)

            val masked = raw
                .split(Regex("\\s+"))
                .joinToString(" ") { token ->
                    if (token.isBlank()) {
                        token
                    } else {
                        "${token.first()}***"
                    }
                }

            all += Match(
                type = SensitiveDataType.NAME,
                sourceText = raw,
                maskedText = masked,
                start = nameMatcher.start(1),
                end = nameMatcher.end(1)
            )
        }

        /*
         * Resolve overlaps deterministically.
         *
         * Higher-priority privacy types win.
         * Explicit types are used here intentionally so the
         * Android/Kotlin compiler does not have to infer the
         * generic receiver of fold/any/sortedBy.
         */
        val ranked: List<Match> =
            all.sortedWith(
                compareByDescending<Match> { match ->
                    priority(match.type)
                }.thenBy { match ->
                    match.start
                }.thenByDescending { match ->
                    match.end - match.start
                }
            )

        val accepted: MutableList<Match> =
            mutableListOf()

        for (candidate: Match in ranked) {

            var overlapsExisting = false

            for (existing: Match in accepted) {

                val overlaps =
                    candidate.start < existing.end &&
                        candidate.end > existing.start

                if (overlaps) {
                    overlapsExisting = true
                    break
                }
            }

            if (!overlapsExisting) {
                accepted.add(candidate)
            }
        }

        accepted.sortBy { match ->
            match.start
        }

        return accepted
    }

    fun sanitize(text: String): String {
        val matches = scan(text)
        if (matches.isEmpty()) return text

        val out = StringBuilder(text)

        matches
            .sortedByDescending { it.start }
            .forEach {
                out.replace(
                    it.start,
                    it.end,
                    it.maskedText
                )
            }

        return out.toString()
    }

    fun findings(
        timestampMs: Long,
        text: String,
        bounds: RectF,
        confidence: Float
    ): List<SensitiveFinding> {

        val left = bounds.left.coerceIn(0f, 1f)
        val top = bounds.top.coerceIn(0f, 1f)
        val right = bounds.right.coerceIn(left, 1f)
        val bottom = bounds.bottom.coerceIn(top, 1f)

        val matches = scan(text).filterNot {
            isVisualNoise(it, text, bottom - top)
        }

        if (matches.isEmpty()) {
            return emptyList()
        }

        val lineWidth = (right - left).coerceAtLeast(0.0001f)
        val textLength = text.length.coerceAtLeast(1)

        return matches.map { match ->

            /*
             * OCR currently supplies a line-level bounding box.
             * Convert the sensitive character span into a
             * proportional sub-region.
             *
             * Result:
             * sensitive value -> masked
             * ordinary words  -> remain visible
             */
            val startRatio =
                (match.start.toFloat() / textLength)
                    .coerceIn(0f, 1f)

            val endRatio =
                (match.end.toFloat() / textLength)
                    .coerceIn(startRatio, 1f)

            val targetLeft =
                (left + lineWidth * startRatio)
                    .coerceIn(0f, 1f)

            val targetRight =
                (left + lineWidth * endRatio)
                    .coerceIn(targetLeft, 1f)

            SensitiveFinding(
                timestampMs = timestampMs,
                type = match.type,
                maskedText = match.maskedText,
                bounds = RectF(
                    targetLeft,
                    top,
                    targetRight,
                    bottom
                ),
                confidence = confidence,
                sourceText = match.sourceText
            )
        }
    }

    fun privacySafeForNarration(text: String): String {
        return sanitize(text)
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(400)
    }

    fun privacyPolicyText(): String {
        return "Original screen-recording audio is analysis-only. " +
            "It must not be used as final narration. " +
            "Sensitive OCR content must be sanitized before script/TTS."
    }
}






