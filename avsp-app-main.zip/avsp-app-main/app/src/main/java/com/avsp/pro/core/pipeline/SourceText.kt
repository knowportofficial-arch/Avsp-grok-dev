package com.avsp.pro.core.pipeline

import java.net.HttpURLConnection

/** Pure text helpers of the UNDERSTAND step (no Android types: unit-tested on the JVM). */
object SourceText {
    const val MAX_TEXT = 6000

    data class Article(val title: String, val summary: String, val body: String)

    private val SPACES = Regex("""\s+""")
    internal fun cleanSpaces(s: String) = s.replace(SPACES, " ").trim()

    /** First sentence / line, at most 14 words. */
    internal fun titleFromText(text: String): String {
        val first = text.trim().lineSequence().map { it.trim() }.firstOrNull { it.length >= 3 } ?: return ""
        val sentence = first.split(Regex("""(?<=[.!?।])\s""")).first().trim().trimEnd('.', '!', '?', '।')
        val words = sentence.split(' ').filter { it.isNotBlank() }
        return if (words.size > 14) words.take(14).joinToString(" ") + "…" else words.joinToString(" ")
    }

    /** (title, author) from YouTube oEmbed JSON. */
    internal fun parseOEmbed(json: String): Pair<String, String>? {
        val o = org.json.JSONObject(json)
        val title = o.optString("title")
        return if (title.isBlank()) null else title to o.optString("author_name")
    }

    internal fun unescapeJson(s: String): String =
        runCatching { org.json.JSONObject("{\"v\":\"$s\"}").getString("v") }.getOrDefault(s)

    /**
     * Description of THIS video only: taken from the "videoDetails" block whose videoId
     * matches. (P8: the first "shortDescription" on the page can belong to another video.)
     */
    internal fun youTubeDescription(html: String, videoId: String? = null): String {
        val block = videoDetailsBlock(html, videoId) ?: return ""
        val m = Regex(""""shortDescription":"((?:[^"\\]|\\.)*)"""").find(block) ?: return ""
        return unescapeJson(m.groupValues[1])
            .lines()
            .filterNot { line -> line.contains("http") || line.trim().startsWith("#") }
            .joinToString("\n")
            .trim()
    }

    private fun videoDetailsBlock(html: String, videoId: String?): String? {
        var from = 0
        while (true) {
            val i = html.indexOf("\"videoDetails\":{", from)
            if (i < 0) return null
            val block = html.substring(i, minOf(html.length, i + 60_000))
            val idMatch = Regex(""""videoId":"([^"]+)"""").find(block.take(400))?.groupValues?.get(1)
            if (videoId == null || idMatch == videoId) return block
            from = i + 10
        }
    }

    /** Caption track of THIS video (its URL carries v=<id>), English first. */
    internal fun youTubeCaptionUrl(html: String, videoId: String? = null): String? {
        val tracks = html.substringAfter("\"captionTracks\":", "").takeIf { it.isNotEmpty() } ?: return null
        val urls = Regex(""""baseUrl":"((?:[^"\\]|\\.)*)"""").findAll(tracks.take(20_000))
            .map { unescapeJson(it.groupValues[1]) }
            .filter { videoId == null || it.contains("v=$videoId") }
            .toList()
        if (urls.isEmpty()) return null
        return urls.firstOrNull { it.contains("lang=en") } ?: urls.first()
    }

    /** Caption XML (<text start=".." dur="..">line</text>) -> plain text. */
    internal fun parseCaptions(xml: String): String =
        Regex("""<text[^>]*>(.*?)</text>""", RegexOption.DOT_MATCHES_ALL).findAll(xml)
            .map { decodeEntities(decodeEntities(it.groupValues[1])).replace(Regex("<[^>]+>"), " ") }
            .map { cleanSpaces(it) }
            .filter { it.isNotBlank() && !it.startsWith("[") }
            .joinToString(" ")
            .take(MAX_TEXT)

    internal fun metaContent(html: String, property: String): String? {
        val p = Regex.escape(property)
        val a = Regex("""<meta[^>]+(?:property|name)=["']$p["'][^>]*content=["']([^"']*)["']""", RegexOption.IGNORE_CASE).find(html)
        val b = Regex("""<meta[^>]+content=["']([^"']*)["'][^>]*(?:property|name)=["']$p["']""", RegexOption.IGNORE_CASE).find(html)
        return (a ?: b)?.groupValues?.get(1)?.let { decodeEntities(it).trim() }?.takeIf { it.isNotBlank() }
    }

    internal fun parseArticle(html: String): Article {
        val noScript = html
            .replace(Regex("""<(script|style|noscript|nav|header|footer|aside|form)[^>]*>.*?</\1>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)), " ")
        val title = metaContent(html, "og:title")
            ?: Regex("""<h1[^>]*>(.*?)</h1>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(noScript)?.groupValues?.get(1)
                ?.let { cleanSpaces(decodeEntities(it.replace(Regex("<[^>]+>"), " "))) }
            ?: Regex("""<title[^>]*>(.*?)</title>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1)
                ?.let { cleanSpaces(decodeEntities(it)) }
            ?: ""
        val summary = metaContent(html, "og:description") ?: metaContent(html, "description") ?: ""
        val paragraphs = Regex("""<p[^>]*>(.*?)</p>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
            .findAll(noScript)
            .map { stripReferenceNoise(cleanSpaces(decodeEntities(it.groupValues[1].replace(Regex("<[^>]+>"), " ")))) }
            .filter { p -> p.split(' ').size >= 8 && !BOILERPLATE.containsMatchIn(p) }
            .distinct()
            .toList()
        return Article(cleanTitleSite(title), summary, paragraphs.joinToString("\n").take(MAX_TEXT))
    }

    /**
     * P10: encyclopedia noise that must never be spoken or printed:
     * "[ 6 ]", "[citation needed]", "( Bengali: [ kʰɔɽɔɡɔpuɾ ] ⓘ)", "semi- planned", "( text )".
     */
    fun stripReferenceNoise(text: String): String = text
        .replace(Regex("""\[\s*(\d+|[a-z]|note \d+|citation needed|clarification needed|when\?|who\?)\s*]""", RegexOption.IGNORE_CASE), " ")
        .replace(Regex("""\(\s*(Bengali|Hindi|Bangla|Odia|Sanskrit|Urdu|Tamil|Telugu|pronounced|pronunciation|IPA|listen)\b[^()]*\)""", RegexOption.IGNORE_CASE), " ")
        .replace("ⓘ", " ")
        .replace(Regex("""(\p{Ll})- (\p{Ll})"""), "$1-$2")
        .replace(Regex("""\(\s+"""), "(")
        .replace(Regex("""\s+\)"""), ")")
        .replace(Regex("""\(\s*\)"""), " ")
        .replace(Regex("""\s+([,.;:!?])"""), "$1")
        .replace(Regex("""\s{2,}"""), " ")
        .trim()

    private val BOILERPLATE = Regex(
        """(cookie|subscribe to|sign up|newsletter|all rights reserved|copyright|advertisement|follow us|download the app|click here|terms of use|privacy policy)""",
        RegexOption.IGNORE_CASE
    )

    /** "Headline - Site" / "Headline | Site" -> "Headline". */
    private val KNOWN_SITES = setOf(
        "wikipedia", "youtube", "bbc", "bbc news", "the hindu", "ndtv", "times of india", "the times of india",
        "hindustan times", "india today", "anandabazar", "aaj tak", "news18", "reuters", "cnn", "the indian express"
    )

    internal fun cleanTitleSite(title: String): String {
        val t = title.trim()
        for (sep in listOf(" | ", " - ", " – ", " — ")) {
            val i = t.lastIndexOf(sep)
            if (i <= 0) continue
            val suffix = t.substring(i + sep.length).trim()
            val known = suffix.lowercase() in KNOWN_SITES
            if ((known && i >= 3) || (i > 20 && suffix.split(' ').size <= 4)) return t.substring(0, i).trim()
        }
        return t
    }

    internal fun decodeEntities(s: String): String = s
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
        .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ").replace("&#8217;", "’")
        .replace("&#8216;", "‘").replace("&#8220;", "“").replace("&#8221;", "”").replace("&#8211;", "–")
        .replace(Regex("""&#(\d+);""")) { m -> m.groupValues[1].toIntOrNull()?.let { String(Character.toChars(it)) } ?: m.value }
        .replace(Regex("""&#x([0-9a-fA-F]+);""")) { m -> m.groupValues[1].toIntOrNull(16)?.let { String(Character.toChars(it)) } ?: m.value }

    internal fun get(url: String): String {
        val c = java.net.URI(url).toURL().openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 10_000
            c.readTimeout = 20_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36")
            c.setRequestProperty("Accept-Language", "en-IN,en;q=0.9,hi;q=0.8")
            check(c.responseCode in 200..299) { "HTTP ${c.responseCode}" }
            return c.inputStream.bufferedReader().use { r ->
                val sb = StringBuilder()
                val buf = CharArray(8192)
                while (sb.length < 2_000_000) {
                    val n = r.read(buf); if (n < 0) break
                    sb.append(buf, 0, n)
                }
                sb.toString()
            }
        } finally {
            c.disconnect()
        }
    }
}

/**
 * P8.2: a file name fit to show as a project title. Gallery items often have
 * no name ("1000528295"); those become "Photo" / "PDF document" / "Video".
 */
fun friendlyFileTitle(rawName: String, mime: String): String {
    val name = rawName.substringAfterLast('/').substringBeforeLast('.').replace('_', ' ').replace('-', ' ').trim()
    val meaningful = name.count { it.isLetter() } >= 3
    if (meaningful) return name.replace(Regex("\\s+"), " ")
    return when {
        mime.startsWith("image/") -> "Photo"
        mime == "application/pdf" -> "PDF document"
        mime.startsWith("video/") -> "Video"
        mime.startsWith("audio/") -> "Audio"
        else -> "My file"
    }
}
