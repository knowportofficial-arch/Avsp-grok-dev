package com.avsp.pro.ui.screens.publish

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avsp.pro.publish.SheetPublisher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * P30 POSTING QUEUE inside AVSP (instead of opening the Google Sheet): channel status, counters,
 * to-do / posted / needs-a-fix lists of videos, blogs and polls, Approve / Hold / Post now, links.
 * The sheet stays only as storage. The same view opens on a PC at the sheet's web app address.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PublishQueue(onClose: () -> Unit) {
    val ctx = LocalContext.current
    val publisher = remember { (ctx.applicationContext as com.avsp.pro.AvspApplication).container.publisher }
    val scope = rememberCoroutineScope()
    var reload by remember { mutableIntStateOf(0) }
    var rows by remember { mutableStateOf<List<SheetPublisher.Row>?>(null) }
    var channels by remember { mutableStateOf<Map<String, Boolean>>(emptyMap()) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf("todo") }
    var busy by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(reload) {
        if (!publisher.isConfigured()) { error = "Connect your Google Sheet in Settings → Publishing first."; rows = emptyList(); return@LaunchedEffect }
        withContext(Dispatchers.IO) {
            runCatching { publisher.rows().second }.onSuccess { rows = it; error = null }.onFailure { error = "Sheet: ${it.message}"; if (rows == null) rows = emptyList() }
            runCatching { publisher.connect(emptyMap()) }.onSuccess { channels = it }
        }
    }
    fun stateOf(r: SheetPublisher.Row) = when {
        r.status.startsWith("Posted") -> "posted"
        r.status.startsWith("Retry") -> "retry"
        r.status == "Approved" || r.approved -> "approved"
        else -> "waiting"
    }
    fun act(id: String, now: Boolean, approve: Boolean = true) {
        busy = id
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching { publisher.approve(id, now, approve) } }
            busy = null
            android.widget.Toast.makeText(ctx, r.fold({ if (now) "Posting: $it" else if (approve) "Approved" else "On hold" }, { "Sheet: ${it.message}" }), android.widget.Toast.LENGTH_LONG).show()
            reload++
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Posting queue", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Row { TextButton(onClick = { reload++ }) { Text("Refresh") }; TextButton(onClick = onClose) { Text("Close") } }
        }
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("YouTube", "Telegram", "Facebook", "Instagram", "Threads").forEach { n ->
                val on = n == "YouTube" || channels[n.lowercase()] == true
                AssistChip(onClick = {}, label = { Text((if (on) "● " else "○ ") + n) })
            }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        val list = rows
        if (list == null) { LinearProgressIndicator(Modifier.fillMaxWidth().padding(vertical = 12.dp)); return@Column }
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Waiting" to list.count { stateOf(it) == "waiting" }, "Scheduled" to list.count { stateOf(it) == "approved" },
                "Posted" to list.count { stateOf(it) == "posted" }, "Views" to list.sumOf { it.views ?: 0L }.toInt()).forEach { (l, n) ->
                Card(Modifier.weight(1f)) {
                    Column(Modifier.padding(10.dp)) {
                        Text("$n", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text(l, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        // P33: one tap for the day - every waiting post is approved and given a good time today.
        val waiting = list.filter { stateOf(it) == "waiting" }
        if (waiting.isNotEmpty()) {
            Button(enabled = busy == null, modifier = Modifier.fillMaxWidth(), onClick = {
                busy = "all"
                scope.launch {
                    val msg = withContext(Dispatchers.IO) {
                        runCatching {
                            val now = System.currentTimeMillis()
                            val timed = waiting.filter { r -> runCatching { java.time.Instant.parse(r.schedule).toEpochMilli() > now }.getOrDefault(false) }
                            val untimed = waiting - timed.toSet()
                            timed.forEach { publisher.approve(it.id, now = false) }
                            val fmt = java.time.format.DateTimeFormatter.ofPattern("h:mm a")
                            val lines = mutableListOf<String>()
                            if (timed.isNotEmpty()) lines += "${timed.size} approved at their own time"
                            if (untimed.isNotEmpty()) {
                                if (publisher.scriptVersion.isBlank()) runCatching { publisher.connect(emptyMap()) }
                                if (publisher.scriptVersion >= "p33") {
                                    val slots = SheetPublisher.todaySlots(untimed.size, now)
                                    untimed.zip(slots).forEach { (r, t) -> publisher.approveAt(r.id, t) }
                                    lines += "${untimed.size} set for " + slots.joinToString(", ") { java.time.Instant.ofEpochMilli(it).atZone(java.time.ZoneId.systemDefault()).format(fmt) }
                                } else lines += "${untimed.size} without a time were left waiting - the sheet script needs the PC update (P33) to time them"
                            }
                            lines.joinToString(" · ")
                        }.getOrElse { "Sheet: ${it.message}" }
                    }
                    busy = null
                    android.widget.Toast.makeText(ctx, msg, android.widget.Toast.LENGTH_LONG).show()
                    reload++
                }
            }) { Text(if (busy == "all") "Scheduling…" else "▶ Post all ${waiting.size} today at good times") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("todo" to "To do", "posted" to "Posted", "retry" to "Needs a fix", "all" to "All").forEach { (k, l) ->
                FilterChip(selected = tab == k, onClick = { tab = k }, label = { Text(l) })
            }
        }
        val shown = list.filter { r -> val s = stateOf(r); tab == "all" || (if (tab == "todo") s == "waiting" || s == "approved" else s == tab) }
        if (shown.isEmpty()) Text("Nothing here.", modifier = Modifier.padding(vertical = 16.dp), style = MaterialTheme.typography.bodyMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
            items(shown, key = { it.id }) { r ->
                val s = stateOf(r)
                val stripe = when (s) { "posted" -> Color(0xFF17945A); "retry" -> Color(0xFFC43D3D); "approved" -> Color(0xFF0EB2AA); else -> Color(0xFFFFB703) }
                Card(colors = CardDefaults.cardColors()) {
                    Row(Modifier.height(androidx.compose.foundation.layout.IntrinsicSize.Min)) {
                        androidx.compose.foundation.layout.Box(Modifier.width(5.dp).fillMaxHeight().background(stripe))
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("${r.type.uppercase()} · ${r.platforms}", style = MaterialTheme.typography.labelSmall)
                            Text(r.title.ifBlank { r.project }, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            val time = r.schedule.takeIf { it.isNotBlank() && s != "posted" }?.let { sch ->
                                " · posts " + runCatching { java.time.Instant.parse(sch).atZone(java.time.ZoneId.systemDefault())
                                    .format(java.time.format.DateTimeFormatter.ofPattern("d MMM, h:mm a")) }.getOrDefault(sch)
                            }.orEmpty()
                            Text(r.status.take(140) + time, style = MaterialTheme.typography.bodySmall,
                                color = if (s == "retry") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f))
                            if (r.views != null) Text("${r.views} views · ${r.likes ?: 0} likes", style = MaterialTheme.typography.labelSmall)
                            if (r.links.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                r.links.forEach { link ->
                                    val url = link.substringBefore(' ')
                                    if (url.startsWith("http")) TextButton(onClick = { runCatching { ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url))) } }) {
                                        Text(when { "youtu" in url -> "YouTube"; "t.me" in url -> "Telegram"; "instagram" in url -> "Instagram"; "threads" in url -> "Threads"; "facebook" in url -> "Facebook"; else -> "Open" })
                                    }
                                }
                            }
                            if (s != "posted") FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                if (s == "waiting") OutlinedButton(enabled = busy == null, onClick = { act(r.id, now = false) }) { Text("Approve") }
                                if (s == "approved") OutlinedButton(enabled = busy == null, onClick = { act(r.id, now = false, approve = false) }) { Text("Hold") }
                                Button(enabled = busy == null, onClick = { act(r.id, now = true) }) { Text(if (busy == r.id) "Working…" else if (s == "retry") "Try again now" else "Post now") }
                            }
                        }
                    }
                }
            }
        }
    }
}
