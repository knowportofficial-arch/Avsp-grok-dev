package com.avsp.pro.video.integration

import com.avsp.pro.audio.integration.AudioToVideoHandoff
import com.avsp.pro.m8.M8Timeline
import com.avsp.pro.video.contract.VideoRenderPlan

/**
 * Canonical M8 -> M4 render-plan adapter.
 *
 * This is intentionally thin: VideoRenderPlanFactory owns the conversion rules,
 * while this adapter provides a stable integration seam for future M8 producers.
 */
object M8TimelineVideoRenderBridge {

    fun build(
        timeline: M8Timeline,
        audioHandoff: AudioToVideoHandoff,
        visualsByScene: Map<String, String> = emptyMap(),
        visualMimeByScene: Map<String, String> = emptyMap()
    ): VideoRenderPlan =
        VideoRenderPlanFactoryBridge.fromM8Timeline(
            timeline = timeline,
            audioHandoff = audioHandoff,
            visualsByScene = visualsByScene,
            visualMimeByScene = visualMimeByScene
        )

    private object VideoRenderPlanFactoryBridge {
        fun fromM8Timeline(
            timeline: M8Timeline,
            audioHandoff: AudioToVideoHandoff,
            visualsByScene: Map<String, String>,
            visualMimeByScene: Map<String, String>
        ): VideoRenderPlan =
            com.avsp.pro.video.contract.VideoRenderPlanFactory.fromM8Timeline(
                timeline = timeline,
                audioHandoff = audioHandoff,
                visualsByScene = visualsByScene,
                visualMimeByScene = visualMimeByScene
            )
    }
}