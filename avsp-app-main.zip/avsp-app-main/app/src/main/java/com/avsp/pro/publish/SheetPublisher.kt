package com.avsp.pro.publish

import com.avsp.pro.settings.SecureConfigStore
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection

/**
 * P16 PUBLISHING through the user's own Google Sheet (tools/sheet-publisher):
 * a finished video goes into the "Queue" sheet with its title, description,
 * hashtags, platforms and schedule. Nothing is posted until the user ticks
 * Approve in the sheet; the sheet's script then posts at the scheduled time
 * (YouTube / Telegram / Instagram / Facebook) and fills in views and likes.
 *
 * The web-app URL and token live in the encrypted store and are never shown or logged.
 */
class SheetPublisher(private val store: SecureConfigStore) {

    data class Row(val id: String, val title: String, val status: String, val platforms: String, val schedule: String,
                   val links: List<String>, val views: Long?, val likes: Long?, val approved: Boolean = false,
                   val type: String = "Video", val created: String = "", val project: String = "")

    data class Sent(val id: String, val sheetUrl: String?)

    fun isConfigured(): Boolean = !url().isNullOrBlank() && !token().isNullOrBlank()
    private fun url() = runCatching { store.getSecret(URL_KEY) }.getOrNull()?.trim()
    private fun token() = runCatching { store.getSecret(TOKEN_KEY) }.getOrNull()?.trim()

    fun save(url: String, token: String) {
        require(isWebAppUrl(url.trim())) { "That is not an Apps Script web-app link (it ends in /exec)" }
        require(token.trim().length >= 16) { "The token looks too short" }
        store.putSecret(URL_KEY, url.trim()); store.putSecret(TOKEN_KEY, token.trim())
    }

    fun clear() { store.clearSecret(URL_KEY); store.clearSecret(TOKEN_KEY) }

    /** Checks the link + token; returns the sheet's name. */
    fun ping(): String {
        val o = JSONObject(get("ping"))
        check(o.optBoolean("ok")) { o.optString("error", "sheet did not answer") }
        return o.optString("sheet", "your sheet")
    }

    /** P21.8: YouTube details sent with each video (all chosen automatically, editable in Settings -> Publishing). */
    data class Extra(
        val tags: List<String> = emptyList(),
        val categoryId: String = "22",
        val madeForKids: Boolean = false,
        val privacy: String = "public",
        val language: String = "en",
        /** P23.1 "Question|answer|answer" - posted as a Telegram poll under the video. */
        val poll: String = ""
    )

    fun send(
        video: ByteArray, videoName: String, thumbnail: ByteArray?, project: String, title: String, description: String,
        hashtags: List<String>, platforms: List<String>, scheduleAtMs: Long?, extra: Extra = Extra()
    ): Sent {
        require(video.size in 1..MAX_VIDEO_BYTES) { "Video is too big for the sheet (max ${MAX_VIDEO_BYTES / 1_000_000} MB)" }
        val body = payload(token().orEmpty(), video, videoName, thumbnail, project, title, description, hashtags, platforms, scheduleAtMs, extra)
        val o = JSONObject(post(body))
        check(o.optBoolean("ok")) { o.optString("error", "sheet refused the video") }
        return Sent(o.optString("id"), o.optString("sheet").takeIf { it.isNotBlank() })
    }

    /**
     * P29: a blog (photo slides or text) or a poll into the same queue - posted to Telegram, Facebook,
     * Instagram and Threads at its time after approval. [type] "blog" or "poll".
     */
    fun sendPost(
        type: String, project: String, title: String, text: String, hashtags: List<String>, images: List<ByteArray>,
        platforms: List<String>, scheduleAtMs: Long?, poll: String = ""
    ): Sent {
        val pics = images.take(10)
        require(pics.sumOf { it.size } <= MAX_VIDEO_BYTES) { "Pictures are too big for the sheet" }
        val body = JSONObject()
            .put("token", token()).put("action", "add").put("type", type)
            .put("id", "avsp_" + type.take(1) + java.lang.Long.toString(System.currentTimeMillis() / 1000, 36))
            .put("project", project).put("title", title.take(100)).put("description", text)
            .put("hashtags", JSONArray(hashtags)).put("platforms", JSONArray(platforms.ifEmpty { listOf("Telegram") }))
            .put("schedule", scheduleAtMs?.let { java.time.Instant.ofEpochMilli(it).toString() } ?: JSONObject.NULL)
            .put("poll", poll)
            .put("images_b64", JSONArray(pics.map { java.util.Base64.getEncoder().encodeToString(it) }))
            .toString()
        val o = JSONObject(post(body))
        check(o.optBoolean("ok")) { o.optString("error", "sheet refused the post") }
        return Sent(o.optString("id"), o.optString("sheet").takeIf { it.isNotBlank() })
    }

    /** P24: tick Approve for a sheet row from the app; [now] also clears its time and posts at once. Returns the new status. */
    fun approve(id: String, now: Boolean, approve: Boolean = true): String {
        val body = JSONObject().put("token", token()).put("action", "approve").put("id", id).put("approve", approve).put("now", now).toString()
        val o = JSONObject(post(body))
        check(o.optBoolean("ok")) { o.optString("error", "sheet did not answer") }
        return o.optString("status")
    }

    /** P26: saves channel settings in the sheet (values never come back); returns which channels are connected. */
    fun connect(settings: Map<String, String>): Map<String, Boolean> {
        val body = JSONObject().put("token", token()).put("action", "config").put("settings", JSONObject(settings)).toString()
        val o = JSONObject(post(body))
        check(o.optBoolean("ok")) { o.optString("error", "sheet did not answer") }
        scriptVersion = o.optString("version")
        return channels(o)
    }

    /** P33: the sheet script's version ("" = older than P33, which can't take a time when approving). */
    @Volatile var scriptVersion: String = ""
        private set

    /** P33: approve [id] to post at [atMs] (needs the P33 sheet script). */
    fun approveAt(id: String, atMs: Long): String {
        val body = JSONObject().put("token", token()).put("action", "approve").put("id", id).put("approve", true).put("now", false)
            .put("schedule", java.time.Instant.ofEpochMilli(atMs).toString()).toString()
        val o = JSONObject(post(body))
        check(o.optBoolean("ok")) { o.optString("error", "sheet did not answer") }
        return o.optString("status")
    }

    /** P26: checks one channel (Telegram: sends a test message). Returns (message, connected channels); throws with the reason. */
    fun test(platform: String): Pair<String, Map<String, Boolean>> {
        val o = JSONObject(post(JSONObject().put("token", token()).put("action", "test").put("platform", platform.lowercase()).toString()))
        check(o.optBoolean("ok")) { o.optString("error", "test failed") }
        return o.optString("message") to channels(o)
    }

    private fun channels(o: JSONObject): Map<String, Boolean> =
        o.optJSONObject("channels")?.let { c -> c.keys().asSequence().associateWith { c.optBoolean(it) } }.orEmpty()

    fun rows(): Pair<String?, List<Row>> {
        val o = JSONObject(get("list"))
        check(o.optBoolean("ok")) { o.optString("error", "sheet did not answer") }
        return o.optString("url").takeIf { it.isNotBlank() } to parseRows(o.optJSONArray("rows") ?: JSONArray())
    }

    private fun get(action: String): String =
        request(url()!! + "?action=$action&token=" + java.net.URLEncoder.encode(token().orEmpty(), "UTF-8"), null)

    private fun post(body: String): String = request(url()!!, body)

    /** Apps Script answers a POST with a redirect to the result; follow it with GET. */
    private fun request(start: String, body: String?): String {
        var u = start
        var method = if (body != null) "POST" else "GET"
        repeat(5) {
            val c = java.net.URI(u).toURL().openConnection() as HttpURLConnection
            try {
                c.instanceFollowRedirects = false
                c.connectTimeout = 15_000
                c.readTimeout = 120_000
                c.requestMethod = method
                if (method == "POST") {
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.setFixedLengthStreamingMode(body!!.toByteArray().size)
                    c.outputStream.use { it.write(body.toByteArray()) }
                }
                val code = c.responseCode
                if (code in 300..399) { u = c.getHeaderField("Location") ?: error("redirect without location"); method = "GET"; return@repeat }
                val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
                check(code in 200..299) { "Sheet HTTP $code" }
                check(!text.trimStart().startsWith("<")) { "Sheet answered with a web page - is the web app deployed for 'Anyone'?" }
                return text
            } finally { c.disconnect() }
        }
        error("too many redirects")
    }

    companion object {
        const val URL_KEY = "publish_sheet_url"
        const val TOKEN_KEY = "publish_sheet_token"
        const val MAX_VIDEO_BYTES = 35_000_000L
        val PLATFORMS = listOf("YouTube", "Instagram", "Facebook", "Telegram", "Threads")

        fun isWebAppUrl(u: String) = Regex("""^https://script\.google\.com/(a/[^/]+/)?macros/s/[\w-]+/exec$""").matches(u)

        fun payload(
            token: String, video: ByteArray, videoName: String, thumb: ByteArray?, project: String, title: String,
            description: String, hashtags: List<String>, platforms: List<String>, scheduleAtMs: Long?, extra: Extra = Extra()
        ): String = JSONObject()
            .put("tags", JSONArray(extra.tags.take(15))).put("category", extra.categoryId)
            .put("kids", extra.madeForKids).put("privacy", extra.privacy).put("language", extra.language).put("poll", extra.poll)
            .put("token", token).put("action", "add")
            .put("id", "avsp_" + java.lang.Long.toString(System.currentTimeMillis() / 1000, 36))
            .put("project", project).put("title", title.take(100)).put("description", description)
            .put("hashtags", JSONArray(hashtags)).put("platforms", JSONArray(platforms.ifEmpty { listOf("YouTube") }))
            .put("schedule", scheduleAtMs?.let { java.time.Instant.ofEpochMilli(it).toString() } ?: JSONObject.NULL)
            .put("video_name", videoName)
            .put("video_b64", java.util.Base64.getEncoder().encodeToString(video))
            .apply { if (thumb != null) put("thumb_b64", java.util.Base64.getEncoder().encodeToString(thumb)) }
            .toString()

        fun parseRows(arr: JSONArray): List<Row> = (0 until arr.length()).mapNotNull { i ->
            val o = arr.optJSONObject(i) ?: return@mapNotNull null
            Row(
                id = o.optString("ID"), title = o.optString("Title"), status = o.optString("Status"),
                platforms = o.optString("Platforms"), schedule = o.optString("Schedule"),
                links = listOf("YouTube", "Telegram", "Instagram", "Facebook", "Threads").map { o.optString(it) }.filter { it.isNotBlank() },
                views = o.optString("Views").toLongOrNull(), likes = o.optString("Likes").toLongOrNull(),
                approved = o.optBoolean("Approve", false),
                type = o.optString("Type").ifBlank { "Video" }, created = o.optString("Created"), project = o.optString("Project")
            )
        }

        /** "As soon as approved", today 7 pm, tomorrow 9 am (phone's time zone). */
        /**
         * P33 "post today": the rest of today's good posting times (9 AM, 1 PM, 6 PM, 8 PM, 10 PM, at least 20 min
         * from now), handed out in order; more posts than slots share the last slots 30 min apart.
         */
        fun todaySlots(count: Int, nowMs: Long, zone: java.time.ZoneId = java.time.ZoneId.systemDefault()): List<Long> {
            if (count <= 0) return emptyList()
            val now = java.time.Instant.ofEpochMilli(nowMs).atZone(zone)
            val base = listOf(9 to 0, 13 to 0, 18 to 0, 20 to 0, 22 to 0)
                .map { (h, m) -> now.toLocalDate().atTime(h, m).atZone(zone).toInstant().toEpochMilli() }
                .filter { it >= nowMs + 20 * 60_000L }
                .ifEmpty { listOf(nowMs + 20 * 60_000L) }
            return (0 until count).map { i -> if (i < base.size) base[i] else base.last() + (i - base.size + 1) * 30 * 60_000L }
        }

        /** P21.8: YouTube category from what the video is about (ids from YouTube's category list). */
        fun categoryFor(text: String): String {
            val t = text.lowercase()
            fun has(vararg w: String) = w.any { Regex("\\b$it").containsMatchIn(t) }
            return when {
                has("recipe", "cook", "kitchen", "how to", "diy", "make up", "makeup", "craft") -> "26"     // Howto & Style
                has("news", "election", "minister", "government", "police", "court") -> "25"               // News & Politics
                has("travel", "trip", "tour", "station", "railway", "platform", "temple", "beach", "visit", "city", "village") -> "19" // Travel & Events
                has("learn", "lesson", "explain", "class", "exam", "study", "school", "history", "science", "rashifal") -> "27" // Education
                has("phone", "laptop", "gadget", "review", "unbox", "app", "software", "ai ") -> "28"     // Science & Technology
                has("joke", "comedy", "funny", "meme") -> "23"                                              // Comedy
                has("song", "music", "singing", "dance") -> "10"                                            // Music
                has("cricket", "football", "match", "sport", "gym", "fitness") -> "17"                      // Sports
                else -> "22"                                                                                // People & Blogs
            }
        }

        /** "Best time": today 7 PM, or tomorrow 7 PM when that has passed (until the sheet learns a better hour). */
        fun bestTime(nowMs: Long, zone: java.time.ZoneId = java.time.ZoneId.systemDefault(), hour: Int = 19): Long {
            val now = java.time.Instant.ofEpochMilli(nowMs).atZone(zone)
            var t = now.toLocalDate().atTime(hour, 0).atZone(zone)
            if (!t.isAfter(now.plusMinutes(10))) t = t.plusDays(1)
            return t.toInstant().toEpochMilli()
        }

        fun scheduleOptions(nowMs: Long, zone: java.time.ZoneId = java.time.ZoneId.systemDefault()): List<Pair<String, Long?>> {
            val now = java.time.Instant.ofEpochMilli(nowMs).atZone(zone)
            val today7 = now.toLocalDate().atTime(19, 0).atZone(zone)
            val tomorrow9 = now.toLocalDate().plusDays(1).atTime(9, 0).atZone(zone)
            return listOfNotNull(
                "Best time (auto)" to bestTime(nowMs, zone),
                "When approved" to null,
                ("Today 7 PM" to today7.toInstant().toEpochMilli()).takeIf { today7.isAfter(now) },
                "Tomorrow 9 AM" to tomorrow9.toInstant().toEpochMilli(),
                "Tomorrow 7 PM" to now.toLocalDate().plusDays(1).atTime(19, 0).atZone(zone).toInstant().toEpochMilli()
            )
        }
    }
}
