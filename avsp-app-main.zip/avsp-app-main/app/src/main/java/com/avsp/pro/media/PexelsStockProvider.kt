package com.avsp.pro.media

import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URLEncoder

/**
 * P2: free stock video per scene from Pexels (free API key, Settings).
 * The key is read from the encrypted store and never logged.
 */
class PexelsStockProvider(
    private val apiKey: () -> String?,
    private val httpGet: (String, String) -> String = ::getJson,
    private val download: (String, File) -> Unit = ::downloadTo,
    /* P9: every saved Pexels key, key 1 first; a rejected / exhausted key falls through to the next. */
    private val apiKeys: () -> List<String> = { listOfNotNull(apiKey()?.trim()?.takeIf { it.isNotEmpty() }) }
) {
    val isConfigured: Boolean get() = apiKeys().isNotEmpty()

    /** Keys that failed with 401/403/429 in this app session are skipped. */
    private val refused = java.util.Collections.synchronizedSet(mutableSetOf<String>())

    data class Clip(val id: Long, val url: String, val width: Int, val height: Int, val durationSec: Int)

    /** Best clip for [query] in the given orientation, or null. */
    fun search(query: String, portrait: Boolean, skip: Set<String> = emptySet()): Clip? {
        val keys = apiKeys().map { it.trim() }.filter { it.isNotEmpty() && it !in refused }.distinct()
        if (keys.isEmpty() || query.isBlank()) {
            if (apiKeys().isNotEmpty() && query.isNotBlank()) error("Pexels HTTP 401 (all keys refused)")
            return null
        }
        val q = URLEncoder.encode(query.take(100), "UTF-8")
        val orientation = if (portrait) "portrait" else "landscape"
        var last: Throwable? = null
        for (key in keys) {
            try {
                val raw = httpGet("https://api.pexels.com/videos/search?query=$q&orientation=$orientation&size=medium&per_page=8", key)
                return pick(raw, portrait, skip)
            } catch (e: Exception) {
                last = e
                val m = e.message.orEmpty()
                if (m.contains("401") || m.contains("403") || m.contains("429")) refused += key else throw e
            }
        }
        throw last ?: IllegalStateException("Pexels search failed")
    }

    internal fun pick(raw: String, portrait: Boolean, skip: Set<String> = emptySet()): Clip? {
        val videos = JSONObject(raw).optJSONArray("videos") ?: return null
        var soft: Clip? = null
        for (i in 0 until videos.length()) {
            val v = videos.getJSONObject(i)
            if (v.optLong("id").toString() in skip) continue   // P22.4: turned down or already in this video
            val files = v.optJSONArray("video_files") ?: continue
            var best: Clip? = null
            for (j in 0 until files.length()) {
                val f = files.getJSONObject(j)
                if (f.optString("file_type") != "video/mp4") continue
                val w = f.optInt("width"); val h = f.optInt("height")
                if (w <= 0 || h <= 0) continue
                if (portrait != (h > w)) continue
                val shortSide = minOf(w, h)
                if (shortSide > 1080) continue
                val c = Clip(v.optLong("id"), f.optString("link"), w, h, v.optInt("duration"))
                if (best == null || minOf(best.width, best.height) < shortSide) best = c
            }
            if (best != null && best.url.startsWith("https://")) {
                // P22.3: prefer sharp (at least 720p) clips; keep a softer one only as a last resort.
                if (minOf(best.width, best.height) >= 720) return best
                if (soft == null) soft = best
            }
        }
        return soft
    }

    fun fetch(clip: Clip, target: File): File {
        target.parentFile?.mkdirs()
        download(clip.url, target)
        check(target.exists() && target.length() > 10_000) { "Stock clip download failed" }
        return target
    }

    companion object {
        private fun getJson(url: String, key: String): String {
            val c = java.net.URI(url).toURL().openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 15_000
                c.readTimeout = 30_000
                c.setRequestProperty("Authorization", key)
                val code = c.responseCode
                check(code in 200..299) { "Pexels HTTP $code" }
                return c.inputStream.bufferedReader().use { it.readText() }
            } finally {
                c.disconnect()
            }
        }

        private fun downloadTo(url: String, target: File) {
            val c = java.net.URI(url).toURL().openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 15_000
                c.readTimeout = 60_000
                c.instanceFollowRedirects = true
                check(c.responseCode in 200..299) { "Download HTTP ${c.responseCode}" }
                c.inputStream.use { input -> target.outputStream().use { input.copyTo(it) } }
            } finally {
                c.disconnect()
            }
        }
    }
}
