﻿package com.avsp.pro.core.input

import java.util.Locale

/**
 * M12 — YouTube / URL adapter.
 *
 * This adapter only converts web/video URLs into the canonical
 * UnifiedInput contract.
 *
 * It does NOT:
 * - download media
 * - call a network endpoint
 * - authenticate
 * - scrape a page
 * - extract captions
 * - invoke YouTube APIs
 * - publish anything
 *
 * Existing download/processing components remain separate.
 */
object WebVideoInputAdapter {

    enum class WebInputKind {
        YOUTUBE,
        URL
    }

    data class AdaptedWebInput(
        val input: UnifiedInput,
        val kind: WebInputKind
    )

    fun adapt(
        locator: String,
        displayName: String? = null
    ): AdaptedWebInput? {

        val value = locator.trim()

        if (!isHttpUrl(value)) {
            return null
        }

        val kind = if (isYouTubeUrl(value)) {
            WebInputKind.YOUTUBE
        } else {
            WebInputKind.URL
        }

        val type = if (kind == WebInputKind.YOUTUBE) {
            UnifiedInputType.YOUTUBE
        } else {
            UnifiedInputType.URL
        }

        return AdaptedWebInput(
            input = UnifiedInput(
                id = "web-" + value.hashCode().toUInt().toString(16),
                type = type,
                locator = value,
                displayName = displayName,
                mimeType = "text/uri-list",
                metadata = mapOf(
                    "adapter" to "M12",
                    "webInputKind" to kind.name
                )
            ),
            kind = kind
        )
    }

    private fun isHttpUrl(value: String): Boolean {
        return value.startsWith("https://", ignoreCase = true) ||
            value.startsWith("http://", ignoreCase = true)
    }

    private fun isYouTubeUrl(value: String): Boolean {
        if (!isHttpUrl(value)) return false

        val normalized = value.lowercase(Locale.ROOT)

        return normalized.contains("youtube.com/") ||
            normalized.contains("youtu.be/") ||
            normalized.contains("youtube-nocookie.com/")
    }
}
