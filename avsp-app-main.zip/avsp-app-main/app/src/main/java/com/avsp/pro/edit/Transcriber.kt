package com.avsp.pro.edit

import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import java.io.FileOutputStream
import kotlin.coroutines.resume

/**
 * P12 SMART EDIT: speech -> text with the phone's own OFFLINE recogniser
 * (Android 13+, free, no key; English / Hindi / Bengali when the phone has
 * that language pack). Each speech segment is recognised on its own, so every
 * piece of text keeps its exact time in the video (for captions and cuts).
 */
class Transcriber(private val context: Context, private val online: GeminiTranscriber? = null) {

    data class Result(val heard: List<EditPlanner.Heard>, val note: String?)

    fun available(): Boolean =
        Build.VERSION.SDK_INT >= 33 && runCatching { SpeechRecognizer.isOnDeviceRecognitionAvailable(context) }.getOrDefault(false)

    fun locale(language: String): String = when (language.lowercase()) {
        "bn" -> "bn-IN"
        "hi" -> "hi-IN"
        else -> "en-IN"
    }

    /** Recognise each segment (long ones in 14 s pieces). Never throws: returns what it could hear. */
    suspend fun transcribe(audio: MediaAnalysis.Audio, segments: List<SpeechSegmenter.Segment>, language: String): Result {
        if (!available()) {
            onlineFallback(audio, segments, language)?.let { return it }
            return Result(emptyList(), "This phone has no offline speech recogniser (needs Android 13+) - cuts use sound levels only.")
        }
        val pieces = segments.flatMap { s ->
            val out = mutableListOf<SpeechSegmenter.Segment>()
            var t = s.startMs
            while (t < s.endMs) { val e = minOf(s.endMs, t + 14_000); out += SpeechSegmenter.Segment(t, e); t = e }
            out
        }
        val heard = mutableListOf<EditPlanner.Heard>()
        var lastError: Int? = null
        for (p in pieces) {
            val from = (p.startMs * audio.sampleRate / 1000).toInt().coerceIn(0, audio.pcm.size)
            val to = (p.endMs * audio.sampleRate / 1000).toInt().coerceIn(from, audio.pcm.size)
            if (to - from < audio.sampleRate / 5) continue
            val (text, error) = recognise(audio.pcm.copyOfRange(from, to), audio.sampleRate, locale(language))
            if (!text.isNullOrBlank()) heard += EditPlanner.Heard(p.startMs, p.endMs, text.trim())
            if (error != null) lastError = error
            if (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED || error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE) break
        }
        val note = when {
            heard.isNotEmpty() -> null
            lastError == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE || lastError == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED ->
                "Offline speech pack for ${locale(language)} is not on this phone yet - downloading it; try again in a few minutes."
            lastError != null -> "Speech could not be read (error $lastError) - cuts use sound levels only."
            else -> "No words recognised."
        }
        if (lastError == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE) requestDownload(locale(language))
        // P13: nothing heard offline (no language pack yet, or the recogniser failed) -> the user's Gemini key.
        if (heard.isEmpty()) onlineFallback(audio, segments, language)?.let { return it }
        return Result(heard, note)
    }

    private fun onlineFallback(audio: MediaAnalysis.Audio, segments: List<SpeechSegmenter.Segment>, language: String): Result? {
        val g = online?.takeIf { it.available() } ?: return null
        val r = g.transcribe(audio, segments, language)
        return r.takeIf { it.heard.isNotEmpty() }
    }

    private fun intent(locale: String, pipe: ParcelFileDescriptor?, rate: Int) = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
        putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        if (pipe != null && Build.VERSION.SDK_INT >= 33) {
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE, pipe)
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_CHANNEL_COUNT, 1)
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_ENCODING, AudioFormat.ENCODING_PCM_16BIT)
            putExtra(RecognizerIntent.EXTRA_AUDIO_SOURCE_SAMPLING_RATE, rate)
        }
    }

    private fun requestDownload(locale: String) {
        if (Build.VERSION.SDK_INT < 33) return
        Handler(Looper.getMainLooper()).post {
            runCatching {
                val r = SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                r.triggerModelDownload(intent(locale, null, MediaAnalysis.RATE))
                r.destroy()
            }
        }
    }

    /** One chunk: returns (text, errorCode). Runs the recogniser on the main thread as Android requires. */
    private suspend fun recognise(pcm: ShortArray, rate: Int, locale: String): Pair<String?, Int?> {
        if (Build.VERSION.SDK_INT < 33) return null to null
        val main = Handler(Looper.getMainLooper())
        val pipe = ParcelFileDescriptor.createPipe()
        // Feed the audio (plus a little silence so the recogniser closes the utterance).
        Thread {
            runCatching {
                FileOutputStream(pipe[1].fileDescriptor).use { out ->
                    val bytes = java.nio.ByteBuffer.allocate((pcm.size + rate) * 2).order(java.nio.ByteOrder.LITTLE_ENDIAN)
                    pcm.forEach { bytes.putShort(it) }
                    repeat(rate) { bytes.putShort(0) }
                    out.write(bytes.array())
                }
            }
            runCatching { pipe[1].close() }
        }.start()
        val budget = 8_000L + pcm.size * 1000L / rate * 2
        val result = withTimeoutOrNull(budget) {
            suspendCancellableCoroutine<Pair<String?, Int?>> { cont ->
                var recognizer: SpeechRecognizer? = null
                // Some recognisers put the words only in partial results: keep the latest as a backup.
                var partial: String? = null
                fun finish(v: Pair<String?, Int?>) {
                    main.post { runCatching { recognizer?.destroy() } }
                    if (cont.isActive) cont.resume(v)
                }
                main.post {
                    try {
                        val r = SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                        recognizer = r
                        r.setRecognitionListener(object : RecognitionListener {
                            override fun onResults(results: Bundle?) {
                                val hyps = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
                                val best = hyps.firstOrNull { it.isNotBlank() } ?: partial
                                android.util.Log.i("AVSP", "speech piece: ${hyps.size} hyps, ${best?.length ?: 0} chars (partial ${partial?.length ?: 0})")
                                finish(best to null)
                            }
                            override fun onError(error: Int) {
                                android.util.Log.i("AVSP", "speech piece error $error (partial ${partial?.length ?: 0})")
                                finish(partial to (if (partial.isNullOrBlank()) error else null))
                            }
                            override fun onReadyForSpeech(params: Bundle?) {}
                            override fun onBeginningOfSpeech() {}
                            override fun onRmsChanged(rmsdB: Float) {}
                            override fun onBufferReceived(buffer: ByteArray?) {}
                            override fun onEndOfSpeech() {}
                            override fun onPartialResults(partialResults: Bundle?) {
                                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull { it.isNotBlank() }?.let { partial = it }
                            }
                            override fun onEvent(eventType: Int, params: Bundle?) {}
                        })
                        r.startListening(intent(locale, pipe[0], rate))
                    } catch (t: Throwable) {
                        finish(null to -1)
                    }
                }
                cont.invokeOnCancellation { main.post { runCatching { recognizer?.destroy() } } }
            }
        }
        runCatching { pipe[0].close() }
        return result ?: (null to SpeechRecognizer.ERROR_SPEECH_TIMEOUT)
    }
}
