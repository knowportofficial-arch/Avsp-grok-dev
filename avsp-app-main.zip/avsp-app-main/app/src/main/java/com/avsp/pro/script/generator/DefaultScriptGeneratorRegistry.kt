package com.avsp.pro.script.generator

import com.avsp.pro.settings.ConfigState
import com.avsp.pro.settings.SecureConfigKeys
import com.avsp.pro.settings.SecureConfigStore

/**
 * Default registry. P2: Gemini AI when an AI key is configured (falls back to the
 * offline generator on any error); offline generator otherwise.
 */
class DefaultScriptGeneratorRegistry(
    private val secureConfigStore: SecureConfigStore,
    private val mock: ScriptGenerator = MockScriptGenerator()
) : ScriptGeneratorRegistry {

    /** P2.2: zero-dependency default writer (real source sentences, offline). */
    private val offline: ScriptGenerator = SmartOfflineScriptGenerator(mock)

    /** P2: real AI writer, used whenever an AI key is saved in Settings. */
    private val gemini = GeminiScriptGenerator(
        apiKey = { secureConfigStore.getSecret(SecureConfigKeys.AI_API) },
        apiKeys = { com.avsp.pro.settings.ApiKeyRing.keys(secureConfigStore, SecureConfigKeys.AI_API) },
        onKeyWorked = { i -> com.avsp.pro.settings.ApiKeyRing.promote(secureConfigStore, SecureConfigKeys.AI_API, i) },
        loadPause = { secureConfigStore.getSecret(AI_PAUSE) },
        savePause = { v -> secureConfigStore.putSecret(AI_PAUSE, v) }
    )

    /** P21: backup AI writers when Gemini fails or its free quota is used up. */
    private fun keys(name: String) = com.avsp.pro.settings.ApiKeyRing.keys(secureConfigStore, name)
    private val groq = ChatScriptGenerator(
        providerId = ChatScriptGenerator.GROQ, displayName = "Groq (Llama)",
        endpoint = "https://api.groq.com/openai/v1/chat/completions",
        models = { ChatScriptGenerator.GROQ_MODELS },
        keys = { keys(ChatScriptGenerator.GROQ_KEY) },
        jsonMode = true
    )
    @Volatile private var openRouterModels: List<String>? = null
    private val openRouter = ChatScriptGenerator(
        providerId = ChatScriptGenerator.OPENROUTER, displayName = "OpenRouter (free models)",
        endpoint = "https://openrouter.ai/api/v1/chat/completions",
        models = {
            openRouterModels ?: runCatching { ChatScriptGenerator.freeModels(ChatScriptGenerator.getText("https://openrouter.ai/api/v1/models")) }
                .getOrDefault(emptyList()).ifEmpty { ChatScriptGenerator.OPENROUTER_FALLBACK }.also { openRouterModels = it }
        },
        keys = { keys(ChatScriptGenerator.OPENROUTER_KEY) },
        jsonMode = false,
        extraHeaders = mapOf("X-Title" to "AVSP")
    )

    @Volatile
    var lastFallbackReason: String? = null
        private set

    override fun available(): List<ScriptGenerator> =
        if (isRemoteConfigured()) listOf(gemini, groq, openRouter, offline, mock) else listOf(offline, mock)

    override fun isRemoteConfigured(): Boolean =
        secureConfigStore.configState(SecureConfigKeys.AI_API) == ConfigState.CONFIGURED ||
            keys(ChatScriptGenerator.GROQ_KEY).isNotEmpty() || keys(ChatScriptGenerator.OPENROUTER_KEY).isNotEmpty()

    override fun resolve(preferredProviderId: String?): ScriptGenerator {
        if (preferredProviderId == MockScriptGenerator.PROVIDER_ID) return mock
        if (!isRemoteConfigured()) return offline
        lastFallbackReason = null
        // P21: Gemini -> Groq -> OpenRouter -> offline writer (only services with a saved key).
        val chain = listOfNotNull(
            gemini.takeIf { secureConfigStore.configState(SecureConfigKeys.AI_API) == ConfigState.CONFIGURED },
            groq.takeIf { keys(ChatScriptGenerator.GROQ_KEY).isNotEmpty() },
            openRouter.takeIf { keys(ChatScriptGenerator.OPENROUTER_KEY).isNotEmpty() }
        )
        val reasons = mutableListOf<String>()
        return chain.foldRight(offline) { gen, next ->
            FallbackScriptGenerator(gen, next) { error ->
                reasons += "${gen.displayName}: " + (error.message ?: error.javaClass.simpleName).take(160)
                lastFallbackReason = reasons.joinToString(" | ")
            }
        }
    }

    fun aiConfigState(): ConfigState = secureConfigStore.configState(SecureConfigKeys.AI_API)
}

/** P9.3: stored "pause until" for an out-of-quota Gemini key set (not a secret, kept with the keys). */
private const val AI_PAUSE = "AI_QUOTA_PAUSE"
