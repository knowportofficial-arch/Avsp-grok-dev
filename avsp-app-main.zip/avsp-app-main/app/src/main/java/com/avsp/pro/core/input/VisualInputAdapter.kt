﻿package com.avsp.pro.core.input

/**
 * M13 - Screenshot / Image -> UnifiedInput adapter.
 *
 * Boundary only:
 * - classifies an existing image locator
 * - preserves the original locator
 * - does not decode pixels
 * - does not run OCR or vision
 * - does not access network resources
 * - does not upload or publish
 */
object VisualInputAdapter {

    enum class VisualInputKind {
        SCREENSHOT,
        IMAGE
    }

    data class AdaptedVisualInput(
        val input: UnifiedInput,
        val kind: VisualInputKind
    )

    fun adapt(
        locator: String,
        displayName: String? = null,
        mimeType: String? = null
    ): AdaptedVisualInput? {
        val value = locator.trim()
        if (value.isEmpty()) return null

        val mime = mimeType?.trim()?.lowercase().orEmpty()
        val name = displayName?.trim().orEmpty().lowercase()
        val lower = value.lowercase()

        val isImageMime = mime.startsWith("image/")
        val isImageExtension = lower.substringAfterLast('.', "") in setOf(
            "jpg", "jpeg", "png", "webp", "bmp", "gif", "heic", "heif"
        )

        val screenshotByMime =
            mime == "image/screenshot" || mime.contains("screenshot")

        val screenshotByName =
            name.contains("screenshot") ||
            name.contains("screen_shot") ||
            name.contains("screen-shot") ||
            name.contains("screen shot")

        val screenshotByLocator =
            lower.contains("screenshot") ||
            lower.contains("screen_shot") ||
            lower.contains("screen-shot")

        val isVisual =
            isImageMime ||
            isImageExtension ||
            screenshotByMime ||
            screenshotByName ||
            screenshotByLocator

        if (!isVisual) return null

        val kind =
            if (screenshotByMime || screenshotByName || screenshotByLocator) {
                VisualInputKind.SCREENSHOT
            } else {
                VisualInputKind.IMAGE
            }

        val input = UnifiedInput(
            id = "visual-" + value.hashCode().toUInt().toString(16),
            type = if (kind == VisualInputKind.SCREENSHOT) {
                UnifiedInputType.SCREENSHOT
            } else {
                UnifiedInputType.IMAGE
            },
            locator = value,
            displayName = displayName,
            mimeType = if (mime.isNotEmpty()) mime else "image/*",
            metadata = mapOf(
                "adapter" to "M13",
                "visualInputKind" to kind.name
            )
        )

        return AdaptedVisualInput(input = input, kind = kind)
    }
}
