package com.avsp.pro.diagnostics

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import com.avsp.pro.settings.ApiKeyRing
import com.avsp.pro.settings.KeyProviders
import com.avsp.pro.settings.SecureConfigStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * P20.1 SELF-CHECK: tests what can be tested without pointing the camera, on the phone
 * itself, and writes a plain report the user copies to Claude. Never includes key values
 * (only how many keys and whether each service accepts them).
 */
object SelfCheck {

    data class Line(val ok: Boolean?, val text: String)   // ok null = information only

    suspend fun run(context: Context, store: SecureConfigStore, testKeys: Boolean, onLine: (Line) -> Unit = {}): List<Line> = withContext(Dispatchers.IO) {
        val out = mutableListOf<Line>()
        fun add(ok: Boolean?, text: String) { val l = Line(ok, text); out += l; onLine(l) }

        // App + phone
        val pkg = runCatching { context.packageManager.getPackageInfo(context.packageName, 0) }.getOrNull()
        add(null, "AVSP ${pkg?.versionName ?: "?"} · installed ${pkg?.lastUpdateTime?.let { java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date(it)) } ?: "?"} · build ${com.avsp.pro.BuildConfig.VERSION_CODE}")
        add(null, "Phone: ${Build.MANUFACTURER} ${Build.MODEL} · Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")

        // Storage
        val free = runCatching { android.os.StatFs(context.filesDir.absolutePath).availableBytes / (1024 * 1024) }.getOrDefault(-1)
        add(free > 1024, "Free space: ${if (free >= 0) "${free / 1024} GB" else "unknown"}" + if (free in 0..1023) " - less than 1 GB, videos may fail" else "")

        // Camera
        camera(context).forEach { add(it.ok, it.text) }

        // Keys were cleared because they could not be opened?
        context.getSharedPreferences(com.avsp.pro.settings.EncryptedSecureConfigStore.KEY_EVENTS, Context.MODE_PRIVATE)
            .getLong("keys_reset_at", 0L).takeIf { it > 0 }?.let { t ->
                add(false, "Saved keys were cleared on " + java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date(t)) + " (could not be opened) - add them again")
            }
        val allKeys = KeyProviders.all.sumOf { ApiKeyRing.keys(store, it.id).size }
        if (allKeys == 0) add(false, "No API keys saved - if you had keys, the app was probably reinstalled (uninstall removes them). Add them again in Settings -> API keys")

        // Keys: count per service, optionally a live test (key values never shown)
        for (p in KeyProviders.all) {
            val keys = ApiKeyRing.keys(store, p.id)
            if (keys.isEmpty()) { add(null, "${p.title}: no key"); continue }
            if (!testKeys) { add(null, "${p.title}: ${keys.size} key(s)"); continue }
            val verdicts = keys.mapIndexed { i, k -> "#${i + 1} " + runCatching { KeyProviders.check(p, k) }.getOrElse { "error ${it.message?.take(40)}" } }
            val good = verdicts.count { it.contains("Working") }
            add(good > 0, "${p.title}: ${keys.size} key(s) - " + verdicts.joinToString("; ").take(240))
        }

        // Speech packs
        com.avsp.pro.edit.SpeechPacks.LANGS.forEach { (l, name) ->
            val st = runCatching { com.avsp.pro.edit.SpeechPacks.state(context, l) }.getOrNull()
            add(st == com.avsp.pro.edit.SpeechPacks.State.READY, "Offline speech $name: " + (st?.let { com.avsp.pro.edit.SpeechPacks.label(it) } ?: "unknown"))
        }

        // Shot planner (phone version, no network)
        runCatching {
            val scenes = listOf(
                com.avsp.pro.script.contract.ScriptScene("a", 0, 5_000, "I am at the railway platform."),
                com.avsp.pro.script.contract.ScriptScene("b", 1, 5_000, "The train arriving."),
                com.avsp.pro.script.contract.ScriptScene("c", 2, 3_000, "Follow for more!")
            )
            val plan = com.avsp.pro.capture.ShotPlanner.offline("I am at the railway platform", scenes)
            add(plan.size == 2, "Shot planner: ${plan.joinToString(" | ") { it.summary() }}")
        }.onFailure { add(false, "Shot planner failed: ${it.message}") }

        // Last crash
        val crash = runCatching { com.avsp.pro.logs.CrashReporter.last(context) }.getOrNull()
        add(crash == null, if (crash == null) "No crash recorded" else "Last crash: " + crash.lines().take(4).joinToString(" / ").take(300))
        out
    }

    private fun camera(context: Context): List<Line> = runCatching {
        val m = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val lines = mutableListOf<Line>()
        val ids = m.cameraIdList.toList()
        fun describe(facing: Int, name: String) {
            val id = ids.firstOrNull { m.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == facing }
            if (id == null) { lines += Line(facing != CameraCharacteristics.LENS_FACING_BACK, "$name camera: none"); return }
            val c = m.getCameraCharacteristics(id)
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList().orEmpty()
            val fps = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.maxOfOrNull { it.upper } ?: 0
            val zoom = if (Build.VERSION.SDK_INT >= 30) c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) else null
            val highSpeed = if (caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_CONSTRAINED_HIGH_SPEED_VIDEO))
                runCatching { c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)?.highSpeedVideoFpsRanges?.maxOfOrNull { it.upper } }.getOrNull() else null
            val stab = c.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.contains(CameraCharacteristics.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true
            val ois = (c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.size ?: 0) > 1
            val manual = caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR)
            val iso = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
            lines += Line(true, "$name camera: up to $fps fps" +
                (zoom?.let { " · zoom ${"%.1f".format(it.lower)}×–${"%.0f".format(it.upper)}×" + if (it.lower < 0.99f) " (0.5× ultra-wide OK)" else " (no ultra-wide)" } ?: "") +
                " · slow motion " + (highSpeed?.let { "true $it fps (needs camera upgrade)" } ?: "via ${if (fps >= 60) "60" else "30"} fps") +
                " · stabilisation " + listOfNotNull("video".takeIf { stab }, "optical".takeIf { ois }).ifEmpty { listOf("none") }.joinToString("+") +
                " · " + if (manual) "manual ISO ${iso?.lower}–${iso?.upper}/shutter" else "auto exposure only")
        }
        // Every camera the phone lets apps use (an ultra-wide is sometimes a separate camera).
        lines += Line(null, "Cameras open to apps: " + ids.joinToString(", ") { id ->
            val c = m.getCameraCharacteristics(id)
            val f = when (c.get(CameraCharacteristics.LENS_FACING)) { CameraCharacteristics.LENS_FACING_FRONT -> "front"; CameraCharacteristics.LENS_FACING_BACK -> "back"; else -> "other" }
            val focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
            val sensor = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            val fov = if (focal != null && sensor != null) Math.toDegrees(2 * Math.atan(sensor.width / (2.0 * focal))).toInt() else null
            val physical = if (Build.VERSION.SDK_INT >= 28) c.physicalCameraIds.size else 0
            "#$id $f" + (fov?.let { " ${it}°" } ?: "") + if (physical > 1) " (multi-lens $physical)" else ""
        })
        describe(CameraCharacteristics.LENS_FACING_BACK, "Back")
        describe(CameraCharacteristics.LENS_FACING_FRONT, "Front")
        val dual = if (Build.VERSION.SDK_INT >= 30) runCatching { m.concurrentCameraIds.any { set -> set.size >= 2 } }.getOrDefault(false) else false
        lines += Line(null, "Front + back at the same time (dual camera): " + if (dual) "supported" else "not supported - dual shots will be filmed one after the other")
        lines
    }.getOrElse { listOf(Line(false, "Camera check failed: ${it.message}")) }

    fun report(lines: List<Line>): String = buildString {
        append("AVSP self-check ").append(java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date())).append('\n')
        lines.forEach { l -> append(when (l.ok) { true -> "✅ "; false -> "❌ "; null -> "• " }).append(l.text).append('\n') }
    }
}
