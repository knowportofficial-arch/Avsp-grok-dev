package com.avsp.pro.video.doodle

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.PorterDuff
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import android.text.TextUtils
import java.io.File

/**
 * P11 DOODLE drawing (Android canvas). [draw] paints the doodle as it looks
 * [ms] into the scene, on a transparent canvas laid over the paper background.
 */
object DoodleRenderer {

    private val INK = Color.rgb(38, 50, 56)
    private val UNDERLINE = Color.rgb(229, 57, 53)

    /** Warm paper with a faint dot grid and soft darker edges (the scene background). */
    fun renderPaper(width: Int, height: Int, output: File) {
        val b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.drawColor(Color.rgb(250, 246, 236))
        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(226, 218, 198) }
        val step = width / 22f
        var y = step
        while (y < height) {
            var x = step
            while (x < width) { c.drawCircle(x, y, width / 540f * 2.2f, dot); x += step }
            y += step
        }
        val vignette = Paint().apply {
            shader = RadialGradient(width / 2f, height / 2f, maxOf(width, height) * 0.75f,
                intArrayOf(Color.TRANSPARENT, Color.argb(46, 120, 96, 60)), floatArrayOf(0.6f, 1f), Shader.TileMode.CLAMP)
        }
        c.drawRect(0f, 0f, width.toFloat(), height.toFloat(), vignette)
        output.parentFile?.mkdirs()
        output.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) }
        b.recycle()
    }

    /**
     * Opaque colour between paper and [accent]. Half-transparent overlay colours come out
     * dark and muddy after the video engine blends them (measured: yellow looked olive),
     * so fills fade in by colour, not by transparency.
     */
    private fun onPaper(accent: Long, p: Float): Int {
        fun mix(paper: Int, c: Int) = (paper + (c - paper) * p).toInt().coerceIn(0, 255)
        return Color.rgb(mix(250, ((accent shr 16) and 0xFF).toInt()), mix(246, ((accent shr 8) and 0xFF).toInt()), mix(236, (accent and 0xFF).toInt()))
    }

    private fun hand(): Typeface = runCatching { Typeface.create("casual", Typeface.BOLD) }.getOrDefault(Typeface.DEFAULT_BOLD)

    private class Built(val paths: List<Path>, val lengths: List<Float>, val fill: Path?)

    private fun build(icon: DoodleIcon, box: RectF, seed: Int): Built {
        val sx = box.width() / 100f
        val sy = box.height() / 100f
        var k = 0
        fun pt(p: Pair<Float, Float>): Pair<Float, Float> {
            k++
            return (box.left + (p.first + DoodlePlanner.wobble(seed, k)) * sx) to (box.top + (p.second + DoodlePlanner.wobble(seed + 7, k)) * sy)
        }
        val paths = icon.strokes.map { s ->
            Path().apply {
                val pts = s.map(::pt)
                if (pts.isEmpty()) return@apply
                moveTo(pts[0].first, pts[0].second)
                // Smooth through midpoints so pen lines look natural.
                for (i in 1 until pts.size) {
                    val (x0, y0) = pts[i - 1]
                    val (x1, y1) = pts[i]
                    quadTo(x0, y0, (x0 + x1) / 2f, (y0 + y1) / 2f)
                }
                lineTo(pts.last().first, pts.last().second)
            }
        }
        val lengths = paths.map { PathMeasure(it, false).length }
        val fill = icon.fill.takeIf { it.size >= 3 }?.let { f ->
            Path().apply {
                val pts = f.map { (x, y) -> (box.left + x * sx) to (box.top + y * sy) }
                moveTo(pts[0].first, pts[0].second); pts.drop(1).forEach { lineTo(it.first, it.second) }; close()
            }
        }
        return Built(paths, lengths, fill)
    }

    /** Draws the doodle at [ms] into the scene. Returns the pen position while drawing (or null). */
    fun draw(c: Canvas, spec: DoodleSpec, ms: Long, w: Int, h: Int, seed: Int): Pair<Float, Float>? {
        c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR)
        val u = w / 720f
        var pen: Pair<Float, Float>? = null

        // ---- icons (or zodiac glyph) in the middle band
        val top = h * 0.37f
        val bottom = h * 0.69f
        val icons = spec.icons.mapNotNull { DoodleIcons.ALL[it] }.take(2)
        val boxes: List<RectF> = when {
            spec.glyph != null -> listOf(RectF(w * 0.66f, top - 40f * u, w * 0.90f, top - 40f * u + w * 0.24f))
            icons.size == 2 -> {
                val s = minOf(w * 0.40f, bottom - top)
                listOf(RectF(w * 0.07f, (top + bottom - s) / 2, w * 0.07f + s, (top + bottom + s) / 2),
                    RectF(w * 0.93f - s, (top + bottom - s) / 2, w * 0.93f, (top + bottom + s) / 2))
            }
            else -> {
                val s = minOf(w * 0.62f, bottom - top)
                listOf(RectF((w - s) / 2, (top + bottom - s) / 2, (w + s) / 2, (top + bottom + s) / 2))
            }
        }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = 7f * u; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = INK
        }
        val pStrokes = DoodlePlanner.phase(ms, 0, DoodlePlanner.ICONS_END_MS)
        val pFill = DoodlePlanner.phase(ms, DoodlePlanner.ICONS_END_MS - 250, DoodlePlanner.FILL_END_MS)

        if (spec.glyph != null) {
            // Big zodiac sign in a hand-drawn ring.
            val cx = w / 2f; val cy = (top + bottom) / 2f; val r = minOf(w * 0.30f, (bottom - top) / 2f)
            val ring = build(DoodleIcon("ring", listOf(DoodleIcons.ALL.getValue("check").strokes[0])), RectF(cx - r, cy - r, cx + r, cy + r), seed)
            if (pFill > 0f) c.drawCircle(cx, cy, r * 0.66f, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = onPaper(0xFFFFD54F, pFill) })
            pen = drawPartial(c, ring, pStrokes, stroke) ?: pen
            val gp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = INK; textSize = r * 1.0f; textAlign = Paint.Align.CENTER
                alpha = (255 * DoodlePlanner.phase(ms, 300, 1100)).toInt()
            }
            c.drawText(spec.glyph, cx, cy + r * 0.35f, gp)
        }
        icons.forEachIndexed { i, icon ->
            val b = build(icon, boxes.getOrElse(i) { boxes[0] }, seed + i * 31)
            if (b.fill != null && pFill > 0f) {
                c.drawPath(b.fill, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = onPaper(icon.accent, pFill) })
            }
            pen = drawPartial(c, b, pStrokes, stroke) ?: pen
        }

        // ---- handwritten headline, revealed left to right, then underlined
        if (spec.headline.isNotBlank()) {
            val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = INK; typeface = hand(); textSize = (if (spec.headline.length > 28) 54f else 66f) * u
            }
            val maxW = (w - 110f * u).toInt()
            val layout = StaticLayout.Builder.obtain(spec.headline, 0, spec.headline.length, tp, maxW)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setMaxLines(3).setEllipsize(TextUtils.TruncateAt.END)
                .setLineSpacing(0f, 1.05f).build()
            val x0 = (w - maxW) / 2f
            val y0 = h * 0.15f
            val pText = DoodlePlanner.phase(ms, DoodlePlanner.TEXT_START_MS, DoodlePlanner.TEXT_END_MS)
            val reveal = pText * layout.lineCount
            for (line in 0 until layout.lineCount) {
                val lp = (reveal - line).coerceIn(0f, 1f)
                if (lp <= 0f) break
                val left = x0 + layout.getLineLeft(line)
                val right = left + layout.getLineWidth(line) * lp
                c.save()
                c.clipRect(left - 4f, y0 + layout.getLineTop(line), right, y0 + layout.getLineBottom(line))
                c.translate(x0, y0)
                layout.draw(c)
                c.restore()
                if (lp < 1f) pen = right to (y0 + layout.getLineBaseline(line))
            }
            val pLine = DoodlePlanner.phase(ms, DoodlePlanner.TEXT_END_MS - 100, DoodlePlanner.UNDERLINE_END_MS)
            if (pLine > 0f) {
                val last = layout.lineCount - 1
                val lx = x0 + layout.getLineLeft(last)
                val lw = layout.getLineWidth(last)
                val ly = y0 + layout.getLineBottom(last) + 8f * u
                val wave = Path().apply {
                    moveTo(lx, ly)
                    val n = 6
                    for (i in 1..n) {
                        val x = lx + lw * i / n
                        quadTo(x - lw / n / 2f, ly + (if (i % 2 == 0) -9f else 9f) * u, x, ly)
                    }
                }
                val m = PathMeasure(wave, false)
                val part = Path()
                m.getSegment(0f, m.length * pLine, part, true)
                c.drawPath(part, Paint(stroke).apply { color = UNDERLINE; strokeWidth = 8f * u })
                if (pLine < 1f) {
                    val pos = FloatArray(2); m.getPosTan(m.length * pLine, pos, null); pen = pos[0] to pos[1]
                }
            }
        }
        if (ms < DoodlePlanner.DONE_MS) pen?.let { drawPencil(c, it.first, it.second, u) }
        return pen
    }

    private fun drawPartial(c: Canvas, b: Built, p: Float, paint: Paint): Pair<Float, Float>? {
        val total = b.lengths.sum().coerceAtLeast(1f)
        var left = total * p
        var pen: Pair<Float, Float>? = null
        b.paths.forEachIndexed { i, path ->
            if (left <= 0f) return@forEachIndexed
            val len = b.lengths[i]
            if (left >= len) { c.drawPath(path, paint); left -= len }
            else {
                val m = PathMeasure(path, false)
                val part = Path()
                m.getSegment(0f, left, part, true)
                c.drawPath(part, paint)
                val pos = FloatArray(2); m.getPosTan(left, pos, null); pen = pos[0] to pos[1]
                left = 0f
            }
        }
        return if (p < 1f) pen else null
    }

    /** A small pencil whose tip sits on the line being drawn. */
    private fun drawPencil(c: Canvas, x: Float, y: Float, u: Float) {
        c.save()
        c.translate(x, y)
        c.rotate(-35f)
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 193, 7) }
        val wood = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 224, 178) }
        val lead = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = INK }
        val tipLen = 26f * u; val width = 20f * u; val bodyLen = 120f * u
        c.drawPath(Path().apply { moveTo(0f, 0f); lineTo(tipLen, -width / 2); lineTo(tipLen, width / 2); close() }, wood)
        c.drawPath(Path().apply { moveTo(0f, 0f); lineTo(tipLen * 0.35f, -width * 0.18f); lineTo(tipLen * 0.35f, width * 0.18f); close() }, lead)
        c.drawRect(tipLen, -width / 2, tipLen + bodyLen, width / 2, body)
        c.drawRect(tipLen + bodyLen, -width / 2, tipLen + bodyLen + 18f * u, width / 2, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(240, 98, 146) })
        c.restore()
    }
}
