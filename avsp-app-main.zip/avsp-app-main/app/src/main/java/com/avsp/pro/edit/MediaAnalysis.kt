package com.avsp.pro.edit

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File
import java.nio.ByteOrder

/**
 * P12 SMART EDIT (Android): reads a video's sound and pictures for the planner.
 *  - [extractAudio]: decodes the audio track to 16 kHz mono PCM (on the phone, offline)
 *  - [sampleFrames]: tiny grey-scale thumbnails every [stepMs] for [ClipQuality]
 */
object MediaAnalysis {
    const val RATE = 16_000

    data class Audio(val pcm: ShortArray, val sampleRate: Int)

    fun durationMs(context: Context, uri: Uri): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(context, uri)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally { r.release() }
    }

    /** Whole audio track as 16 kHz mono PCM, or null when the video has no sound. */
    fun extractAudio(context: Context, uri: Uri, maxMs: Long = 15 * 60_000L): Audio? {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(context, uri, null)
            val track = (0 until ex.trackCount).firstOrNull {
                ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: return null
            ex.selectTrack(track)
            val fmt = ex.getTrackFormat(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME)!!
            val codec = MediaCodec.createDecoderByType(mime)
            codec.configure(fmt, null, null, 0)
            codec.start()
            var srcRate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val mono = java.io.ByteArrayOutputStream()
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            // Running resampler state (linear interpolation to 16 kHz).
            var pos = 0.0
            var prev = 0
            val out = ShortBuilder()
            while (!outputDone) {
                if (!inputDone) {
                    val ix = codec.dequeueInputBuffer(10_000)
                    if (ix >= 0) {
                        val buf = codec.getInputBuffer(ix)!!
                        val n = ex.readSampleData(buf, 0)
                        if (n < 0 || ex.sampleTime / 1000 > maxMs) {
                            codec.queueInputBuffer(ix, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true
                        } else {
                            codec.queueInputBuffer(ix, 0, n, ex.sampleTime, 0); ex.advance()
                        }
                    }
                }
                val ox = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    ox == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        srcRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    ox >= 0 -> {
                        val ob = codec.getOutputBuffer(ox)!!.order(ByteOrder.LITTLE_ENDIAN)
                        ob.position(info.offset); ob.limit(info.offset + info.size)
                        val sb = ob.asShortBuffer()
                        val frames = sb.remaining() / channels.coerceAtLeast(1)
                        val step = srcRate.toDouble() / RATE
                        for (f in 0 until frames) {
                            var sum = 0
                            for (c in 0 until channels) sum += sb.get(f * channels + c)
                            val s = sum / channels.coerceAtLeast(1)
                            // emit output samples that fall between prev and s
                            while (pos <= 1.0) {
                                out.add((prev + (s - prev) * pos).toInt().coerceIn(-32768, 32767).toShort())
                                pos += step
                            }
                            pos -= 1.0
                            prev = s
                        }
                        codec.releaseOutputBuffer(ox, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                }
            }
            codec.stop(); codec.release()
            mono.close()
            return Audio(out.toArray(), RATE)
        } finally {
            ex.release()
        }
    }

    /** Tiny grey frames (64 px wide) every [stepMs] - enough to judge exposure, blur and motion. */
    fun sampleFrames(context: Context, uri: Uri, durationMs: Long, stepMs: Long = 500, maxSamples: Int = 360): List<ClipQuality.Sample> {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, uri)
            val step = maxOf(stepMs, durationMs / maxSamples)
            val out = mutableListOf<ClipQuality.Sample>()
            var t = 0L
            while (t < durationMs) {
                val bmp: Bitmap? = if (android.os.Build.VERSION.SDK_INT >= 27)
                    r.getScaledFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 64, 64)
                else r.getFrameAtTime(t * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { Bitmap.createScaledBitmap(it, 64, 36, true) }
                if (bmp != null) {
                    val w = bmp.width; val h = bmp.height
                    val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
                    val luma = IntArray(px.size) { i -> val c = px[i]; (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000 }
                    out += ClipQuality.Sample(t, luma, w, h)
                    bmp.recycle()
                }
                t += step
            }
            return out
        } finally { r.release() }
    }

    /** 16-bit mono PCM -> WAV file (for the speech recogniser and for checks). */
    fun writeWav(pcm: ShortArray, rate: Int, file: File) {
        file.parentFile?.mkdirs()
        val bb = java.nio.ByteBuffer.allocate(44 + pcm.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size * 2); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1); bb.putInt(rate); bb.putInt(rate * 2); bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size * 2)
        pcm.forEach { bb.putShort(it) }
        file.writeBytes(bb.array())
    }

    private class ShortBuilder {
        private var a = ShortArray(1 shl 16)
        private var n = 0
        fun add(s: Short) { if (n == a.size) a = a.copyOf(a.size * 2); a[n++] = s }
        fun toArray(): ShortArray = a.copyOf(n)
    }
}
