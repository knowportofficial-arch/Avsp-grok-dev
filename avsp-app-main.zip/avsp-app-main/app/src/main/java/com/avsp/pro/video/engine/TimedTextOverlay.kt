package com.avsp.pro.video.engine

import android.graphics.Typeface
import android.text.SpannableString
import android.text.style.StyleSpan
import androidx.media3.effect.TextOverlay
import com.avsp.pro.video.contract.VideoCaptionInput

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class TimedTextOverlay(
    private val captions: List<VideoCaptionInput>
) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString {
        val active = TimedCaptionSelector.active(captions, presentationTimeUs / 1000L)
        if (active.isEmpty()) return SpannableString("")
        val text = active.joinToString(" ") { it.text.trim() }
        val result = SpannableString(text)
        if (active.any { it.emphasis } && text.isNotEmpty()) {
            result.setSpan(
                StyleSpan(Typeface.BOLD), 0, text.length,
                SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        return result
    }
}