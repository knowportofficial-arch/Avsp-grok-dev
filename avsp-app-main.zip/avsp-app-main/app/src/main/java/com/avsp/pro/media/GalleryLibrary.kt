package com.avsp.pro.media

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * P16 PHONE GALLERY as a picture source (opt-in in Settings): the user's own
 * photos and videos on the phone - including Google Photos pictures kept on
 * the phone - are tagged on-device (ML Kit labels, nothing uploaded) and a
 * matching one is used for a scene before any internet picture.
 *
 * Privacy: off by default; selfies / close-up people are never picked unless
 * the scene is about people; screenshots, WhatsApp/stickers and AVSP's own
 * outputs are skipped. Every gallery item used is listed in the result.
 */
class GalleryLibrary(private val context: Context) {

    data class Item(val id: Long, val video: Boolean, val dateMs: Long, val labels: List<String>) {
        val uri: Uri get() = ContentUris.withAppendedId(if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id)
        val key get() = (if (video) "v" else "i") + id
    }

    private val indexFile = File(context.filesDir, "gallery_index.json")
    private val prefs get() = context.getSharedPreferences("avsp_gallery", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = prefs.getBoolean("enabled", false)
        set(v) { prefs.edit().putBoolean("enabled", v).apply() }

    fun hasPermission(): Boolean {
        val perms = if (Build.VERSION.SDK_INT >= 33) listOf(android.Manifest.permission.READ_MEDIA_IMAGES)
        else listOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        return perms.all { context.checkSelfPermission(it) == android.content.pm.PackageManager.PERMISSION_GRANTED }
    }

    @Synchronized fun load(): MutableMap<String, Item> = runCatching {
        val o = JSONObject(indexFile.readText())
        val out = mutableMapOf<String, Item>()
        o.keys().forEach { k ->
            val j = o.getJSONObject(k)
            val labels = j.optJSONArray("l") ?: JSONArray()
            out[k] = Item(j.getLong("id"), j.optBoolean("v"), j.optLong("d"), (0 until labels.length()).map { labels.getString(it) })
        }
        out
    }.getOrDefault(mutableMapOf())

    @Synchronized private fun save(items: Map<String, Item>) {
        val o = JSONObject()
        items.forEach { (k, it) -> o.put(k, JSONObject().put("id", it.id).put("v", it.video).put("d", it.dateMs).put("l", JSONArray(it.labels))) }
        val tmp = File(indexFile.parentFile, indexFile.name + ".tmp")
        tmp.writeText(o.toString()); tmp.renameTo(indexFile)
    }

    fun size(): Int = load().size

    /**
     * Tags up to [maxNew] newest not-yet-tagged photos/videos (≈40 ms each, on the phone,
     * offline). Returns how many were added. Safe to call again: it continues where it stopped.
     */
    @android.annotation.SuppressLint("NewApi")
    fun index(maxNew: Int = 300, budgetMs: Long = 60_000): Int {
        if (Build.VERSION.SDK_INT < 29 || !enabled || !hasPermission()) return 0
        val started = System.currentTimeMillis()
        val items = load()
        val labeler = ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.62f).build())
        var added = 0
        try {
            for (video in listOf(false, true)) {
                val table = if (video) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val cols = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATE_MODIFIED, MediaStore.MediaColumns.RELATIVE_PATH, MediaStore.MediaColumns.SIZE)
                runCatching { context.contentResolver.query(table, cols, null, null, "${MediaStore.MediaColumns.DATE_MODIFIED} DESC") }.getOrNull()?.use { c ->
                    var seen = 0
                    while (c.moveToNext() && added < maxNew && seen < 2_000) {
                        seen++
                        if (System.currentTimeMillis() - started > budgetMs) return@use
                        val id = c.getLong(0)
                        val key = (if (video) "v" else "i") + id
                        if (items.containsKey(key)) continue
                        val path = c.getString(2).orEmpty()
                        if (skipFolder(path) || (video && c.getLong(3) > MAX_VIDEO_BYTES)) { items[key] = Item(id, video, 0, emptyList()); continue }
                        val uri = ContentUris.withAppendedId(table, id)
                        val thumb = runCatching { context.contentResolver.loadThumbnail(uri, Size(384, 384), null) }.getOrNull()
                        val labels = thumb?.let { b ->
                            runCatching {
                                Tasks.await(labeler.process(InputImage.fromBitmap(b, 0)), 4, TimeUnit.SECONDS).map { it.text.lowercase() }
                            }.getOrDefault(emptyList()).also { b.recycle() }
                        }.orEmpty()
                        // P31: event shots also carry their folder's words (day, pandal / place) as labels.
                        val eventWords = if (path.lowercase().contains("avsp/events/")) eventLabels(path) else emptyList()
                        items[key] = Item(id, video, c.getLong(1) * 1000, (labels + eventWords).distinct())
                        added++
                        if (added % 40 == 0) save(items)
                    }
                }
            }
        } finally {
            labeler.close()
            save(items)
        }
        return added
    }

    /** Copies [item] into [out] (photos re-encoded ≤ 1920 px, videos copied as they are). */
    fun copyTo(item: Item, out: File) {
        out.parentFile?.mkdirs()
        if (item.video) {
            context.contentResolver.openInputStream(item.uri)!!.use { i -> out.outputStream().use { o -> i.copyTo(o) } }
            return
        }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(item.uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= 1920) sample *= 2
        val bmp = context.contentResolver.openInputStream(item.uri)!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sample }) }
            ?: error("Could not read gallery photo")
        val rotated = rotateByExif(item.uri, bmp)
        out.outputStream().use { rotated.compress(Bitmap.CompressFormat.JPEG, 90, it) }
        rotated.recycle()
    }

    private fun rotateByExif(uri: Uri, b: Bitmap): Bitmap = runCatching {
        val deg = context.contentResolver.openInputStream(uri)!!.use { android.media.ExifInterface(it).let { e -> when (e.getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90; 3 -> 180; 8 -> 270; else -> 0 } } }
        if (deg == 0) b else Bitmap.createBitmap(b, 0, 0, b.width, b.height, android.graphics.Matrix().apply { postRotate(deg.toFloat()) }, true).also { if (it !== b) b.recycle() }
    }.getOrDefault(b)

    companion object {
        const val MAX_VIDEO_BYTES = 150L * 1024 * 1024

        /** "Movies/AVSP/Events/2026-10-19_Ashtami_ABC-Sarbojanin-pandal/" -> ashtami, abc, sarbojanin, pandal, puja, festival */
        fun eventLabels(relativePath: String): List<String> {
            val folder = relativePath.trimEnd('/').substringAfterLast('/')
            val words = folder.split(Regex("[^\\p{L}]+")).map { it.lowercase() }.filter { it.length > 2 }
            val puja = words.any { it in setOf("shashthi", "saptami", "ashtami", "navami", "dashami", "pandal", "puja", "pujo") }
            return (words + if (puja) listOf("puja", "festival", "durga puja") else emptyList()).distinct()
        }

        fun skipFolder(relativePath: String): Boolean {
            val p = relativePath.lowercase()
            if (p.contains("avsp/events/")) return false   // P31: the creator's own event shots are reused
            return listOf("screenshot", "whatsapp", "sticker", "telegram", "pictures/avsp", "movies/avsp", "download/avsp", "screenrecord", "screen recordings", ".thumbnails", "documents")
                .any { p.contains(it) }
        }

        /** Labels that say nothing about a topic, or point to private people pictures. */
        private val GENERIC = setOf("room", "event", "fun", "pattern", "darkness", "smile", "selfie", "skin", "eyelash", "hand", "flesh", "musical instrument", "vehicle", "metal")

        /** P22.2: labels that fit almost any photo - they only count when the scene literally says them. */
        private val BROAD = setOf("building", "sky", "tree", "road", "plant", "cloud", "water", "wall", "floor", "street", "city", "tower", "house", "grass", "window", "door")

        /** P21.4: a picture with these labels is not that topic (an airplane cabin is not a train). */
        private val CONFLICTS = mapOf(
            "train" to setOf("airplane", "aircraft", "airliner", "aviation", "cabin", "seat", "car", "bus"),
            "railway" to setOf("airplane", "aircraft", "airliner", "aviation", "cabin", "seat"),
            "temple" to setOf("church", "mosque"),
            "sea" to setOf("swimming pool")
        )
        private val PEOPLE = setOf("selfie", "smile", "eyelash", "skin", "beard", "hair", "child", "baby", "bride")
        private val SELF_WORDS = setOf("i", "me", "my", "myself", "selfie", "আমি", "আমার", "मैं", "मेरा")
        private val PEOPLE_WORDS = setOf("people", "person", "family", "friends", "crowd", "wedding", "child", "children", "students", "team", "festival", "celebration")

        /** Simple word forms + a few synonyms so "temples" finds "temple", "food" finds "dish"/"cuisine". */
        private val SYNONYMS = mapOf(
            "food" to listOf("food", "dish", "cuisine", "meal", "lunch", "dinner", "breakfast", "fast food", "dessert", "baked goods"),
            "temple" to listOf("temple", "shrine", "monument", "tower"),
            "river" to listOf("river", "lake", "water", "waterfall", "canal", "boat"),
            "sea" to listOf("sea", "beach", "coast", "waves", "water", "surfing"),
            "water" to listOf("water", "river", "lake", "drink", "bottle"),
            "mountain" to listOf("mountain", "hill", "cliff", "rock"),
            "rain" to listOf("rain", "cloud", "storm", "umbrella", "sky"),
            "weather" to listOf("sky", "cloud", "rain", "sunset", "storm"),
            "city" to listOf("building", "skyscraper", "road", "city", "bridge", "tower"),
            "train" to listOf("train", "rail", "railway", "station"),
            "railway" to listOf("train", "rail", "station"),
            "car" to listOf("car", "vehicle", "wheel", "road"),
            "flower" to listOf("flower", "plant", "petal", "garden"),
            "garden" to listOf("garden", "plant", "flower", "lawn", "tree"),
            "tree" to listOf("tree", "forest", "jungle", "plant"),
            "dog" to listOf("dog", "pet"), "cat" to listOf("cat", "pet"),
            "school" to listOf("classroom", "school", "student", "paper", "book"),
            "book" to listOf("book", "paper", "poster", "newspaper"),
            "office" to listOf("computer", "desk", "office", "monitor", "keyboard"),
            "phone" to listOf("mobile phone", "cell phone", "screen"),
            "sunset" to listOf("sunset", "sky", "cloud"),
            "festival" to listOf("event", "lighting", "fireworks", "flower", "crowd"),
        )

        fun expand(words: Collection<String>): Set<String> = words.flatMap { w0 ->
            val w = w0.lowercase().trim()
            // Singular forms: "temples" -> temple, "beaches" -> beach, "cities" -> city.
            val forms = listOfNotNull(
                w,
                w.takeIf { it.endsWith("s") && it.length > 3 }?.dropLast(1),
                w.takeIf { it.endsWith("es") && it.length > 4 }?.dropLast(2),
                w.takeIf { it.endsWith("ies") }?.let { it.dropLast(3) + "y" }
            )
            forms + forms.flatMap { SYNONYMS[it].orEmpty() }
        }.filter { it.length > 2 }.toSet()

        /**
         * Best gallery item for a scene described by [words], or null when nothing fits
         * well enough. Pure (testable).
         */
        fun match(items: Collection<Item>, words: Collection<String>, used: Set<String>, preferVideo: Boolean = false): Item? {
            val want = expand(words)
            if (want.isEmpty()) return null
            val aboutMe = words.any { it.lowercase() in SELF_WORDS }
            val aboutPeople = aboutMe || words.any { it.lowercase() in PEOPLE_WORDS }
            return items.asSequence()
                .filter { it.key !in used && it.labels.isNotEmpty() }
                .filter { aboutPeople || it.labels.none { l -> l in PEOPLE } }
                .filter { item -> words.none { w -> CONFLICTS[w.lowercase().trimEnd('s')]?.let { bad -> item.labels.any { it in bad } } == true } }
                .map { it to it.labels.count { l -> l !in GENERIC && (l in want || l.split(' ').any { p -> p in want }) &&
                    (l !in BROAD || words.any { w -> w.lowercase().trimEnd('s') == l }) } }
                // P27: a selfie is only for a video about the creator; a photo with people needs two real matches
                // (a Durga Puja hook got the creator's selfie through one loose label).
                .filter { (item, _) -> "selfie" !in item.labels || aboutMe }
                .filter { (item, hits) -> hits >= 1 && (aboutMe || item.labels.none { l -> l in PEOPLE } || hits >= 2) }
                .maxWithOrNull(compareBy<Pair<Item, Int>> { it.second }.thenBy { if (it.first.video == preferVideo) 1 else 0 }.thenBy { it.first.dateMs })
                ?.first
        }
    }
}
