package com.avsp.pro.edit

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.StaticLayout
import android.text.TextPaint
import android.text.style.ForegroundColorSpan
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * P12 THUMBNAIL: from the best moment of the video's own pictures/clips
 * (sharp, well exposed, colourful, a clear face scores extra) with a short
 * bold title on it. Saved to Pictures/AVSP/Thumbnails in 9:16 and 16:9.
 */
class ThumbnailMaker(private val context: Context) {

    sealed class Source {
        data class Image(val file: File) : Source()
        data class Video(val uri: Uri, val durationMs: Long) : Source()
    }

    data class Thumbs(val portrait: Uri, val landscape: Uri?)

    /** Picks the best frame of [sources] (fallback: [fallback] frames) and draws [title] on it. */
    fun make(sources: List<Source>, title: String, stem: String, fallback: Source? = null): Thumbs? {
        val frames = mutableListOf<Bitmap>()
        sources.take(8).forEach { frames += candidates(it) }
        if (frames.isEmpty() && fallback != null) frames += candidates(fallback)
        if (frames.isEmpty()) return null
        val best = frames.maxByOrNull { score(it) }!!
        val line = ThumbnailText.make(title)
        val portrait = save(compose(best, line, 1080, 1920), "${stem}_9x16.jpg")
        val landscape = runCatching { save(compose(best, line, 1280, 720), "${stem}_16x9.jpg") }.getOrNull()
        frames.forEach { if (!it.isRecycled) it.recycle() }
        return Thumbs(portrait, landscape)
    }

    private fun candidates(s: Source): List<Bitmap> = runCatching {
        when (s) {
            is Source.Image -> listOfNotNull(decode(s.file, 1280))
            is Source.Video -> {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(context, s.uri)
                    // Skip the first/last 8 %, take 6 moments in between.
                    (1..6).mapNotNull { k ->
                        val t = (s.durationMs * (0.08 + 0.84 * k / 7.0)).toLong() * 1000
                        if (Build.VERSION.SDK_INT >= 27) r.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, 1280, 1280)
                        else r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    }
                } finally { r.release() }
            }
        }
    }.getOrDefault(emptyList())

    private fun decode(f: File, max: Int): Bitmap? {
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.absolutePath, b)
        var sample = 1
        while (maxOf(b.outWidth, b.outHeight) / (sample * 2) >= max) sample *= 2
        return BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private val faces by lazy {
        FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).setMinFaceSize(0.12f).build())
    }

    /** Quality (exposure, detail) + colourfulness + a clear face. */
    private fun score(b: Bitmap): Float {
        val small = Bitmap.createScaledBitmap(b, 64, (64f * b.height / b.width).toInt().coerceAtLeast(16), true)
        val px = IntArray(small.width * small.height); small.getPixels(px, 0, small.width, 0, 0, small.width, small.height)
        val luma = IntArray(px.size) { i -> val c = px[i]; (((c shr 16) and 0xFF) * 299 + ((c shr 8) and 0xFF) * 587 + (c and 0xFF) * 114) / 1000 }
        var sat = 0f
        px.forEach { c ->
            val r = (c shr 16) and 0xFF; val g = (c shr 8) and 0xFF; val bl = c and 0xFF
            val mx = maxOf(r, g, bl); val mn = minOf(r, g, bl)
            sat += if (mx == 0) 0f else (mx - mn).toFloat() / mx
        }
        val q = ClipQuality.score(listOf(ClipQuality.Sample(0, luma, small.width, small.height))).first()
        small.recycle()
        val colour = (sat / px.size).coerceIn(0f, 1f)
        val face = runCatching {
            val found = Tasks.await(faces.process(InputImage.fromBitmap(b, 0)), 3, TimeUnit.SECONDS)
            val area = found.maxOfOrNull { it.boundingBox.width().toFloat() * it.boundingBox.height() / (b.width * b.height) } ?: 0f
            if (area > 0.02f) 0.35f + minOf(0.25f, area) else 0f
        }.getOrDefault(0f)
        return q.score + 0.35f * colour + face
    }

    private fun compose(src: Bitmap, line: ThumbnailText.Line, w: Int, h: Int): Bitmap {
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        // Cover crop.
        val s = maxOf(w.toFloat() / src.width, h.toFloat() / src.height)
        val cw = (w / s).toInt(); val ch = (h / s).toInt()
        val left = (src.width - cw) / 2; val top = ((src.height - ch) / 2.6f).toInt().coerceAtLeast(0)
        c.drawBitmap(src, Rect(left, top, left + cw, (top + ch).coerceAtMost(src.height)), RectF(0f, 0f, w.toFloat(), h.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
        // Shade behind the text so it reads on any picture.
        val shadeTop = if (w > h) h * 0.45f else h * 0.28f
        c.drawRect(0f, shadeTop, w.toFloat(), h.toFloat(), Paint().apply {
            shader = LinearGradient(0f, shadeTop, 0f, h.toFloat(), Color.TRANSPARENT, Color.argb(200, 0, 0, 0), Shader.TileMode.CLAMP)
        })
        // Title: big, bold, outlined; key word in yellow.
        val u = minOf(w, h) / 1080f
        val text = SpannableStringBuilder()
        line.words.forEachIndexed { i, word ->
            if (i > 0) text.append(' ')
            val st = text.length
            text.append(word)
            if (i == line.highlight) text.setSpan(ForegroundColorSpan(Color.rgb(255, 214, 0)), st, text.length, 0)
        }
        val size = (if (w > h) 118f else 132f) * u * (if (text.length > 26) 0.8f else 1f)
        val maxW = (w * 0.88f).toInt()
        fun layout(p: TextPaint) = StaticLayout.Builder.obtain(text, 0, text.length, p, maxW)
            .setAlignment(Layout.Alignment.ALIGN_CENTER).setLineSpacing(0f, 0.92f).setMaxLines(3).build()
        val fill = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = size; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val stroke = TextPaint(fill).apply { style = Paint.Style.STROKE; strokeWidth = size * 0.12f; color = Color.BLACK; strokeJoin = Paint.Join.ROUND }
        val lf = layout(fill)
        // P14: portrait title sits in the safe zone (feeds put buttons over the bottom third).
        val y = if (w > h) h - lf.height - 60f * u else h * 0.64f - lf.height
        val x = (w - maxW) / 2f
        c.save(); c.translate(x, y); layout(stroke).draw(c); lf.draw(c); c.restore()
        return out
    }

    private fun save(b: Bitmap, name: String): Uri {
        val bytes = ByteArrayOutputStream().also { b.compress(Bitmap.CompressFormat.JPEG, 92, it) }.toByteArray()
        b.recycle()
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= 29) { put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/AVSP/Thumbnails"); put(MediaStore.MediaColumns.IS_PENDING, 1) }
        }
        val r = context.contentResolver
        val uri = r.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: error("Could not save thumbnail")
        r.openOutputStream(uri, "w")?.use { it.write(bytes) }
        if (Build.VERSION.SDK_INT >= 29) r.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        return uri
    }
}
