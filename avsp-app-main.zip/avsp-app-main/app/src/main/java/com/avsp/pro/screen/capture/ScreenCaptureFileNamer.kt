package com.avsp.pro.screen.capture

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ScreenCaptureFileNamer {

    private val formatter =
        SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US)

    fun createBaseName(nowMs: Long = System.currentTimeMillis()): String =
        "screen_${formatter.format(Date(nowMs))}"

    fun videoName(baseName: String): String =
        "$baseName.mp4"

    fun metadataName(baseName: String): String =
        "${baseName}_metadata.json"
}