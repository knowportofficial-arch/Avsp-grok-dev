package com.avsp.pro

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import com.avsp.pro.m5.M5InputEngine
import com.avsp.pro.m5.UnifiedInputResult
import com.avsp.pro.ui.navigation.AvspNavHost
import com.avsp.pro.ui.theme.AvspTheme

class MainActivity : ComponentActivity() {

    /** P5: content shared into AVSP (a YouTube link, a web page, photos, a PDF...). */
    private val shared = mutableStateOf<List<UnifiedInputResult>?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.avsp.pro.core.dailypost.DailySettings.init(applicationContext)
        enableEdgeToEdge()
        val app = application as AvspApplication
        if (savedInstanceState == null) shared.value = readShare(intent)
        // P16: tag new gallery photos in the background (only when the user turned the gallery on).
        if (savedInstanceState == null) Thread {
            runCatching { app.container.gallery.index() }
        }.apply { priority = Thread.MIN_PRIORITY; isDaemon = true }.start()
        setContent {
            AvspTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AvspNavHost(
                        container = app.container,
                        shared = shared.value,
                        onSharedConsumed = { shared.value = null }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        readShare(intent)?.let { shared.value = it }
    }

    private fun readShare(intent: Intent?): List<UnifiedInputResult>? {
        intent ?: return null
        val out = mutableListOf<UnifiedInputResult>()
        when (intent.action) {
            Intent.ACTION_SEND -> {
                intent.getStringExtra(Intent.EXTRA_TEXT)?.takeIf { it.isNotBlank() }?.let { text ->
                    // YouTube/Chrome share "Title https://link" - keep the link when there is one.
                    val link = Regex("""https?://\S+""").find(text)?.value
                    out += M5InputEngine.analyzeUnifiedText(link ?: text)
                }
                streamExtra(intent)?.let { out += localSource(it, intent.type) }
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                streamListExtra(intent).forEach { out += localSource(it, intent.type) }
            }
        }
        return out.takeIf { it.isNotEmpty() }
    }

    /**
     * P8.2: some apps (and the system resolver for media the app cannot list)
     * report no MIME type for a shared file; the share intent's own type is
     * then used so photos and PDFs are still read (OCR) and used as visuals.
     */
    private fun localSource(uri: Uri, intentType: String?): UnifiedInputResult {
        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        val r = runCatching { M5InputEngine.analyzeLocalMediaUnified(this, uri) }
            .getOrElse { com.avsp.pro.m5.UnifiedInputResult(kind = com.avsp.pro.m5.UnifiedInputKind.UNKNOWN, reference = uri.toString()) }
        val hint = intentType?.takeIf { it.isNotBlank() && !it.contains('*') }
        return if (r.mimeType.isNullOrBlank() && hint != null) {
            r.copy(mimeType = hint, kind = M5InputEngine.classifyMimeType(hint))
        } else r
    }

    @Suppress("DEPRECATION")
    private fun streamExtra(intent: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else intent.getParcelableExtra(Intent.EXTRA_STREAM)

    @Suppress("DEPRECATION")
    private fun streamListExtra(intent: Intent): List<Uri> =
        (if (Build.VERSION.SDK_INT >= 33) intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)).orEmpty()
}
