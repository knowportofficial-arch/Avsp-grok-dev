package com.avsp.pro.ui.screens.home

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.avsp.pro.capture.EventInfo
import com.avsp.pro.capture.EventLocation
import com.avsp.pro.capture.FestivalCalendar
import com.avsp.pro.core.model.ProjectLanguage
import java.time.LocalDateTime

/** P28: "I'm here" - where (GPS), which festival day, what is happening -> an event project, then Plan & shoot. */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EventStartDialog(onDismiss: () -> Unit, onStart: (EventInfo, ProjectLanguage) -> Unit) {
    val ctx = LocalContext.current
    val now = remember { LocalDateTime.now() }
    var what by remember { mutableStateOf("") }
    var place by remember { mutableStateOf("") }
    var day by remember { mutableStateOf(FestivalCalendar.dayFor(now.toLocalDate()).orEmpty()) }
    var lat by remember { mutableStateOf<Double?>(null) }
    var lon by remember { mutableStateOf<Double?>(null) }
    var status by remember { mutableStateOf("Finding where you are…") }
    var picked by remember { mutableStateOf(setOf<String>()) }
    var lang by remember { mutableStateOf(ProjectLanguage.BENGALI) }
    var asked by remember { mutableStateOf(false) }
    var granted by remember { mutableStateOf<Boolean?>(null) }

    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r -> granted = r.values.any { it } }
    LaunchedEffect(Unit) {
        val has = listOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION).any {
            androidx.core.content.ContextCompat.checkSelfPermission(ctx, it) == android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (has) granted = true else if (!asked) { asked = true; permission.launch(arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION)) }
    }
    LaunchedEffect(granted) {
        when (granted) {
            true -> {
                val l = EventLocation.current(ctx)
                if (l == null) { status = "Location not found - type the place below (turn on GPS for better results)"; return@LaunchedEffect }
                lat = l.latitude; lon = l.longitude
                val name = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { EventLocation.placeName(ctx, l.latitude, l.longitude) }
                if (place.isBlank() && name != null) place = name
                status = "📍 " + (name ?: "%.4f, %.4f".format(l.latitude, l.longitude))
            }
            false -> status = "Location not allowed - type the place below"
            null -> {}
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("I'm here - live event") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(status, style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(value = what, onValueChange = { what = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Where exactly? (pandal / mela / event name)") })
                OutlinedTextField(value = place, onValueChange = { place = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Area, city") })
                OutlinedTextField(value = day, onValueChange = { day = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    label = { Text("Day / occasion (e.g. Maha Ashtami)") })
                Text("What is happening now?", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FestivalCalendar.moments(day.ifBlank { null }).forEach { m ->
                        FilterChip(selected = m in picked, onClick = { picked = if (m in picked) picked - m else picked + m }, label = { Text(m) })
                    }
                }
                Text("Video language", style = MaterialTheme.typography.labelLarge)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(ProjectLanguage.BENGALI to "বাংলা", ProjectLanguage.HINDI to "हिन्दी", ProjectLanguage.ENGLISH to "English").forEach { (l, label) ->
                        FilterChip(selected = lang == l, onClick = { lang = l }, label = { Text(label) })
                    }
                }
                Text("Your shots are saved with the place, time and location in Movies/AVSP/Events.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = {
            Button(enabled = what.isNotBlank() || place.isNotBlank(), onClick = {
                onStart(EventInfo(what.trim(), place.trim(), day.trim().ifBlank { null }, lat, lon, now, picked.toList()), lang)
            }) { Text("Make shot list →") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
