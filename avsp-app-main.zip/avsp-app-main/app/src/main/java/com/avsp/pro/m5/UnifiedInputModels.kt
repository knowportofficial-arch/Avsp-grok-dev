﻿package com.avsp.pro.m5

/** Canonical user-facing input categories for M5. */
enum class UnifiedInputKind {
    TEXT,
    YOUTUBE,
    URL,
    IMAGE,
    VIDEO,
    AUDIO,
    DOCUMENT,
    SCREEN_RECORDING,
    UNKNOWN
}

data class UnifiedInputResult(
    val kind: UnifiedInputKind,
    val reference: String,
    val title: String = "",
    val text: String = "",
    val durationSeconds: Long = 0L,
    val numbers: List<Double> = emptyList(),
    val confidence: Double = 0.0,
    val mimeType: String? = null,
    val youtubeId: String? = null,
    val warnings: List<String> = emptyList(),
    val processedAt: Long = System.currentTimeMillis()
)
