package com.avsp.pro.audio.engine

import android.content.Context
import com.avsp.pro.audio.error.AudioErrorCode
import com.avsp.pro.audio.error.AudioException
import com.avsp.pro.settings.ConfigState
import com.avsp.pro.settings.SecureConfigKeys
import com.avsp.pro.settings.SecureConfigStore

/**
 * Resolves TTS engines. Always offers Mock. Android Local is registered when constructible.
 * Remote/cloud providers remain extension points and are never mandatory.
 */
class DefaultTtsEngineRegistry(
    context: Context,
    private val secureConfigStore: SecureConfigStore,
    private val mock: TtsEngine = MockTtsEngine(),
    androidEngineFactory: (Context) -> TtsEngine? = { ctx ->
        runCatching { AndroidTtsEngine(ctx) }.getOrNull()
    }
) : TtsEngineRegistry {

    private val androidEngine: TtsEngine? = androidEngineFactory(context.applicationContext)

    /** P21: natural cloud voices (Gemini / Azure / Google), falling back to the phone voice per scene. */
    val smartVoice: SmartVoiceEngine = SmartVoiceEngine(context.applicationContext, secureConfigStore) {
        androidEngine?.takeIf { it.isAvailable() } ?: mock
    }

    override fun available(): List<TtsEngine> {
        val list = mutableListOf(mock)
        val android = androidEngine
        if (android != null && android.isAvailable()) {
            list.add(android)
        }
        return list
    }

    override fun isRemoteConfigured(): Boolean =
        secureConfigStore.configState(SecureConfigKeys.AI_API) == ConfigState.CONFIGURED

    override fun resolve(preferredProviderId: String?): TtsEngine {
        // P21: the natural voice speaks whatever voice was picked, unless the test voice (Mock) was asked for.
        if (preferredProviderId != mock.providerId && runCatching { smartVoice.enabled() }.getOrDefault(false)) return smartVoice
        val preferred = preferredProviderId?.let { id ->
            available().find { it.providerId == id }
        }
        if (preferred != null) return preferred

        // Prefer Android local when available; otherwise Mock (safe offline/default).
        val android = androidEngine
        if (android != null && android.isAvailable()) return android
        return mock
    }

    fun requireProvider(providerId: String): TtsEngine {
        val engine = available().find { it.providerId == providerId }
            ?: throw AudioException(
                AudioErrorCode.TTS_PROVIDER_UNAVAILABLE,
                "TTS provider unavailable: $providerId"
            )
        if (!engine.isAvailable()) {
            throw AudioException(
                AudioErrorCode.TTS_PROVIDER_UNAVAILABLE,
                "TTS provider unavailable: $providerId"
            )
        }
        return engine
    }

    fun aiConfigState(): ConfigState = secureConfigStore.configState(SecureConfigKeys.AI_API)
}
