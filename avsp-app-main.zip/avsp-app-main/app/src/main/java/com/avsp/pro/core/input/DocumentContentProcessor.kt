﻿package com.avsp.pro.core.input

import android.content.Context
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.StandardCharsets

/**
 * M15 — local Document/PDF content processing boundary.
 *
 * REAL:
 * - Reads supported local text documents as UTF-8.
 * - Opens local PDFs with Android PdfRenderer.
 * - Reports PDF page count.
 *
 * NOT IMPLEMENTED:
 * - PDF text extraction.
 * - OCR for PDF pages.
 * - AI document understanding.
 * - Network download/upload.
 * - Publishing.
 *
 * This intentionally does not modify M5 or M7.
 */
object DocumentContentProcessor {

    enum class ContentKind {
        PDF,
        TEXT_DOCUMENT,
        UNSUPPORTED
    }

    data class ProcessedDocument(
        val input: UnifiedInput,
        val kind: ContentKind,
        val pageCount: Int? = null,
        val text: String? = null,
        val truncated: Boolean = false
    )

    fun process(
        context: Context,
        input: UnifiedInput,
        maxTextChars: Int = 100_000
    ): ProcessedDocument? {
        if (maxTextChars <= 0) return null

        return when (input.type) {
            UnifiedInputType.PDF_DOCUMENT ->
                processPdf(context, input)

            UnifiedInputType.DOCUMENT ->
                processTextDocument(context, input, maxTextChars)

            else -> null
        }
    }

    private fun processPdf(
        context: Context,
        input: UnifiedInput
    ): ProcessedDocument? {
        val uri = android.net.Uri.parse(input.locator)

        var descriptor: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null

        return try {
            descriptor = context.contentResolver.openFileDescriptor(uri, "r")
                ?: return null

            renderer = PdfRenderer(descriptor)

            ProcessedDocument(
                input = input,
                kind = ContentKind.PDF,
                pageCount = renderer.pageCount,
                text = null,
                truncated = false
            )
        } catch (_: Exception) {
            null
        } finally {
            try {
                renderer?.close()
            } catch (_: Exception) {
            }

            try {
                descriptor?.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun processTextDocument(
        context: Context,
        input: UnifiedInput,
        maxTextChars: Int
    ): ProcessedDocument? {
        val uri = android.net.Uri.parse(input.locator)

        return try {
            val stream = context.contentResolver.openInputStream(uri)
                ?: return null

            stream.use { source ->
                BufferedReader(
                    InputStreamReader(source, StandardCharsets.UTF_8)
                ).use { reader ->

                    val builder = StringBuilder()
                    var truncated = false

                    while (true) {
                        val line = reader.readLine() ?: break

                        if (builder.isNotEmpty()) {
                            builder.append('\n')
                        }

                        val remaining = maxTextChars - builder.length

                        if (remaining <= 0) {
                            truncated = true
                            break
                        }

                        if (line.length <= remaining) {
                            builder.append(line)
                        } else {
                            builder.append(line, 0, remaining)
                            truncated = true
                            break
                        }
                    }

                    ProcessedDocument(
                        input = input,
                        kind = ContentKind.TEXT_DOCUMENT,
                        pageCount = null,
                        text = builder.toString(),
                        truncated = truncated
                    )
                }
            }
        } catch (_: Exception) {
            null
        }
    }
}
