package com.avsp.pro.capture

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

/**
 * P28 "I'M HERE" EVENT MODE (Puja pandal, mela, wedding, match...): where the creator is
 * (GPS -> place name), which festival day it is, and how the shots are named and filed so
 * they can be found and used again: Movies/AVSP/Events/2026-10-19_Ashtami_Kumartuli/
 * 2026-10-19_1942_Ashtami_Kumartuli_01.mp4, with the location written into the file.
 */
data class EventInfo(
    val what: String,                 // "ABC Sarbojanin pandal"
    val place: String,                // "Kumartuli, Kolkata" (from GPS, editable)
    val day: String?,                 // "Maha Ashtami"
    val latitude: Double?,
    val longitude: Double?,
    val startedAt: LocalDateTime,
    val moments: List<String> = emptyList()   // "Aarti", "Dhak"...
) {
    /** Folder and file stem: date, festival day and a short place word, safe for file names. */
    val folder: String get() = listOfNotNull(startedAt.toLocalDate().toString(), day?.substringAfterLast(' '), short(what.ifBlank { place }))
        .joinToString("_")

    fun fileName(index: Int, video: Boolean, at: LocalDateTime = LocalDateTime.now()): String =
        listOfNotNull(at.format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HHmm")), day?.substringAfterLast(' '), short(what.ifBlank { place }))
            .joinToString("_") + "_%02d.%s".format(index, if (video) "mp4" else "jpg")

    /** The topic the AI writes the script from (first person, present tense). */
    fun topic(): String = buildString {
        append("LIVE EVENT: I am at ").append(what.ifBlank { place })
        if (what.isNotBlank() && place.isNotBlank()) append(", ").append(place)
        day?.let { append(", on ").append(it) }
        append(", ").append(startedAt.format(DateTimeFormatter.ofPattern("d MMMM yyyy, h:mm a")))
        append(". ")
        if (moments.isNotEmpty()) append("Happening now: ").append(moments.joinToString(", ")).append(". ")
    }

    fun metadata(): Map<String, String> = buildMap {
        put("event.what", what); put("event.place", place); put("event.folder", folder)
        put("event.started", startedAt.toString())
        day?.let { put("event.day", it) }
        latitude?.let { put("event.lat", "%.6f".format(it)) }
        longitude?.let { put("event.lon", "%.6f".format(it)) }
        if (moments.isNotEmpty()) put("event.moments", moments.joinToString(","))
    }

    companion object {
        fun short(s: String): String = s.split(Regex("[^\\p{L}\\p{N}]+")).filter { it.isNotBlank() }.take(3)
            .joinToString("-").take(30).ifBlank { "event" }

        fun fromMetadata(m: Map<String, String>): EventInfo? {
            val folder = m["event.folder"] ?: return null
            return EventInfo(m["event.what"].orEmpty(), m["event.place"].orEmpty(), m["event.day"],
                m["event.lat"]?.toDoubleOrNull(), m["event.lon"]?.toDoubleOrNull(),
                runCatching { LocalDateTime.parse(m["event.started"]) }.getOrDefault(LocalDateTime.now()),
                m["event.moments"]?.split(',')?.filter { it.isNotBlank() }.orEmpty()).takeIf { folder.isNotBlank() }
        }
    }
}

/** Festival days (dates checked against published 2026 calendars). */
object FestivalCalendar {
    private val DAYS: Map<LocalDate, String> = mapOf(
        LocalDate.of(2026, 10, 16) to "Durga Puja - Maha Shashthi",
        LocalDate.of(2026, 10, 17) to "Durga Puja - Maha Saptami eve",
        LocalDate.of(2026, 10, 18) to "Durga Puja - Maha Saptami",
        LocalDate.of(2026, 10, 19) to "Durga Puja - Maha Ashtami",
        LocalDate.of(2026, 10, 20) to "Durga Puja - Maha Navami",
        LocalDate.of(2026, 10, 21) to "Durga Puja - Vijaya Dashami"
    )

    fun dayFor(date: LocalDate): String? = DAYS[date]

    /** The short day word used in names: "Ashtami". */
    fun shortDay(full: String?): String? = full?.substringAfterLast(' ')

    /** Things that usually happen, offered as quick chips. */
    fun moments(day: String?): List<String> = when {
        day == null -> listOf("Crowd", "Lights", "Food stalls", "Music", "Rides", "Shopping")
        day.contains("Ashtami") -> listOf("Pushpanjali", "Sandhi Puja", "Dhak", "Aarti", "Idol", "Pandal", "Crowd", "Bhog")
        day.contains("Dashami") -> listOf("Sindoor Khela", "Immersion", "Dhak", "Idol", "Crowd")
        else -> listOf("Pandal", "Idol", "Lights", "Dhak", "Aarti", "Crowd", "Bhog", "Food stalls")
    }
}

/** Phone location -> "Area, City" (Android's own geocoder, free; works offline only roughly). */
object EventLocation {
    @SuppressLint("MissingPermission")   // the screen asks for location first
    suspend fun current(ctx: Context): Location? = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER).filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            for (p in providers) {
                val l = kotlinx.coroutines.withTimeoutOrNull(12_000) {
                    kotlinx.coroutines.suspendCancellableCoroutine<Location?> { c ->
                        val signal = android.os.CancellationSignal()
                        c.invokeOnCancellation { signal.cancel() }
                        lm.getCurrentLocation(p, signal, ctx.mainExecutor) { loc -> if (c.isActive) c.resume(loc) {} }
                    }
                }
                if (l != null) return@withContext l
            }
        }
        providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.time }
    }

    @Suppress("DEPRECATION")
    fun placeName(ctx: Context, lat: Double, lon: Double): String? = runCatching {
        val a = android.location.Geocoder(ctx, java.util.Locale.ENGLISH).getFromLocation(lat, lon, 1)?.firstOrNull() ?: return null
        listOfNotNull(a.subLocality ?: a.featureName?.takeIf { it.any(Char::isLetter) }, a.locality ?: a.subAdminArea)
            .distinct().joinToString(", ").ifBlank { null }
    }.getOrNull()

    /** The location given to the camera so every shot carries it (set while an event project is open). */
    @Volatile var forCapture: Location? = null
}
