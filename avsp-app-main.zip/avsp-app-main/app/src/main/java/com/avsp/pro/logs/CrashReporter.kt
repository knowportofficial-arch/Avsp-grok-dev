package com.avsp.pro.logs

import android.content.Context
import java.io.File

/**
 * P19: if AVSP ever closes unexpectedly, the reason is kept (on the phone only)
 * and shown on Home next time with "Copy details", so a problem can be fixed
 * even when no PC is connected. No keys or personal data are written - only the
 * error and where in AVSP it happened.
 */
object CrashReporter {
    private const val FILE = "last_crash.txt"

    fun install(context: Context) {
        val app = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching { File(app.filesDir, FILE).writeText(describe(app, thread.name, error)) }
            previous?.uncaughtException(thread, error)
        }
    }

    fun describe(context: Context?, threadName: String, error: Throwable): String = buildString {
        val version = runCatching { context?.packageManager?.getPackageInfo(context.packageName, 0)?.lastUpdateTime }.getOrNull()
        append("AVSP crash ").append(java.time.Instant.now()).append('\n')
        append("Android ").append(android.os.Build.VERSION.SDK_INT).append(" · ").append(android.os.Build.MODEL).append(" · app updated ").append(version ?: "?").append('\n')
        append("Thread: ").append(threadName).append('\n')
        var e: Throwable? = error; var depth = 0
        while (e != null && depth < 4) {
            append(if (depth == 0) "" else "Caused by: ").append(e.javaClass.name).append(": ").append(e.message?.take(300) ?: "").append('\n')
            e.stackTrace.take(if (depth == 0) 25 else 12).forEach { append("  at ").append(it).append('\n') }
            e = e.cause; depth++
        }
    }

    fun last(context: Context): String? = runCatching { File(context.filesDir, FILE).takeIf { it.exists() }?.readText() }.getOrNull()

    fun clear(context: Context) { runCatching { File(context.filesDir, FILE).delete() } }
}
