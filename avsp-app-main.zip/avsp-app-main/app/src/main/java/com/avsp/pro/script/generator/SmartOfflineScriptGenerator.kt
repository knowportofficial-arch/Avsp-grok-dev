package com.avsp.pro.script.generator

import com.avsp.pro.script.contract.ScriptGenerationRequest
import com.avsp.pro.script.contract.ScriptMetadata
import com.avsp.pro.script.contract.ScriptPackage
import com.avsp.pro.script.contract.ScriptScene
import com.avsp.pro.script.contract.ScriptValidation
import com.avsp.pro.script.contract.ShotType
import com.avsp.pro.script.contract.TransitionIntent
import com.avsp.pro.script.contract.ValidationStatus
import com.avsp.pro.script.language.ScriptLanguageRegistry
import com.avsp.pro.script.validation.ScriptValidator
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToLong

/**
 * P2.2 ZERO-DEPENDENCY SCRIPT WRITER (default, works offline on every phone)
 *
 * Builds the script from the REAL content of the source (Daily Post article,
 * pasted text, document text): cleans it, picks the most informative
 * sentences in their original order, and arranges them into
 * hook -> body scenes -> call to action. No AI service, no key, no network.
 *
 * When the source has almost no text (only a title), it writes a short,
 * natural script around the title instead of placeholder text.
 */
class SmartOfflineScriptGenerator(
    private val fallback: ScriptGenerator = MockScriptGenerator()
) : ScriptGenerator {

    override val providerId: String = PROVIDER_ID
    override val displayName: String = "Smart offline writer"
    override val mode: GeneratorMode = GeneratorMode.LOCAL

    override suspend fun generate(request: ScriptGenerationRequest): ScriptPackage {
        val pre = ScriptValidator.validateRequest(request)
        if (!pre.isValid) return fallback.generate(request)

        val language = ScriptLanguageRegistry.resolve(request.languageCode)
        val english = language.code.equals("en", ignoreCase = true)
        val targetMs = request.duration.resolveTargetMs()

        val title = cleanTitle(request.topic)
        val facts = sentences(request.topic)
            .filterNot { similar(it, title) }
            .let { dedupe(it) }

        // Words that fit the target length at ~2.3 spoken words per second.
        val wordBudget = (targetMs / 1000.0 * 2.3).toInt().coerceAtLeast(30)
        val body = pickInOrder(facts, wordBudget - 25)

        val hook = when {
            english && body.isNotEmpty() -> "$title. Here is what you need to know."
            english -> "Here's today's update: $title."
            else -> title
        }
        val cta = if (english) "Like, share and follow!" else com.avsp.pro.core.pipeline.CtaRule.spoken(language.code)

        val bodyScenes: List<String> = when {
            body.isNotEmpty() -> groupIntoScenes(body, maxScenes = sceneBudget(targetMs) - 2)
            english -> listOf(
                "More details are still coming in, so keep an eye on trusted sources for the latest."
            )
            else -> listOf(language.sectionNarration(shortLabel(title), 0, 1))
        }

        val texts = listOf(hook) + bodyScenes + listOf(cta)
        val weights = texts.map { max(25, it.length) }
        val durations = distribute(targetMs, weights)
        val last = texts.size - 1

        val scenes = texts.mapIndexed { i, narration ->
            ScriptScene(
                sceneId = when (i) { 0 -> "scn_hook"; last -> "scn_outro"; else -> "scn_" + i.toString().padStart(2, '0') },
                order = i,
                durationMs = durations[i],
                narration = narration,
                onScreenText = when (i) { 0 -> shortLabel(title); last -> if (english) "Follow for more" else shortLabel(cta); else -> shortLabel(narration) },
                visualDescription = keywords(if (i == 0 || i == last) title else narration),
                shotType = when (i) { 0 -> ShotType.INTRO; last -> ShotType.OUTRO; else -> if (i % 2 == 0) ShotType.B_ROLL else ShotType.MEDIUM },
                cameraDirection = "",
                bRollSuggestion = keywords(if (i == 0 || i == last) title else narration),
                transition = if (i == last) TransitionIntent.FADE else TransitionIntent.CUT,
                notes = when (i) { 0 -> "Hook"; last -> "CTA / Ending"; else -> "Body" }
            )
        }

        val now = System.currentTimeMillis()
        val draft = ScriptPackage(
            version = ScriptPackage.CURRENT_VERSION,
            projectId = request.projectId,
            scriptId = "scr_" + UUID.randomUUID().toString().replace("-", "").take(16),
            topic = request.topic.trim(),
            language = language.code,
            title = title,
            hook = hook,
            introduction = body.firstOrNull().orEmpty(),
            scenes = scenes,
            cta = cta,
            ending = "",
            estimatedDurationMs = scenes.sumOf { it.durationMs },
            targetDurationMs = targetMs,
            estimatedNarrationDurationMs = scenes.sumOf { minOf(it.durationMs, max(1_000L, (it.narration.length / 13.0 * 1000).roundToLong())) },
            validation = ScriptValidation(true, ValidationStatus.VALID),
            metadata = ScriptMetadata(
                contentType = request.contentType,
                audience = request.audience,
                platform = request.platform,
                aspectRatio = request.aspectRatioLabel,
                generatorId = PROVIDER_ID,
                generatorMode = mode.name,
                createdAt = now,
                updatedAt = now,
                userInstructions = request.userInstructions,
                factualRequirements = request.factualRequirements
            )
        )
        val validated = draft.copy(validation = ScriptValidator.validatePackage(draft, request.durationToleranceRatio))
        return if (validated.validation.isValid) validated else fallback.generate(request)
    }

    companion object {
        const val PROVIDER_ID = "smart-offline"

        private val URL = Regex("""(https?://\S+|www\.\S+|\S+\.(com|in|org|net|co|io|news)(/\S*)?)""", RegexOption.IGNORE_CASE)
        private val SPACES = Regex("""\s+""")

        internal fun clean(text: String): String =
            com.avsp.pro.core.pipeline.SourceText.stripReferenceNoise(text).replace(URL, " ")
                .replace(Regex("""\s+[-|–—:]\s*$"""), "")
                .replace(Regex("""^\s*(Source|Date|Reference|Title)\s*:.*$""", RegexOption.MULTILINE), " ")
                .replace(Regex("""\bSource \d+:\s*"""), " ")
                .replace(Regex("""\s+([,.;:!?।)])"""), "$1")
                .replace(SPACES, " ")
                .trim()
                .trim('-', '|', '–', '—', ':', ' ')

        /** First line of the topic, without site names / URLs, max ~14 words. */
        internal fun cleanTitle(topic: String): String {
            val first = topic.lineSequence().map { clean(it) }.firstOrNull { it.length >= 3 } ?: clean(topic)
            val noSite = first.substringBefore(" - ").ifBlank { first }.trim()
            val words = noSite.split(' ').filter { it.isNotBlank() }
            return (if (words.size > 14) words.take(14).joinToString(" ") else noSite).trimEnd('.', '!', '?', ':', ';', ',')
        }

        internal fun sentences(topic: String): List<String> =
            topic.lines()
                .drop(1) // first line is the title
                .joinToString(" ")
                .let { clean(it) }
                .split(Regex("""(?<=[.!?।])\s+"""))
                .map { it.trim() }
                .filter { s -> s.split(' ').size >= 4 && s.any { it.isLetter() } }
                .map { s -> if (s.last() in ".!?।") s else "$s." }

        private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() || it == ' ' }.split(' ').filter { it.length > 2 }.toSet()

        internal fun similar(a: String, b: String): Boolean {
            val x = norm(a); val y = norm(b)
            if (x.isEmpty() || y.isEmpty()) return false
            val inter = x.intersect(y).size.toDouble()
            return inter / minOf(x.size, y.size) >= 0.8
        }

        internal fun dedupe(list: List<String>): List<String> {
            val out = mutableListOf<String>()
            for (s in list) if (out.none { similar(it, s) }) out += s
            return out
        }

        /** Keeps original order; stops at the word budget. */
        internal fun pickInOrder(list: List<String>, wordBudget: Int): List<String> {
            val out = mutableListOf<String>()
            var words = 0
            for (s in list) {
                val w = s.split(' ').size
                if (out.isNotEmpty() && words + w > wordBudget) break
                out += s
                words += w
            }
            return out
        }

        internal fun sceneBudget(targetMs: Long): Int = when {
            targetMs <= 30_000L -> 4
            targetMs <= 60_000L -> 6
            targetMs <= 120_000L -> 8
            else -> 10
        }

        internal fun groupIntoScenes(sentences: List<String>, maxScenes: Int): List<String> {
            val n = maxScenes.coerceAtLeast(1)
            if (sentences.size <= n) return sentences
            val per = (sentences.size + n - 1) / n
            return sentences.chunked(per).map { it.joinToString(" ") }
        }

        internal fun shortLabel(text: String): String {
            val words = clean(text).trimEnd('.', '!', '?').split(' ').filter { it.isNotBlank() }
            return if (words.size <= 6) words.joinToString(" ") else words.take(6).joinToString(" ") + "…"
        }

        private val STOP = setOf(
            "the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "with", "is", "are", "was", "were",
            "this", "that", "it", "as", "at", "by", "from", "be", "has", "have", "had", "after", "about",
            "here", "what", "you", "need", "know", "their", "they", "his", "her", "its", "will", "said"
        )

        /** 2-4 search words for stock footage. */
        internal fun keywords(text: String): String =
            clean(text).lowercase()
                .split(Regex("""[^\p{L}\p{N}]+"""))
                .filter { it.length > 3 && it !in STOP && it.none(Char::isDigit) }
                .distinct()
                .take(3)
                .joinToString(" ")

        private fun distribute(totalMs: Long, weights: List<Int>): List<Long> {
            val sum = weights.sum().toDouble()
            val raw = weights.map { max(ScriptValidator.MIN_SCENE_MS, (totalMs * it / sum).roundToLong()) }.toMutableList()
            var diff = totalMs - raw.sum()
            var i = 0
            while (diff != 0L && i < raw.size * 20_000) {
                val idx = i % raw.size
                if (diff > 0) { raw[idx]++; diff-- } else if (raw[idx] > ScriptValidator.MIN_SCENE_MS) { raw[idx]--; diff++ }
                i++
            }
            return raw
        }
    }
}
