package com.avsp.pro.screen.capture

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.util.DisplayMetrics
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/**
 * P31 SCREEN RECORDING, explained: choose "Entire screen" or "One app" before Android asks;
 * a running timer and a big Stop button here, a Stop button in the notification and (optional)
 * a floating Stop button over every app. When the recorded app closes, what was recorded is kept.
 */
@Composable
fun ScreenCaptureScreen(projectId: String, onNavigateBack: () -> Unit) {
    val context = LocalContext.current
    val state by ScreenCaptureStateStore.state.collectAsStateWithLifecycle()
    val note by ScreenCaptureStateStore.note.collectAsStateWithLifecycle()
    val pm = remember(context) { context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager }
    var canOverlay by remember { mutableStateOf(Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(context)) }
    var showDetails by remember { mutableStateOf(false) }

    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode != Activity.RESULT_OK) {
            ScreenCaptureStateStore.update(ScreenCaptureState(projectId = projectId, errorMessage = "Recording was not started (you tapped Cancel)."))
            return@rememberLauncherForActivityResult
        }
        val data = r.data ?: run {
            ScreenCaptureStateStore.update(ScreenCaptureState(ScreenCaptureStatus.ERROR, projectId = projectId, errorMessage = "Android did not allow the recording - try again."))
            return@rememberLauncherForActivityResult
        }
        val m: DisplayMetrics = context.resources.displayMetrics
        ContextCompat.startForegroundService(context, Intent(context, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, r.resultCode); putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            putExtra(ScreenCaptureService.EXTRA_PROJECT_ID, projectId)
            putExtra(ScreenCaptureService.EXTRA_WIDTH, m.widthPixels.coerceAtLeast(2)); putExtra(ScreenCaptureService.EXTRA_HEIGHT, m.heightPixels.coerceAtLeast(2))
            putExtra(ScreenCaptureService.EXTRA_DPI, m.densityDpi.coerceAtLeast(1))
        })
    }
    // Android 13+: without notification permission the Stop button in the notification is hidden.
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun start(entireScreen: Boolean) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        ScreenCaptureStateStore.reset(projectId)
        val intent = if (Build.VERSION.SDK_INT >= 34) {
            pm.createScreenCaptureIntent(
                if (entireScreen) android.media.projection.MediaProjectionConfig.createConfigForDefaultDisplay()
                else android.media.projection.MediaProjectionConfig.createConfigForUserChoice()
            )
        } else pm.createScreenCaptureIntent()
        launcher.launch(intent)
    }

    val recording = state.status == ScreenCaptureStatus.STARTING || state.status == ScreenCaptureStatus.RECORDING || state.status == ScreenCaptureStatus.STOPPING
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(recording) { while (recording) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(500) } }
    LaunchedEffect(Unit) { while (true) { canOverlay = Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(context); kotlinx.coroutines.delay(1500) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Record your screen", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        when {
            recording -> {
                val secs = ((now - ScreenCaptureStateStore.startedAt) / 1000).coerceAtLeast(0)
                Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("🔴 Recording  %d:%02d".format(secs / 60, secs % 60), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Go to the app you want to show. To stop: the red Stop button on screen, Stop in the notification, or come back here.",
                            style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Button(onClick = { context.startService(Intent(context, ScreenCaptureService::class.java).apply { action = ScreenCaptureService.ACTION_STOP }) },
                    modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text(if (state.status == ScreenCaptureStatus.STOPPING) "Saving…" else "■ Stop recording", style = MaterialTheme.typography.titleMedium)
                }
            }
            state.status == ScreenCaptureStatus.COMPLETED -> {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("✅ Recording saved (${state.durationMs / 1000} s)", style = MaterialTheme.typography.titleMedium)
                        note?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                        Text(when (state.analysisStatus) {
                            ScreenAnalysisStatus.RUNNING -> "Cleaning it now: blurring private info (numbers, OTPs, names) and finding the best parts…"
                            ScreenAnalysisStatus.COMPLETED -> "Cleaned: ${state.sensitiveFindingCount} private spots blurred, ${state.highlightCount} highlights, ${state.cutSuggestionCount} cut suggestions."
                            ScreenAnalysisStatus.ERROR -> "The recording is saved; the clean-up step had a problem."
                            else -> "Saved."
                        }, style = MaterialTheme.typography.bodyMedium)
                        Text("Next: go back to the project and tap Make Video - your recording becomes a short with voice-over and captions.",
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
                Button(onClick = onNavigateBack, modifier = Modifier.fillMaxWidth()) { Text("Back to project → make the video") }
                OutlinedButton(onClick = { ScreenCaptureStateStore.reset(projectId) }, modifier = Modifier.fillMaxWidth()) { Text("Record again") }
            }
            else -> {
                Text("Android will ask what to share. Pick what you need:", style = MaterialTheme.typography.bodyMedium)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Entire screen", style = MaterialTheme.typography.titleMedium)
                        Text("Everything you see, across apps. Notifications and private numbers are blurred afterwards.", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { start(entireScreen = true) }, modifier = Modifier.fillMaxWidth()) { Text("Record entire screen") }
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("One app only", style = MaterialTheme.typography.titleMedium)
                        Text("Android shows a list - choose \"A single app\" and then the app. If you close that app, the recording ends and is saved.",
                            style = MaterialTheme.typography.bodySmall)
                        OutlinedButton(onClick = { start(entireScreen = false) }, modifier = Modifier.fillMaxWidth()) { Text("Record one app") }
                    }
                }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(if (canOverlay) "✅ Floating Stop button is on" else "Floating Stop button (recommended)", style = MaterialTheme.typography.titleSmall)
                        Text("A small red Stop button stays on top of every app while recording, so you can stop without coming back here.",
                            style = MaterialTheme.typography.bodySmall)
                        if (!canOverlay) TextButton(onClick = {
                            runCatching {
                                context.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + context.packageName))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            }
                        }) { Text("Allow \"Display over other apps\"") }
                    }
                }
                state.errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                note?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
        TextButton(onClick = { showDetails = !showDetails }) { Text(if (showDetails) "Hide details" else "Details") }
        if (showDetails) {
            Text("Status: ${state.status.name} · analysis ${state.analysisStatus.name}", style = MaterialTheme.typography.bodySmall)
            state.outputRelativePath?.let { Text("Video: $it", style = MaterialTheme.typography.bodySmall) }
            state.redactionRelativePath?.let { Text("Blur plan: $it", style = MaterialTheme.typography.bodySmall) }
            state.scriptRelativePath?.let { Text("Script draft: $it", style = MaterialTheme.typography.bodySmall) }
        }
        if (!recording) OutlinedButton(onClick = onNavigateBack, modifier = Modifier.fillMaxWidth()) { Text("Back") }
    }
}
