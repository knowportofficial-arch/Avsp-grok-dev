﻿package com.avsp.pro.di

import android.content.Context
import com.avsp.pro.database.AvspDatabase
import com.avsp.pro.database.DatabaseProvider
import com.avsp.pro.logs.AvspLogger
import com.avsp.pro.logs.AvspLoggerImpl
import com.avsp.pro.repository.LogRepository
import com.avsp.pro.repository.LogRepositoryImpl
import com.avsp.pro.repository.ModuleStatusRepository
import com.avsp.pro.repository.ModuleStatusRepositoryImpl
import com.avsp.pro.repository.ProjectRepository
import com.avsp.pro.repository.ProjectRepositoryImpl
import com.avsp.pro.repository.SettingsRepository
import com.avsp.pro.repository.SettingsRepositoryImpl
import com.avsp.pro.settings.EncryptedSecureConfigStore
import com.avsp.pro.settings.SecureConfigStore
import com.avsp.pro.script.generator.DefaultScriptGeneratorRegistry
import com.avsp.pro.script.repository.ScriptRepository
import com.avsp.pro.script.repository.ScriptRepositoryImpl
import com.avsp.pro.audio.engine.DefaultTtsEngineRegistry
import com.avsp.pro.audio.repository.AudioRepository
import com.avsp.pro.audio.repository.AudioRepositoryImpl
import com.avsp.pro.video.engine.Media3VideoEngine
import com.avsp.pro.video.repository.VideoRepository
import com.avsp.pro.video.repository.VideoRepositoryImpl
import com.avsp.pro.video.export.VideoMediaStoreExporter
import com.avsp.pro.storage.AvspStorage
import com.avsp.pro.storage.FileAvspStorage
import com.avsp.pro.media.BundledMediaSeeder
import com.avsp.pro.m7.M7Services

/**
 * Service locator for M1 + M2 + M3 wiring. Keeps Compose free of Room/DAO access.
 */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val m7Services: M7Services = M7Services(appContext)

    val database: AvspDatabase = DatabaseProvider.get(appContext)
    val storage: AvspStorage = FileAvspStorage(appContext)
    /** P5: UNDERSTAND step - reads links, text and files before the script is written. */
    val sourceReader by lazy {
        com.avsp.pro.core.pipeline.SourceReader(appContext, geminiKeys = {
            com.avsp.pro.settings.ApiKeyRing.keys(secureConfigStore, com.avsp.pro.settings.SecureConfigKeys.AI_API)
        })
    }
    val appContextPublic: Context get() = appContext
    val secureConfigStore: SecureConfigStore = EncryptedSecureConfigStore(appContext)

    val logRepository: LogRepository = LogRepositoryImpl(database.logDao())
    val logger: AvspLogger = AvspLoggerImpl(logRepository)

    val bundledMediaSeeder: BundledMediaSeeder = BundledMediaSeeder(
        context = appContext,
        storage = storage,
        mediaAssetDao = database.mediaAssetDao(),
        logger = logger
    )

    val projectRepository: ProjectRepository = ProjectRepositoryImpl(
        projectDao = database.projectDao(),
        mediaAssetDao = database.mediaAssetDao(),
        storage = storage,
        logger = logger
    )

    val settingsRepository: SettingsRepository = SettingsRepositoryImpl(
        settingsDao = database.settingsDao(),
        secureConfigStore = secureConfigStore
    )

    val moduleStatusRepository: ModuleStatusRepository = ModuleStatusRepositoryImpl(
        dao = database.moduleStatusDao()
    )

    private val scriptGeneratorRegistry = DefaultScriptGeneratorRegistry(secureConfigStore)

    val scriptRepository: ScriptRepository = ScriptRepositoryImpl(
        storage = storage,
        generatorRegistry = scriptGeneratorRegistry,
        logger = logger
    )

    val ttsEngineRegistry = DefaultTtsEngineRegistry(appContext, secureConfigStore)

    val audioRepository: AudioRepository = AudioRepositoryImpl(
        storage = storage,
        scriptRepository = scriptRepository,
        ttsRegistry = ttsEngineRegistry,
        logger = logger
    )

    private val videoEngine = Media3VideoEngine(appContext, storage)

    private val videoMediaStoreExporter = VideoMediaStoreExporter(appContext)

    val videoRepository: VideoRepository = VideoRepositoryImpl(
        projectRepository = projectRepository,
        audioRepository = audioRepository,
        scriptRepository = scriptRepository,
        storage = storage,
        engine = videoEngine,
        logger = logger,
        bundledMediaSeeder = bundledMediaSeeder,
        mediaStoreExporter = videoMediaStoreExporter
    )

    /** P12: smart edit of the user's own video (cut dead air, pauses, fillers; captions). */
    /** P16: posting through the user's own Google Sheet (approval, schedule, results). */
    val publisher: com.avsp.pro.publish.SheetPublisher by lazy { com.avsp.pro.publish.SheetPublisher(secureConfigStore) }

    /** P16: the user's own phone gallery as an opt-in picture source. */
    val gallery: com.avsp.pro.media.GalleryLibrary by lazy { com.avsp.pro.media.GalleryLibrary(appContextPublic) }

    fun smartEdit(): com.avsp.pro.edit.SmartEditService =
        com.avsp.pro.edit.SmartEditService(appContextPublic, projectRepository, storage, logger) {
            com.avsp.pro.settings.ApiKeyRing.keys(secureConfigStore, com.avsp.pro.settings.SecureConfigKeys.AI_API)
        }

    /** P10: text blog + photo blog from a project. */
    /** P19: SEO + thumbnail for a video that is already edited. */
    fun readyVideo(): com.avsp.pro.edit.ReadyVideoService =
        com.avsp.pro.edit.ReadyVideoService(appContextPublic, projectRepository, storage, logger) {
            com.avsp.pro.settings.ApiKeyRing.keys(secureConfigStore, com.avsp.pro.settings.SecureConfigKeys.AI_API)
        }

    fun blogExporter(): com.avsp.pro.core.pipeline.BlogExporter =
        com.avsp.pro.core.pipeline.BlogExporter(
            context = appContextPublic,
            projectRepository = projectRepository,
            scriptRepository = scriptRepository,
            storage = storage,
            autoProducer = autoProducer(),
            logger = logger
        )

    /** One-tap / manual production pipeline (script -> visuals -> voice -> video). */
    fun autoProducer(): com.avsp.pro.core.pipeline.AutoProducer =
        com.avsp.pro.core.pipeline.AutoProducer(
            projectRepository = projectRepository,
            scriptRepository = scriptRepository,
            audioRepository = audioRepository,
            videoRepository = videoRepository,
            logger = logger,
            storage = storage,
            stock = com.avsp.pro.media.PexelsStockProvider(
                apiKey = { secureConfigStore.getSecret(com.avsp.pro.settings.SecureConfigKeys.PEXELS) },
                apiKeys = { com.avsp.pro.settings.ApiKeyRing.keys(secureConfigStore, com.avsp.pro.settings.SecureConfigKeys.PEXELS) }
            ),
            pictures = com.avsp.pro.media.OpenverseImageProvider(),
            thumbnails = com.avsp.pro.edit.ThumbnailMaker(appContextPublic),
            gallery = gallery,
            keyedPhotos = com.avsp.pro.media.KeyedPhotoProvider(secureConfigStore)
        )
}
