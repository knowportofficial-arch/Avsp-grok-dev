package com.avsp.pro.screen.capture

import kotlin.math.max
import kotlin.math.min

/**
 * AVSP P1 CONTEXT PRIVACY
 *
 * The pattern sanitizer looks at ONE OCR line at a time, so it can only
 * see values that carry their own shape (numbers, e-mail, PAN, ...).
 * Personal data that is only recognisable from its CONTEXT was leaking:
 *
 *   - "Elector's Name" on one OCR line, ": Angur Maiti" on another
 *   - ID cards: value column (incl. Bengali/other scripts ML Kit cannot read)
 *   - Contact names in dialer / call-log / contact lists
 *
 * This object looks at all OCR lines of one frame together and returns
 * extra regions to censor. Pure Kotlin (no Android types): unit-tested on
 * the JVM. Coordinates are normalized 0..1.
 */
data class PrivacyTextLine(
    val text: String,
    val box: PrivacyBox
)

data class ContextPrivacyFinding(
    val type: SensitiveDataType,
    val box: PrivacyBox,
    /** Raw value when known (used to scrub narration); empty for region-only findings. */
    val sourceText: String,
    val maskedText: String
)

object ScreenContextPrivacy {

    /** Label vocabulary. A label line consists ONLY of these tokens and contains an anchor. */
    private val LABEL_TOKENS = setOf(
        "elector", "electors", "name", "names", "father", "fathers", "mother", "mothers",
        "husband", "husbands", "guardian", "guardians", "spouse", "spouses", "holder", "holders",
        "customer", "applicant", "account", "nominee", "full", "first", "last", "middle", "surname",
        "date", "of", "birth", "dob", "son", "daughter", "wife", "so", "do", "wo", "co",
        "address", "permanent", "present", "residential", "year", "the", "relation", "relations",
        "नाम", "पिता", "पति", "माता", "का", "की", "जन्म", "तिथि", "पता"
    )

    private val LABEL_ANCHORS = setOf(
        "elector", "electors", "name", "names", "father", "fathers", "mother", "mothers",
        "husband", "husbands", "guardian", "guardians", "spouse", "spouses", "nominee",
        "surname", "birth", "dob", "so", "do", "wo", "co", "address",
        "नाम", "पिता", "पति", "माता", "जन्म", "पता"
    )

    /** Extra label words that are only treated as labels on identity documents. */
    private val ID_ONLY_TOKENS = setOf("sex", "gender", "age", "as", "on", "लिंग", "आयु")
    private val ID_ONLY_ANCHORS = setOf("sex", "gender", "age", "लिंग", "आयु")

    private val ID_KEYWORDS = listOf(
        "election commission", "identity card", "elector", "epic no", "government of india",
        "govt of india", "govt. of india", "unique identification", "aadhaar", "aadhar",
        "आधार", "भारत सरकार", "भारत निर्वाचन", "income tax department",
        "permanent account number", "driving licence", "driving license",
        "republic of india", "passport no", "date of birth", "voter"
    )

    private val CONTACT_SCREEN_WORDS = setOf(
        "dial", "dialer", "dialpad", "keypad", "contacts", "favorites", "favourites",
        "recents", "recent", "call history", "call log", "calls", "missed", "phone"
    )

    /** Words that are UI chrome, never a person's name on a contact screen. */
    private val CONTACT_UI_WORDS = setOf(
        "dial", "dialer", "dialpad", "keypad", "contacts", "contact", "favorites", "favourites",
        "recents", "recent", "call", "calls", "history", "log", "search", "message", "messages",
        "today", "yesterday", "missed", "incoming", "outgoing", "mobile", "home", "work", "other",
        "unknown", "spam", "edit", "settings", "phone", "video", "hd", "volte", "bsnl", "jio",
        "airtel", "vi", "vodafone", "abc", "def", "ghi", "jkl", "mno", "pqrs", "tuv", "wxyz",
        "am", "pm", "add", "new", "create", "select", "all", "more", "delete", "block", "info",
        "truecaller", "voicemail", "sim", "groups", "emergency", "verified", "business"
    )

    private val SEPARATORS = Regex("[\\s/:：=\\-–—,.|()]+")
    private val INLINE_LABEL = Regex("^(.{2,48}?)\\s*[:：=\\-–]\\s*(.+)$")
    private val NAME_LIKE = Regex("^[\\p{L}][\\p{L}\\p{M} .'’\\-]{1,48}$")

    fun detect(lines: List<PrivacyTextLine>): List<ContextPrivacyFinding> {
        val valid = lines.filter { it.text.isNotBlank() && it.box.isValid }
        if (valid.isEmpty()) return emptyList()

        // P3: home-screen / app-drawer icon labels ("Aadhaar", "Wallet", "Phone",
        // "Contacts") are app names, not personal data and not an ID card.
        val launcher = launcherLabels(valid)
        val joined = valid.filter { it !in launcher }.joinToString("\n") { it.text }.lowercase()
        val idMode = ID_KEYWORDS.any { joined.contains(it) }

        val out = mutableListOf<ContextPrivacyFinding>()

        // ------------------------------------------------------------
        // 1. Labelled values (same line, same row, or line below).
        // ------------------------------------------------------------
        val labelOnly = valid.filter { isLabelOnly(it.text, idMode) }
        val labelSet = labelOnly.toSet()
        val valueBoxes = mutableListOf<PrivacyBox>()

        valid.forEach { line ->
            if (line in labelSet) return@forEach
            val m = INLINE_LABEL.find(line.text.trim()) ?: return@forEach
            val label = m.groupValues[1]
            val value = m.groupValues[2].trim()
            if (!isLabelOnly(label, idMode)) return@forEach
            if (value.count { it.isLetterOrDigit() } < 2) return@forEach
            val start = line.text.indexOf(value).coerceAtLeast(0)
            val box = spanBox(line, start, start + value.length)
            valueBoxes += box
            out += ContextPrivacyFinding(SensitiveDataType.NAME, box, value, "[PERSONAL]")
        }

        labelOnly.forEach { label ->
            val value = findValueLine(label, valid, labelSet) ?: return@forEach
            val text = value.text
            val first = text.indexOfFirst { it.isLetterOrDigit() }.coerceAtLeast(0)
            val box = spanBox(value, first, text.length)
            valueBoxes += box
            out += ContextPrivacyFinding(
                SensitiveDataType.NAME,
                box,
                text.substring(first).trim(),
                "[PERSONAL]"
            )
        }

        // ------------------------------------------------------------
        // 2. Identity documents: censor the whole value band of every
        //    labelled row (covers lines OCR cannot read, e.g. Bengali).
        // ------------------------------------------------------------
        if (idMode) {
            out += idValueBands(valid, labelSet, valueBoxes)
        }

        // ------------------------------------------------------------
        // 3. Contact / dialer / call-log screens: person names.
        // ------------------------------------------------------------
        if (isContactScreen(valid)) {
            valid.forEach { line ->
                if (line in labelSet || line in launcher) return@forEach
                if (isContactName(line)) {
                    out += ContextPrivacyFinding(
                        SensitiveDataType.CONTACT_NAME,
                        line.box,
                        line.text.trim(),
                        "[CONTACT]"
                    )
                }
            }
        }

        return out.filter { it.box.isValid }
    }

    // ------------------------------------------------------------------

    internal fun isLabelOnly(text: String, idMode: Boolean): Boolean {
        val tokens = tokens(text)
        if (tokens.isEmpty() || tokens.size > 8) return false
        var anchor = false
        for (t in tokens) {
            val known = t in LABEL_TOKENS || (idMode && t in ID_ONLY_TOKENS)
            if (!known) return false
            if (t in LABEL_ANCHORS || (idMode && t in ID_ONLY_ANCHORS)) anchor = true
        }
        return anchor
    }

    private fun tokens(text: String): List<String> {
        val lower = text.lowercase()
            .replace("s/o", " so ")
            .replace("d/o", " do ")
            .replace("w/o", " wo ")
            .replace("c/o", " co ")
            .replace("’", "'")
        return lower
            .split(SEPARATORS)
            .map { it.removeSuffix("'s").removeSuffix("'").replace("'", "") }
            .filter { it.isNotEmpty() }
    }

    private fun verticalOverlap(a: PrivacyBox, b: PrivacyBox): Float {
        val o = min(a.bottom, b.bottom) - max(a.top, b.top)
        val h = min(a.height, b.height)
        return if (o <= 0f || h <= 0f) 0f else o / h
    }

    private fun findValueLine(
        label: PrivacyTextLine,
        lines: List<PrivacyTextLine>,
        labels: Set<PrivacyTextLine>
    ): PrivacyTextLine? {
        val l = label.box
        val candidates = lines.filter {
            it !== label && it !in labels && it.text.any { c -> c.isLetterOrDigit() }
        }

        // Same row, to the right.
        val sameRow = candidates
            .filter {
                verticalOverlap(l, it.box) >= 0.5f &&
                    it.box.left >= l.left + l.width * 0.5f &&
                    it.box.left - l.right <= 0.55f
            }
            .minByOrNull { it.box.left }
        if (sameRow != null) return sameRow

        // Directly below (form layout), starting at the label's column.
        val h = l.height.coerceAtLeast(0.005f)
        return candidates
            .filter {
                it.box.top >= l.bottom - h * 0.3f &&
                    it.box.top <= l.bottom + h * 1.6f &&
                    it.box.left >= l.left - 0.03f &&
                    it.box.left <= l.left + max(l.width, 0.10f)
            }
            .minByOrNull { it.box.top }
    }

    /** Sub-box of a line for a character span (same ratio method as the sanitizer). */
    private fun spanBox(line: PrivacyTextLine, start: Int, end: Int): PrivacyBox {
        val len = line.text.length.coerceAtLeast(1)
        val s = (start.toFloat() / len).coerceIn(0f, 1f)
        val e = (end.toFloat() / len).coerceIn(s, 1f)
        val w = line.box.width
        return PrivacyBox(
            line.box.left + w * s,
            line.box.top,
            line.box.left + w * e,
            line.box.bottom
        )
    }

    private fun idValueBands(
        lines: List<PrivacyTextLine>,
        labels: Set<PrivacyTextLine>,
        valueBoxes: List<PrivacyBox>
    ): List<ContextPrivacyFinding> {

        // Label rows: label-only lines + lines that start with a label and a separator.
        val labelRows = lines.filter { line ->
            line in labels || run {
                val m = INLINE_LABEL.find(line.text.trim())
                m != null && isLabelOnly(m.groupValues[1], true)
            }
        }
            .filter { it.box.left < 0.60f }
            .sortedBy { it.box.top }

        if (labelRows.isEmpty()) return emptyList()

        val firstTop = labelRows.first().box.top
        val lastBottom = labelRows.last().box.bottom

        val docRight = lines
            .filter { it.box.bottom >= firstTop - 0.02f && it.box.top <= lastBottom + 0.12f }
            .maxOfOrNull { it.box.right }
            ?.coerceIn(0f, 1f)
            ?: 1f

        val out = mutableListOf<ContextPrivacyFinding>()

        labelRows.forEachIndexed { index, row ->
            val r = row.box
            val h = r.height.coerceAtLeast(0.005f)

            val ownValue = valueBoxes
                .filter { verticalOverlap(r, it) >= 0.5f || (it.top >= r.top && it.top <= r.bottom + h * 1.6f) }
                .minOfOrNull { it.left }

            val inlineStart = INLINE_LABEL.find(row.text.trim())?.let { m ->
                if (row in labels) null
                else {
                    val idx = row.text.indexOf(m.groupValues[2])
                    if (idx > 0) r.left + r.width * (idx.toFloat() / row.text.length.coerceAtLeast(1)) else null
                }
            }

            val left = (ownValue ?: inlineStart ?: (r.right + 0.01f))
                .coerceAtMost(r.right + 0.05f)

            val next = labelRows.getOrNull(index + 1)?.box?.top
            val bottom = min(
                next?.let { it - 0.003f } ?: (r.bottom + h * 2.2f),
                r.bottom + h * 3.2f
            ).coerceAtLeast(r.bottom)

            val right = max(docRight, left + 0.12f).coerceAtMost(1f)

            val band = PrivacyBox(left, r.top - 0.003f, right, bottom).clamped()
            if (band.isValid && band.width < 0.95f) {
                out += ContextPrivacyFinding(SensitiveDataType.ID_FIELD, band, "", "[ID FIELD]")
            }
        }
        return out
    }

    /**
     * P3: app-icon labels of a launcher grid / dock: short (1-2 words), narrow,
     * and at least 3 of them side by side on the same row. A contact list has
     * one name per row, so real names are never in such a row.
     */
    internal fun launcherLabels(lines: List<PrivacyTextLine>): Set<PrivacyTextLine> {
        val short = lines.filter { l ->
            val t = l.text.trim()
            t.length in 2..18 && t.split(Regex("\\s+")).size <= 2 && l.box.width < 0.26f && l.box.height < 0.035f
        }
        val out = mutableSetOf<PrivacyTextLine>()
        for (l in short) {
            val row = short.filter { o ->
                verticalOverlap(l.box, o.box) >= 0.5f
            }
            if (row.size < 3) continue
            // Spread across the screen like icon columns (not one sentence split by OCR).
            val sorted = row.sortedBy { it.box.left }
            val gaps = sorted.zipWithNext { a, b -> b.box.left - a.box.right }
            if (gaps.all { it > 0.02f } && sorted.last().box.right - sorted.first().box.left > 0.45f) out += row
        }
        return out
    }

    internal fun isContactScreen(lines: List<PrivacyTextLine>): Boolean {
        // Ignore tiny text (e.g. app thumbnails on the recent-apps screen).
        val readable = lines.filter { it.box.height >= 0.008f }
        val hits = readable
            .map { it.text.trim().lowercase() }
            .filter { it in CONTACT_SCREEN_WORDS }
            .toSet()
        val truecaller = readable.any {
            it.text.trim().equals("truecaller", ignoreCase = true) && it.box.top < 0.12f
        }
        return hits.size >= 2 || truecaller
    }

    internal fun isContactName(line: PrivacyTextLine): Boolean {
        val text = line.text.trim()
        if (!NAME_LIKE.matches(text)) return false
        if (text.count { it.isLetter() } < 3) return false
        if (line.box.height > 0.035f) return false
        val words = text.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty() || words.size > 6) return false
        val uiOnly = words.all { it.lowercase().trim('.', '\'', '-') in CONTACT_UI_WORDS }
        return !uiOnly
    }
}
