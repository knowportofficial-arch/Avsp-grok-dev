package com.avsp.pro.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avsp.pro.core.error.AvspException
import com.avsp.pro.core.model.AspectRatio
import com.avsp.pro.core.model.ProjectLanguage
import com.avsp.pro.core.ui.UiState
import com.avsp.pro.logs.AvspLogger
import com.avsp.pro.logs.LogLevel
import com.avsp.pro.repository.SettingsRepository
import com.avsp.pro.settings.AppSettings
import com.avsp.pro.settings.ThemePreference
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val logger: AvspLogger,
    private val secureConfigStore: com.avsp.pro.settings.SecureConfigStore? = null
) : ViewModel() {

    /** P2: save the Gemini AI key (encrypted). The key is never logged or shown. */
    private val _keyMessage = MutableStateFlow<String?>(null)
    val keyMessage: StateFlow<String?> = _keyMessage.asStateFlow()

    fun saveAiKey(key: String) {
        val store = secureConfigStore ?: return
        val trimmed = key.trim()
        if (trimmed.isEmpty()) return
        /* P2.1: Gemini keys start with "AIza"; catches a Pexels key pasted here. */
        if (!trimmed.startsWith("AIza")) {
            _keyMessage.value = "That is not a Gemini key (Gemini keys start with AIza). Not saved."
            return
        }
        _keyMessage.value = "Gemini key saved."
        
        store.putSecret(com.avsp.pro.settings.SecureConfigKeys.AI_API, trimmed)
        logger.info("M1", "AI key saved")
        refresh()
    }

    /** P2: generic encrypted key save / clear (e.g. Pexels). */
    fun saveSecret(name: String, value: String) {
        val store = secureConfigStore ?: return
        if (value.isBlank()) return
        if (name == com.avsp.pro.settings.SecureConfigKeys.PEXELS && value.trim().startsWith("AIza")) {
            _keyMessage.value = "That looks like a Gemini key, not a Pexels key. Not saved."
            return
        }
        _keyMessage.value = "Key saved." 
        store.putSecret(name, value.trim())
        logger.info("M1", "Key saved: $name")
        refresh()
    }

    fun clearSecret(name: String) {
        secureConfigStore?.clearSecret(name)
        logger.info("M1", "Key cleared: $name")
        refresh()
    }

    /** Spec 36 "Test API": real request with the saved key; shows ✓ Connected or ✗ Failed + reason. */
    private val _testResult = MutableStateFlow<Map<String, String>>(emptyMap())
    val testResult: StateFlow<Map<String, String>> = _testResult.asStateFlow()

    /** P9: masked keys per provider ("••••ABCD"), key 1 first. Bumped on every change. */
    private val _keys = MutableStateFlow<Map<String, List<String>>>(emptyMap())
    val keys: StateFlow<Map<String, List<String>>> = _keys.asStateFlow()

    fun reloadKeys() {
        val store = secureConfigStore ?: return
        _keys.value = com.avsp.pro.settings.KeyProviders.all.map { it.id }
            .associateWith { n -> com.avsp.pro.settings.ApiKeyRing.keys(store, n).map(com.avsp.pro.settings.ApiKeyRing::mask) }
    }

    /** P17: add one or many keys (one per line) for a provider; wrong-looking keys are refused. */
    fun addKey(name: String, value: String) {
        val store = secureConfigStore ?: return
        val p = com.avsp.pro.settings.KeyProviders.byId(name)
        // P21.5: key formats change (and a password box can hide typos), so any key-like text is saved;
        // the live test right after saving says whether the service accepts it.
        val tokens = value.split(Regex("""[\s,;]+""")).map { it.trim().trim('"', '\'') }.filter { it.isNotEmpty() }
        val odd = tokens.count { it.length >= 16 && !p.looksRight(it) }
        val r = com.avsp.pro.settings.ApiKeyRing.addMany(store, name, value, accept = { it.length >= 16 && it.none(Char::isWhitespace) })
        _keyMessage.value = listOfNotNull(
            "${p.title}: ${r.added} key${if (r.added == 1) "" else "s"} saved".takeIf { r.added > 0 },
            "${r.duplicates} already saved".takeIf { r.duplicates > 0 },
            "$odd look unusual for ${p.title} - check the test result below".takeIf { odd > 0 && r.added > 0 },
            "${r.rejected} too short to be a key - not saved".takeIf { r.rejected > 0 },
            "Nothing saved - paste the key(s) and try again".takeIf { r.added == 0 && r.duplicates == 0 && r.rejected == 0 },
            "${r.full} skipped (max ${com.avsp.pro.settings.ApiKeyRing.MAX_KEYS})".takeIf { r.full > 0 }
        ).joinToString(" · ").ifBlank { null }
        logger.info("M1", "Keys added for ${p.title}: ${r.added}")
        _testResult.value = _testResult.value.filterKeys { !it.startsWith("$name#") }
        reloadKeys(); refresh()
        if (r.added > 0) testAll(name)
    }

    fun removeKey(name: String, index: Int) {
        val store = secureConfigStore ?: return
        com.avsp.pro.settings.ApiKeyRing.remove(store, name, index)
        logger.info("M1", "Key ${index + 1} removed")
        _testResult.value = _testResult.value.filterKeys { !it.startsWith("$name#") }
        _keyMessage.value = "Key removed."
        reloadKeys(); refresh()
    }

    fun testKey(name: String, index: Int = 0) {
        val id = "$name#$index"
        val key = com.avsp.pro.settings.ApiKeyRing.keys(secureConfigStore, name).getOrNull(index).orEmpty()
        if (key.isEmpty()) { _testResult.value = _testResult.value + (id to "✗ No key saved"); return }
        _testResult.value = _testResult.value + (id to "Testing…")
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            val msg = com.avsp.pro.settings.KeyProviders.check(com.avsp.pro.settings.KeyProviders.byId(name), key)
            _testResult.value = _testResult.value + (id to msg)
        }
    }

    /** P17: test every saved key of a provider. */
    fun testAll(name: String) {
        val n = com.avsp.pro.settings.ApiKeyRing.keys(secureConfigStore, name).size
        for (i in 0 until n) testKey(name, i)
    }

    fun isConfigured(name: String): Boolean = secureConfigStore?.hasSecret(name) == true

    fun clearAiKey() {
        secureConfigStore?.clearSecret(com.avsp.pro.settings.SecureConfigKeys.AI_API)
        logger.info("M1", "AI key cleared")
        refresh()
    }

    private val _state = MutableStateFlow<UiState<AppSettings>>(UiState.Idle)
    val state: StateFlow<UiState<AppSettings>> = _state.asStateFlow()

    private val _saved = MutableStateFlow(false)
    val saved: StateFlow<Boolean> = _saved.asStateFlow()

    init {
        refresh()
        reloadKeys()
    }

    fun refresh() {
        viewModelScope.launch {
            _state.value = UiState.Loading
            try {
                _state.value = UiState.Success(settingsRepository.getSettings())
            } catch (e: Exception) {
                val msg = (e as? AvspException)?.errorInfo?.message ?: e.message ?: "Failed to load settings"
                logger.error("M1", "Settings load failed", details = msg)
                _state.value = UiState.Error(msg)
            }
        }
    }

    fun save(settings: AppSettings) {
        viewModelScope.launch {
            try {
                settingsRepository.saveSettings(settings)
                logger.info("M1", "Settings saved")
                _saved.value = true
                _state.value = UiState.Success(settingsRepository.getSettings())
            } catch (e: Exception) {
                val msg = (e as? AvspException)?.errorInfo?.message ?: e.message ?: "Failed to save settings"
                logger.error("M1", "Settings save failed", details = msg)
                _state.value = UiState.Error(msg)
            }
        }
    }

    fun updateLanguage(language: ProjectLanguage) { com.avsp.pro.core.model.AppDefaults.language = language; mutate { it.copy(defaultLanguage = language) } }
    fun updateAspect(aspect: AspectRatio) = mutate { it.copy(defaultAspectRatio = aspect) }
    fun updateTheme(theme: ThemePreference) = mutate { it.copy(themePreference = theme) }
    fun updateLogLevel(level: LogLevel) = mutate { it.copy(loggingLevel = level) }
    fun updateOutputRef(ref: String) = mutate { it.copy(defaultOutputDirectoryRef = ref) }

    fun clearSavedFlag() {
        _saved.value = false
    }

    private fun mutate(block: (AppSettings) -> AppSettings) {
        val current = (_state.value as? UiState.Success)?.data ?: return
        _state.value = UiState.Success(block(current))
    }
}
