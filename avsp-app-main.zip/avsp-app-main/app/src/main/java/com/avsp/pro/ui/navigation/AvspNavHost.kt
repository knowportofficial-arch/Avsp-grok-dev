﻿package com.avsp.pro.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.avsp.pro.di.AppContainer
import com.avsp.pro.ui.screens.home.HomeScreen
import com.avsp.pro.ui.screens.dailypost.DailyPostScreen
import com.avsp.pro.ui.viewmodel.DailyPostViewModel
import com.avsp.pro.ui.screens.logs.LogsScreen
import com.avsp.pro.ui.screens.media.MediaScreen
import com.avsp.pro.ui.screens.modules.ModulesScreen
import com.avsp.pro.ui.screens.projects.ProjectDetailScreen
import com.avsp.pro.ui.screens.projects.ProjectsScreen
import com.avsp.pro.ui.screens.settings.SettingsScreen
import com.avsp.pro.script.ui.ScriptAiScreen
import com.avsp.pro.script.ui.ScriptAiViewModel
import com.avsp.pro.audio.ui.AudioTtsScreen
import com.avsp.pro.audio.ui.AudioTtsViewModel
import com.avsp.pro.video.ui.VideoScreen
import com.avsp.pro.video.ui.VideoViewModel
import com.avsp.pro.ui.screens.pipeline.M5InputScreen
import com.avsp.pro.ui.screens.pipeline.M8CreativeScreen
import com.avsp.pro.ui.screens.pipeline.M9PublishingScreen
import com.avsp.pro.m7.capture.camera.CameraPreviewScreen
import com.avsp.pro.m7.capture.camera.CameraViewModel
import com.avsp.pro.screen.capture.ScreenCaptureScreen
import com.avsp.pro.ui.viewmodel.HomeViewModel
import com.avsp.pro.ui.viewmodel.LogsViewModel
import com.avsp.pro.ui.viewmodel.MediaViewModel
import com.avsp.pro.ui.viewmodel.ModulesViewModel
import com.avsp.pro.ui.viewmodel.ProjectDetailViewModel
import com.avsp.pro.ui.viewmodel.ProjectsViewModel
import com.avsp.pro.ui.viewmodel.SettingsViewModel
import com.avsp.pro.ui.viewmodel.ViewModelFactory
import kotlinx.coroutines.launch

@Composable
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
fun AvspNavHost(
    container: AppContainer,
    shared: List<com.avsp.pro.m5.UnifiedInputResult>? = null,
    onSharedConsumed: () -> Unit = {}
) {
    val navController = rememberNavController()
    val factory = ViewModelFactory(container)
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    // P5: something was shared into AVSP -> go to Home, which turns it into a project.
    androidx.compose.runtime.LaunchedEffect(shared) {
        if (shared != null && !navController.popBackStack(AvspDestination.Home.route, inclusive = false)) {
            navController.navigate(AvspDestination.Home.route) { launchSingleTop = true }
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                AvspDestination.bottomBar.forEach { dest ->
                    NavigationBarItem(
                        selected = currentRoute == dest.route ||
                            (dest == AvspDestination.Projects &&
                                (currentRoute?.startsWith("project/") == true || currentRoute?.startsWith("manual/") == true)) ||
                            (dest == AvspDestination.Settings &&
                                (currentRoute == AvspDestination.Modules.route ||
                                    currentRoute == AvspDestination.Logs.route)),
                        onClick = {
                            if (dest == AvspDestination.Home) {
                                // Home always means the Home page itself, never a screen opened from it.
                                if (!navController.popBackStack(AvspDestination.Home.route, inclusive = false)) {
                                    navController.navigate(AvspDestination.Home.route) { launchSingleTop = true }
                                }
                            } else {
                                navController.navigate(dest.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = dest != AvspDestination.Projects
                                }
                            }
                        },
                        icon = {
                            Icon(
                                iconFor(dest),
                                contentDescription = dest.label
                            )
                        },
                        label = { Text(dest.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = AvspDestination.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(AvspDestination.Home.route) {
                val vm: HomeViewModel = viewModel(factory = factory)
                HomeScreen(
                    viewModel = vm,
                    shared = shared,
                    onSharedConsumed = onSharedConsumed,
                    onOpenProjects = {
                        navController.navigate(AvspDestination.Projects.route)
                    },
                    onOpenVideos = {
                        navController.navigate(AvspDestination.Videos.route)
                    },
                    onOpenDailyPost = {
                        navController.navigate(AvspDestination.DailyPost.route)
                    },
                    onOpenProject = { id ->
                        navController.navigate(
                            AvspDestination.ProjectDetail.createRoute(id)
                        )
                    },
                    onRecordScreen = { id ->
                        navController.navigate(AvspDestination.ScreenCapture.createRoute(id))
                    },
                    onOpenCamera = { id ->
                        navController.navigate(AvspDestination.M6Camera.createRoute(id))
                    },
                    onOpenManual = { id -> navController.navigate(AvspDestination.Manual.createRoute(id)) }
                )
            }

            composable(AvspDestination.DailyPost.route) {
                val dailyPostViewModel: DailyPostViewModel = viewModel()
                val scope = rememberCoroutineScope()

                // P23.2: video and blog both start from a project made from the topic.
                val openFor: (com.avsp.pro.ui.screens.dailypost.DailyPostItem, String?) -> Unit = { post, blog ->
                        scope.launch {
                            val created = container.projectRepository.createProject(
                                name = cleanNewsTitle(post.title).ifBlank { "Daily Post" }.take(120),
                                description = post.summary
                            )
                            // P11: weather, rashifal, jokes, history and observances look best as doodle animation.
                            val doodle = post.category in setOf(
                                com.avsp.pro.ui.screens.dailypost.DailyPostCategory.WEATHER,
                                com.avsp.pro.ui.screens.dailypost.DailyPostCategory.RASHIFAL,
                                com.avsp.pro.ui.screens.dailypost.DailyPostCategory.JOKES,
                                com.avsp.pro.ui.screens.dailypost.DailyPostCategory.HISTORY,
                                com.avsp.pro.ui.screens.dailypost.DailyPostCategory.WHY_TODAY
                            )
                            val project = if (doodle) runCatching {
                                container.projectRepository.updateProject(created.copy(metadata = created.metadata + ("visual.style" to "doodle")))
                            }.getOrDefault(created) else created

                            val handoff =
                                com.avsp.pro.core.handoff.DailyPostM5Handoff.from(post)

                            navController.currentBackStackEntry
                                ?.savedStateHandle
                                ?.set(
                                    "daily_post_m5_handoff",
                                    handoff.asInputText()
                                )

                            /*
                             * P2: Daily Post opens the project screen, where
                             * "Make Video Now" produces the video in one tap.
                             * Step-by-step tools (M5, Script, Audio, Video)
                             * stay available on that screen.
                             */
                            navController.navigate(
                                AvspDestination.ProjectDetail.createRoute(
                                    project.projectId
                                )
                            )
                            if (blog != null) navController.currentBackStackEntry?.savedStateHandle?.set("auto_blog", blog)
                        }
                }
                DailyPostScreen(
                    onBack = { navController.popBackStack() },
                    onMakeVideo = { post -> openFor(post, null) },
                    onMakeBlog = { post, photo -> openFor(post, if (photo) "photo" else "text") },
                    viewModel = dailyPostViewModel
                )
            }

            composable(AvspDestination.Projects.route) {
                val vm: ProjectsViewModel = viewModel(factory = factory)
                ProjectsScreen(
                    viewModel = vm,
                    onOpenProject = { id ->
                        navController.navigate(
                            AvspDestination.ProjectDetail.createRoute(id)
                        )
                    }
                )
            }

            composable(
                route = AvspDestination.ProjectDetail.route,
                arguments = listOf(
                    navArgument("projectId") {
                        type = NavType.StringType
                    }
                )
            ) { entry ->
                val projectId =
                    entry.arguments?.getString("projectId")
                        ?: return@composable

                val vm: ProjectDetailViewModel = viewModel(factory = factory)
                // P23.2: opened from Daily Post with "Text blog" / "Photo blog" -> start it right away.
                androidx.compose.runtime.LaunchedEffect(projectId) {
                    entry.savedStateHandle.remove<String>("auto_blog")?.let { vm.makeBlog(projectId, photo = it == "photo") }
                }

                ProjectDetailScreen(
                    projectId = projectId,
                    viewModel = vm,
                    onBack = { navController.popBackStack() },
                    onOpenScriptAi = {
                        navController.navigate(
                            AvspDestination.ScriptAi.createRoute(projectId)
                        )
                    },
                    onOpenAudioTts = {
                        navController.navigate(
                            AvspDestination.AudioTts.createRoute(projectId)
                        )
                    },
                    onOpenVideoEngine = {
                        navController.navigate(
                            AvspDestination.VideoEngine.createRoute(projectId)
                        )
                    },
                    onOpenM5 = {
                        navController.navigate(
                            AvspDestination.M5Input.createRoute(projectId)
                        )
                    },
                    onOpenM6 = {
                        navController.navigate(
                            AvspDestination.M6Camera.createRoute(projectId)
                        )
                    },
                    onOpenScreenCapture = {
                        navController.navigate(
                            AvspDestination.ScreenCapture.createRoute(projectId)
                        )
                    },
                    onOpenM8 = {
                        navController.navigate(
                            AvspDestination.M8Creative.createRoute(projectId)
                        )
                    },
                    onOpenM9 = {
                        navController.navigate(
                            AvspDestination.M9Publishing.createRoute(projectId)
                        )
                    },
                    onOpenManual = {
                        navController.navigate(AvspDestination.Manual.createRoute(projectId))
                    }
                )
            }

            composable(
                route = AvspDestination.Manual.route,
                arguments = listOf(navArgument("projectId") { type = NavType.StringType })
            ) { entry ->
                val projectId = entry.arguments?.getString("projectId") ?: return@composable
                val vm: com.avsp.pro.ui.viewmodel.ManualViewModel = viewModel(factory = factory)
                com.avsp.pro.ui.screens.projects.ManualScreen(
                    projectId = projectId,
                    viewModel = vm,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = AvspDestination.ScriptAi.route,
                arguments = listOf(
                    navArgument("projectId") {
                        type = NavType.StringType
                    }
                )
            ) { entry ->
                val projectId =
                    entry.arguments?.getString("projectId")
                        ?: return@composable

                val vm: ScriptAiViewModel = viewModel(factory = factory)

                val m5ScriptSource =
                    navController.previousBackStackEntry
                        ?.savedStateHandle
                        ?.get<String>("m5_script_source")
                        .orEmpty()

                ScriptAiScreen(
                    projectId = projectId,
                    viewModel = vm,
                    onBack = { navController.popBackStack() },
                    initialTopic = m5ScriptSource,
                    onOpenAudio = {
                        navController.navigate(
                            AvspDestination.AudioTts.createRoute(projectId)
                        )
                    }
                )
            }

            composable(
                route = AvspDestination.AudioTts.route,
                arguments = listOf(
                    navArgument("projectId") {
                        type = NavType.StringType
                    }
                )
            ) { entry ->
                val projectId =
                    entry.arguments?.getString("projectId")
                        ?: return@composable

                val vm: AudioTtsViewModel = viewModel(factory = factory)

                AudioTtsScreen(
                    projectId = projectId,
                    viewModel = vm,
                    onBack = { navController.popBackStack() },
                    onOpenVideo = {
                        navController.navigate(
                            AvspDestination.VideoEngine.createRoute(projectId)
                        )
                    }
                )
            }

            composable(
                route = AvspDestination.VideoEngine.route,
                arguments = listOf(
                    navArgument("projectId") {
                        type = NavType.StringType
                    }
                )
            ) { entry ->
                val projectId =
                    entry.arguments?.getString("projectId")
                        ?: return@composable

                val m5VideoSource =
                    navController.previousBackStackEntry
                        ?.savedStateHandle
                        ?.get<String>("m5_video_source")
                        .orEmpty()

                val vm: VideoViewModel = viewModel(factory = factory)

                VideoScreen(
                    projectId = projectId,
                    viewModel = vm,
                    onBack = { navController.popBackStack() },
                    initialSource = m5VideoSource
                )
            }

            composable(
                route = AvspDestination.M5Input.route,
                arguments = listOf(
                    navArgument("projectId") {
                        type = NavType.StringType
                    }
                )
            ) { entry ->
                val projectId =
                    entry.arguments?.getString("projectId")
                        ?: return@composable

                // P19: the simple "Add to this project" box (replaces the old developer input screen).
                val addVm: HomeViewModel = viewModel(factory = factory)
                com.avsp.pro.ui.screens.projects.AddToProjectScreen(
                    projectId = projectId,
                    viewModel = addVm,
                    onDone = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }

            composable(
                route = AvspDestination.M6Camera.route,
                arguments = listOf(
                    navArgument("projectId") {
                        type = NavType.StringType
                    }
                )
            ) { entry ->
                val projectId =
                    entry.arguments?.getString("projectId")
                        ?: return@composable

                val vm: CameraViewModel = viewModel(factory = factory)

                CameraPreviewScreen(
                    projectId = projectId,
                    viewModel = vm,
                    onNavigateBack = {
                        navController.popBackStack()
                    }
                )
            }

            composable(
                route = AvspDestination.ScreenCapture.route,
                arguments = listOf(
                    navArgument("projectId") {
                        type = NavType.StringType
                    }
                )
            ) { entry ->
                val projectId =
                    entry.arguments?.getString("projectId")
                        ?: return@composable

                ScreenCaptureScreen(
                    projectId = projectId,
                    onNavigateBack = {
                        navController.popBackStack()
                    }
                )
            }

            composable(
                route = AvspDestination.M8Creative.route,
                arguments = listOf(
                    navArgument("projectId") {
                        type = NavType.StringType
                    }
                )
            ) { entry ->
                val projectId =
                    entry.arguments?.getString("projectId")
                        ?: return@composable

                M8CreativeScreen(
                    projectId,
                    onBack = {
                        navController.popBackStack()
                    }
                )
            }

            composable(
                route = AvspDestination.M9Publishing.route,
                arguments = listOf(
                    navArgument("projectId") {
                        type = NavType.StringType
                    }
                )
            ) { entry ->
                val projectId =
                    entry.arguments?.getString("projectId")
                        ?: return@composable

                M9PublishingScreen(
                    projectId,
                    onBack = {
                        navController.popBackStack()
                    }
                )
            }

            composable(AvspDestination.Media.route) {
                val vm: MediaViewModel = viewModel(factory = factory)
                MediaScreen(viewModel = vm)
            }

            composable(AvspDestination.Videos.route) {
                com.avsp.pro.ui.screens.videos.VideosScreen(
                    loadProjectNames = {
                        container.projectRepository.listProjects().associate { it.projectId to it.name }
                    },
                    onOpenProject = { id ->
                        navController.navigate(AvspDestination.ProjectDetail.createRoute(id))
                    },
                    onMakeVideo = {
                        navController.navigate(AvspDestination.Home.route) {
                            popUpTo(navController.graph.findStartDestination().id)
                            launchSingleTop = true
                        }
                    }
                )
            }

            composable(AvspDestination.Modules.route) {
                val vm: ModulesViewModel = viewModel(factory = factory)
                ModulesScreen(viewModel = vm, onBack = { navController.popBackStack() })
            }

            composable(AvspDestination.Settings.route) {
                val vm: SettingsViewModel = viewModel(factory = factory)
                SettingsScreen(
                    viewModel = vm,
                    onOpenModules = { navController.navigate(AvspDestination.Modules.route) },
                    onOpenLogs = { navController.navigate(AvspDestination.Logs.route) }
                )
            }

            composable(AvspDestination.Logs.route) {
                val vm: LogsViewModel = viewModel(factory = factory)
                LogsScreen(viewModel = vm)
            }
        }
    }
}

private fun iconFor(dest: AvspDestination): ImageVector =
    when (dest) {
        AvspDestination.Home -> Icons.Filled.Home
        AvspDestination.DailyPost -> Icons.Filled.Info
        AvspDestination.Projects -> Icons.Filled.Folder
        AvspDestination.Media -> Icons.Filled.VideoLibrary
        AvspDestination.Videos -> Icons.Filled.VideoLibrary
        AvspDestination.Modules -> Icons.Filled.List
        AvspDestination.Settings -> Icons.Filled.Settings
        AvspDestination.Logs -> Icons.Filled.Info
        AvspDestination.Manual,
        AvspDestination.ProjectDetail,
        AvspDestination.ScriptAi,
        AvspDestination.AudioTts,
        AvspDestination.VideoEngine -> Icons.Filled.Folder
        AvspDestination.M5Input -> Icons.Filled.List
        AvspDestination.M6Camera -> Icons.Filled.Folder
        AvspDestination.ScreenCapture -> Icons.Filled.Folder
        AvspDestination.M8Creative -> Icons.Filled.Folder
        AvspDestination.M9Publishing -> Icons.Filled.Folder
    }

/** "Big story headline - Careers360" -> "Big story headline" (site name dropped). */
internal fun cleanNewsTitle(title: String): String {
    val t = title.trim()
    val i = t.lastIndexOf(" - ")
    return if (i > 20 && t.substring(i + 3).trim().split(' ').size <= 4) t.substring(0, i).trim() else t
}
