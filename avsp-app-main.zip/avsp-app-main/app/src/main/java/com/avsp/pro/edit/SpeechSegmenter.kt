package com.avsp.pro.edit

import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

/**
 * P12 SMART EDIT: where someone is speaking in an audio track (pure, testable).
 * Energy-based voice activity detection with an adaptive noise floor:
 * 20 ms frames -> loudness (dBFS) -> "speech" when clearly above the
 * room noise, with hangover so word endings are not clipped.
 */
object SpeechSegmenter {
    data class Segment(val startMs: Long, val endMs: Long) {
        val durationMs get() = endMs - startMs
    }

    const val FRAME_MS = 20

    /** Loudness of each 20 ms frame in dBFS (-90 = silence). */
    fun frameLevels(pcm: ShortArray, sampleRate: Int): FloatArray {
        val frame = max(1, sampleRate * FRAME_MS / 1000)
        val n = pcm.size / frame
        return FloatArray(n) { i ->
            var sum = 0.0
            for (k in i * frame until (i + 1) * frame) { val v = pcm[k] / 32768.0; sum += v * v }
            val rms = sqrt(sum / frame)
            if (rms <= 1e-6) -90f else (20 * log10(rms)).toFloat().coerceAtLeast(-90f)
        }
    }

    /** Noise floor = quiet end of the track (15th percentile), never below -70 dBFS. */
    fun noiseFloor(levels: FloatArray): Float {
        if (levels.isEmpty()) return -70f
        val sorted = levels.sorted()
        return sorted[(sorted.size * 0.15).toInt().coerceIn(0, sorted.size - 1)].coerceAtLeast(-70f)
    }

    fun segments(
        levels: FloatArray,
        minSpeechMs: Long = 160,
        mergeGapMs: Long = 260,
        hangoverMs: Long = 140
    ): List<Segment> {
        if (levels.isEmpty()) return emptyList()
        val floor = noiseFloor(levels)
        val peak = levels.sorted()[(levels.size * 0.95).toInt().coerceIn(0, levels.size - 1)]
        // Speech must be clearly above the floor; in a very quiet room at least -48 dBFS.
        val threshold = maxOf(floor + 9f, minOf(-48f, peak - 25f), -55f)
        val raw = mutableListOf<Segment>()
        var start = -1
        for (i in levels.indices) {
            val on = levels[i] >= threshold
            if (on && start < 0) start = i
            if (!on && start >= 0) { raw += Segment(start * FRAME_MS.toLong(), i * FRAME_MS.toLong()); start = -1 }
        }
        if (start >= 0) raw += Segment(start * FRAME_MS.toLong(), levels.size * FRAME_MS.toLong())
        // Merge short gaps (between words), then drop blips.
        val merged = mutableListOf<Segment>()
        for (s in raw) {
            val last = merged.lastOrNull()
            if (last != null && s.startMs - last.endMs <= mergeGapMs) merged[merged.lastIndex] = Segment(last.startMs, s.endMs)
            else merged += s
        }
        val total = levels.size * FRAME_MS.toLong()
        return merged.filter { it.durationMs >= minSpeechMs }
            .map { Segment(it.startMs, minOf(total, it.endMs + hangoverMs)) }
    }
}
