﻿package com.avsp.pro.video.export

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class VideoMediaStoreExport(
    val uri: Uri,
    val relativePath: String,
    val displayName: String
)

class VideoMediaStoreExporter(
    private val context: Context
) {
    suspend fun export(
        sourceFile: File,
        projectId: String
    ): VideoMediaStoreExport = withContext(Dispatchers.IO) {
        require(sourceFile.exists()) {
            "Rendered video does not exist: ${sourceFile.absolutePath}"
        }

        val safeProjectId = projectId
            .trim()
            .replace(Regex("[^A-Za-z0-9_-]"), "_")
            .take(60)
            .ifBlank { "project" }

        val timestamp = SimpleDateFormat(
            "yyyyMMdd_HHmmss",
            Locale.US
        ).format(Date())

        val displayName = "AVSP_${safeProjectId}_${timestamp}.mp4"
        val relativePath = "Movies/AVSP/Exports"

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, displayName)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(
                    MediaStore.Video.Media.RELATIVE_PATH,
                    relativePath
                )
                put(
                    MediaStore.Video.Media.IS_PENDING,
                    1
                )
            }
        }

        val resolver = context.contentResolver
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

        val uri = resolver.insert(collection, values)
            ?: error("Unable to create MediaStore video entry")

        try {
            resolver.openOutputStream(uri, "w")?.use { output ->
                sourceFile.inputStream().use { input ->
                    input.copyTo(output)
                }
            } ?: error("Unable to open MediaStore output stream")

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val publishValues = ContentValues().apply {
                    put(MediaStore.Video.Media.IS_PENDING, 0)
                }
                resolver.update(uri, publishValues, null, null)
            }

            VideoMediaStoreExport(
                uri = uri,
                relativePath = relativePath,
                displayName = displayName
            )
        } catch (e: Exception) {
            runCatching {
                resolver.delete(uri, null, null)
            }
            throw e
        }
    }
}
