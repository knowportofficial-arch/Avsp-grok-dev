﻿package com.avsp.pro.core.input

/**
 * M14 adapter boundary for local PDF/document inputs.
 *
 * This adapter only normalizes an already-available locator into the
 * M11 UnifiedInput contract. It does not open, parse, decode, OCR,
 * upload, fetch, or transmit document contents.
 */
object DocumentInputAdapter {

    enum class DocumentInputKind {
        PDF,
        DOCUMENT
    }

    data class AdaptedDocumentInput(
        val input: UnifiedInput,
        val kind: DocumentInputKind
    )

    fun adapt(
        locator: String,
        displayName: String? = null,
        mimeType: String? = null
    ): AdaptedDocumentInput? {
        val value = locator.trim()
        if (value.isBlank()) return null

        val name = displayName?.trim().orEmpty()
        val mime = mimeType?.trim()?.lowercase().orEmpty()

        val pdf = isPdf(value, name, mime)

        if (!pdf && !isDocument(value, name, mime)) {
            return null
        }

        val kind = if (pdf) {
            DocumentInputKind.PDF
        } else {
            DocumentInputKind.DOCUMENT
        }

        val type = if (pdf) {
            UnifiedInputType.PDF_DOCUMENT
        } else {
            UnifiedInputType.DOCUMENT
        }

        return AdaptedDocumentInput(
            input = UnifiedInput(
                id = "document-" + value.hashCode().toUInt().toString(16),
                type = type,
                locator = value,
                displayName = name.ifBlank { null },
                mimeType = mime.ifBlank { null },
                metadata = mapOf(
                    "adapter" to "M14",
                    "documentInputKind" to kind.name
                )
            ),
            kind = kind
        )
    }

    private fun isPdf(
        value: String,
        name: String,
        mime: String
    ): Boolean {
        return mime == "application/pdf" ||
            hasExtension(value, ".pdf") ||
            hasExtension(name, ".pdf")
    }

    private fun isDocument(
        value: String,
        name: String,
        mime: String
    ): Boolean {
        if (mime.startsWith("text/")) return true
        if (mime.contains("document")) return true
        if (mime.contains("word")) return true
        if (mime.contains("sheet")) return true
        if (mime.contains("spreadsheet")) return true
        if (mime.contains("presentation")) return true
        if (mime.contains("opendocument")) return true

        val extensions = listOf(
            ".txt", ".text", ".rtf",
            ".doc", ".docx", ".odt",
            ".xls", ".xlsx", ".ods",
            ".ppt", ".pptx", ".odp",
            ".csv"
        )

        return extensions.any { ext ->
            hasExtension(value, ext) || hasExtension(name, ext)
        }
    }

    private fun hasExtension(
        value: String,
        extension: String
    ): Boolean {
        val clean = value
            .substringBefore('?')
            .substringBefore('#')

        return clean.endsWith(extension, ignoreCase = true)
    }
}
