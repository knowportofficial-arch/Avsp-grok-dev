﻿package com.avsp.pro.ui.screens.projects

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.horizontalScroll
import androidx.compose.ui.unit.dp
import com.avsp.pro.core.module.AvspModules
import com.avsp.pro.core.model.AspectRatio
import com.avsp.pro.core.ui.UiState
import com.avsp.pro.ui.components.ErrorState
import com.avsp.pro.ui.components.LoadingState
import com.avsp.pro.ui.viewmodel.AutoProduceState
import com.avsp.pro.ui.viewmodel.ProjectDetailViewModel
import java.text.DateFormat
import java.util.Date

@Composable
fun ProjectDetailScreen(
    projectId: String,
    viewModel: ProjectDetailViewModel,
    onBack: () -> Unit,
    onOpenScriptAi: () -> Unit = {},
    onOpenAudioTts: () -> Unit = {},
    onOpenVideoEngine: () -> Unit = {},
    onOpenM5: () -> Unit = {},
    onOpenM6: () -> Unit = {},
    onOpenScreenCapture: () -> Unit = {},
    onOpenM8: () -> Unit = {},
    onOpenM9: () -> Unit = {},
    onOpenManual: () -> Unit = {}
) {
    val state by viewModel.state.collectAsState()
    var showRename by remember { mutableStateOf(false) }
    var renameValue by remember { mutableStateOf("") }
    var showAspectPicker by remember { mutableStateOf(false) }

    LaunchedEffect(projectId) {
        viewModel.load(projectId)
    }

    when (val s = state) {
        is UiState.Idle, is UiState.Loading -> LoadingState("Opening project…")
        is UiState.Error -> ErrorState(s.message, onRetry = { viewModel.load(projectId) })
        is UiState.Success -> {
            val dash = s.data
            val project = dash.project
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    TextButton(onClick = onBack) { Text("← Back") }
                    TextButton(onClick = {
                        renameValue = project.name
                        showRename = true
                    }) { Text("Rename") }
                }
                Text(
                    project.name,
                    style = MaterialTheme.typography.headlineSmall,
                    maxLines = 4,
                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                )
                val norm: (String) -> String = { it.lowercase().filter { c -> c.isLetterOrDigit() } }
                val descN = norm(project.description)
                val nameN = norm(project.name)
                if (descN.isNotEmpty() && !descN.contains(nameN) && !nameN.contains(descN)) {
                    Text(
                        project.description,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = 4,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    Text(
                        buildString {
                            append("${project.aspectRatio.label} · ${project.language.displayName}")
                            project.duration?.takeIf { it > 0 }?.let { append(" · last video ${(it + 500) / 1000} s") }
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    TextButton(onClick = { showAspectPicker = true }) { Text("Change shape") }
                }

                // P11: look of the video - free pictures or hand-drawn doodle animation
                val doodleLook = project.metadata["visual.style"] == "doodle"
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                ) {
                    Text("Look:", style = MaterialTheme.typography.bodyMedium)
                    androidx.compose.material3.FilterChip(selected = !doodleLook, onClick = { viewModel.setStyle(projectId, "photos") }, label = { Text("Photos") })
                    androidx.compose.material3.FilterChip(selected = doodleLook, onClick = { viewModel.setStyle(projectId, "doodle") }, label = { Text("Doodle ✏️") })
                }
                AutoProduceCard(projectId = projectId, viewModel = viewModel, onOpenManual = onOpenManual)
                androidx.compose.material3.OutlinedButton(onClick = onOpenManual, modifier = Modifier.fillMaxWidth()) {
                    Text("Manual: edit script & choose pictures")
                }
                // P12: the project has its own video -> smart edit it (cut dead air, pauses, fillers; captions)
                if (dash.assets.any { a -> a.mimeType.startsWith("video/") && !a.tags.contains("m4-test") && !a.tags.contains("stock") }) {
                    ReadyVideoCard(projectId = projectId, viewModel = viewModel)
                    SmartEditCard(projectId = projectId, viewModel = viewModel)
                }
                if (viewModel.blogAvailable) BlogCard(projectId = projectId, viewModel = viewModel)

                // ---------- Add more material ----------
                Text("Add to this video", style = MaterialTheme.typography.titleMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    androidx.compose.material3.OutlinedButton(onClick = onOpenScreenCapture, modifier = Modifier.weight(1f)) { Text("Record screen") }
                    androidx.compose.material3.OutlinedButton(onClick = onOpenM6, modifier = Modifier.weight(1f)) { Text("Camera") }
                }
                androidx.compose.material3.OutlinedButton(onClick = onOpenM5, modifier = Modifier.fillMaxWidth()) {
                    Text("Add text, link or files")
                }

                val ownMedia = dash.assets.filterNot { a -> a.tags.contains("m4-test") || a.tags.contains("stock") }
                if (ownMedia.isNotEmpty()) {
                    Text("Your media (${ownMedia.size})", style = MaterialTheme.typography.titleMedium)
                    ownMedia.forEach { asset ->
                        Text("• ${asset.fileName}", style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                    }
                }

                // ---------- Advanced: step by step ----------
                var showSteps by remember { mutableStateOf(false) }
                TextButton(onClick = { showSteps = !showSteps }) {
                    Text(if (showSteps) "Hide step-by-step tools ▲" else "Step-by-step tools (advanced) ▼")
                }
                if (showSteps) {
                    Text(
                        "Edit each stage yourself instead of one tap.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                    listOf(
                        "1. Script" to onOpenScriptAi,
                        "2. Voice-over" to onOpenAudioTts,
                        "3. Video" to onOpenVideoEngine,
                        "4. Timeline & effects" to onOpenM8,
                        "5. Publishing" to onOpenM9
                    ).forEach { (label, action) ->
                        androidx.compose.material3.OutlinedButton(onClick = action, modifier = Modifier.fillMaxWidth()) { Text(label) }
                    }
                }
                Text(
                    "Created ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(project.createdAt))}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }
    }

    if (showAspectPicker) {
        AlertDialog(
            onDismissRequest = { showAspectPicker = false },
            title = { Text("Video shape") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    AspectRatio.entries.forEach { option ->
                        TextButton(
                            onClick = {
                                showAspectPicker = false
                                viewModel.updateAspectRatio(projectId, option)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${option.label}  •  ${option.width}×${option.height}")
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showAspectPicker = false }) { Text("Cancel") }
            }
        )
    }

    if (showRename) {
        AlertDialog(
            onDismissRequest = { showRename = false },
            title = { Text("Rename project") },
            text = {
                OutlinedTextField(
                    value = renameValue,
                    onValueChange = { renameValue = it },
                    label = { Text("Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.rename(projectId, renameValue)
                    showRename = false
                }) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showRename = false }) { Text("Cancel") }
            }
        )
    }
}


/**
 * P3 publish: ready-made title / description / hashtags + one tap to each app.
 * No accounts or keys: the video and caption are handed to the installed app.
 */
@Composable
internal fun PublishKitSection(uri: String, title: String, kit: com.avsp.pro.core.pipeline.PublishKit?, thumbnail: String? = null) {
    val context = androidx.compose.ui.platform.LocalContext.current
    if (thumbnail != null) ThumbnailRow(thumbnail)
    val caption = kit?.caption ?: title
    var copied by remember { mutableStateOf(false) }

    fun copyCaption() {
        val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
        cm?.setPrimaryClip(android.content.ClipData.newPlainText("AVSP caption", caption))
        copied = true
    }

    fun share(target: com.avsp.pro.core.pipeline.PublishTarget) {
        copyCaption() // Instagram / YouTube ignore shared text: the caption is ready to paste
        val send = android.content.Intent(android.content.Intent.ACTION_SEND)
            .setType("video/mp4")
            .putExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri.parse(uri))
            .putExtra(android.content.Intent.EXTRA_TEXT, caption)
            .putExtra(android.content.Intent.EXTRA_SUBJECT, kit?.title ?: title)
            .putExtra(android.content.Intent.EXTRA_TITLE, kit?.title ?: title)
            .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        val direct = target.packageName?.let { android.content.Intent(send).setPackage(it) }
        val opened = direct != null && runCatching { context.startActivity(direct) }.isSuccess
        if (!opened) {
            runCatching { context.startActivity(android.content.Intent.createChooser(send, "Post video")) }
        }
        android.widget.Toast.makeText(
            context,
            if (direct != null && !opened) "${target.label} not installed - pick an app. Caption copied." else "Caption copied - paste it in the app.",
            android.widget.Toast.LENGTH_LONG
        ).show()
    }

    Text("Ready to post", style = MaterialTheme.typography.titleMedium)
    if (kit != null) {
        androidx.compose.foundation.text.selection.SelectionContainer {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(kit.title, style = MaterialTheme.typography.bodyLarge)
                if (kit.description.isNotBlank()) Text(kit.description, style = MaterialTheme.typography.bodySmall)
                if (kit.hashtags.isNotEmpty()) Text(kit.hashtags.joinToString(" "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }
        }
    }
    androidx.compose.material3.OutlinedButton(onClick = { copyCaption() }, modifier = Modifier.fillMaxWidth()) {
        Text(if (copied) "Caption copied" else "Copy caption")
    }
    val targets = com.avsp.pro.core.pipeline.PublishTarget.values().toList()
    targets.chunked(2).forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            row.forEach { t ->
                Button(onClick = { share(t) }, modifier = Modifier.weight(1f)) { Text(t.label, maxLines = 1) }
            }
        }
    }
}

/**
 * P2 one-tap production: script -> voice -> video -> gallery, then share.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun AutoProduceCard(projectId: String, viewModel: ProjectDetailViewModel, onOpenManual: () -> Unit = {}) {
    if (!viewModel.autoAvailable) return
    val auto by viewModel.auto.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current
    var seconds by remember { mutableStateOf(60) }

    androidx.compose.material3.Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Make video automatically", style = MaterialTheme.typography.titleLarge)
            Text(
                "AI script, voice-over and video in one tap. Saved to Movies/AVSP.",
                style = MaterialTheme.typography.bodyMedium
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.horizontalScroll(androidx.compose.foundation.rememberScrollState())) {
                listOf(0, 30, 60, 90, 180, 300).forEach { s ->
                    if (seconds == s) {
                        Button(onClick = { seconds = s }) { Text(when { s == 0 -> "Auto"; s >= 120 -> "${s / 60} min"; else -> "${s}s" }) }
                    } else {
                        androidx.compose.material3.OutlinedButton(onClick = { seconds = s }) { Text(when { s == 0 -> "Auto"; s >= 120 -> "${s / 60} min"; else -> "${s}s" }) }
                    }
                }
            }
            when (val a = auto) {
                is AutoProduceState.Running -> {
                    Text("Step ${a.stepIndex} of 4: ${a.label}...", style = MaterialTheme.typography.titleMedium)
                    if (a.detail.isNotBlank()) Text(a.detail, style = MaterialTheme.typography.bodySmall)
                    androidx.compose.material3.LinearProgressIndicator(
                        progress = { (a.stepIndex - 1) / 4f },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                is AutoProduceState.Done -> {
                    Text("Video ready: ${a.title}", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "${a.durationMs / 1000}s - ${a.displayName ?: "saved"} - " +
                            when {
                                a.provider.startsWith("gemini") -> "script by Gemini AI"
                                a.provider == "smart-offline" -> "script by built-in writer (offline)"
                                else -> "basic offline script"
                            },
                        style = MaterialTheme.typography.bodySmall
                    )
                    a.note?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                    a.uri?.let { uri ->
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                val view = android.content.Intent(android.content.Intent.ACTION_VIEW)
                                    .setDataAndType(android.net.Uri.parse(uri), "video/mp4")
                                    .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                runCatching { context.startActivity(view) }
                            }) { Text("Play") }
                        }
                        PublishKitSection(uri = uri, title = a.title, kit = a.kit, thumbnail = a.thumbnail)
                        com.avsp.pro.ui.screens.publish.SendForApprovalRow(videoUri = uri, project = a.title, title = a.title, kit = a.kit, thumbnail = a.thumbnail, projectId = projectId)
                    }
                    // P31: not happy? Remake it automatically, edit it by hand, or tell the AI what to change.
                    var changeOpen by remember { mutableStateOf(false) }
                    Text("Not happy with it?", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        androidx.compose.material3.OutlinedButton(onClick = { viewModel.autoProduce(projectId, seconds) }, modifier = Modifier.weight(1f)) { Text("Remake") }
                        androidx.compose.material3.OutlinedButton(onClick = onOpenManual, modifier = Modifier.weight(1f)) { Text("Edit") }
                        androidx.compose.material3.OutlinedButton(onClick = { changeOpen = true }, modifier = Modifier.weight(1f)) { Text("Change…") }
                    }
                    Text("Remake = a fresh version · Edit = change script and pictures yourself · Change = tell the AI what to do differently",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f))
                    // P33: the same video in other languages and shapes (each shape fits where it is posted).
                    var versionsOpen by remember { mutableStateOf(false) }
                    androidx.compose.material3.OutlinedButton(onClick = { versionsOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("Other languages & sizes…") }
                    val jobs by viewModel.versions.collectAsState()
                    jobs.forEach { j ->
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("${j.label}: ${j.status}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                            j.uri?.let { u ->
                                androidx.compose.material3.TextButton(onClick = {
                                    runCatching { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW).setDataAndType(android.net.Uri.parse(u), "video/mp4").addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                                }) { Text("Play") }
                            }
                        }
                    }
                    if (versionsOpen) {
                        val langs = com.avsp.pro.core.model.ProjectLanguage.entries
                        val shapes = listOf(
                            com.avsp.pro.core.model.AspectRatio.RATIO_9_16 to "9:16 · Shorts, Reels, Status",
                            com.avsp.pro.core.model.AspectRatio.RATIO_16_9 to "16:9 · YouTube video",
                            com.avsp.pro.core.model.AspectRatio.RATIO_4_5 to "4:5 · Instagram / Facebook feed",
                            com.avsp.pro.core.model.AspectRatio.RATIO_1_1 to "1:1 · Square feed")
                        var pickL by remember { mutableStateOf(setOf(viewModel.languageCode)) }
                        var pickA by remember { mutableStateOf(setOf(viewModel.aspect)) }
                        val combos = langs.filter { it.code in pickL }.flatMap { l -> shapes.map { it.first }.filter { it in pickA }.map { a -> l to a } }
                            .filterNot { (l, a) -> l.code == viewModel.languageCode && a == viewModel.aspect }
                        androidx.compose.material3.AlertDialog(
                            onDismissRequest = { versionsOpen = false },
                            title = { Text("Make other versions") },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text("Languages", style = MaterialTheme.typography.labelLarge)
                                    androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        langs.forEach { l -> androidx.compose.material3.FilterChip(selected = l.code in pickL,
                                            onClick = { pickL = if (l.code in pickL) pickL - l.code else pickL + l.code }, label = { Text(l.displayName) }) }
                                    }
                                    Text("Sizes - pick by where it will be posted", style = MaterialTheme.typography.labelLarge)
                                    shapes.forEach { (a, label) ->
                                        androidx.compose.material3.FilterChip(selected = a in pickA, onClick = { pickA = if (a in pickA) pickA - a else pickA + a }, label = { Text(label) })
                                    }
                                    Text("${combos.size} new video(s) will be made one after another (about a minute each). The script is written fresh in each language; your own photos and clips are used again.",
                                        style = MaterialTheme.typography.bodySmall)
                                }
                            },
                            confirmButton = { Button(enabled = combos.isNotEmpty(), onClick = { versionsOpen = false; viewModel.makeVersions(projectId, seconds, combos) }) { Text("Make ${combos.size}") } },
                            dismissButton = { androidx.compose.material3.TextButton(onClick = { versionsOpen = false }) { Text("Cancel") } }
                        )
                    }
                    if (changeOpen) {
                        var text by remember { mutableStateOf("") }
                        androidx.compose.material3.AlertDialog(
                            onDismissRequest = { changeOpen = false },
                            title = { Text("What should be different?") },
                            text = {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    androidx.compose.material3.OutlinedTextField(value = text, onValueChange = { text = it }, minLines = 3, modifier = Modifier.fillMaxWidth(),
                                        label = { Text("e.g. shorter, more festive, start with the idol, in Bengali") })
                                    androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        listOf("Shorter", "More exciting hook", "Simpler words", "More facts", "Funny tone", "Emotional tone").forEach { s ->
                                            androidx.compose.material3.AssistChip(onClick = { text = (text + (if (text.isBlank()) "" else ", ") + s.lowercase()) }, label = { Text(s) })
                                        }
                                    }
                                }
                            },
                            confirmButton = { Button(enabled = text.isNotBlank(), onClick = { changeOpen = false; viewModel.remakeWith(projectId, seconds, text) }) { Text("Remake with this") } },
                            dismissButton = { androidx.compose.material3.TextButton(onClick = { changeOpen = false }) { Text("Cancel") } }
                        )
                    }
                }
                is AutoProduceState.Failed -> {
                    Text("Could not finish: ${a.message}", color = MaterialTheme.colorScheme.error)
                    Text(
                        "Work done so far is saved. Retry, or continue step by step below.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Button(
                        onClick = { viewModel.autoProduce(projectId, seconds) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Retry") }
                }
                AutoProduceState.Idle -> {
                    Button(
                        onClick = { viewModel.autoProduce(projectId, seconds) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Make Video Now") }
                }
            }
        }
    }
}

/** P10: the same story as a text blog (article) or a photo blog (swipe carousel). */
@Composable
private fun BlogCard(projectId: String, viewModel: com.avsp.pro.ui.viewmodel.ProjectDetailViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val st by viewModel.blog.collectAsState()
    val working = st is com.avsp.pro.ui.viewmodel.ProjectDetailViewModel.BlogState.Working
    androidx.compose.material3.Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Blog from this story", style = MaterialTheme.typography.titleMedium)
            Text(
                "Text blog: an article with pictures (HTML + text to paste). Photo blog: swipe slides for Instagram / Facebook.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                androidx.compose.material3.Button(onClick = { viewModel.makeBlog(projectId, photo = false) }, enabled = !working, modifier = Modifier.weight(1f)) { Text("Text blog") }
                androidx.compose.material3.Button(onClick = { viewModel.makeBlog(projectId, photo = true) }, enabled = !working, modifier = Modifier.weight(1f)) { Text("Photo blog") }
            }
            when (val b = st) {
                is com.avsp.pro.ui.viewmodel.ProjectDetailViewModel.BlogState.Working -> {
                    androidx.compose.material3.LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(b.label, style = MaterialTheme.typography.bodySmall)
                }
                is com.avsp.pro.ui.viewmodel.ProjectDetailViewModel.BlogState.TextDone -> {
                    Text("Text blog ready: ${b.blog.title}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    Text("Saved in Download/AVSP/Blogs", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        androidx.compose.material3.OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                            val open = android.content.Intent(android.content.Intent.ACTION_VIEW).setDataAndType(b.blog.uri, "text/html")
                                .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            runCatching { context.startActivity(open) }.onFailure {
                                android.widget.Toast.makeText(context, "No app to open HTML - use Share", android.widget.Toast.LENGTH_LONG).show()
                            }
                        }) { Text("Open") }
                        androidx.compose.material3.OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                            val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                            cm?.setPrimaryClip(android.content.ClipData.newPlainText("AVSP blog", b.blog.markdown))
                            android.widget.Toast.makeText(context, "Blog text copied - paste it in Blogger / WordPress / Medium", android.widget.Toast.LENGTH_LONG).show()
                        }) { Text("Copy text") }
                        androidx.compose.material3.OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                            val send = android.content.Intent(android.content.Intent.ACTION_SEND).setType("text/html")
                                .putExtra(android.content.Intent.EXTRA_STREAM, b.blog.uri)
                                .putExtra(android.content.Intent.EXTRA_SUBJECT, b.blog.title)
                                .putExtra(android.content.Intent.EXTRA_TEXT, b.blog.markdown)
                                .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            runCatching { context.startActivity(android.content.Intent.createChooser(send, "Share blog")) }
                        }) { Text("Share") }
                    }
                    // P29: post the blog to the channels at a chosen time.
                    var postIt by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
                    androidx.compose.material3.Button(onClick = { postIt = true }, modifier = Modifier.fillMaxWidth()) { Text("Post / schedule to channels") }
                    if (postIt) com.avsp.pro.ui.screens.publish.PostBlogDialog(project = b.blog.title, title = b.blog.title,
                        text = b.blog.markdown.replace(Regex("(?m)^#+\\s*"), "").replace("**", "").take(3500), hashtags = emptyList(), images = emptyList(),
                        language = viewModel.languageCode, onDismiss = { postIt = false })
                }
                is com.avsp.pro.ui.viewmodel.ProjectDetailViewModel.BlogState.PhotoDone -> {
                    Text("Photo blog ready: ${b.blog.slides.size} slides", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    Text("Saved in Pictures/AVSP/Blog", style = MaterialTheme.typography.bodySmall)
                    androidx.compose.material3.OutlinedButton(modifier = Modifier.fillMaxWidth(), onClick = {
                        val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                        cm?.setPrimaryClip(android.content.ClipData.newPlainText("AVSP caption", b.blog.caption))
                        val send = android.content.Intent(android.content.Intent.ACTION_SEND_MULTIPLE).setType("image/jpeg")
                            .putParcelableArrayListExtra(android.content.Intent.EXTRA_STREAM, ArrayList(b.blog.slides))
                            .putExtra(android.content.Intent.EXTRA_TEXT, b.blog.caption)
                            .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        runCatching { context.startActivity(android.content.Intent.createChooser(send, "Post photo blog")) }
                        android.widget.Toast.makeText(context, "Caption copied - paste it in the app.", android.widget.Toast.LENGTH_LONG).show()
                    }) { Text("Share slides (caption copied)") }
                    // P29: or straight to the channels, scheduled, with a Telegram poll.
                    var postIt by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
                    androidx.compose.material3.Button(onClick = { postIt = true }, modifier = Modifier.fillMaxWidth()) { Text("Post / schedule to channels") }
                    if (postIt) com.avsp.pro.ui.screens.publish.PostBlogDialog(project = b.blog.title, title = b.blog.title, text = b.blog.caption,
                        hashtags = emptyList(), images = b.blog.slides, language = viewModel.languageCode, onDismiss = { postIt = false })
                }
                is com.avsp.pro.ui.viewmodel.ProjectDetailViewModel.BlogState.Failed ->
                    Text(b.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                else -> {}
            }
        }
    }
}

/** P12: one tap - the user's own video, cleaned: dead air, long pauses, fillers and retakes cut; captions added. */
/** P19: the video is already edited - only SEO text, thumbnail and posting. */
@Composable
private fun ReadyVideoCard(projectId: String, viewModel: com.avsp.pro.ui.viewmodel.ProjectDetailViewModel) {
    val st by viewModel.ready.collectAsState()
    androidx.compose.material3.Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("My video is ready - just post it", style = MaterialTheme.typography.titleMedium)
            Text(
                "Your video is not changed. AVSP writes an SEO title, description, tags and hashtags from what is said, makes a thumbnail and gets it ready to post.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            when (val r = st) {
                is com.avsp.pro.ui.viewmodel.ProjectDetailViewModel.ReadyState.Working -> {
                    androidx.compose.material3.LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(r.label, style = MaterialTheme.typography.bodySmall)
                }
                is com.avsp.pro.ui.viewmodel.ProjectDetailViewModel.ReadyState.Done -> {
                    Text(if (r.outcome.byAi) "SEO written with Gemini" else "SEO written on the phone (add a Gemini key for better titles)",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    PublishKitSection(uri = r.outcome.uri, title = r.outcome.kit.title, kit = r.outcome.kit, thumbnail = r.outcome.thumbnail)
                    com.avsp.pro.ui.screens.publish.SendForApprovalRow(videoUri = r.outcome.uri, project = r.outcome.kit.title, title = r.outcome.kit.title, kit = r.outcome.kit, thumbnail = r.outcome.thumbnail, projectId = projectId)
                    androidx.compose.material3.OutlinedButton(onClick = { viewModel.readyToPost(projectId) }, modifier = Modifier.fillMaxWidth()) { Text("Write it again") }
                }
                is com.avsp.pro.ui.viewmodel.ProjectDetailViewModel.ReadyState.Failed -> {
                    Text(r.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    androidx.compose.material3.Button(onClick = { viewModel.readyToPost(projectId) }) { Text("Try again") }
                }
                else -> androidx.compose.material3.Button(onClick = { viewModel.readyToPost(projectId) }, modifier = Modifier.fillMaxWidth()) { Text("Get it ready to post (SEO + thumbnail)") }
            }
        }
    }
}

@Composable
private fun SmartEditCard(projectId: String, viewModel: com.avsp.pro.ui.viewmodel.ProjectDetailViewModel) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val st by viewModel.edit.collectAsState()
    // P18: full clean edit, or a short made from the best part.
    var length by remember { mutableStateOf<Long?>(null) }
    androidx.compose.material3.Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Smart edit my video", style = MaterialTheme.typography.titleMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf<Pair<String, Long?>>("Full" to null, "60 s short" to 60_000L, "30 s short" to 30_000L).forEach { (label, ms) ->
                    androidx.compose.material3.FilterChip(selected = length == ms, onClick = { length = ms }, label = { Text(label) })
                }
            }
            Text(
                "Keeps your voice. Cuts dead air, long pauses, \"umm\" and repeated takes, skips dark or blurry parts, adds captions.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            when (val e = st) {
                is com.avsp.pro.ui.viewmodel.ProjectDetailViewModel.EditState.Working -> {
                    androidx.compose.material3.LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    Text(e.label, style = MaterialTheme.typography.bodySmall)
                }
                is com.avsp.pro.ui.viewmodel.ProjectDetailViewModel.EditState.Done -> {
                    val o = e.outcome
                    Text(
                        "Edited video ready: ${(o.originalMs + 500) / 1000} s → ${(o.editedMs + 500) / 1000} s (${o.cuts} cuts)",
                        color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium
                    )
                    o.note?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                    o.thumbnail?.let { ThumbnailRow(it) }
                    if (o.transcript.isNotBlank()) Text("Heard: " + o.transcript.take(220) + if (o.transcript.length > 220) "…" else "", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        androidx.compose.material3.OutlinedButton(modifier = Modifier.weight(1f), onClick = {
                            runCatching {
                                context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW)
                                    .setDataAndType(android.net.Uri.parse(o.uri), "video/mp4")
                                    .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION))
                            }
                        }) { Text("Play") }
                        androidx.compose.material3.Button(modifier = Modifier.weight(1f), onClick = { viewModel.smartEdit(projectId, length) }) { Text("Edit again") }
                    }
                    androidx.compose.material3.Button(onClick = { viewModel.readyToPost(projectId, o.uri) }, modifier = Modifier.fillMaxWidth()) { Text("Get this edit ready to post (SEO + thumbnail)") }
                    Text("The SEO text appears in the card above.", style = MaterialTheme.typography.bodySmall)
                }
                is com.avsp.pro.ui.viewmodel.ProjectDetailViewModel.EditState.Failed -> {
                    Text(e.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    androidx.compose.material3.Button(onClick = { viewModel.smartEdit(projectId, length) }) { Text("Try again") }
                }
                else -> androidx.compose.material3.Button(onClick = { viewModel.smartEdit(projectId, length) }, modifier = Modifier.fillMaxWidth()) { Text(if (length == null) "Smart edit my video" else "Make ${length!! / 1000} s short") }
            }
        }
    }
}

/** P12: the thumbnail (best moment + title) with Share. */
@Composable
internal fun ThumbnailRow(thumbnail: String) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val bmp by androidx.compose.runtime.produceState<android.graphics.Bitmap?>(null, thumbnail) {
        value = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            runCatching {
                context.contentResolver.openInputStream(android.net.Uri.parse(thumbnail))?.use {
                    android.graphics.BitmapFactory.decodeStream(it, null, android.graphics.BitmapFactory.Options().apply { inSampleSize = 4 })
                }
            }.getOrNull()
        }
    }
    Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        bmp?.let {
            androidx.compose.foundation.Image(
                bitmap = it.asImageBitmap(), contentDescription = "Thumbnail",
                modifier = Modifier.height(150.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(10.dp))
            )
        }
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Thumbnail", style = MaterialTheme.typography.titleSmall)
            Text("Best moment + title. Saved in Pictures/AVSP/Thumbnails.", style = MaterialTheme.typography.bodySmall)
            androidx.compose.material3.OutlinedButton(onClick = {
                val send = android.content.Intent(android.content.Intent.ACTION_SEND).setType("image/jpeg")
                    .putExtra(android.content.Intent.EXTRA_STREAM, android.net.Uri.parse(thumbnail))
                    .addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                runCatching { context.startActivity(android.content.Intent.createChooser(send, "Share thumbnail")) }
            }) { Text("Share thumbnail") }
        }
    }
}
