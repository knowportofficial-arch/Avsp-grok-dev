﻿package com.avsp.pro.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avsp.pro.core.dailypost.DailyPostProviderFactory
import com.avsp.pro.core.dailypost.DailyPostRepository
import com.avsp.pro.ui.screens.dailypost.DailyPostItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class DailyPostUiState(
    val loading: Boolean = false,
    val posts: List<DailyPostItem> = emptyList(),
    val error: String? = null,
    val providerConfigured: Boolean = false
)

class DailyPostViewModel : ViewModel() {

    private val repository =
        DailyPostRepository(DailyPostProviderFactory.create())

    private val _state = MutableStateFlow(DailyPostUiState())
    val state: StateFlow<DailyPostUiState> = _state.asStateFlow()

    init {
        refresh()
    }

    /** P11: weather city (Open-Meteo geocoding, no key). */
    private val _city = MutableStateFlow(com.avsp.pro.core.dailypost.DailySettings.city().name)
    val city: StateFlow<String> = _city.asStateFlow()
    private val _cityMessage = MutableStateFlow<String?>(null)
    val cityMessage: StateFlow<String?> = _cityMessage.asStateFlow()

    fun changeCity(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val found = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                runCatching {
                    val c = java.net.URI(com.avsp.pro.core.dailypost.DailyTopics.geocodeUrl(name)).toURL().openConnection() as java.net.HttpURLConnection
                    try {
                        c.connectTimeout = 8000; c.readTimeout = 10000
                        c.setRequestProperty("User-Agent", "AVSP/1.0 (Daily Post)")
                        com.avsp.pro.core.dailypost.DailyTopics.parseGeocode(c.inputStream.bufferedReader().use { it.readText() })
                    } finally { c.disconnect() }
                }.getOrNull()
            }
            if (found == null) {
                _cityMessage.value = "City not found - check the spelling or your internet."
            } else {
                com.avsp.pro.core.dailypost.DailySettings.setCity(found)
                _city.value = found.name
                _cityMessage.value = "Weather city set to ${found.name}."
                refresh()
            }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            _state.value = _state.value.copy(
                loading = true,
                error = null
            )

            runCatching {
                repository.getPosts()
            }.onSuccess { posts ->
                _state.value = DailyPostUiState(
                    loading = false,
                    posts = posts,
                    error = null,
                    providerConfigured = posts.isNotEmpty()
                )
            }.onFailure { error ->
                _state.value = DailyPostUiState(
                    loading = false,
                    posts = emptyList(),
                    error = error.message ?: "Daily Post provider error",
                    providerConfigured = false
                )
            }
        }
    }
}
