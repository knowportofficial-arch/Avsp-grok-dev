﻿package com.avsp.pro.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.avsp.pro.di.AppContainer

class ViewModelFactory(
    private val container: AppContainer
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(HomeViewModel::class.java) ->
                HomeViewModel(
                    projectRepository = container.projectRepository,
                    moduleStatusRepository = container.moduleStatusRepository,
                    logger = container.logger,
                    sourceReader = container.sourceReader,
                    storage = container.storage,
                    appContext = container.appContextPublic
                ) as T
            modelClass.isAssignableFrom(ProjectsViewModel::class.java) ->
                ProjectsViewModel(
                    projectRepository = container.projectRepository,
                    settingsRepository = container.settingsRepository,
                    logger = container.logger
                ) as T
            modelClass.isAssignableFrom(ProjectDetailViewModel::class.java) ->
                ProjectDetailViewModel(
                    projectRepository = container.projectRepository,
                    moduleStatusRepository = container.moduleStatusRepository,
                    logger = container.logger,
                    bundledMediaSeeder = container.bundledMediaSeeder,
                    autoProducer = container.autoProducer(),
                    blogExporter = container.blogExporter(),
                    smartEdit = container.smartEdit(),
                    readyVideo = container.readyVideo()
                ) as T
            modelClass.isAssignableFrom(ManualViewModel::class.java) ->
                ManualViewModel(
                    projectRepository = container.projectRepository,
                    scriptRepository = container.scriptRepository,
                    storage = container.storage,
                    logger = container.logger,
                    autoProducer = container.autoProducer(),
                    appContext = container.appContextPublic,
                    geminiKeys = { com.avsp.pro.settings.ApiKeyRing.keys(container.secureConfigStore, com.avsp.pro.settings.SecureConfigKeys.AI_API) }
                ) as T
            modelClass.isAssignableFrom(MediaViewModel::class.java) ->
                MediaViewModel(
                    projectRepository = container.projectRepository,
                    logger = container.logger,
                    bundledMediaSeeder = container.bundledMediaSeeder,
                    m7MediaRepository = container.m7Services.mediaRepository
                ) as T
            modelClass.isAssignableFrom(ModulesViewModel::class.java) ->
                ModulesViewModel(
                    moduleStatusRepository = container.moduleStatusRepository,
                    logger = container.logger
                ) as T
            modelClass.isAssignableFrom(SettingsViewModel::class.java) ->
                SettingsViewModel(
                    settingsRepository = container.settingsRepository,
                    logger = container.logger,
                    secureConfigStore = container.secureConfigStore
                ) as T
            modelClass.isAssignableFrom(LogsViewModel::class.java) ->
                LogsViewModel(
                    logRepository = container.logRepository,
                    logger = container.logger
                ) as T
            modelClass.isAssignableFrom(com.avsp.pro.script.ui.ScriptAiViewModel::class.java) ->
                com.avsp.pro.script.ui.ScriptAiViewModel(
                    scriptRepository = container.scriptRepository,
                    projectRepository = container.projectRepository,
                    settingsRepository = container.settingsRepository,
                    logger = container.logger
                ) as T
            modelClass.isAssignableFrom(com.avsp.pro.audio.ui.AudioTtsViewModel::class.java) ->
                com.avsp.pro.audio.ui.AudioTtsViewModel(
                    audioRepository = container.audioRepository,
                    logger = container.logger
                ) as T
            modelClass.isAssignableFrom(com.avsp.pro.video.ui.VideoViewModel::class.java) ->
                com.avsp.pro.video.ui.VideoViewModel(container.videoRepository) as T
            // P20.0.1: the AI camera screen (project -> Camera) crashed on open: its ViewModel was missing here.
            modelClass.isAssignableFrom(com.avsp.pro.m7.capture.camera.CameraViewModel::class.java) ->
                com.avsp.pro.m7.capture.camera.CameraViewModel(
                    mediaRepository = container.m7Services.mediaRepository,
                    projectRepository = container.m7Services.projectRepository,
                    onKept = { projectId, uri, video ->
                        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                            val ext = if (video) "mp4" else "jpg"
                            val now = System.currentTimeMillis()
                            val relative = "media/camera/AVSP_cam_$now.$ext"
                            var size = 0L
                            container.storage.openOutput(com.avsp.pro.storage.StorageArea.PROJECT_DATA, relative, projectId).use { out ->
                                container.appContextPublic.contentResolver.openInputStream(android.net.Uri.parse(uri))?.use { size = it.copyTo(out) }
                            }
                            if (size > 0) container.projectRepository.addMediaAsset(
                                com.avsp.pro.core.contracts.MediaAsset(
                                    assetId = "camera_$now",
                                    projectId = projectId,
                                    fileName = relative.substringAfterLast('/'),
                                    relativePath = relative,
                                    mimeType = if (video) "video/mp4" else "image/jpeg",
                                    sizeBytes = size,
                                    createdAt = now,
                                    tags = listOf("own", "camera")
                                )
                            )
                        }
                    }
                ) as T
            else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
        }
    }
}

