package com.avsp.pro.core.pipeline

import com.avsp.pro.screen.capture.ScreenSensitiveSanitizer

/**
 * P18.1: text read from a photo / PDF / video frame (OCR) before it becomes a
 * script. Two problems seen on the phone:
 *  - a hand-written diagram gave garbage ("CPAN OLT riANPORT coMPUTER|) static fP:")
 *    that was read aloud word for word;
 *  - it also read out private details (user id, IP addresses, gateway).
 * So: lines that are mostly not real words are dropped, lines with private data
 * are dropped (and counted), and the caller learns how readable the text was.
 */
object OcrCleaner {
    data class Result(val text: String, val readable: Float, val privateLinesDropped: Int, val noiseLinesDropped: Int)

    private val PRIVATE_WORDS = Regex(
        "(?i)\\b(pass(word)?|pwd|passcode|user ?id|userid|usevid|login|username|otp|pin|cvv|ip|gateway|subnet|vpn|mac|ssid|wifi password|account|a/c|ifsc|aadhaar|pan)\\b"
    )
    private val IP_LIKE = Regex("""\b\d{1,3}(\.\d{1,3}){2,3}\b""")

    /** A token that looks like a real word (letters, a vowel, not random caps). */
    internal fun isWord(t: String): Boolean {
        val w = t.trim('.', ',', ':', ';', '!', '?', '"', '\'', '(', ')', '-', '|')
        if (w.length < 2) return w.length == 1 && w[0].isLetter() && w.lowercase() in setOf("a", "i")
        if (w.any { it.code >= 0x0900 }) return w.all { it.isLetter() || it.isWhitespace() || Character.getType(it) == Character.NON_SPACING_MARK.toInt() || Character.getType(it) == Character.COMBINING_SPACING_MARK.toInt() }
        if (!w.all { it.isLetter() || it == '\'' }) return false
        if (w.none { it.lowercaseChar() in "aeiouy" }) return false
        // "coMPUTER", "riANPORT": mixed case inside a word is OCR noise; "IIT" / "Kolkata" are fine.
        val upperInside = w.drop(1).count { it.isUpperCase() }
        return upperInside == 0 || (upperInside == w.length - 1 && w[0].isUpperCase())
    }

    fun lineReadable(line: String): Float {
        val tokens = line.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (tokens.isEmpty()) return 0f
        return tokens.count(::isWord).toFloat() / tokens.size
    }

    fun isPrivate(line: String): Boolean =
        PRIVATE_WORDS.containsMatchIn(line) || IP_LIKE.containsMatchIn(line) ||
            ScreenSensitiveSanitizer.scan(line).any { it.type != com.avsp.pro.screen.capture.SensitiveDataType.URL && it.type != com.avsp.pro.screen.capture.SensitiveDataType.NAME }

    fun clean(ocr: String): Result {
        val lines = ocr.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return Result("", 0f, 0, 0)
        var priv = 0; var noise = 0
        val kept = mutableListOf<String>()
        var words = 0; var tokens = 0
        for (l in lines) {
            val toks = l.split(Regex("\\s+")).filter { it.isNotBlank() }
            tokens += toks.size; words += toks.count(::isWord)
            when {
                isPrivate(l) -> priv++
                lineReadable(l) < 0.6f || toks.count(::isWord) == 0 -> noise++
                else -> kept += l
            }
        }
        return Result(kept.joinToString("\n"), if (tokens == 0) 0f else words.toFloat() / tokens, priv, noise)
    }
}
