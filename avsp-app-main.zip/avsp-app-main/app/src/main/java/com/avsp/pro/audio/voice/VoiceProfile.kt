﻿package com.avsp.pro.audio.voice

/**
 * Provider-neutral description of a TTS voice.
 *
 * This is deliberately independent of Android's TextToSpeech.Voice so the
 * selection layer can be tested off-device and can later host cloud engines.
 */
data class VoiceProfile(
    val id: String,
    val providerId: String,
    val displayName: String,
    val languageCodes: Set<String>,
    val gender: VoiceGender = VoiceGender.UNKNOWN,
    val styles: Set<VoiceStyle> = emptySet(),
    val qualityScore: Float = 0.5f,
    val available: Boolean = true,
    val networkRequired: Boolean = false,
    val minSpeechRate: Float = 0.5f,
    val maxSpeechRate: Float = 2.0f
) {
    fun supportsLanguage(language: String): Boolean =
        languageCodes.any { it.equals(language.trim(), ignoreCase = true) }

    fun supportsRate(rate: Float): Boolean = rate in minSpeechRate..maxSpeechRate
}

enum class VoiceGender {
    MALE,
    FEMALE,
    NEUTRAL,
    UNKNOWN
}

enum class VoiceStyle {
    NEWS,
    DEVOTIONAL,
    ENERGETIC,
    EDUCATIONAL,
    CONVERSATIONAL,
    STORYTELLING,
    FORMAL,
    CALM
}
