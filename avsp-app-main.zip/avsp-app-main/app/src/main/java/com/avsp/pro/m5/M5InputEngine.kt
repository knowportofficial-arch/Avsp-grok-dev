﻿package com.avsp.pro.m5

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import java.util.Locale
import java.util.regex.Pattern

data class M5InputResult(
    val source: String,
    val reference: String,
    val title: String = "",
    val durationSeconds: Long = 0L,
    val text: String = "",
    val numbers: List<Double> = emptyList(),
    val confidence: Double = 0.0,
    val processedAt: Long = System.currentTimeMillis()
)

object M5InputEngine {

    private val youtubePattern = Pattern.compile(
        "(?:youtu\\.be/|youtube\\.com/(?:watch\\?v=|shorts/|embed/))([A-Za-z0-9_-]{6,})"
    )

    private val numberPattern = Pattern.compile(
        "[-+]?\\d+(?:[.,]\\d+)?"
    )

    fun parseYouTubeUrl(url: String): String? {
        val matcher = youtubePattern.matcher(url.trim())
        return if (matcher.find()) matcher.group(1) else null
    }

    fun parseUnifiedYouTubeUrl(url: String): String? {
        return parseYouTubeUrl(url)
    }

    fun isUrl(value: String): Boolean {
        val clean = value.trim()
        return clean.startsWith("http://", ignoreCase = true) ||
            clean.startsWith("https://", ignoreCase = true)
    }

    fun classifyMimeType(mimeType: String?): UnifiedInputKind {
        val mime = mimeType?.lowercase(Locale.ROOT).orEmpty()

        return when {
            mime == "application/pdf" ||
                mime.startsWith("text/") ||
                mime.contains("document") ||
                mime.contains("word") ||
                mime.contains("sheet") ||
                mime.contains("presentation") ->
                UnifiedInputKind.DOCUMENT

            mime.startsWith("image/") ->
                UnifiedInputKind.IMAGE

            mime.startsWith("video/") ->
                UnifiedInputKind.VIDEO

            mime.startsWith("audio/") ->
                UnifiedInputKind.AUDIO

            else ->
                UnifiedInputKind.UNKNOWN
        }
    }

    fun classifyUnifiedMimeType(mimeType: String?): UnifiedInputKind {
        return classifyMimeType(mimeType)
    }

    fun analyzeText(
        source: String,
        reference: String,
        text: String
    ): M5InputResult {

        val matcher = numberPattern.matcher(text)

        val numbers = buildList {
            while (matcher.find()) {
                matcher.group()
                    .replace(",", "")
                    .toDoubleOrNull()
                    ?.let(::add)
            }
        }.distinct()

        return M5InputResult(
            source = source,
            reference = reference,
            text = text.trim(),
            numbers = numbers,
            confidence = if (text.isBlank()) 0.0 else 0.9
        )
    }

    fun analyzeUnifiedText(text: String): UnifiedInputResult {

        val clean = text.trim()
        val youtubeId = parseYouTubeUrl(clean)

        val kind = when {
            youtubeId != null ->
                UnifiedInputKind.YOUTUBE

            isUrl(clean) ->
                UnifiedInputKind.URL

            clean.isNotBlank() ->
                UnifiedInputKind.TEXT

            else ->
                UnifiedInputKind.UNKNOWN
        }

        val base = analyzeText(
            source = kind.name.lowercase(Locale.ROOT),
            reference = clean,
            text = clean
        )

        val unifiedConfidence = when {
            kind == UnifiedInputKind.YOUTUBE -> 0.95
            kind == UnifiedInputKind.URL -> 0.90
            kind == UnifiedInputKind.TEXT -> base.confidence
            else -> 0.0
        }

        return UnifiedInputResult(
            kind = kind,
            reference = clean,
            title = if (kind == UnifiedInputKind.TEXT) {
                "Text input"
            } else {
                clean
            },
            text = base.text,
            numbers = base.numbers,
            confidence = unifiedConfidence,
            youtubeId = youtubeId
        )
    }

    fun analyzeLocalMedia(
        context: Context,
        uri: Uri,
        kindOverride: UnifiedInputKind? = null
    ): M5InputResult {

        val retriever = MediaMetadataRetriever()

        return try {
            retriever.setDataSource(context, uri)

            val duration =
                retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION
                )
                    ?.toLongOrNull()
                    ?.div(1000)
                    ?: 0L

            M5InputResult(
                source = "media",
                reference = uri.toString(),
                title = queryDisplayName(context, uri),
                durationSeconds = duration,
                confidence = if (duration > 0L) 0.8 else 0.4
            )
        } finally {
            retriever.release()
        }
    }

    fun analyzeLocalMediaUnified(
        context: Context,
        uri: Uri,
        kindOverride: UnifiedInputKind? = null
    ): UnifiedInputResult {

        val mime = context.contentResolver.getType(uri)

        val detected =
            kindOverride ?: classifyMimeType(mime)

        val title = queryDisplayName(context, uri)

        val duration =
            if (
                detected == UnifiedInputKind.VIDEO ||
                detected == UnifiedInputKind.AUDIO ||
                detected == UnifiedInputKind.SCREEN_RECORDING
            ) {

                val retriever = MediaMetadataRetriever()

                try {
                    retriever.setDataSource(context, uri)

                    retriever.extractMetadata(
                        MediaMetadataRetriever.METADATA_KEY_DURATION
                    )
                        ?.toLongOrNull()
                        ?.div(1000)
                        ?: 0L

                } finally {
                    retriever.release()
                }

            } else {
                0L
            }

        val confidence =
            when (detected) {
                UnifiedInputKind.IMAGE,
                UnifiedInputKind.VIDEO,
                UnifiedInputKind.AUDIO,
                UnifiedInputKind.DOCUMENT ->
                    0.85

                UnifiedInputKind.SCREEN_RECORDING ->
                    0.90

                else ->
                    0.40
            }

        val warnings =
            when (detected) {

                UnifiedInputKind.IMAGE ->
                    listOf(
                        "Image selected. OCR/vision analysis can run downstream."
                    )

                UnifiedInputKind.DOCUMENT ->
                    listOf(
                        "Document selected. Text extraction can run downstream."
                    )

                UnifiedInputKind.VIDEO ->
                    listOf(
                        "Video selected. Scene/OCR/audio analysis can run downstream."
                    )

                UnifiedInputKind.AUDIO ->
                    listOf(
                        "Audio selected. Speech-to-text analysis can run downstream."
                    )

                UnifiedInputKind.SCREEN_RECORDING ->
                    listOf(
                        "Screen recording selected. Screen intelligence/OCR/audio analysis can run downstream."
                    )

                else ->
                    emptyList()
            }

        return UnifiedInputResult(
            kind = detected,
            reference = uri.toString(),
            title = title,
            durationSeconds = duration,
            confidence = confidence,
            mimeType = mime,
            warnings = warnings
        )
    }

    fun analyzeUnifiedLocalMedia(
        context: Context,
        uri: Uri,
        kindOverride: UnifiedInputKind? = null
    ): UnifiedInputResult {
        return analyzeLocalMediaUnified(
            context = context,
            uri = uri,
            kindOverride = kindOverride
        )
    }

    private fun queryDisplayName(
        context: Context,
        uri: Uri
    ): String {

        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->

            if (cursor.moveToFirst()) {

                val index =
                    cursor.getColumnIndex(
                        OpenableColumns.DISPLAY_NAME
                    )

                if (index >= 0) {
                    return cursor.getString(index)
                }
            }
        }

        return uri.lastPathSegment ?: "Imported media"
    }
}


