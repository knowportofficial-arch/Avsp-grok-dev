package com.avsp.pro.ui.screens.home

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** P23.2: "How to make a video" - the whole path in plain steps, folded until tapped. */
object HowTo {
    data class Part(val title: String, val steps: List<String>)

    val parts = listOf(
        Part("Fast: one tap", listOf(
            "Home → pick a news story, or paste a topic / link / photos.",
            "Choose the length (Auto fits the content) and tap Make video.",
            "AVSP writes the script, finds pictures, records the voice, adds captions, music and your Knowport logo.",
            "Watch it. Not right? Use Step by step (Manual) below."
        )),
        Part("Step by step (best quality)", listOf(
            "Open the project → Manual: edit script & choose pictures.",
            "Edit the script: every line should say one thing you can SEE.",
            "Show a picture for every scene → tap Another on any picture that doesn't match, or change its search words.",
            "Or use your own: Phone (gallery), Camera, or Plan & shoot (the guided camera films each scene with you).",
            "🎙 Say the intro / outro in your own voice: Record → Stop → Use my voice (or keep only the words for the AI voice).",
            "Make video."
        )),
        Part("Recipe videos", listOf(
            "Write the dish name with 'recipe', e.g. 'Chicken curry recipe'.",
            "The script gets one scene per step with amounts and minutes; captions look like '300g Onions – sliced'.",
            "For a real cooking look, film each step with Plan & shoot - stock pictures are only a backup."
        )),
        Part("Post it", listOf(
            "On the finished video: Send for approval (or Videos tab → Post…).",
            "Title, description, hashtags, thumbnail, category and a Telegram poll are made automatically.",
            "Choose the time (Best time = auto) → it waits in your Google Sheet → tick Approve → it posts.",
            "Videos tab shows Posted / Waiting with views and likes. Delete moves a test video to the phone's Trash."
        )),
        Part("Blogs", listOf(
            "Daily Post card → Text blog or Photo blog, or a project page → Blog from this story.",
            "Saved in Download/AVSP/Blogs; Copy text pastes into Blogger / WordPress / Medium."
        )),
        Part("Good to know", listOf(
            "Videos are saved in your phone gallery (Movies/AVSP/Exports) - uninstalling AVSP does not delete them.",
            "API keys and your logo are stored only on this phone (not in the app). Uninstall removes them - add them again in Settings.",
            "Settings → Self-check tests the phone and keys and gives a report to copy."
        ))
    )
}

@Composable
fun HowToGuide(modifier: Modifier = Modifier) {
    var open by rememberSaveable { mutableStateOf(false) }
    Card(modifier = modifier.fillMaxWidth()) {
        Column(modifier = Modifier.clickable { open = !open }.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text((if (open) "▾ " else "▸ ") + "How to make a video", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            if (!open) Text("One tap, step by step, own voice, posting - tap to read.", style = MaterialTheme.typography.bodySmall)
            else HowTo.parts.forEach { part ->
                Text(part.title, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 6.dp))
                part.steps.forEachIndexed { i, s -> Text("${i + 1}. $s", style = MaterialTheme.typography.bodyMedium) }
            }
        }
    }
}
