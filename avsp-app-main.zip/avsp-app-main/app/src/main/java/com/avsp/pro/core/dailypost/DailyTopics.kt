package com.avsp.pro.core.dailypost

import org.json.JSONObject
import java.time.LocalDate
import kotlin.math.roundToInt

/**
 * P11 DAILY TOPICS (no API keys): text builders and parsers for the daily
 * categories beyond news. Pure Kotlin + org.json, unit-tested.
 *
 *  - Weather: Open-Meteo forecast (api.open-meteo.com, free, no key)
 *  - Rashifal: daily horoscope per sign, made on the phone, clearly "for entertainment"
 *  - Jokes: JokeAPI safe-mode (v2.jokeapi.dev) + a small built-in clean set (EN / HI / BN)
 *  - Trending: Google Trends India daily RSS
 *  - Today's importance: Wikipedia "On this day" holidays & observances
 */
object DailyTopics {

    // ------------------------------------------------------------------ weather

    data class City(val name: String, val lat: Double, val lon: Double)

    val DEFAULT_CITY = City("Kharagpur", 22.3460, 87.2320)

    fun forecastUrl(c: City): String =
        "https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}" +
            "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
            "&timezone=Asia%2FKolkata&forecast_days=3"

    fun geocodeUrl(name: String): String =
        "https://geocoding-api.open-meteo.com/v1/search?count=1&language=en&format=json&name=" + java.net.URLEncoder.encode(name.trim(), "UTF-8")

    fun parseGeocode(json: String): City? {
        val r = JSONObject(json).optJSONArray("results")?.optJSONObject(0) ?: return null
        return City(r.optString("name"), r.optDouble("latitude"), r.optDouble("longitude"))
    }

    /** WMO weather code -> words. */
    fun weatherWords(code: Int): String = when (code) {
        0 -> "Clear sky"
        1 -> "Mostly clear"
        2 -> "Partly cloudy"
        3 -> "Cloudy"
        45, 48 -> "Foggy"
        51, 53, 55 -> "Drizzle"
        56, 57 -> "Freezing drizzle"
        61 -> "Light rain"
        63 -> "Rain"
        65 -> "Heavy rain"
        66, 67 -> "Freezing rain"
        71, 73, 75, 77 -> "Snow"
        80 -> "Light showers"
        81 -> "Showers"
        82 -> "Heavy showers"
        85, 86 -> "Snow showers"
        95 -> "Thunderstorm"
        96, 99 -> "Thunderstorm with hail"
        else -> "Mixed weather"
    }

    data class Weather(val title: String, val text: String)

    /** Spoken weather report (numbers written so voices read them naturally). */
    fun weatherReport(json: String, city: String): Weather {
        val o = JSONObject(json)
        val cur = o.optJSONObject("current")
        val d = o.getJSONObject("daily")
        val codes = d.getJSONArray("weather_code")
        val max = d.getJSONArray("temperature_2m_max")
        val min = d.getJSONArray("temperature_2m_min")
        val rain = d.optJSONArray("precipitation_probability_max")
        fun deg(v: Double) = "${v.roundToInt()} degrees"
        val today = weatherWords(codes.getInt(0))
        val parts = mutableListOf<String>()
        parts += "Weather today in $city: ${today.lowercase()}."
        if (cur != null) {
            parts += "Right now it is ${deg(cur.optDouble("temperature_2m"))} Celsius, with ${cur.optInt("relative_humidity_2m")} percent humidity and wind at ${cur.optDouble("wind_speed_10m").roundToInt()} kilometres per hour."
        }
        parts += "Today's high is ${deg(max.getDouble(0))} and the low is ${deg(min.getDouble(0))}."
        rain?.let { if (!it.isNull(0)) parts += rainLine(it.getInt(0), "today") }
        if (codes.length() > 1) {
            parts += "Tomorrow: ${weatherWords(codes.getInt(1)).lowercase()}, between ${min.getDouble(1).roundToInt()} and ${deg(max.getDouble(1))}." +
                (rain?.takeIf { !it.isNull(1) }?.let { " " + rainLine(it.getInt(1), "tomorrow") } ?: "")
        }
        if (codes.length() > 2) {
            parts += "Day after tomorrow: ${weatherWords(codes.getInt(2)).lowercase()}, up to ${deg(max.getDouble(2))}."
        }
        val tip = when {
            (rain?.optInt(0) ?: 0) >= 60 || codes.getInt(0) in 61..99 -> "Carry an umbrella if you go out."
            max.getDouble(0) >= 36 -> "Drink plenty of water and avoid the midday sun."
            max.getDouble(0) <= 12 -> "Keep warm clothes handy."
            else -> "Have a good day."
        }
        parts += tip
        return Weather("$city weather: $today, ${max.getDouble(0).roundToInt()}°C", parts.joinToString(" "))
    }

    private fun rainLine(p: Int, day: String) = when {
        p >= 70 -> "Rain is very likely $day, about $p percent chance."
        p >= 40 -> "There is a $p percent chance of rain $day."
        p >= 15 -> "Only a small chance of rain $day."
        else -> "No rain expected $day."
    }

    // ------------------------------------------------------------------ rashifal

    data class Sign(val en: String, val hi: String, val bn: String, val glyph: String)

    val SIGNS = listOf(
        Sign("Aries", "Mesh", "মেষ", "♈"), Sign("Taurus", "Vrishabh", "বৃষ", "♉"), Sign("Gemini", "Mithun", "মিথুন", "♊"),
        Sign("Cancer", "Kark", "কর্কট", "♋"), Sign("Leo", "Simha", "সিংহ", "♌"), Sign("Virgo", "Kanya", "কন্যা", "♍"),
        Sign("Libra", "Tula", "তুলা", "♎"), Sign("Scorpio", "Vrishchik", "বৃশ্চিক", "♏"), Sign("Sagittarius", "Dhanu", "ধনু", "♐"),
        Sign("Capricorn", "Makar", "মকর", "♑"), Sign("Aquarius", "Kumbh", "কুম্ভ", "♒"), Sign("Pisces", "Meen", "মীন", "♓")
    )

    private val MOOD = listOf(
        "a calm and steady day", "a day full of fresh energy", "a good day to start something new", "a day to slow down and plan",
        "a cheerful, social day", "a day when patience pays off", "a lucky day for small wins", "a thoughtful day, good for decisions"
    )
    private val WORK = listOf(
        "Work moves smoothly if you finish pending tasks first.", "A colleague or friend may bring useful news.",
        "Avoid big spending today; small savings add up.", "A new idea at work deserves a try.",
        "Money matters look stable; review your budget.", "Teamwork brings better results than working alone.",
        "Stay focused; a deadline goes better than you expect.", "Good time to learn a new skill."
    )
    private val LIFE = listOf(
        "Spend some time with family in the evening.", "Take a short walk and drink enough water.",
        "A kind word to someone close will mean a lot.", "Rest well tonight; your body needs it.",
        "Reconnect with an old friend.", "Keep calm in conversations; listen first.",
        "Light exercise will lift your mood.", "Enjoy a simple pleasure today."
    )
    private val COLORS = listOf("red", "orange", "yellow", "green", "blue", "white", "pink", "purple", "silver", "gold")

    private fun pick(list: List<String>, date: LocalDate, sign: Int, salt: Int): String {
        val h = (date.toEpochDay() * 31 + sign * 17 + salt * 7919).let { it xor (it ushr 7) }
        return list[(h.mod(list.size.toLong())).toInt()]
    }

    fun rashifal(date: LocalDate, sign: Int): String {
        val s = SIGNS[sign]
        val n = ((date.toEpochDay() + sign * 5) % 9 + 1).toInt()
        return "${s.en} (${s.hi}): ${pick(MOOD, date, sign, 1).replaceFirstChar { it.uppercase() }}. " +
            "${pick(WORK, date, sign, 2)} ${pick(LIFE, date, sign, 3)} " +
            "Lucky colour: ${pick(COLORS, date, sign, 4)}. Lucky number: $n."
    }

    fun rashifalAll(date: LocalDate): String =
        SIGNS.indices.joinToString(" ") { i ->
            val s = SIGNS[i]
            "${s.en}: ${pick(MOOD, date, i, 1)}, lucky colour ${pick(COLORS, date, i, 4)}."
        } + " Rashifal is just for fun and entertainment."

    // ------------------------------------------------------------------ jokes

    const val JOKE_URL = "https://v2.jokeapi.dev/joke/Programming,Misc,Pun?safe-mode&type=single&amount=8&lang=en"

    fun parseJokes(json: String): List<String> {
        val o = JSONObject(json)
        val arr = o.optJSONArray("jokes") ?: return listOfNotNull(o.optString("joke").takeIf { it.isNotBlank() })
        return (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.optString("joke")?.trim()?.takeIf { j -> j.length in 20..300 } }
    }

    /** Clean built-in jokes, used when offline and for Hindi / Bengali. */
    val BUILT_IN_JOKES = listOf(
        "Teacher: Why are you late? Student: Because of the sign. Teacher: What sign? Student: The one that says school ahead, go slow.",
        "My phone battery and I have one thing in common. We both need charging after a long day of doing nothing.",
        "Why did the computer go to the doctor? Because it caught a virus!",
        "Why don't eggs tell jokes? Because they would crack each other up.",
        "टीचर: पानी का फॉर्मूला बताओ। छात्र: H, I, J, K, L, M, N, O। टीचर: यह क्या है? छात्र: आपने ही तो कहा था, H to O!",
        "पापा: बेटा, रिजल्ट कैसा आया? बेटा: पापा, प्रिंसिपल का बेटा भी फेल हो गया। पापा: और तुम? बेटा: मैं कौन सा प्रिंसिपल का बेटा हूँ!",
        "শিক্ষক: বল তো, পৃথিবী গোল কেন? ছাত্র: স্যার, চৌকো হলে কোণায় কোণায় ধাক্কা লাগত!",
        "মা: পড়তে বসেছিস? ছেলে: হ্যাঁ মা, বইটা আমার দিকে তাকিয়ে আছে, আমিও বইয়ের দিকে তাকিয়ে আছি!"
    )

    // ------------------------------------------------------------------ trending (Google Trends RSS)

    const val TRENDS_URL = "https://trends.google.com/trending/rss?geo=IN"

    data class Trend(val title: String, val traffic: String, val newsTitle: String, val newsSnippet: String, val newsSource: String)

    fun parseTrends(xml: String): List<Trend> =
        Regex("""<item>(.*?)</item>""", RegexOption.DOT_MATCHES_ALL).findAll(xml).mapNotNull { m ->
            val item = m.groupValues[1]
            fun tag(name: String) = Regex("""<$name>(.*?)</$name>""", RegexOption.DOT_MATCHES_ALL).find(item)?.groupValues?.get(1)
                ?.replace(Regex("""<!\[CDATA\[(.*?)]]>""", RegexOption.DOT_MATCHES_ALL), "$1")
                ?.replace(Regex("<[^>]+>"), " ")
                ?.replace("&amp;", "&")?.replace("&quot;", "\"")?.replace("&#39;", "'")?.replace("&lt;", "<")?.replace("&gt;", ">")
                ?.replace(Regex("""\s+"""), " ")?.trim().orEmpty()
            val title = tag("title")
            if (title.isBlank()) null
            else Trend(title, tag("ht:approx_traffic"), tag("ht:news_item_title"), tag("ht:news_item_snippet"), tag("ht:news_item_source"))
        }.toList()

    // ------------------------------------------------------------------ today's importance (observances)

    fun holidaysUrl(date: LocalDate) =
        "https://en.wikipedia.org/api/rest_v1/feed/onthisday/holidays/%02d/%02d".format(date.monthValue, date.dayOfMonth)

    data class Observance(val name: String, val about: String)

    fun parseHolidays(json: String): List<Observance> {
        val arr = JSONObject(json).optJSONArray("holidays") ?: return emptyList()
        return (0 until arr.length()).mapNotNull { i ->
            val h = arr.optJSONObject(i) ?: return@mapNotNull null
            val name = h.optString("text").trim()
            val about = h.optJSONArray("pages")?.optJSONObject(0)?.optString("extract").orEmpty().trim()
            name.takeIf { it.isNotBlank() }?.let { Observance(it, about) }
        }
    }

    /** India-related and worldwide days first, then the rest. */
    fun rankObservances(list: List<Observance>): List<Observance> =
        list.sortedByDescending { o ->
            val t = (o.name + " " + o.about).lowercase()
            (if ("india" in t || "indian" in t) 3 else 0) + (if ("international" in t || "world" in t) 2 else 0) - (if ("christian feast" in t || "eastern orthodox" in t) 2 else 0)
        }
}
