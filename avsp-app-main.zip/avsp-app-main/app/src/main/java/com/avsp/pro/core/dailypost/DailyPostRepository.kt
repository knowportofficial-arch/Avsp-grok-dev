﻿package com.avsp.pro.core.dailypost

import com.avsp.pro.ui.screens.dailypost.DailyPostItem

class DailyPostRepository(
    private val provider: DailyPostProvider
) {
    suspend fun getPosts(): List<DailyPostItem> =
        provider.load()
            .filter {
                it.title.isNotBlank() &&
                it.date.isNotBlank() &&
                it.source.isNotBlank()
            }
            .distinctBy { it.id }
}
