package com.avsp.pro.ui.screens.pipeline

import androidx.compose.ui.unit.dp
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.avsp.pro.m5.M5InputEngine
import com.avsp.pro.m5.UnifiedInputKind
import com.avsp.pro.m5.UnifiedInputResult
import com.avsp.pro.m8.M8Timeline
import com.avsp.pro.m9.M9Job
import com.avsp.pro.m9.M9Platform
import com.avsp.pro.m9.M9StateMachine
import com.avsp.pro.m9.M9Status

@Composable
fun M5InputScreen(
    onBack: () -> Unit,
    initialSourceText: String = "",
    onOpenScript: (String) -> Unit = {},
    onOpenVideo: (String) -> Unit = {}
) {
    val context = LocalContext.current
    var sourceText by remember { mutableStateOf(initialSourceText) }
    var result by remember { mutableStateOf<UnifiedInputResult?>(null) }

    val mediaPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            runCatching {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            result = M5InputEngine.analyzeLocalMediaUnified(context, uri)
        }
    }

    val screenRecordingPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            result = M5InputEngine.analyzeLocalMediaUnified(
                context = context,
                uri = uri,
                kindOverride = UnifiedInputKind.SCREEN_RECORDING
            )
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "M5 — Unified Content Input",
            style = MaterialTheme.typography.headlineSmall
        )

        Text(
            "One intake point for text, YouTube, URLs, images, video, audio, documents and screen recordings."
        )

        OutlinedTextField(
            value = sourceText,
            onValueChange = { sourceText = it },
            label = { Text("Paste text, URL or YouTube link") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 4
        )

        Button(
            onClick = { result = M5InputEngine.analyzeUnifiedText(sourceText) },
            enabled = sourceText.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Analyze text / URL")
        }

        result?.let { r ->
            val scriptSource = buildString {
                if (sourceText.isNotBlank()) {
                    appendLine(sourceText)
                } else {
                    appendLine("SOURCE TYPE: ${r.kind}")
                    if (r.title.isNotBlank()) {
                        appendLine("TITLE: ${r.title}")
                    }
                    if (r.reference.isNotBlank()) {
                        appendLine("REFERENCE: ${r.reference}")
                    }
                    if (r.youtubeId != null) {
                        appendLine("YOUTUBE ID: ${r.youtubeId}")
                    }
                    if (r.durationSeconds > 0) {
                        appendLine("DURATION: ${r.durationSeconds}s")
                    }
                    if (r.numbers.isNotEmpty()) {
                        appendLine("NUMBERS: ${r.numbers.joinToString()}")
                    }
                    if (r.warnings.isNotEmpty()) {
                        appendLine("ANALYSIS NOTES:")
                        r.warnings.forEach { appendLine(it) }
                    }
                }
            }.trim()

            if (scriptSource.isNotBlank()) {
                Button(
                    onClick = { onOpenScript(scriptSource) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Continue to Script")
                }
            }
            if (r.kind == UnifiedInputKind.VIDEO || r.kind == UnifiedInputKind.SCREEN_RECORDING) {
                Button(
                    onClick = { onOpenVideo(r.reference) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Continue to Video")
                }
            }
        }

        Button(
            onClick = {
                mediaPicker.launch(
                    arrayOf(
                        "image/*",
                        "video/*",
                        "audio/*",
                        "application/pdf",
                        "text/*",
                        "application/msword",
                        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                    )
                )
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Import image / video / audio / document")
        }

        Button(
            onClick = {
                screenRecordingPicker.launch(arrayOf("video/*"))
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Import screen recording")
        }

        result?.let { r ->
            Text("Detected: ${r.kind}")
            Text("Title: ${r.title.ifBlank { "—" }}")
            Text("Reference: ${r.reference}")
            if (r.youtubeId != null) Text("YouTube ID: ${r.youtubeId}")
            if (r.durationSeconds > 0) Text("Duration: ${r.durationSeconds}s")
            if (r.numbers.isNotEmpty()) Text("Numbers: ${r.numbers.joinToString()}")
            Text("Confidence: ${"%.2f".format(r.confidence)}")
            r.warnings.forEach { Text("Next layer: $it") }
        }

        Button(
            onClick = onBack,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Back")
        }
    }
}

@Composable
fun M8CreativeScreen(projectId: String, onBack: () -> Unit) {
    val timeline = remember {
        M8Timeline(projectId = projectId, ctaStart = 10.0, ctaEnd = 15.0)
    }
    val errors = remember { timeline.validate() }
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("M8 Creative Director / Timeline", style = MaterialTheme.typography.headlineSmall)
        Text("Canvas: ${timeline.width}×${timeline.height}  •  ${timeline.format}")
        Text("CTA: ${if (timeline.validateCta()) "VALID (5s)" else "INVALID"}")
        Text(if (errors.isEmpty()) "Timeline contract: READY" else errors.joinToString("\n"))
        Button(onClick = onBack) { Text("Back") }
    }
}

@Composable
@androidx.compose.material3.ExperimentalMaterial3Api
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
fun M9PublishingScreen(projectId: String, onBack: () -> Unit) {
    var selectedProvider by androidx.compose.runtime.remember {
        androidx.compose.runtime.mutableStateOf(com.avsp.pro.m9.M9ProviderId.YOUTUBE)
    }

    val uiState = com.avsp.pro.m9.M9PublishingUiIntegration.providerState(
        selectedProvider
    )

    androidx.compose.material3.Scaffold(
        topBar = {
            androidx.compose.material3.TopAppBar(
                title = {
                    androidx.compose.material3.Text("Publish Center")
                },
                navigationIcon = {
                    androidx.compose.material3.IconButton(
                        onClick = onBack
                    ) {
                        androidx.compose.material3.Text("←", style = androidx.compose.material3.MaterialTheme.typography.titleLarge)
                    }
                }
            )
        }
    ) { paddingValues ->

        androidx.compose.foundation.layout.Column(
            modifier = androidx.compose.ui.Modifier
                .padding(paddingValues)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(12.dp)
        ) {

            androidx.compose.material3.Text(
                text = "Project: $projectId",
                style = androidx.compose.material3.MaterialTheme.typography.titleMedium
            )

            androidx.compose.material3.Text(
                text = "Select publishing platform",
                style = androidx.compose.material3.MaterialTheme.typography.titleSmall
            )

            androidx.compose.foundation.layout.Column(
                verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)
            ) {

                com.avsp.pro.m9.M9ProviderId.values().forEach { provider ->

                    val selected = provider == selectedProvider

                    androidx.compose.material3.Button(
                        onClick = {
                            selectedProvider = provider
                        },
                        modifier = androidx.compose.ui.Modifier.fillMaxWidth()
                    ) {
                        androidx.compose.material3.Text(
                            if (selected) {
                                "${provider.name}  •  SELECTED"
                            } else {
                                provider.name
                            }
                        )
                    }
                }
            }

            androidx.compose.material3.HorizontalDivider()

            androidx.compose.material3.Text(
                text = "Provider: ${uiState.provider}",
                style = androidx.compose.material3.MaterialTheme.typography.bodyLarge
            )

            androidx.compose.material3.Text(
                text = "Mode: ${uiState.providerMode}",
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium
            )

            androidx.compose.material3.Text(
                text = "Authentication: ${uiState.authState}",
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium
            )

            androidx.compose.material3.Text(
                text = "Runtime: ${
                    if (uiState.realOperationPerformed) {
                        "REAL OPERATION"
                    } else {
                        "NO EXTERNAL OPERATION"
                    }
                }",
                style = androidx.compose.material3.MaterialTheme.typography.bodyMedium
            )

            androidx.compose.material3.Card(
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                androidx.compose.foundation.layout.Column(
                    modifier = androidx.compose.ui.Modifier.padding(16.dp),
                    verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp)
                ) {
                    androidx.compose.material3.Text(
                        text = "Publishing status",
                        style = androidx.compose.material3.MaterialTheme.typography.titleSmall
                    )

                    androidx.compose.material3.Text(
                        text = uiState.status
                    )

                    if (uiState.message.isNotBlank()) {
                        androidx.compose.material3.Text(
                            text = uiState.message
                        )
                    }

                    androidx.compose.material3.Text(
                        text = "External publication is not claimed unless a real provider operation reports it."
                    )
                }
            }

            androidx.compose.foundation.layout.Spacer(
                modifier = androidx.compose.ui.Modifier.weight(1f)
            )

            androidx.compose.material3.Button(
                onClick = onBack,
                modifier = androidx.compose.ui.Modifier.fillMaxWidth()
            ) {
                androidx.compose.material3.Text("Back")
            }
        }
    }
}







