package com.avsp.pro.settings

/**
 * P17 KEY MANAGEMENT: every free service AVSP can use with your own keys, how
 * to recognise its key and how to test it. Each provider keeps up to
 * [ApiKeyRing.MAX_KEYS] keys; when one is refused or out of quota the next is used.
 */
object KeyProviders {
    data class Provider(
        val id: String,
        val title: String,
        val use: String,
        val getAt: String,
        /** Quick check of the key's shape (catches a key pasted in the wrong box). */
        val looksRight: (String) -> Boolean,
        /** URL + headers for a tiny test request. */
        val test: (String) -> Pair<String, Map<String, String>>
    )

    const val PIXABAY = "pixabay_api_credential"
    const val UNSPLASH = "unsplash_api_credential"

    val all: List<Provider> = listOf(
        Provider(SecureConfigKeys.AI_API, "Gemini (Google AI)", "Scripts, smarter captions, speech-to-text backup", "aistudio.google.com/apikey",
            { it.startsWith("AIza") && it.length >= 30 },
            { k -> "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1" to mapOf("x-goog-api-key" to k) }),
        Provider(SecureConfigKeys.PEXELS, "Pexels", "Stock video clips and photos", "pexels.com/api",
            { !it.startsWith("AIza") && it.length >= 40 && it.all(Char::isLetterOrDigit) },
            { k -> "https://api.pexels.com/videos/search?query=nature&per_page=1" to mapOf("Authorization" to k) }),
        Provider(PIXABAY, "Pixabay", "Stock photos (and videos)", "pixabay.com/api/docs",
            { Regex("""^\d+-[0-9a-f]{20,}$""").matches(it) },
            { k -> "https://pixabay.com/api/?key=$k&q=nature&per_page=3" to emptyMap() }),
        Provider(UNSPLASH, "Unsplash", "High-quality photos", "unsplash.com/developers",
            { !it.startsWith("AIza") && it.length in 40..50 && it.all { c -> c.isLetterOrDigit() || c == '-' || c == '_' } },
            { k -> "https://api.unsplash.com/search/photos?query=nature&per_page=1" to mapOf("Authorization" to "Client-ID $k", "Accept-Version" to "v1") }),
        // P21 backup AI writers
        Provider(com.avsp.pro.script.generator.ChatScriptGenerator.GROQ_KEY, "Groq (backup AI)", "Free, very fast Llama models - writes scripts when Gemini is busy or out of quota", "console.groq.com/keys",
            { it.startsWith("gsk_") && it.length >= 40 },
            { k -> "https://api.groq.com/openai/v1/models" to mapOf("Authorization" to "Bearer $k") }),
        Provider(com.avsp.pro.script.generator.ChatScriptGenerator.OPENROUTER_KEY, "OpenRouter (backup AI)", "Free models (Llama, DeepSeek, Gemma) - last AI backup for scripts", "openrouter.ai/keys",
            { it.startsWith("sk-or-") && it.length >= 40 },
            { k -> "https://openrouter.ai/api/v1/key" to mapOf("Authorization" to "Bearer $k") }),
        // P21 voices
        Provider(com.avsp.pro.audio.engine.SmartVoiceEngine.AZURE, "Azure Speech (voice)", "Natural Hindi / Bengali / English voices - set the region under Voice", "portal.azure.com -> Speech service -> Keys",
            { Regex("^[0-9a-fA-F]{32}$").matches(it) || Regex("^[A-Za-z0-9]{80,90}$").matches(it) },
            { k -> "https://${azureRegion.ifBlank { "centralindia" }}.tts.speech.microsoft.com/cognitiveservices/voices/list" to mapOf("Ocp-Apim-Subscription-Key" to k) }),
        Provider(com.avsp.pro.audio.engine.SmartVoiceEngine.GOOGLE_TTS, "Google Cloud Text-to-Speech (voice)", "Natural voices - needs the Text-to-Speech API turned on for the key", "console.cloud.google.com -> APIs -> Text-to-Speech",
            { it.startsWith("AIza") && it.length >= 30 },
            { k -> "https://texttospeech.googleapis.com/v1/voices?languageCode=hi-IN" to mapOf("x-goog-api-key" to k) })
    )

    /** P21: Azure region used by the key test (set from the Voice settings). */
    @Volatile var azureRegion: String = "centralindia"

    fun byId(id: String) = all.first { it.id == id }

    /** Result text for a test: ✓ / ✗ with a plain reason (never the key). */
    fun verdict(code: Int): String = when (code) {
        in 200..299 -> "✓ Working"
        400, 401, 403 -> "✗ Refused (HTTP $code) - wrong or disabled key"
        429 -> "⚠ Out of quota for now (HTTP 429) - the next key is used meanwhile"
        in 500..599 -> "⚠ Service busy (HTTP $code) - try again later"
        else -> "✗ Failed (HTTP $code)"
    }

    /** Runs the provider's test request (blocking; call on a background thread). */
    fun check(p: Provider, key: String): String = runCatching {
        val (url, headers) = p.test(key)
        val c = java.net.URI(url).toURL().openConnection() as java.net.HttpURLConnection
        try {
            c.connectTimeout = 10_000; c.readTimeout = 15_000
            headers.forEach { (h, v) -> c.setRequestProperty(h, v) }
            verdict(c.responseCode)
        } finally { c.disconnect() }
    }.getOrElse { "✗ No connection (${it.javaClass.simpleName})" }
}
