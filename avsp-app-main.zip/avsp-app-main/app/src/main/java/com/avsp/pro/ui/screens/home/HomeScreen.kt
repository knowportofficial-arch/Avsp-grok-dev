package com.avsp.pro.ui.screens.home

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.ScreenShare
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.avsp.pro.core.contracts.Project
import com.avsp.pro.core.ui.UiState
import com.avsp.pro.m5.M5InputEngine
import com.avsp.pro.m5.UnifiedInputKind
import com.avsp.pro.m5.UnifiedInputResult
import com.avsp.pro.ui.components.ErrorState
import com.avsp.pro.ui.components.LoadingState
import com.avsp.pro.ui.screens.videos.ExportedVideo
import com.avsp.pro.ui.screens.videos.VideoThumb
import com.avsp.pro.ui.screens.videos.loadExportedVideos
import com.avsp.pro.ui.screens.videos.playVideo
import com.avsp.pro.ui.viewmodel.HomeViewModel
import java.text.DateFormat
import java.util.Date

/**
 * Home: one clear job - make a video.
 *  1. Today's news -> video (the fastest path)
 *  2. Start from text/link, photos/files, screen recording or camera
 *  3. Recent videos (tap to play) and recent projects
 * Developer/module details live in Settings > Advanced.
 */
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpenProjects: () -> Unit,
    onOpenVideos: () -> Unit,
    onOpenDailyPost: () -> Unit,
    onOpenProject: (String) -> Unit,
    onRecordScreen: (String) -> Unit,
    onOpenCamera: (String) -> Unit,
    /** P28: event project -> straight to Manual (script + Plan & shoot). */
    onOpenManual: (String) -> Unit = onOpenProject,
    shared: List<UnifiedInputResult>? = null,
    onSharedConsumed: () -> Unit = {}
) {
    val state by viewModel.state.collectAsState()
    val actionError by viewModel.actionError.collectAsState()
    val working by viewModel.working.collectAsState()
    val context = LocalContext.current
    val sources = remember { mutableStateListOf<UnifiedInputResult>() }
    var showComposer by remember { mutableStateOf(false) }
    var showEvent by remember { mutableStateOf(false) }
    if (showEvent) EventStartDialog(onDismiss = { showEvent = false }) { info, lang ->
        showEvent = false
        viewModel.createEventProject(info, lang) { onOpenManual(it.projectId) }
    }
    var textInput by remember { mutableStateOf("") }
    var projectName by remember { mutableStateOf("") }
    var videos by remember { mutableStateOf<List<ExportedVideo>>(emptyList()) }

    LaunchedEffect(Unit) { videos = loadExportedVideos(context, limit = 10) }

    // P5: content shared into AVSP becomes a project straight away (read -> project screen).
    LaunchedEffect(shared) {
        val incoming = shared ?: return@LaunchedEffect
        onSharedConsumed()
        sources.clear()
        sources += incoming
        showComposer = true
        viewModel.createProjectFromSources(
            name = "",
            description = "",
            sources = incoming,
            onCreated = { project ->
                sources.clear()
                showComposer = false
                onOpenProject(project.projectId)
            }
        )
    }

    val filePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        uris.forEach { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val result = M5InputEngine.analyzeLocalMediaUnified(context, uri)
            if (sources.none { it.reference == result.reference }) sources += result
        }
        if (uris.isNotEmpty()) showComposer = true
    }

    fun stamp() = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date())

    when (val s = state) {
        is UiState.Idle, is UiState.Loading -> LoadingState("Opening AVSP…")
        is UiState.Error -> ErrorState(s.message, onRetry = viewModel::refresh)
        is UiState.Success -> {
            val data = s.data
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // ---------- Header ----------
                item {
                    Column(modifier = Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp)) {
                        Text(
                            "AVSP",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "Turn any story into a short video",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                        )
                    }
                }

                // ---------- P19: last crash, so it can be reported from the phone ----------
                item {
                    val ctx = androidx.compose.ui.platform.LocalContext.current
                    var crash by remember { mutableStateOf(com.avsp.pro.logs.CrashReporter.last(ctx)) }
                    crash?.let { details ->
                        androidx.compose.material3.Card(
                            modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                            colors = androidx.compose.material3.CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                        ) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("AVSP closed unexpectedly last time", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onErrorContainer)
                                Text(details.lines().getOrNull(3).orEmpty().take(140), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                                androidx.compose.foundation.layout.Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = {
                                        val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
                                        cm?.setPrimaryClip(android.content.ClipData.newPlainText("AVSP crash", details))
                                        android.widget.Toast.makeText(ctx, "Copied - paste it to Claude", android.widget.Toast.LENGTH_LONG).show()
                                    }) { Text("Copy details") }
                                    TextButton(onClick = { com.avsp.pro.logs.CrashReporter.clear(ctx); crash = null }) { Text("Dismiss") }
                                }
                            }
                        }
                    }
                }

                // ---------- Hero: news -> video ----------
                item {
                    Box(
                        modifier = Modifier
                            .padding(horizontal = 16.dp)
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(
                                        MaterialTheme.colorScheme.primary,
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.75f)
                                    )
                                )
                            )
                            .padding(20.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "Today's news → video",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary
                            )
                            Text(
                                "Pick a story. Script, voice-over and video are made for you in about a minute.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.9f)
                            )
                            Spacer(Modifier.height(4.dp))
                            Button(
                                onClick = onOpenDailyPost,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.onPrimary,
                                    contentColor = MaterialTheme.colorScheme.primary
                                )
                            ) { Text("Pick a news story", fontWeight = FontWeight.SemiBold) }
                        }
                    }
                }

                // ---------- P23.2 How to ----------
                item { HowToGuide(Modifier.padding(horizontal = 16.dp)) }

                // ---------- Start from ----------
                item {
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Or start from", style = MaterialTheme.typography.titleMedium)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.height(androidx.compose.foundation.layout.IntrinsicSize.Min)) {
                            StartTile(Icons.Filled.Edit, "Text or link", "Paste an article, idea or YouTube link", Modifier.weight(1f)) {
                                showComposer = true
                            }
                            StartTile(Icons.Filled.PhotoLibrary, "Photos & files", "Images, videos, PDFs", Modifier.weight(1f)) {
                                filePicker.launch(arrayOf("*/*"))
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.height(androidx.compose.foundation.layout.IntrinsicSize.Min)) {
                            StartTile(Icons.Filled.ScreenShare, "Record screen", "Private info is blurred", Modifier.weight(1f)) {
                                viewModel.createQuickProject("Screen recording ${stamp()}") { onRecordScreen(it.projectId) }
                            }
                            StartTile(Icons.Filled.PhotoCamera, "Camera", "Film with guidance", Modifier.weight(1f)) {
                                viewModel.createQuickProject("Camera video ${stamp()}") { onOpenCamera(it.projectId) }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.height(androidx.compose.foundation.layout.IntrinsicSize.Min)) {
                            StartTile(Icons.Filled.Place, "I'm here", "Puja, mela, event - live with place & time", Modifier.weight(1f)) {
                                showEvent = true
                            }
                        }
                    }
                }

                // ---------- Composer (text / link / files) ----------
                if (showComposer || sources.isNotEmpty()) {
                    item {
                        Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("What is the video about?", style = MaterialTheme.typography.titleMedium)
                                OutlinedTextField(
                                    modifier = Modifier.fillMaxWidth(),
                                    value = textInput,
                                    onValueChange = { textInput = it },
                                    label = { Text("Paste text, a website or YouTube link") },
                                    minLines = 3
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(
                                        enabled = textInput.isNotBlank(),
                                        onClick = {
                                            val result = M5InputEngine.analyzeUnifiedText(textInput.trim())
                                            if (sources.none { it.reference == result.reference }) sources += result
                                            textInput = ""
                                        }
                                    ) { Text("Add") }
                                    OutlinedButton(onClick = { filePicker.launch(arrayOf("*/*")) }) { Text("Add files") }
                                }
                                sources.forEachIndexed { index, source ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(kindLabel(source.kind), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                            Text(
                                                source.title.ifBlank { source.reference },
                                                style = MaterialTheme.typography.bodyMedium,
                                                maxLines = 2,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        TextButton(onClick = { sources.removeAt(index) }) { Text("Remove") }
                                    }
                                }
                                if (sources.isNotEmpty()) {
                                    OutlinedTextField(
                                        modifier = Modifier.fillMaxWidth(),
                                        value = projectName,
                                        onValueChange = { projectName = it },
                                        label = { Text("Video title (optional)") },
                                        singleLine = true
                                    )
                                }
                                working?.let {
                                    androidx.compose.material3.LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                                    Text(it, style = MaterialTheme.typography.bodySmall)
                                }
                                Button(
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = working == null && (sources.isNotEmpty() || textInput.isNotBlank()),
                                    onClick = {
                                        if (textInput.isNotBlank()) {
                                            val result = M5InputEngine.analyzeUnifiedText(textInput.trim())
                                            if (sources.none { it.reference == result.reference }) sources += result
                                            textInput = ""
                                        }
                                        viewModel.createProjectFromSources(
                                            name = projectName,
                                            description = "",
                                            sources = sources.toList(),
                                            onCreated = { project ->
                                                sources.clear()
                                                projectName = ""
                                                showComposer = false
                                                onOpenProject(project.projectId)
                                            }
                                        )
                                    }
                                ) { Text("Continue →") }
                            }
                        }
                    }
                }

                // ---------- Recent videos ----------
                if (videos.isNotEmpty()) {
                    item {
                        SectionHeader("Recent videos", "See all", onOpenVideos)
                        LazyRow(
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 16.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            items(videos, key = { it.uri.toString() }) { v ->
                                Box(modifier = Modifier.clickable { playVideo(context, v.uri) }) {
                                    VideoThumb(v.uri, 96.dp, 170.dp, v.durationMs)
                                }
                            }
                        }
                    }
                }

                // ---------- Recent projects ----------
                item {
                    SectionHeader("Recent projects", if (data.projectCount > 0) "See all" else null, onOpenProjects)
                    Column(
                        modifier = Modifier.padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (data.recentProjects.isEmpty()) {
                            Text(
                                "Your projects will appear here.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                            )
                        } else {
                            data.recentProjects.forEach { project ->
                                ProjectRow(project) { onOpenProject(project.projectId) }
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
        }
    }

    actionError?.let { err ->
        AlertDialog(
            onDismissRequest = viewModel::clearActionError,
            title = { Text("Could not start") },
            text = { Text(err) },
            confirmButton = { TextButton(onClick = viewModel::clearActionError) { Text("OK") } }
        )
    }
}

@Composable
private fun StartTile(icon: ImageVector, title: String, hint: String, modifier: Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.fillMaxHeight().clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
            Text(
                hint,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                maxLines = 2
            )
        }
    }
}

@Composable
private fun SectionHeader(title: String, action: String?, onAction: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, bottom = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        if (action != null) TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
internal fun ProjectRow(project: Project, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    project.name,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(project.updatedAt)),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
            val ready = project.outputPath != null
            Text(
                if (ready) "Video ready" else "Draft",
                style = MaterialTheme.typography.labelMedium,
                color = if (ready) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (ready) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.06f)
                    )
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

private fun kindLabel(kind: UnifiedInputKind): String =
    kind.name.lowercase().replace('_', ' ').replaceFirstChar { it.uppercase() }
