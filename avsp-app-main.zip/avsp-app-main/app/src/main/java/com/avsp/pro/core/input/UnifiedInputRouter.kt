﻿package com.avsp.pro.core.input

import java.util.Locale
import java.util.UUID

/**
 * M11 foundation router.
 *
 * It classifies an input into the canonical UnifiedInput model.
 *
 * IMPORTANT:
 * This class does NOT perform OCR, transcription, AI generation,
 * media decoding, downloading, publishing, or external network work.
 * Those responsibilities remain with their existing modules.
 */
object UnifiedInputRouter {

    fun classify(
        locator: String,
        mimeType: String? = null,
        displayName: String? = null
    ): UnifiedInputResult {

        val value = locator.trim()

        if (value.isEmpty()) {
            return UnifiedInputResult(
                accepted = false,
                reason = "Input locator is empty."
            )
        }

        val normalizedMime = mimeType
            ?.trim()
            ?.lowercase(Locale.ROOT)

        val normalizedName = displayName
            ?.trim()
            ?.lowercase(Locale.ROOT)

        val type = when {
            isYouTubeUrl(value) ->
                UnifiedInputType.YOUTUBE

            isHttpUrl(value) ->
                UnifiedInputType.URL

            normalizedMime == "image/screenshot" ->
                UnifiedInputType.SCREENSHOT

            normalizedMime?.startsWith("image/") == true ->
                UnifiedInputType.IMAGE

            normalizedMime?.startsWith("video/") == true ->
                if (isScreenRecordingName(normalizedName)) {
                    UnifiedInputType.SCREEN_RECORDING
                } else {
                    UnifiedInputType.VIDEO
                }

            normalizedMime?.startsWith("audio/") == true ->
                UnifiedInputType.AUDIO

            normalizedMime == "application/pdf" ->
                UnifiedInputType.PDF_DOCUMENT

            normalizedMime?.startsWith("text/") == true ->
                UnifiedInputType.TEXT

            looksLikePdf(value, normalizedName) ->
                UnifiedInputType.PDF_DOCUMENT

            looksLikeImage(value, normalizedName) ->
                UnifiedInputType.IMAGE

            looksLikeVideo(value, normalizedName) ->
                UnifiedInputType.VIDEO

            looksLikeAudio(value, normalizedName) ->
                UnifiedInputType.AUDIO

            looksLikeDocument(value, normalizedName) ->
                UnifiedInputType.DOCUMENT

            else ->
                UnifiedInputType.TEXT
        }

        return UnifiedInputResult(
            accepted = true,
            input = UnifiedInput(
                id = UUID.randomUUID().toString(),
                type = type,
                locator = value,
                displayName = displayName,
                mimeType = mimeType
            )
        )
    }

    private fun isHttpUrl(value: String): Boolean {
        return value.startsWith("https://", ignoreCase = true) ||
            value.startsWith("http://", ignoreCase = true)
    }

    private fun isYouTubeUrl(value: String): Boolean {
        if (!isHttpUrl(value)) return false

        val v = value.lowercase(Locale.ROOT)

        return v.contains("youtube.com/") ||
            v.contains("youtu.be/") ||
            v.contains("youtube-nocookie.com/")
    }

    private fun isScreenRecordingName(name: String?): Boolean {
        if (name == null) return false

        return name.contains("screenrecording") ||
            name.contains("screen_recording") ||
            name.contains("screen-recording") ||
            name.contains("screen recording")
    }

    private fun looksLikePdf(value: String, name: String?): Boolean {
        return hasExtension(value, ".pdf") ||
            hasExtension(name, ".pdf")
    }

    private fun looksLikeImage(value: String, name: String?): Boolean {
        return hasAnyExtension(
            value,
            name,
            ".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".heic"
        )
    }

    private fun looksLikeVideo(value: String, name: String?): Boolean {
        return hasAnyExtension(
            value,
            name,
            ".mp4", ".mkv", ".mov", ".webm", ".avi", ".3gp"
        )
    }

    private fun looksLikeAudio(value: String, name: String?): Boolean {
        return hasAnyExtension(
            value,
            name,
            ".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac"
        )
    }

    private fun looksLikeDocument(value: String, name: String?): Boolean {
        return hasAnyExtension(
            value,
            name,
            ".txt", ".doc", ".docx", ".rtf", ".odt"
        )
    }

    private fun hasAnyExtension(
        value: String,
        name: String?,
        vararg extensions: String
    ): Boolean {
        return extensions.any { ext ->
            hasExtension(value, ext) || hasExtension(name, ext)
        }
    }

    private fun hasExtension(value: String?, extension: String): Boolean {
        return value?.lowercase(Locale.ROOT)?.contains(extension) == true
    }
}
