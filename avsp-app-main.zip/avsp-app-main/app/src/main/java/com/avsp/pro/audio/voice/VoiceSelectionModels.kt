﻿package com.avsp.pro.audio.voice

/**
 * Inputs used by the deterministic M3 voice-selection policy.
 *
 * The policy is intentionally local and provider-agnostic. AI providers can
 * supply richer content intent later without replacing this safety gate.
 */
data class VoiceSelectionRequest(
    val language: String,
    val contentType: VoiceContentType = VoiceContentType.GENERAL,
    val preferredProviderId: String? = null,
    val preferredVoiceId: String? = null,
    val preferredGender: VoiceGender? = null,
    val speechRate: Float = 1.0f
)

enum class VoiceContentType {
    GENERAL,
    NEWS,
    DEVOTIONAL,
    SHORTS,
    EDUCATION,
    LOCAL,
    STORY,
    FORMAL
}

data class VoiceSelectionCandidate(
    val voice: VoiceProfile,
    val score: Int,
    val reasons: List<String>
)

data class VoiceSelectionResult(
    val selected: VoiceProfile,
    val candidates: List<VoiceSelectionCandidate>,
    val automatic: Boolean
)
