package com.avsp.pro.core.pipeline

import com.avsp.pro.script.contract.ScriptPackage

/**
 * P3 PUBLISH KIT (zero dependency)
 *
 * Title, description and hashtags ready to paste into YouTube, Instagram,
 * WhatsApp or Facebook. Built offline from the finished script - no AI
 * service, no account, no key.
 */
data class PublishKit(
    val title: String,
    val description: String,
    val hashtags: List<String>
) {
    /** Full text for the caption / description box. */
    val caption: String
        get() = buildString {
            append(title)
            if (description.isNotBlank()) append("\n\n").append(description)
            if (hashtags.isNotEmpty()) append("\n\n").append(hashtags.joinToString(" "))
        }

    companion object {
        const val MAX_TITLE = 95
        const val MAX_DESCRIPTION = 1200
        private const val MAX_TAGS = 8

        fun from(script: ScriptPackage, portrait: Boolean = true): PublishKit {
            val title = shorten(script.title.ifBlank { script.topic.lineSequence().firstOrNull().orEmpty() }, MAX_TITLE)
            val body = script.scenes.sortedBy { it.order }.map { it.narration.trim() }
                .filter { it.isNotBlank() && !it.equals(script.cta.trim(), ignoreCase = true) }
                .drop(1) // the hook repeats the title
                .take(4)
            val description = shorten(
                (body + listOfNotNull(script.cta.trim().takeIf { it.isNotBlank() })).joinToString("\n"),
                MAX_DESCRIPTION
            )
            return PublishKit(title, description, hashtags(title, script, portrait))
        }

        private val STOP = setOf(
            "the", "and", "for", "with", "from", "this", "that", "what", "your", "you", "are", "was", "were",
            "have", "has", "had", "will", "about", "after", "into", "over", "here", "need", "know", "more",
            "today", "update", "updates", "news", "follow", "like", "their", "they", "them", "than", "then",
            "also", "just", "said", "says", "new", "shocking", "terrifying", "horrific", "breaking",
            "top", "list", "make", "makes", "world", "feature", "features", "follows", "leads", "lead", "over",
            "first", "last", "big", "know", "here", "this", "what", "why", "how", "when", "where", "who"
        )

        internal fun hashtags(title: String, script: ScriptPackage, portrait: Boolean): List<String> {
            fun words(text: String) = text.split(Regex("""[^\p{L}\p{M}\p{N}]+"""))
                .map { it.trim() }
                .filter { w -> w.length >= 3 && w.lowercase() !in STOP && w.any { it.isLetter() } && w.none { it.isDigit() } }
            val titleWords = words(title)
            // P4.1: names and places first (capitalised words: ISRO, IISc, Delhi), then other title words.
            // P10: from the script only real names (capitalised mid-sentence: Kolkata, IIT), most frequent
            // first - sentence-start words like "It is located…" gave junk tags (#Located, #Fourth).
            val names = script.scenes.flatMap { sc ->
                sc.narration.split(Regex("""(?<=[.!?।])\s+""")).flatMap { sentence -> words(sentence).drop(1).filter { it.first().isUpperCase() } }
            }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.map { it.key }
            val ranked = titleWords.filter { it.first().isUpperCase() } +
                titleWords.filterNot { it.first().isUpperCase() } +
                names
            val tags = LinkedHashMap<String, String>()
            for (w in ranked) {
                val tag = "#" + w.replaceFirstChar { it.uppercaseChar() }
                tags.putIfAbsent(tag.lowercase(), tag)
                if (tags.size >= MAX_TAGS - 2) break
            }
            val out = tags.values.toMutableList()
            if (portrait) out += "#Shorts"
            // P22.4: the closing tag fits the topic (a recipe was tagged #News before) + the creator's channel.
            out += topicTags(listOf(title, script.topic).joinToString(" "), script.language)
            com.avsp.pro.settings.BrandKit.channel.replace(Regex("[^\\p{L}\\p{N}]"), "").takeIf { it.isNotBlank() }?.let { out += "#$it" }
            return out.distinctBy { it.lowercase() }.take(MAX_TAGS + 2)
        }

        internal fun topicTags(text: String, language: String): List<String> {
            val t = text.lowercase()
            val hi = language.equals("hi", ignoreCase = true)
            return when {
                com.avsp.pro.capture.ShotPlanner.kind(t) == com.avsp.pro.capture.TopicKind.RECIPE -> listOf("#Recipe", "#IndianFood")
                Regex("news|breaking|election|minister|government|police|court|accident|খবর|समाचार").containsMatchIn(t) -> listOf(if (hi) "#HindiNews" else "#News")
                com.avsp.pro.capture.ShotPlanner.kind(t) == com.avsp.pro.capture.TopicKind.PLACE -> listOf("#Travel", "#India")
                else -> emptyList()
            }
        }

        internal fun shorten(text: String, max: Int): String {
            val t = text.trim().replace(Regex("""[ \t]+"""), " ")
            if (t.length <= max) return t
            val cut = t.take(max - 1)
            val space = cut.lastIndexOf(' ')
            return (if (space > max / 2) cut.take(space) else cut).trimEnd(',', ';', ':', '-') + "…"
        }
    }
}

/** Apps the finished video can be posted to directly (falls back to the share sheet). */
enum class PublishTarget(val label: String, val packageName: String?) {
    YOUTUBE("YouTube", "com.google.android.youtube"),
    INSTAGRAM("Instagram", "com.instagram.android"),
    WHATSAPP("WhatsApp", "com.whatsapp"),
    FACEBOOK("Facebook", "com.facebook.katana"),
    MORE("More…", null)
}
