package com.avsp.pro.video.contract

import com.avsp.pro.audio.integration.AudioToVideoHandoff

/** M4 render contract. Android and desktop backends consume the same plan. */
data class VideoCaptionInput(
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val emphasis: Boolean = false
)

data class VideoEmojiInput(
    val startMs: Long,
    val endMs: Long,
    val emoji: String,
    val emphasis: Boolean = false
)

data class VideoSceneInput(
    val sceneId: String,
    val order: Int,
    val startMs: Long,
    val endMs: Long,
    val durationMs: Long,
    val audioRelativePath: String,
    val visualRelativePath: String?,
    val visualMimeType: String? = null,
    val overlayText: String? = null,
    val captions: List<VideoCaptionInput> = emptyList(),
    val emojis: List<VideoEmojiInput> = emptyList(),
    /**
     * P2.2: full-frame designed card drawn over [visualRelativePath] (a short
     * base clip). Rendering cards as still images made them last ~1.5x longer
     * than the voice-over on device; a video base keeps exact timing.
     */
    val cardRelativePath: String? = null,
    /** P6: spoken text of this scene (timed captions) and whether it is the call-to-action outro. */
    val narration: String = "",
    val isCta: Boolean = false,
    /** P11: hand-drawn doodle animation for this scene (drawn over the paper card). */
    val doodle: com.avsp.pro.video.doodle.DoodleSpec? = null,
    /** P20: playback speed of this scene's own clip (0.5 = slow motion); 1 = normal. */
    val speed: Float = 1f
)

data class VideoRenderPlan(
    val projectId: String,
    val scriptId: String,
    val audioPackageId: String,
    val language: String,
    val totalDurationMs: Long,
    val width: Int,
    val height: Int,
    val fps: Int,
    val scenes: List<VideoSceneInput>,
    val musicRelativePath: String? = null,
    /** P15: volume of the music track (real songs are mixed low under the voice; the generated pad is already quiet). */
    val musicGain: Float = 1f,
    /** P6: captions, emoji, progress bar, border and CTA overlay on every scene. */
    val polish: Boolean = false
) {
    companion object {
        const val DEFAULT_SHORTS_WIDTH = 1080
        const val DEFAULT_SHORTS_HEIGHT = 1920
        const val DEFAULT_LANDSCAPE_WIDTH = 1920
        const val DEFAULT_LANDSCAPE_HEIGHT = 1080
        const val DEFAULT_SQUARE_WIDTH = 1080
        const val DEFAULT_SQUARE_HEIGHT = 1080
        const val DEFAULT_PORTRAIT_4_5_WIDTH = 1080
        const val DEFAULT_PORTRAIT_4_5_HEIGHT = 1350
        const val DEFAULT_FPS = 30
    }
}

object VideoRenderPlanFactory {

    fun fromAudio(
        handoff: AudioToVideoHandoff,
        visualsByScene: Map<String, String>,
        visualMimeByScene: Map<String, String> = emptyMap(),
        width: Int = VideoRenderPlan.DEFAULT_SHORTS_WIDTH,
        height: Int = VideoRenderPlan.DEFAULT_SHORTS_HEIGHT,
        fps: Int = VideoRenderPlan.DEFAULT_FPS
    ): VideoRenderPlan {
        val segments = handoff.segments.sortedBy { it.order }
        return VideoRenderPlan(
            projectId = handoff.projectId,
            scriptId = handoff.scriptId,
            audioPackageId = handoff.audioPackageId,
            language = handoff.language,
            totalDurationMs = handoff.totalDurationMs,
            width = width,
            height = height,
            fps = fps,
            scenes = segments.map { segment ->
                VideoSceneInput(
                    sceneId = segment.sceneId,
                    order = segment.order,
                    startMs = segment.startMs,
                    endMs = segment.endMs,
                    durationMs = segment.durationMs,
                    audioRelativePath = segment.relativeAudioPath,
                    visualRelativePath = visualsByScene[segment.sceneId],
                    visualMimeType = visualMimeByScene[segment.sceneId]
                )
            }
        )
    }

    fun fromM8Timeline(
        timeline: com.avsp.pro.m8.M8Timeline,
        audioHandoff: AudioToVideoHandoff,
        visualsByScene: Map<String, String> = emptyMap(),
        visualMimeByScene: Map<String, String> = emptyMap()
    ): VideoRenderPlan {
        val validation = timeline.validate()
        require(validation.isEmpty()) {
            "Invalid M8 timeline: ${validation.joinToString("; ")}"
        }
        require(timeline.projectId == audioHandoff.projectId) {
            "M8 timeline project_id does not match audio handoff project_id"
        }

        val segments = audioHandoff.segments.sortedBy { it.order }
        val timelineVisuals = timeline.visuals.sortedBy { it.start }

        return VideoRenderPlan(
            projectId = audioHandoff.projectId,
            scriptId = audioHandoff.scriptId,
            audioPackageId = audioHandoff.audioPackageId,
            language = audioHandoff.language,
            totalDurationMs = audioHandoff.totalDurationMs,
            width = timeline.width,
            height = timeline.height,
            fps = timeline.fps.toInt().coerceAtLeast(1),
            scenes = segments.map { segment ->
                val sceneStart = segment.startMs.toDouble() / 1000.0
                val sceneEnd = segment.endMs.toDouble() / 1000.0

                val matchingVisual = timelineVisuals.firstOrNull { event ->
                    event.end > sceneStart && event.start < sceneEnd
                }

                val visualPath =
                    visualsByScene[segment.sceneId] ?: matchingVisual?.path

                val visualType =
                    visualMimeByScene[segment.sceneId] ?: matchingVisual?.type

                val sceneCaptions = timeline.captions
                    .filter { caption ->
                        caption.end > sceneStart && caption.start < sceneEnd
                    }
                    .map { caption ->
                        VideoCaptionInput(
                            startMs = maxOf(
                                segment.startMs,
                                (caption.start * 1000.0).toLong()
                            ),
                            endMs = minOf(
                                segment.endMs,
                                (caption.end * 1000.0).toLong()
                            ),
                            text = caption.text,
                            emphasis = caption.emphasis
                        )
                    }
                    .filter { it.endMs > it.startMs && it.text.isNotBlank() }

                val sceneEmojis = timeline.emojiEvents
                    .filter { emoji ->
                        emoji.end > sceneStart && emoji.start < sceneEnd
                    }
                    .map { emoji ->
                        VideoEmojiInput(
                            startMs = maxOf(
                                segment.startMs,
                                (emoji.start * 1000.0).toLong()
                            ),
                            endMs = minOf(
                                segment.endMs,
                                (emoji.end * 1000.0).toLong()
                            ),
                            emoji = emoji.emoji,
                            emphasis = emoji.emphasis
                        )
                    }
                    .filter { it.endMs > it.startMs && it.emoji.isNotBlank() }

                val captionText = sceneCaptions
                    .joinToString(" ") { it.text }
                    .ifBlank { null }

                VideoSceneInput(
                    sceneId = segment.sceneId,
                    order = segment.order,
                    startMs = segment.startMs,
                    endMs = segment.endMs,
                    durationMs = segment.durationMs,
                    audioRelativePath = segment.relativeAudioPath,
                    visualRelativePath = visualPath,
                    visualMimeType = visualType,
                    overlayText = captionText,
                    captions = sceneCaptions,
                    emojis = sceneEmojis
                )
            },
            musicRelativePath = timeline.musicPath
        )
    }
}

data class VideoRenderResult(
    val projectId: String,
    val outputRelativePath: String,
    val outputAbsolutePath: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val videoCodec: String,
    val audioCodec: String,
    val status: String,
    val exportedUri: String? = null,
    val exportedRelativePath: String? = null,
    val exportedDisplayName: String? = null
)
