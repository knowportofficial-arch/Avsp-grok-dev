package com.avsp.pro.screen.capture
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
enum class ScreenCaptureStatus { IDLE, STARTING, RECORDING, STOPPING, COMPLETED, ERROR }
enum class ScreenAnalysisStatus { IDLE, RUNNING, COMPLETED, ERROR }
data class ScreenCaptureState(
 val status: ScreenCaptureStatus=ScreenCaptureStatus.IDLE,val projectId:String?=null,
 val outputRelativePath:String?=null,val metadataRelativePath:String?=null,val durationMs:Long=0,
 val fileSizeBytes:Long=0,val width:Int=0,val height:Int=0,val fps:Int=0,
 val analysisStatus:ScreenAnalysisStatus=ScreenAnalysisStatus.IDLE,
 val analysisRelativePath:String?=null,val redactionRelativePath:String?=null,
 val scriptRelativePath:String?=null,val highlightCount:Int=0,val sensitiveFindingCount:Int=0,
 val cutSuggestionCount:Int=0,val errorMessage:String?=null)
object ScreenCaptureStateStore {
 private val _state=MutableStateFlow(ScreenCaptureState()); val state:StateFlow<ScreenCaptureState> = _state.asStateFlow()
 fun update(v:ScreenCaptureState){_state.value=v}; fun reset(id:String?=null){_state.value=ScreenCaptureState(projectId=id); _note.value=null; startedAt=0L}
 // P31: plain-language note (e.g. "the recorded app was closed") and when recording began (for the timer)
 private val _note=MutableStateFlow<String?>(null); val note:StateFlow<String?> = _note.asStateFlow()
 fun note(t:String?){_note.value=t}
 @Volatile var startedAt:Long=0L
}
