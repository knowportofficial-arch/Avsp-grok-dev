package com.avsp.pro.video.doodle

/**
 * P11 DOODLE: what a doodle scene shows and when (pure, testable).
 *  - headline written by hand at the top
 *  - 1-2 icons picked from the scene's words (English, Bengali, Hindi keywords),
 *    or a zodiac sign glyph for rashifal scenes
 *  - timeline: icons are drawn, then filled, the headline is written, then underlined
 */
data class DoodleSpec(
    val headline: String,
    val icons: List<String>,
    val glyph: String? = null
)

object DoodlePlanner {
    const val ICONS_END_MS = 1300L
    const val FILL_END_MS = 1600L
    const val TEXT_START_MS = 500L
    const val TEXT_END_MS = 1900L
    const val UNDERLINE_END_MS = 2200L
    const val DONE_MS = 2200L

    private val KEYWORDS: List<Pair<Regex, String>> = listOf(
        "rain|drizzle|shower|monsoon|storm|thunder|বৃষ্টি|বর্ষা|बारिश|वर्षा" to "rain",
        "cloud|overcast|মেঘ|बादल" to "cloud",
        "sun|sunny|clear sky|heat|hot|রোদ|গরম|धूप|गर्मी" to "sun",
        "temperature|°c|degree|তাপমাত্রা|तापमान" to "thermometer",
        "wind|breeze|cyclone|ঝড়|হাওয়া|हवा|तूफान" to "wind",
        "horoscope|rashifal|zodiac|astrolog|lucky|রাশি|राशि" to "star",
        "night|moon|চাঁদ|রাত|चांद|रात" to "moon",
        "book|read|library|fair|বই|किताब|पुस्तक" to "book",
        "train|rail|station|platform|ট্রেন|রেল|ट्रेन|रेल" to "train",
        "water|drink|river|sea|জল|পানি|पानी" to "drop",
        "love|heart|health|ভালোবাসা|স্বাস্থ্য|प्यार|स्वास्थ्य" to "heart",
        "home|house|city|town|বাড়ি|শহর|घर|शहर" to "house",
        "people|person|man|woman|student|leader|মানুষ|लोग" to "person",
        "world|country|india|international|global|দেশ|বিশ্ব|देश|विश्व" to "globe",
        "time|hour|minute|সময়|समय" to "clock",
        "today|date|day|anniversary|born|history|year|দিন|তারিখ|इतिहास|दिन|तारीख" to "calendar",
        "idea|tip|learn|science|technology|বিজ্ঞান|विज्ञान" to "bulb",
        "growth|rise|increase|market|economy|price|বাজার|बाजार" to "chart",
        "win|won|award|champion|cup|medal|জয়|जीत" to "trophy",
        "joke|funny|laugh|smile|হাসি|मज़ाक|हंसी" to "laugh",
        "phone|mobile|app|internet|online|ফোন|फोन" to "phone",
        "tree|forest|nature|plant|গাছ|पेड़" to "tree",
        "money|rupee|₹|bank|budget|টাকা|पैसा|रुपये" to "coin",
        "school|college|exam|university|iit|education|স্কুল|পরীক্ষা|स्कूल|परीक्षा" to "cap",
        "independence|republic|national|nation|flag|পতাকা|झंडा" to "flag",
        "warning|alert|danger|accident|caution|সতর্ক|चेतावनी" to "warning",
        "news|announce|update|খবর|खबर" to "megaphone"
    ).map { (k, v) -> Regex("(?i)($k)") to v }

    private val ZODIAC: List<Pair<Regex, String>> = listOf(
        "aries|mesh|মেষ|मेष" to "♈", "taurus|vrishabh|বৃষ|वृषभ" to "♉", "gemini|mithun|মিথুন|मिथुन" to "♊",
        "cancer|kark|কর্কট|कर्क" to "♋", "leo|simha|singh|সিংহ|सिंह" to "♌", "virgo|kanya|কন্যা|कन्या" to "♍",
        "libra|tula|তুলা|तुला" to "♎", "scorpio|vrishchik|বৃশ্চিক|वृश्चिक" to "♏", "sagittarius|dhanu|ধনু|धनु" to "♐",
        "capricorn|makar|মকর|मकर" to "♑", "aquarius|kumbh|কুম্ভ|कुंभ" to "♒", "pisces|meen|মীন|मीन" to "♓"
    ).map { (k, v) -> Regex("(?i)(?<![\\p{L}])($k)(?![\\p{L}])") to v }

    fun plan(headline: String, narration: String, sceneIndex: Int): DoodleSpec {
        val text = "$headline $narration"
        val glyph = ZODIAC.firstOrNull { it.first.containsMatchIn(headline) }?.second
            ?: ZODIAC.firstOrNull { it.first.containsMatchIn(narration) }?.second
        // Order of first appearance in the text, at most 2 icons.
        val found = KEYWORDS.mapNotNull { (re, icon) -> re.find(text)?.let { it.range.first to icon } }
            .sortedBy { it.first }.map { it.second }.distinct()
        val icons = when {
            glyph != null -> listOfNotNull(found.firstOrNull { it != "star" } ?: "star")
            found.isNotEmpty() -> found.take(2)
            else -> listOf(DoodleIcons.GENERIC[sceneIndex.mod(DoodleIcons.GENERIC.size)])
        }
        return DoodleSpec(headline.trim().trimEnd('.', '!', '…').take(60), icons, glyph)
    }

    /** 0..1 progress of a phase between [from] and [to] ms. */
    fun phase(ms: Long, from: Long, to: Long): Float =
        if (ms <= from) 0f else if (ms >= to) 1f else (ms - from).toFloat() / (to - from)

    /** Small deterministic wobble so lines look hand-drawn, not ruler-straight. */
    fun wobble(seed: Int, i: Int, amount: Float = 0.8f): Float {
        var x = seed * 374761393 + i * 668265263
        x = (x xor (x ushr 13)) * 1274126177
        return (((x xor (x ushr 16)) and 0xFFFF) / 65535f - 0.5f) * 2f * amount
    }
}
