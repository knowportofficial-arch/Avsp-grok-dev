﻿package com.avsp.pro.audio.engine

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.speech.tts.UtteranceProgressListener
import com.avsp.pro.audio.error.AudioErrorCode
import com.avsp.pro.audio.error.AudioException
import com.avsp.pro.audio.language.AudioLanguageRegistry
import com.avsp.pro.audio.wav.WavEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Android platform TTS provider.
 * Detects availability and language support; never crashes when TTS is missing.
 * Synthesizes to a WAV file via [TextToSpeech.synthesizeToFile] when available.
 */
class AndroidTtsEngine(
    context: Context
) : TtsEngine {

    private val appContext = context.applicationContext
    private val ready = AtomicBoolean(false)
    private var initFailed = false
    private var tts: TextToSpeech? = null

    override val providerId: String = PROVIDER_ID
    override val displayName: String = "Android Local TTS"
    override val mode: TtsProviderMode = TtsProviderMode.ANDROID_LOCAL

    init {
        /*
         * P2.1: start the platform TTS at app start. Its ready-callback is
         * delivered on the main thread, so it must not be awaited there.
         */
        runCatching { ensureInitialized() }
    }

    @Synchronized
    private fun ensureInitialized() {
        if (tts != null || initFailed) return
        try {
            tts = TextToSpeech(appContext) { status ->
                ready.set(status == TextToSpeech.SUCCESS)
                if (status != TextToSpeech.SUCCESS) {
                    initFailed = true
                }
            }
            // P2.1: no blocking here; isAvailable() waits (off the main thread only).
        } catch (_: Exception) {
            initFailed = true
            tts = null
            ready.set(false)
        }
    }

    override fun isAvailable(): Boolean {
        return try {
            ensureInitialized()
            /*
             * P2.1: the init callback arrives on the main thread. Off the main
             * thread wait up to 4 s for it; previously a fixed 150 ms wait made
             * auto-production fall back to the MOCK tone voice.
             */
            val onMain = android.os.Looper.myLooper() == android.os.Looper.getMainLooper()
            if (!onMain) {
                var waited = 0
                while (!ready.get() && !initFailed && waited < 4000) {
                    Thread.sleep(50)
                    waited += 50
                }
            }
            !initFailed && tts != null && ready.get()
        } catch (_: Exception) {
            false
        }
    }

    override fun supportedLanguages(): Set<String> {
        if (!isAvailable()) return emptySet()
        val engine = tts ?: return emptySet()
        return AudioLanguageRegistry.supportedCodes().filter { code ->
            val locale = localeFor(code)
            val result = runCatching { engine.isLanguageAvailable(locale) }.getOrDefault(-2)
            result >= TextToSpeech.LANG_AVAILABLE
        }.toSet()
    }

    override fun voices(): List<com.avsp.pro.audio.voice.VoiceProfile> {
        if (!isAvailable()) return emptyList()
        val engine = tts ?: return emptyList()
        return runCatching {
            engine.voices.orEmpty().mapNotNull { v ->
                val code = v.locale.language.lowercase()
                if (!AudioLanguageRegistry.isSupported(code)) return@mapNotNull null
                com.avsp.pro.audio.voice.VoiceProfile(
                    id = v.name,
                    providerId = providerId,
                    displayName = v.name,
                    languageCodes = setOf(code),
                    qualityScore = when (v.quality) {
                        Voice.QUALITY_VERY_HIGH -> 1.0f
                        Voice.QUALITY_HIGH -> 0.85f
                        Voice.QUALITY_NORMAL -> 0.65f
                        else -> 0.45f
                    },
                    available = true,
                    networkRequired = v.isNetworkConnectionRequired
                )
            }
        }.getOrDefault(emptyList())
    }
    override fun supportsLanguage(languageCode: String): Boolean {
        if (!AudioLanguageRegistry.isSupported(languageCode)) return false
        if (!isAvailable()) return false
        val engine = tts ?: return false
        val locale = localeFor(languageCode)
        val result = runCatching { engine.isLanguageAvailable(locale) }.getOrDefault(-2)
        return result >= TextToSpeech.LANG_AVAILABLE
    }

    override suspend fun synthesize(request: TtsSynthesisRequest): TtsSynthesisResult =
        withContext(Dispatchers.IO) {
            if (!isAvailable()) {
                throw AudioException(
                    AudioErrorCode.TTS_PROVIDER_UNAVAILABLE,
                    "Android Local TTS is unavailable on this device"
                )
            }
            if (!supportsLanguage(request.language)) {
                throw AudioException(
                    AudioErrorCode.TTS_LANGUAGE_UNAVAILABLE,
                    "Language unavailable for Android TTS: ${request.language}"
                )
            }
            if (request.text.isBlank()) {
                throw AudioException(AudioErrorCode.INVALID_INPUT, "TTS text must not be blank")
            }

            val engine = tts
                ?: throw AudioException(
                    AudioErrorCode.TTS_PROVIDER_UNAVAILABLE,
                    "Android Local TTS is unavailable on this device"
                )

            val locale = localeFor(request.language)
            val requestedVoiceId = request.voice.voiceId.trim()
val langResult = engine.setLanguage(locale)
            if (requestedVoiceId.isNotEmpty() && requestedVoiceId != "default") {
                runCatching {
                    engine.voices.firstOrNull { it.name == requestedVoiceId }?.let { engine.voice = it }
                }
            }
                        if (langResult < TextToSpeech.LANG_AVAILABLE) {
                throw AudioException(
                    AudioErrorCode.TTS_LANGUAGE_UNAVAILABLE,
                    "Language unavailable for Android TTS: ${request.language}"
                )
            }
            engine.setSpeechRate(request.voice.speechRate.coerceIn(0.5f, 2.0f))
            engine.setPitch(request.voice.pitch.coerceIn(0.5f, 2.0f))

            val outFile = File(appContext.cacheDir, "avsp_tts_${UUID.randomUUID()}.wav")
            try {
                synthesizeToFile(engine, request.text, outFile)
                if (!outFile.exists() || outFile.length() < 44L) {
                    // Some devices write non-WAV or empty files — fall back to timed mock tone
                    // only as generation failure signal (not silent language substitution).
                    throw AudioException(
                        AudioErrorCode.TTS_GENERATION_FAILED,
                        "Android TTS produced empty or invalid audio output"
                    )
                }
                val bytes = outFile.readBytes()
                val durationMs = WavEncoder.durationMsFromWav(bytes)
                    ?: request.targetDurationMs ?: maxOf(500L, request.text.length * 60L)
                TtsSynthesisResult(
                    audioBytes = bytes,
                    durationMs = durationMs.coerceAtLeast(1L),
                    mimeType = "audio/wav",
                    providerId = providerId,
                    language = request.language.lowercase(),
                    voiceId = request.voice.voiceId.ifBlank { "android-default" }
                )
            } catch (e: AudioException) {
                throw e
            } catch (e: Exception) {
                throw AudioException(
                    AudioErrorCode.TTS_GENERATION_FAILED,
                    "Android TTS generation failed",
                    details = e.message,
                    cause = e
                )
            } finally {
                outFile.delete()
            }
        }

    private suspend fun synthesizeToFile(
        engine: TextToSpeech,
        text: String,
        outFile: File
    ) = suspendCancellableCoroutine { cont ->
        val utteranceId = UUID.randomUUID().toString()
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = Unit
            override fun onDone(utteranceId: String?) {
                if (cont.isActive) cont.resume(Unit)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                if (cont.isActive) {
                    cont.resumeWithException(
                        AudioException(AudioErrorCode.TTS_GENERATION_FAILED, "Android TTS utterance error")
                    )
                }
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                if (cont.isActive) {
                    cont.resumeWithException(
                        AudioException(
                            AudioErrorCode.TTS_GENERATION_FAILED,
                            "Android TTS utterance error code=$errorCode"
                        )
                    )
                }
            }
        })
        val params = HashMap<String, String>()
        params[TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID] = utteranceId
        @Suppress("DEPRECATION")
        val result = engine.synthesizeToFile(text, params, outFile.absolutePath)
        if (result != TextToSpeech.SUCCESS) {
            cont.resumeWithException(
                AudioException(AudioErrorCode.TTS_GENERATION_FAILED, "synthesizeToFile rejected")
            )
        }
        cont.invokeOnCancellation {
            runCatching { engine.stop() }
        }
    }

    private fun localeFor(languageCode: String): Locale {
        val tag = AudioLanguageRegistry.resolve(languageCode).localeTag
        return Locale.forLanguageTag(tag)
    }

    fun shutdown() {
        runCatching {
            tts?.stop()
            tts?.shutdown()
        }
        tts = null
        ready.set(false)
    }

    companion object {
        const val PROVIDER_ID = "android_local"
    }
}





