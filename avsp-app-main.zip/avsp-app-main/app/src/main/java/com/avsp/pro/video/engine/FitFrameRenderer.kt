package com.avsp.pro.video.engine

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import java.io.File

/**
 * P9: the user's own photos (posters, notices, screenshots) must be shown
 * WHOLE - filling the frame cropped the text off the edges. The picture is
 * centred (with a margin so the slow zoom never cuts it) over a blurred,
 * darkened copy of itself, so the frame is still full.
 */
object FitFrameRenderer {

    /** True when the picture's shape differs enough from the frame that filling would crop it. */
    fun needsFit(srcW: Int, srcH: Int, frameW: Int, frameH: Int): Boolean {
        if (srcW <= 0 || srcH <= 0) return false
        val src = srcW.toDouble() / srcH
        val frame = frameW.toDouble() / frameH
        return kotlin.math.abs(src - frame) / frame > 0.10
    }

    /** Box the picture fits into: inside a 92 % frame, keeping its shape. */
    fun fitBox(srcW: Int, srcH: Int, frameW: Int, frameH: Int, margin: Double = 0.92): RectF {
        val boxW = frameW * margin
        val boxH = frameH * margin
        val scale = minOf(boxW / srcW, boxH / srcH)
        val w = (srcW * scale).toFloat()
        val h = (srcH * scale).toFloat()
        val left = (frameW - w) / 2f
        val top = (frameH - h) / 2f
        return RectF(left, top, left + w, top + h)
    }

    /** Writes the fitted frame as JPEG; returns false if the picture could not be read. */
    fun render(source: File, frameW: Int, frameH: Int, output: File): Boolean {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(source.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxOf(frameW, frameH)) sample *= 2
        val src = BitmapFactory.decodeFile(source.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return false
        val out = Bitmap.createBitmap(frameW, frameH, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val filter = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)

        // Background: cover-scaled, blurred by down/up-scaling, darkened.
        val tinyW = maxOf(1, frameW / 28)
        val tinyH = maxOf(1, frameH / 28)
        val coverScale = maxOf(frameW.toFloat() / src.width, frameH.toFloat() / src.height)
        val cw = src.width * coverScale
        val ch = src.height * coverScale
        val cover = Bitmap.createBitmap(frameW, frameH, Bitmap.Config.ARGB_8888)
        Canvas(cover).drawBitmap(src, null, RectF((frameW - cw) / 2f, (frameH - ch) / 2f, (frameW + cw) / 2f, (frameH + ch) / 2f), filter)
        val tiny = Bitmap.createScaledBitmap(cover, tinyW, tinyH, true)
        cover.recycle()
        val blurred = Bitmap.createScaledBitmap(tiny, frameW, frameH, true)
        tiny.recycle()
        c.drawBitmap(blurred, 0f, 0f, filter)
        blurred.recycle()
        c.drawColor(Color.argb(110, 0, 0, 0))

        // Foreground: the whole picture with a soft shadow.
        val box = fitBox(src.width, src.height, frameW, frameH)
        val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(120, 0, 0, 0)
            setShadowLayer(frameW / 40f, 0f, frameW / 120f, Color.argb(160, 0, 0, 0))
        }
        c.drawRect(box, shadow)
        c.drawBitmap(src, null, box, filter)
        src.recycle()

        output.parentFile?.mkdirs()
        output.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        out.recycle()
        return output.length() > 0
    }
}
