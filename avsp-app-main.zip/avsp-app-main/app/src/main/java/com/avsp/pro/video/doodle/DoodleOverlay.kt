package com.avsp.pro.video.doodle

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.media3.common.OverlaySettings
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.StaticOverlaySettings
import com.avsp.pro.video.engine.Motion

/**
 * P11 DOODLE overlay: the doodle being drawn over the paper. Drawn at 2/3 size
 * and scaled up (soft pen lines don't need full resolution), redrawn every
 * 40 ms only while something is being drawn (~2.2 s), then one still frame.
 * Two bitmaps alternate so Media3 uploads each new frame.
 */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class DoodleOverlay(
    private val spec: DoodleSpec,
    private val seed: Int,
    private val pieceOffsetMs: Long,
    private val pieceDurationMs: Long,
    private val pieceAbsoluteStartMs: Long,
    frameWidth: Int,
    frameHeight: Int
) : BitmapOverlay() {

    private val w = frameWidth * 2 / 3
    private val h = frameHeight * 2 / 3
    private val scale = frameWidth.toFloat() / w
    private var pool: Array<Bitmap>? = null
    private var next = 0
    private var lastKey = Long.MIN_VALUE
    private var last: Bitmap? = null

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = Motion.sceneMs(presentationTimeUs, pieceDurationMs, pieceAbsoluteStartMs, pieceOffsetMs)
        val key = if (ms >= DoodlePlanner.DONE_MS) Long.MAX_VALUE else ms / 40L
        last?.let { if (key == lastKey) return it }
        val bitmaps = pool ?: Array(2) { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) }.also { pool = it }
        val b = bitmaps[next]
        next = 1 - next
        DoodleRenderer.draw(Canvas(b), spec, if (key == Long.MAX_VALUE) DoodlePlanner.DONE_MS else ms, w, h, seed)
        lastKey = key
        last = b
        return b
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        StaticOverlaySettings.Builder().setScale(scale, scale).build()
}
