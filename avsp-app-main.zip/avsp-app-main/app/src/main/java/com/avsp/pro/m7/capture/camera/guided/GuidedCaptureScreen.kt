package com.avsp.pro.m7.capture.camera.guided

import android.Manifest
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.avsp.pro.m7.core.theme.*

@Composable
fun GuidedCaptureScreen(
    template: GuidedCaptureTemplate,
    onFinished: (List<ClipMetadata>) -> Unit,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val viewModel: GuidedCaptureViewModel = viewModel(
        factory = GuidedCaptureViewModelFactory(context)
    )
    val state by viewModel.state.collectAsState()

    LaunchedEffect(template) { viewModel.loadTemplate(template) }
    // P20: the camera is released when this screen closes (it may be hosted inside another screen).
    DisposableEffect(Unit) { onDispose { viewModel.release() } }

    // Orientation sensor (M6 feature #12)
    DisposableEffect(Unit) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event != null && event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
                    val x = event.values[0]
                    val y = event.values[1]
                    val roll = Math.toDegrees(Math.atan2(x.toDouble(), y.toDouble())).toFloat()
                    viewModel.onDeviceOrientationChanged(roll.toInt())
                    viewModel.onMotion(x, y, event.values[2])
                }
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        sensorManager?.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_UI)
        onDispose { sensorManager?.unregisterListener(listener) }
    }

    // Permissions (M6 test #11)
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val cameraGranted = permissions[Manifest.permission.CAMERA] == true
        val audioGranted = permissions[Manifest.permission.RECORD_AUDIO] == true
        viewModel.onPermissionResult(cameraGranted, audioGranted)
    }

    LaunchedEffect(Unit) {
        val cameraGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
            PackageManager.PERMISSION_GRANTED
        val audioGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        viewModel.onPermissionResult(cameraGranted, audioGranted)
        if (!cameraGranted) {
            permissionsLauncher.launch(
                arrayOf(
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
            )
        }
    }

    var previewViewRef by remember { mutableStateOf<PreviewView?>(null) }
    LaunchedEffect(state.currentClipIndex, previewViewRef, state.phase == GuidedCapturePhase.READY) {
        val pv = previewViewRef
        // P20.0.2: bind ONLY when ready. This effect also re-runs when the phase leaves READY
        // (countdown / recording); rebinding then closed the camera under the running
        // recording -> "Recording finalized with error code 4" (source inactive).
        if (pv != null && state.phase == GuidedCapturePhase.READY) {
            viewModel.bindCamera(lifecycleOwner, pv)
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        if (state.phase == GuidedCapturePhase.PERMISSION_REQUIRED) {
            PermissionRequiredView(onExit)
            return@Box
        }
        if (state.phase == GuidedCapturePhase.ERROR) {
            ErrorView(state.errorMessage ?: "Unknown error", onRetry = { viewModel.retryCurrent(template) }, onExit = onExit)
            return@Box
        }
        if (state.phase == GuidedCapturePhase.COMPLETE) {
            CompleteView(state.completedClips, (state.template?.clips?.size ?: 0) - state.completedClips.size, onFinished)
            return@Box
        }

        // Camera preview
        AndroidView(
            factory = { ctx -> PreviewView(ctx).also { previewViewRef = it } },
            modifier = Modifier.fillMaxSize()
        )

        if (state.isGridEnabled) {
            GuidedGridOverlay(modifier = Modifier.fillMaxSize())
        }

        // Top bar: clip name/category, aspect ratio, flash, grid
        Row(
            modifier = Modifier.fillMaxWidth().padding(16.dp).align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            state.currentClip?.let { clip ->
                Surface(shape = RoundedCornerShape(8.dp), color = Slate900.copy(alpha = 0.8f)) {
                    Text(
                        text = if (clip.sceneId != null) "${state.currentClipIndex + 1}/${state.template?.clips?.size ?: 0} • ${clip.clipName}"
                        else "${clip.clipName} • ${clip.category} • ${clip.aspectRatio.displayName} • ${clip.targetDurationSeconds}s",
                        color = Slate100,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                IconButton(onClick = { viewModel.toggleFlash() }) {
                    Icon(
                        if (state.isFlashOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        contentDescription = "Flash",
                        tint = Slate100
                    )
                }
                IconButton(onClick = { viewModel.toggleGrid() }) {
                    Icon(Icons.Default.GridOn, contentDescription = "Grid", tint = if (state.isGridEnabled) Emerald500 else Slate400)
                }
                if (state.currentClip?.sceneId != null) {
                    TextButton(onClick = { viewModel.toggleAutoCapture() }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("AUTO", color = if (state.autoCapture) Emerald500 else Slate100, fontWeight = FontWeight.Bold) }
                    TextButton(onClick = { viewModel.togglePro() }, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("PRO", color = if (state.showPro) Emerald500 else Slate100, fontWeight = FontWeight.Bold) }
                    TextButton(onClick = { viewModel.finishNow() }, enabled = state.phase != GuidedCapturePhase.RECORDING, contentPadding = PaddingValues(horizontal = 6.dp)) { Text("Finish", color = Slate100, maxLines = 1, softWrap = false, fontSize = 13.sp) }
                }
            }
        }

        // P20: what to film for this scene, and the shot's lens choices.
        state.currentClip?.takeIf { it.sceneId != null }?.let { clip ->
            Column(
                modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(top = 70.dp, start = 12.dp, end = 12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (state.phase == GuidedCapturePhase.READY || state.phase == GuidedCapturePhase.COUNTDOWN) {
                    Surface(shape = RoundedCornerShape(10.dp), color = Slate900.copy(alpha = 0.78f)) {
                        Column(Modifier.padding(10.dp)) {
                            Text(clip.instruction, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Text(
                                listOfNotNull(
                                    clip.category,
                                    clip.movement.takeIf { it.isNotBlank() },
                                    if (clip.mediaType == GuidedClipMediaType.PHOTO) "Photo" else "${clip.targetDurationSeconds} s",
                                    if (clip.slowMotion) "Slow motion (${state.boundFps} fps)" else if (clip.mediaType == GuidedClipMediaType.VIDEO) "${state.boundFps} fps" else null,
                                    clip.resolution.displayName
                                ).joinToString(" · "),
                                color = Slate200, fontSize = 12.sp
                            )
                        }
                    }
                    val caps = state.caps
                    if (caps != null && !clip.frontCamera) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0.5f, 1f, 2f, 3f).filter { it >= caps.minZoom - 0.01f && it <= caps.maxZoom + 0.01f }.forEach { z ->
                                val selected = kotlin.math.abs((state.zoomRatio ?: clip.zoomRatio ?: 1f) - z) < 0.05f
                                FilterChip(colors = camChip(), 
                                    selected = selected,
                                    onClick = { viewModel.setZoom(z) },
                                    label = { Text(if (z < 1f) "0.5×" else "${z.toInt()}×", color = Color.White) }
                                )
                            }
                        }
                    }
                }
                // P25 live tips: phone check (light, focus, level) + AI look at the frame.
                val live = state.liveTip
                if (live != null && (state.phase == GuidedCapturePhase.READY || state.phase == GuidedCapturePhase.RECORDING || state.phase == GuidedCapturePhase.COUNTDOWN)) {
                    Surface(shape = RoundedCornerShape(10.dp), color = Color(0xFFB45309).copy(alpha = 0.92f)) {
                        Text("⚠ $live", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }
                if (state.phase == GuidedCapturePhase.READY) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(10.dp), color = Slate900.copy(alpha = 0.78f), modifier = Modifier.weight(1f, fill = false)) {
                            Text(
                                when {
                                    state.aiChecking -> "✨ AI is looking at your shot…"
                                    state.aiTip != null -> (if (state.aiOk) "✅ " else "✨ ") + state.aiTip
                                    else -> "✨ Tap AI check - AI tells you if this shot fits the scene"
                                },
                                color = if (state.aiOk) Emerald500 else Color.White, fontSize = 13.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                        FilterChip(colors = camChip(), selected = false, enabled = !state.aiChecking,
                            onClick = { viewModel.askAiTip() }, label = { Text("AI check", color = Color.White) })
                    }
                }
                if (state.autoCapture && state.phase == GuidedCapturePhase.READY) {
                    Surface(shape = RoundedCornerShape(10.dp), color = Slate900.copy(alpha = 0.78f)) {
                        Column(Modifier.padding(10.dp).fillMaxWidth()) {
                            Text(if (state.steadyProgress > 0f) "Hold steady… recording starts by itself" else "Auto: frame the shot and hold the phone steady and level",
                                color = Color.White, fontSize = 13.sp)
                            LinearProgressIndicator(progress = { state.steadyProgress }, modifier = Modifier.fillMaxWidth().padding(top = 6.dp).height(4.dp), color = Emerald500, trackColor = Slate800)
                        }
                    }
                }
                if (state.autoCapture && state.phase == GuidedCapturePhase.REVIEW && !state.isLastClip) {
                    Surface(shape = RoundedCornerShape(10.dp), color = Slate900.copy(alpha = 0.78f)) {
                        Text("Next scene in 3 s - tap Retake to film again", color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(10.dp))
                    }
                }
                if (state.showPro) ProPanel(state, viewModel, previewViewRef)
            }
        }

        // Countdown overlay
        if (state.phase == GuidedCapturePhase.COUNTDOWN) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(text = "${state.countdownSecondsRemaining}", color = Color.White, fontSize = 96.sp, fontWeight = FontWeight.Black)
            }
        }

        // Recording progress (M6 feature #19)
        if (state.phase == GuidedCapturePhase.RECORDING) {
            Column(
                modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter).padding(top = 64.dp, start = 16.dp, end = 16.dp)
            ) {
                LinearProgressIndicator(
                    progress = { state.progressFraction },
                    modifier = Modifier.fillMaxWidth().height(4.dp),
                    color = Rose500,
                    trackColor = Slate800
                )
                Text(
                    text = "${state.elapsedMs / 1000}s / ${state.targetDurationMs / 1000}s",
                    color = Slate200,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }

        // Exposure slider (M6 feature #14)
        if (state.exposureRange.first != 0 || state.exposureRange.last != 0) {
            Column(
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 12.dp).height(200.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Slider(
                    value = state.exposureIndex.toFloat(),
                    onValueChange = { viewModel.setExposureIndex(it.toInt()) },
                    valueRange = state.exposureRange.first.toFloat()..state.exposureRange.last.toFloat(),
                    steps = (state.exposureRange.last - state.exposureRange.first - 1).coerceAtLeast(0),
                    modifier = Modifier.width(160.dp).rotate(-90f)
                )
            }
        }

        // Bottom controls
        Row(
            modifier = Modifier.fillMaxWidth().align(Alignment.BottomCenter).padding(24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            when (state.phase) {
                GuidedCapturePhase.READY -> {
                    if (state.currentClip?.sceneId != null) {
                        OutlinedButton(onClick = { viewModel.skip() }) { Text("Skip", color = Slate100) }
                    }
                    Button(
                        onClick = { viewModel.beginCapture() },
                        colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                        shape = CircleShape,
                        modifier = Modifier.size(72.dp)
                    ) {}
                }
                GuidedCapturePhase.RECORDING -> {
                    Button(
                        onClick = { viewModel.stopRecording() },
                        colors = ButtonDefaults.buttonColors(containerColor = Rose500),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.size(72.dp)
                    ) {}
                }
                GuidedCapturePhase.COUNTDOWN -> {
                    OutlinedButton(onClick = { viewModel.cancelCountdown() }) { Text("Cancel") }
                }
                GuidedCapturePhase.REVIEW -> {
                    OutlinedButton(onClick = { viewModel.retake() }, colors = ButtonDefaults.outlinedButtonColors(contentColor = Rose500)) {
                        Icon(Icons.Default.Refresh, contentDescription = "Retake")
                        Spacer(Modifier.width(6.dp))
                        Text("RETAKE")
                    }
                    Button(onClick = { viewModel.acceptAndAdvance() }, colors = ButtonDefaults.buttonColors(containerColor = Emerald500)) {
                        Icon(Icons.Default.Check, contentDescription = "Keep")
                        Spacer(Modifier.width(6.dp))
                        Text(if (state.isLastClip) "FINISH" else "NEXT")
                    }
                }
                GuidedCapturePhase.SAVING -> {
                    CircularProgressIndicator(color = Slate100)
                }
                else -> Unit
            }
        }
    }
}

@Composable
private fun PermissionRequiredView(onExit: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Camera permission is required for guided capture.", color = Slate100)
            Spacer(Modifier.height(12.dp))
            OutlinedButton(onClick = onExit) { Text("Back") }
        }
    }
}

@Composable
private fun ErrorView(message: String, onRetry: () -> Unit, onExit: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = Rose500, modifier = Modifier.size(40.dp))
            Spacer(Modifier.height(12.dp))
            Text(message, color = Slate100, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onExit) { Text("Exit") }
                Button(onClick = onRetry) { Text("Retry") }
            }
        }
    }
}

@Composable
private fun CompleteView(clips: List<ClipMetadata>, notFilmed: Int, onFinished: (List<ClipMetadata>) -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Emerald500, modifier = Modifier.size(48.dp))
            Spacer(Modifier.height(12.dp))
            Text("${clips.size} clips captured", color = Slate100, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            if (notFilmed > 0) Text("$notFilmed scene(s) not filmed - filled from your phone, free pictures or an animated card", color = Slate200, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
            Spacer(Modifier.height(16.dp))
            Button(onClick = { onFinished(clips) }, colors = ButtonDefaults.buttonColors(containerColor = Emerald500)) {
                Text("Done")
            }
        }
    }
}


/** P20 Pro panel: ISO, shutter speed, white balance, exposure and focus lock - only what this phone offers. */
@Composable
private fun ProPanel(state: GuidedCaptureState, viewModel: GuidedCaptureViewModel, previewView: PreviewView?) {
    val caps = state.caps ?: return
    val pro = state.pro
    Surface(shape = RoundedCornerShape(10.dp), color = Slate900.copy(alpha = 0.85f)) {
        Column(Modifier.padding(10.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "This phone: up to ${caps.maxFps} fps · zoom ${"%.1f".format(caps.minZoom)}×–${"%.0f".format(caps.maxZoom)}× · " +
                    (if (caps.stabilization) "stabilisation on" else "no stabilisation") + " · " +
                    (if (caps.manualSensor) "manual ISO/shutter" else "auto exposure only"),
                color = Slate200, fontSize = 11.sp
            )
            val isoRange = caps.isoRange
            val expRange = caps.exposureNsRange
            if (caps.manualSensor && isoRange != null && expRange != null) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (pro.iso == null) "ISO auto" else "ISO ${pro.iso}", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(76.dp))
                    Slider(
                        value = (pro.iso ?: 0).toFloat(),
                        onValueChange = { v ->
                            val iso = if (v < isoRange.first) null else v.toInt().coerceIn(isoRange.first, isoRange.last)
                            viewModel.setPro(pro.copy(iso = iso, exposureNs = if (iso == null) null else pro.exposureNs ?: 1_000_000_000L / 60))
                        },
                        valueRange = 0f..isoRange.last.coerceAtMost(3200).toFloat()
                    )
                }
                val shutters = listOf(30, 60, 125, 250, 500, 1000, 2000, 4000)
                    .filter { 1_000_000_000L / it in expRange && it >= state.boundFps.coerceAtLeast(24) }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    shutters.take(6).forEach { d ->
                        val ns = 1_000_000_000L / d
                        FilterChip(colors = camChip(), 
                            selected = pro.exposureNs == ns && pro.iso != null,
                            onClick = { viewModel.setPro(pro.copy(exposureNs = ns, iso = pro.iso ?: isoRange.first.coerceAtLeast(100))) },
                            label = { Text("1/$d", color = Color.White, fontSize = 11.sp) }
                        )
                    }
                }
            }
            val wb = listOf(
                android.hardware.camera2.CaptureRequest.CONTROL_AWB_MODE_AUTO to "Auto",
                android.hardware.camera2.CaptureRequest.CONTROL_AWB_MODE_DAYLIGHT to "Sun",
                android.hardware.camera2.CaptureRequest.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT to "Cloud",
                android.hardware.camera2.CaptureRequest.CONTROL_AWB_MODE_INCANDESCENT to "Bulb",
                android.hardware.camera2.CaptureRequest.CONTROL_AWB_MODE_FLUORESCENT to "Tube"
            ).filter { it.first in caps.whiteBalanceModes }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                wb.forEach { (mode, name) ->
                    FilterChip(colors = camChip(), selected = pro.whiteBalance == mode, onClick = { viewModel.setPro(pro.copy(whiteBalance = mode)) },
                        label = { Text(name, color = Color.White, fontSize = 11.sp) })
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                FilterChip(colors = camChip(), selected = pro.aeLock, onClick = { viewModel.setPro(pro.copy(aeLock = !pro.aeLock)) },
                    label = { Text("Lock exposure", color = Color.White, fontSize = 11.sp) })
                FilterChip(colors = camChip(), selected = pro.focusLock, onClick = { previewView?.let { viewModel.lockFocus(it, !pro.focusLock) } },
                    label = { Text("Lock focus", color = Color.White, fontSize = 11.sp) })
                if (pro.isActive() || pro.focusLock) TextButton(onClick = {
                    previewView?.let { viewModel.lockFocus(it, false) }
                    viewModel.setPro(ProSettings())
                }) { Text("Reset", color = Slate100, fontSize = 11.sp) }
            }
        }
    }
}


/** P22.1: camera chips readable over any picture - dark glass when off, bright green when on. */
@Composable
private fun camChip() = FilterChipDefaults.filterChipColors(
    containerColor = Color.Black.copy(alpha = 0.6f),
    labelColor = Color.White,
    selectedContainerColor = Emerald500,
    selectedLabelColor = Color.Black
)
