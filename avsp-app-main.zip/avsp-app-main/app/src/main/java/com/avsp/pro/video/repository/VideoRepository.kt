package com.avsp.pro.video.repository

import com.avsp.pro.audio.integration.AudioToVideoContract
import com.avsp.pro.audio.repository.AudioRepository
import com.avsp.pro.logs.AvspLogger
import com.avsp.pro.repository.ProjectRepository
import com.avsp.pro.script.repository.ScriptRepository
import com.avsp.pro.storage.AvspStorage
import com.avsp.pro.video.contract.VideoRenderPlan
import com.avsp.pro.video.contract.VideoRenderResult
import com.avsp.pro.video.contract.VideoRenderPlanFactory
import com.avsp.pro.video.engine.VideoEngine
import com.avsp.pro.media.BundledMediaSeeder
import com.avsp.pro.video.export.VideoMediaStoreExporter


interface VideoRepository {
    suspend fun importVideoFile(projectId: String, sourceFile: java.io.File, fileName: String = sourceFile.name, mimeType: String = "video/mp4"): com.avsp.pro.core.contracts.MediaAsset
    suspend fun buildPlan(projectId: String): VideoRenderPlan
    suspend fun render(projectId: String): VideoRenderResult
}
class VideoRepositoryImpl(
    private val projectRepository: ProjectRepository,
    private val audioRepository: AudioRepository,
    private val scriptRepository: ScriptRepository,
    private val storage: AvspStorage,
    private val engine: VideoEngine,
    private val logger: AvspLogger,
    private val bundledMediaSeeder: BundledMediaSeeder,
    private val mediaStoreExporter: VideoMediaStoreExporter
) : VideoRepository {

    override suspend fun importVideoFile(
        projectId: String,
        sourceFile: java.io.File,
        fileName: String,
        mimeType: String
    ): com.avsp.pro.core.contracts.MediaAsset {
        require(sourceFile.exists()) { "Video source file not found: ${sourceFile.absolutePath}" }
        projectRepository.openProject(projectId)
        val safeName = fileName.substringAfterLast('/').substringAfterLast('\\').ifBlank { "imported_video.mp4" }
        val relativePath = "media/imported/$safeName"
        storage.openOutput(
            com.avsp.pro.storage.StorageArea.PROJECT_DATA,
            relativePath,
            projectId
        ).use { output ->
            sourceFile.inputStream().use { input -> input.copyTo(output) }
        }
        val asset = com.avsp.pro.core.contracts.MediaAsset(
            assetId = "video_${System.currentTimeMillis()}",
            projectId = projectId,
            fileName = safeName,
            relativePath = relativePath,
            mimeType = mimeType,
            sizeBytes = sourceFile.length(),
            createdAt = System.currentTimeMillis(),
            tags = listOf("m5-import", "video")
        )
        projectRepository.addMediaAsset(asset)
        return asset
    }
    override suspend fun buildPlan(projectId: String): VideoRenderPlan {
        val project = projectRepository.openProject(projectId)
        bundledMediaSeeder.ensureForProject(projectId)

        val audio = audioRepository.load(projectId)
            ?: error("M3 audio package not found. Generate Audio/TTS first.")

        val handoff = AudioToVideoContract.fromPackage(audio)
        val script = scriptRepository.load(projectId, handoff.scriptId)

        /*
         * P2: the project's own photos/videos are used first (in order).
         * Scenes without own media get a designed scene card (gradient +
         * headline + narration caption) instead of bundled test clips or a
         * black placeholder.
         */
        val allAssets = projectRepository.listMediaAssets(projectId)
            .filter { it.mimeType.startsWith("video/") || it.mimeType.startsWith("image/") }
            .filterNot { it.tags.contains("m4-test") }
            .sortedBy { it.createdAt }
        /* P7 manual mode: media the user picked for a specific scene ("scene:<scriptId>:<sceneId>"). */
        val sceneAssigned = allAssets.mapNotNull { asset ->
            asset.tags.firstOrNull { it.startsWith("scene:${handoff.scriptId}:") }
                ?.substringAfterLast(':')
                ?.let { sceneId -> sceneId to asset }
        }.toMap()
        val ownAssets = allAssets.filterNot { a -> a.tags.contains("stock") || a.tags.any { it.startsWith("scene:") } }
        /* P2.2: short bundled clip used as the timing base under scene cards. */
        val cardBase = projectRepository.listMediaAssets(projectId)
            .firstOrNull { it.tags.contains("m4-test") && it.mimeType.startsWith("video/") }
        /* Stock clips fetched for THIS script, by scene. */
        // P11: doodle style = hand-drawn animation instead of free stock pictures (own media still used).
        val doodleStyle = project.metadata["visual.style"] == "doodle"
        val doodles = mutableMapOf<String, com.avsp.pro.video.doodle.DoodleSpec>()
        val stockByScene = allAssets
            .filter { it.tags.contains("stock") && !doodleStyle }
            .mapNotNull { asset ->
                asset.tags.firstOrNull { it.startsWith("stock:${handoff.scriptId}:") }
                    ?.substringAfterLast(':')
                    ?.let { sceneId -> sceneId to asset }
            }
            .toMap()

        val (cardWidth, cardHeight) = project.aspectRatio.width to project.aspectRatio.height
        val orderedSegments = handoff.segments.sortedBy { it.order }
        val scriptScenes = script?.scenes?.associateBy { it.sceneId }.orEmpty()
        val cardScenes = mutableSetOf<String>()
        val cardPaths = mutableMapOf<String, String>()

        val visuals = mutableMapOf<String, String>()
        val mime = mutableMapOf<String, String>()
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        orderedSegments.forEachIndexed { index, segment ->
            val own = sceneAssigned[segment.sceneId] ?: stockByScene[segment.sceneId].takeIf { sceneAssigned.isNotEmpty() }
                ?: ownAssets.getOrNull(index) ?: stockByScene[segment.sceneId]
            if (own != null) {
                visuals[segment.sceneId] = own.relativePath
                mime[segment.sceneId] = own.mimeType
                // P9: the user's own pictures are shown whole (no cropped poster text).
                if (own.mimeType.startsWith("image/") && !own.tags.contains("stock")) {
                    runCatching {
                        val src = java.io.File(storage.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, own.relativePath, projectId))
                        val b = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        android.graphics.BitmapFactory.decodeFile(src.absolutePath, b)
                        if (com.avsp.pro.video.engine.FitFrameRenderer.needsFit(b.outWidth, b.outHeight, cardWidth, cardHeight)) {
                            val rel = "video/fitted/${own.assetId}_${cardWidth}x${cardHeight}.jpg"
                            val out = java.io.File(storage.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, rel, projectId))
                            if (out.exists() || com.avsp.pro.video.engine.FitFrameRenderer.render(src, cardWidth, cardHeight, out)) {
                                visuals[segment.sceneId] = rel
                                mime[segment.sceneId] = "image/jpeg"
                            }
                        }
                    }.onFailure { logger.warning("M4", "Own picture shown cropped", details = it.toString(), projectId = projectId) }
                }
            } else {
                val relative = "video/cards/${segment.sceneId}_${cardWidth}x${cardHeight}.png"
                val scene = scriptScenes[segment.sceneId]
                val isCtaScene = index == orderedSegments.lastIndex && orderedSegments.size > 1
                // P11: picture-less scenes become a hand-drawn doodle on paper (the CTA keeps its designed card).
                val doodle = if (!isCtaScene) runCatching {
                    com.avsp.pro.video.doodle.DoodlePlanner.plan(scene?.onScreenText.orEmpty().ifBlank { script?.title.orEmpty() }, scene?.narration.orEmpty(), index)
                }.getOrNull() else null
                if (doodle != null && runCatching {
                        com.avsp.pro.video.doodle.DoodleRenderer.renderPaper(cardWidth, cardHeight,
                            java.io.File(storage.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, "video/cards/paper_${cardWidth}x${cardHeight}.png", projectId)))
                    }.isSuccess) {
                    doodles[segment.sceneId] = doodle
                    val paper = "video/cards/paper_${cardWidth}x${cardHeight}.png"
                    if (cardBase != null) {
                        visuals[segment.sceneId] = cardBase.relativePath
                        mime[segment.sceneId] = cardBase.mimeType
                        cardPaths[segment.sceneId] = paper
                    } else {
                        visuals[segment.sceneId] = paper
                        mime[segment.sceneId] = "image/png"
                    }
                    cardScenes += segment.sceneId
                    return@forEachIndexed
                }
                com.avsp.pro.video.engine.SceneCardRenderer.render(
                    card = com.avsp.pro.video.engine.SceneCardRenderer.Card(
                        title = script?.title.orEmpty(),
                        // P8: the CTA outro shows Like • Follow • Share + icons; no headline under them.
                        headline = if (index == orderedSegments.lastIndex && orderedSegments.size > 1) "" else scene?.onScreenText.orEmpty(),
                        narration = "", // P6: narration is shown as synced captions instead
                        index = index,
                        count = orderedSegments.size,
                        brandOutro = index == orderedSegments.lastIndex && orderedSegments.size > 1
                    ),
                    width = cardWidth,
                    height = cardHeight,
                    output = java.io.File(storage.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, relative, projectId))
                )
                if (cardBase != null) {
                    visuals[segment.sceneId] = cardBase.relativePath
                    mime[segment.sceneId] = cardBase.mimeType
                    cardPaths[segment.sceneId] = relative
                } else {
                    visuals[segment.sceneId] = relative
                    mime[segment.sceneId] = "image/png"
                }
                cardScenes += segment.sceneId
            }
        }
        }

        val (width, height) = project.aspectRatio.width to project.aspectRatio.height

        val plan = VideoRenderPlanFactory.fromAudio(
            handoff,
            visuals,
            mime,
            width,
            height
        )

        val overlayByScene = script?.scenes
            ?.associate { it.sceneId to it.onScreenText.trim() }
            .orEmpty()

        // P6: original background music (synthesized once per project, no licence needed).
        val musicRelative = "audio/music/avsp_ambient_v1.wav"
        try {
            val f = java.io.File(storage.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, musicRelative, projectId))
            if (!f.exists()) {
                f.parentFile?.mkdirs()
                f.writeBytes(com.avsp.pro.video.engine.PolishPlanner.musicWav())
            }
        } catch (t: Throwable) {
            logger.warning("M4", "Background music skipped", details = t.toString(), projectId = projectId)
        }
        // P15: real free music (downloaded by AutoProducer while the voice was made; no network here).
        var chosenMusic = musicRelative
        var musicGain = 1f
        val free = if (project.metadata["music"] == "generated") null else runCatching {
            com.avsp.pro.media.FreeMusicProvider.cached(java.io.File(storage.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, "audio/music", projectId)))
        }.getOrNull()
        if (free != null) {
            chosenMusic = "audio/music/" + free.first.name
            musicGain = 0.13f
            logger.info("M4", "Free music used: ${free.second}", projectId = projectId)
        }
        val musicFile = java.io.File(storage.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, chosenMusic, projectId))
        val lastSceneId = plan.scenes.maxByOrNull { it.order }?.sceneId

        return plan.copy(
            polish = true,
            musicRelativePath = chosenMusic.takeIf { musicFile.exists() },
            musicGain = musicGain,
            scenes = plan.scenes.map {
                it.copy(
                    narration = scriptScenes[it.sceneId]?.narration.orEmpty(),
                    isCta = it.sceneId == lastSceneId && plan.scenes.size > 1,
                    /* Cards already show the headline; overlay only on own media. */
                    overlayText = if (it.sceneId in cardScenes) null
                    else overlayByScene[it.sceneId].takeUnless { text -> text.isNullOrBlank() },
                    cardRelativePath = cardPaths[it.sceneId],
                    doodle = doodles[it.sceneId],
                    /* P20: a slow-motion shot from Plan & shoot plays slower ("speed:0.5"). */
                    speed = sceneAssigned[it.sceneId]?.takeIf { a -> a.mimeType.startsWith("video/") }
                        ?.tags?.firstOrNull { t -> t.startsWith("speed:") }?.removePrefix("speed:")?.toFloatOrNull()
                        ?.coerceIn(0.25f, 1f) ?: 1f
                )
            }
        )
    }

    override suspend fun render(projectId: String): VideoRenderResult {
        val plan = buildPlan(projectId)

        val result = try {
            engine.render(plan)
        } catch (e: Exception) {
            // P20: if this phone cannot slow a clip down, make the video at normal speed rather than fail.
            if (e is kotlinx.coroutines.CancellationException || plan.scenes.none { it.speed < 1f }) throw e
            logger.warning("M4", "Slow motion not possible here - normal speed used", details = e.message, projectId = projectId)
            engine.render(plan.copy(scenes = plan.scenes.map { it.copy(speed = 1f) }))
        }

        val exported = mediaStoreExporter.export(
            sourceFile = java.io.File(result.outputAbsolutePath),
            projectId = projectId
        )

        val finalResult = result.copy(
            exportedUri = exported.uri.toString(),
            exportedRelativePath = exported.relativePath,
            exportedDisplayName = exported.displayName
        )

        val project = projectRepository.openProject(projectId)

        projectRepository.updateProject(
            project.copy(
                duration = finalResult.durationMs,
                outputPath = finalResult.outputRelativePath
            )
        )

        logger.info(
            "M4",
            "Video rendered and exported",
            details = "${finalResult.outputRelativePath} -> ${exported.displayName}",
            projectId = projectId
        )

        return finalResult
    }
}
