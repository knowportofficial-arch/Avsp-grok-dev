﻿package com.avsp.pro.video.engine

import com.avsp.pro.video.contract.VideoEmojiInput

object TimedEmojiSelector {
    fun active(
        emojis: List<VideoEmojiInput>,
        timeMs: Long
    ): List<VideoEmojiInput> =
        emojis.filter { timeMs >= it.startMs && timeMs < it.endMs }
}
