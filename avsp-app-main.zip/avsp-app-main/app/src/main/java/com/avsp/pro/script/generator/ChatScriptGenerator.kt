package com.avsp.pro.script.generator

import com.avsp.pro.script.contract.ScriptGenerationRequest
import com.avsp.pro.script.contract.ScriptPackage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection

/**
 * P21 BACKUP AI WRITERS (used when Gemini fails or its free quota is used up):
 * Groq (free key, very fast, Meta Llama / open models) and OpenRouter (free ":free" models).
 * Same prompt, same JSON and same checks as the Gemini writer; only the service differs.
 */
class ChatScriptGenerator(
    override val providerId: String,
    override val displayName: String,
    private val endpoint: String,
    private val models: () -> List<String>,
    private val keys: () -> List<String>,
    private val jsonMode: Boolean,
    private val extraHeaders: Map<String, String> = emptyMap(),
    private val http: (String, String, String, Map<String, String>) -> String = ::postChat
) : ScriptGenerator {

    override val mode: GeneratorMode = GeneratorMode.REMOTE
    /** Prompt / parsing / packaging shared with the Gemini writer (no network used from it). */
    private val shared = GeminiScriptGenerator(apiKey = { null })

    override suspend fun generate(request: ScriptGenerationRequest): ScriptPackage = withContext(Dispatchers.IO) {
        val ks = keys().map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        require(ks.isNotEmpty()) { "$displayName key not configured" }
        val targetMs = request.duration.resolveTargetMs()
        val prompt = shared.buildPrompt(request, targetMs, GeminiScriptGenerator.sceneCountFor(targetMs))
        val errors = mutableListOf<String>()
        val started = System.currentTimeMillis()
        for (key in ks.take(3)) {
            for (model in models().take(3)) {
                if (System.currentTimeMillis() - started > 40_000) break
                try {
                    val body = JSONObject()
                        .put("model", model)
                        .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
                        .put("temperature", 0.8)
                        .apply { if (jsonMode) put("response_format", JSONObject().put("type", "json_object")) }
                        .toString()
                    val text = content(http(endpoint, key, body, extraHeaders))
                    return@withContext shared.toPackage(request, shared.parseScript(text), targetMs, "$providerId:$model")
                } catch (t: Throwable) {
                    errors += "$model: ${t.message?.take(100)}"
                    if (GeminiScriptGenerator.isRejected(t.message)) break   // this key is refused - next key
                }
            }
        }
        throw IllegalStateException("$displayName failed: " + errors.joinToString(" | "))
    }

    companion object {
        const val GROQ = "groq"
        const val OPENROUTER = "openrouter"
        /** Key-ring names (encrypted store). */
        const val GROQ_KEY = "groq_api_credential"
        const val OPENROUTER_KEY = "openrouter_api_credential"

        val GROQ_MODELS = listOf("llama-3.3-70b-versatile", "openai/gpt-oss-120b", "meta-llama/llama-4-scout-17b-16e-instruct")
        val OPENROUTER_FALLBACK = listOf("meta-llama/llama-3.3-70b-instruct:free", "deepseek/deepseek-chat-v3.1:free", "google/gemma-3-27b-it:free")

        /** Text of an OpenAI-style chat reply. */
        fun content(raw: String): String =
            JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content")

        /** Free OpenRouter models from its model list, bigger well-known families first. */
        fun freeModels(raw: String): List<String> = runCatching {
            val arr = JSONObject(raw).optJSONArray("data") ?: JSONArray()
            val ids = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }
                .filter { it.optString("id").endsWith(":free") && it.optInt("context_length", 0) >= 8_000 }
                .map { it.optString("id") }
            val rank = listOf("llama-3.3-70b", "deepseek-chat", "deepseek", "qwen", "gemma-3", "llama", "mistral")
            ids.sortedBy { id -> rank.indexOfFirst { id.contains(it) }.let { if (it < 0) 99 else it } }
        }.getOrDefault(emptyList())

        fun postChat(url: String, key: String, body: String, headers: Map<String, String>): String {
            val c = java.net.URI(url).toURL().openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"; c.doOutput = true
                c.connectTimeout = 10_000; c.readTimeout = 40_000
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.setRequestProperty("Authorization", "Bearer $key")
                headers.forEach { (h, v) -> c.setRequestProperty(h, v) }
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                check(code in 200..299) { "HTTP $code" }
                return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally { c.disconnect() }
        }

        fun getText(url: String): String {
            val c = java.net.URI(url).toURL().openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 8_000; c.readTimeout = 15_000
                check(c.responseCode in 200..299) { "HTTP ${c.responseCode}" }
                return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally { c.disconnect() }
        }
    }
}
