package com.avsp.pro.edit

/**
 * P12 THUMBNAIL: the words on a thumbnail (pure, testable) - short and punchy:
 * at most 5 words, site names and filler dropped, one key word to highlight
 * (a number, a name, or the longest word).
 */
object ThumbnailText {
    data class Line(val words: List<String>, val highlight: Int)

    private val DROP = setOf("the", "a", "an", "of", "to", "in", "on", "for", "and", "is", "are", "was", "with", "at", "by", "from",
        "here", "what", "you", "need", "know", "today's", "todays")

    fun make(title: String, maxWords: Int = 7): Line {
        val clean = title.substringBefore(" - ").substringBefore(" | ").replace(Regex("""[\[\](){}"“”]"""), " ").trim()
        val all = clean.split(Regex("""\s+""")).filter { it.isNotBlank() }
        // Keep the title whole when it is short enough (dropping words made it ungrammatical);
        // a long one is cut at a word boundary, never ending on "the / of / and…".
        var words = all.take(maxWords)
        while (words.size > 2 && words.last().lowercase().trim(',', '.', ':', '!') in DROP) words = words.dropLast(1)
        words = words.map { it.trim(',', ';') }.ifEmpty { listOf("Watch") }
        val latin = words.all { w -> w.all { it.code < 0x0900 } }
        val shown = if (latin) words.map { it.uppercase() } else words
        // Highlight: a word with a digit, else a capitalised name (not the first word), else the longest.
        val hi = words.indexOfFirst { w -> w.any(Char::isDigit) }.takeIf { it >= 0 }
            ?: words.indices.drop(1).firstOrNull { words[it].first().isUpperCase() && words[it].length > 3 }
            ?: words.indices.maxByOrNull { words[it].length } ?: 0
        return Line(shown, hi)
    }
}
