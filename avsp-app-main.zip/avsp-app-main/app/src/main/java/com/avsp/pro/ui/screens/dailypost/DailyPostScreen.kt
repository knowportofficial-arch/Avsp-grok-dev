package com.avsp.pro.ui.screens.dailypost

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.avsp.pro.ui.viewmodel.DailyPostViewModel
import com.avsp.pro.core.handoff.DailyPostM5Handoff

enum class DailyPostGeography {
    LOCAL,
    NATIONAL,
    INTERNATIONAL
}

enum class DailyPostCategory {
    TRENDING,
    NEWS,
    HISTORY,
    WHY_TODAY,
    WEATHER,
    RASHIFAL,
    JOKES
}

data class DailyPostItem(
    val id: String,
    val title: String,
    val category: DailyPostCategory,
    val geography: DailyPostGeography,
    val date: String,
    val source: String,
    val summary: String,
    val relevance: String,
    val videoAngle: String
)

private enum class DailyPostFilter(val label: String, val category: DailyPostCategory?) {
    ALL("All", null),
    TRENDING("Trending", DailyPostCategory.TRENDING),
    NEWS("News", DailyPostCategory.NEWS),
    WHY_TODAY("Today's importance", DailyPostCategory.WHY_TODAY),
    HISTORY("On this day", DailyPostCategory.HISTORY),
    WEATHER("Weather", DailyPostCategory.WEATHER),
    RASHIFAL("Rashifal", DailyPostCategory.RASHIFAL),
    JOKES("Jokes", DailyPostCategory.JOKES)
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun DailyPostScreen(
    onBack: () -> Unit,
    onMakeVideo: (DailyPostItem) -> Unit,
    /** P23.2: a blog straight from the topic (photo = swipe slides, else text article). */
    onMakeBlog: (DailyPostItem, Boolean) -> Unit = { _, _ -> },
    viewModel: DailyPostViewModel = viewModel()
) {
    val state by viewModel.state.collectAsState()
    var geography by remember { mutableStateOf<DailyPostGeography?>(null) }
    var category by remember { mutableStateOf(DailyPostFilter.ALL) }

    val filteredPosts = state.posts.filter { post ->
        val geoMatch = geography == null || post.geography == geography
        val categoryMatch = category.category == null || post.category == category.category
        geoMatch && categoryMatch
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Daily Post")
                        Text(
                            "Discover → verify → make video",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                navigationIcon = {
                    TextButton(onClick = onBack) { Text("Back") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("Daily Content", style = MaterialTheme.typography.titleLarge)
                        Text(
                            "Trending • News • Today's importance • On this day • Weather • Rashifal • Jokes"
                        )
                        Text(
                            "Only configured and source-backed content is displayed.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }

            item {
                FilterRow(
                    title = "Geography",
                    chips = listOf(
                        "All" to (geography == null),
                        "Local / Regional" to (geography == DailyPostGeography.LOCAL),
                        "National" to (geography == DailyPostGeography.NATIONAL),
                        "International" to (geography == DailyPostGeography.INTERNATIONAL)
                    ),
                    onClick = { index ->
                        geography = when (index) {
                            0 -> null
                            1 -> DailyPostGeography.LOCAL
                            2 -> DailyPostGeography.NATIONAL
                            else -> DailyPostGeography.INTERNATIONAL
                        }
                    }
                )
            }

            item {
                FilterRow(
                    title = "Content Type",
                    chips = DailyPostFilter.entries.map { it.label to (category == it) },
                    onClick = { index ->
                        category = DailyPostFilter.entries[index]
                    }
                )
            }

            if (category == DailyPostFilter.WEATHER) {
                item {
                    val city by viewModel.city.collectAsState()
                    val msg by viewModel.cityMessage.collectAsState()
                    var editing by remember { mutableStateOf(false) }
                    var text by remember { mutableStateOf("") }
                    Card(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                Text("Weather city: $city", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                TextButton(onClick = { editing = !editing }) { Text(if (editing) "Close" else "Change") }
                            }
                            if (editing) {
                                androidx.compose.material3.OutlinedTextField(
                                    value = text, onValueChange = { text = it }, singleLine = true,
                                    label = { Text("City or town") }, modifier = Modifier.fillMaxWidth()
                                )
                                Button(onClick = { viewModel.changeCity(text); editing = false }, enabled = text.isNotBlank()) { Text("Use this city") }
                            }
                            msg?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
            }

            if (state.loading) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    ) {
                        Text(
                            "Loading Daily Post…",
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            } else if (state.error != null) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text("Provider error", style = MaterialTheme.typography.titleLarge)
                            Text(state.error ?: "")
                            OutlinedButton(onClick = viewModel::refresh) {
                                Text("Retry")
                            }
                        }
                    }
                }
            } else if (state.posts.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Text(
                                "NOT_CONFIGURED",
                                style = MaterialTheme.typography.labelLarge
                            )
                            Text(
                                "No Daily Post provider is configured.",
                                style = MaterialTheme.typography.titleLarge
                            )
                            Text(
                                "No fabricated Trending, News, History or Why Today Matters content is shown."
                            )
                            Text(
                                "Configure an approved RSS/HTTP provider to populate this feed.",
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                    }
                }
            } else if (filteredPosts.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                    ) {
                        Text(
                            "No posts match the selected filters.",
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            } else {
                items(filteredPosts, key = { it.id }) { post ->
                    DailyPostCard(post, onMakeVideo = { onMakeVideo(post) }, onMakeBlog = { photo -> onMakeBlog(post, photo) })
                }
            }

            item { Spacer(Modifier.height(20.dp)) }
        }
    }
}

@Composable
private fun FilterRow(
    title: String,
    chips: List<Pair<String, Boolean>>,
    onClick: (Int) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(6.dp))
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            chips.forEachIndexed { index, chip ->
                FilterChip(
                    selected = chip.second,
                    onClick = { onClick(index) },
                    label = { Text(chip.first) }
                )
            }
        }
    }
}

@Composable
private fun DailyPostCard(
    post: DailyPostItem,
    onMakeVideo: () -> Unit,
    onMakeBlog: (Boolean) -> Unit = {}
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                "${post.category.name.replace('_', ' ')} • ${post.geography.name}",
                style = MaterialTheme.typography.labelLarge
            )
            Text(post.title, style = MaterialTheme.typography.titleLarge)
            Text("Date: ${post.date}", style = MaterialTheme.typography.labelMedium)
            Text("Source: ${post.source}", style = MaterialTheme.typography.labelMedium)
            Text(post.summary)
            if (post.relevance.isNotBlank()) {
                Text(
                    "Why it matters",
                    style = MaterialTheme.typography.titleMedium
                )
                Text(post.relevance)
            }
            Text("Short-video angle", style = MaterialTheme.typography.titleMedium)
            Text(post.videoAngle)
            Button(
                onClick = onMakeVideo,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Make Video")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                androidx.compose.material3.OutlinedButton(onClick = { onMakeBlog(false) }, modifier = Modifier.weight(1f)) { Text("Text blog") }
                androidx.compose.material3.OutlinedButton(onClick = { onMakeBlog(true) }, modifier = Modifier.weight(1f)) { Text("Photo blog") }
            }
        }
    }
}

