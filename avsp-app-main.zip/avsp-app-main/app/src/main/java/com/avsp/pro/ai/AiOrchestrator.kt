package com.avsp.pro.ai

/**
 * Executes an AI request with graceful provider fallback.
 *
 * A provider that throws is treated as failed for this request only. Persistent
 * health/quota state is owned by the provider descriptor/configuration layer;
 * this class never invents quota information.
 */
class AiOrchestrator(
    private val registry: AiProviderRegistry
) {
    suspend fun execute(request: AiRequest): AiExecutionResult {
        val candidates = registry.candidates(request)
        if (candidates.isEmpty()) {
            return AiExecutionResult.Failure(
                capability = request.capability,
                attemptedProviders = emptyList(),
                message = "No available provider supports ${request.capability}"
            )
        }

        val attempted = mutableListOf<String>()

        for (provider in candidates) {
            attempted += provider.descriptor.providerId
            try {
                val output = provider.execute(request)
                if (output.isBlank()) {
                    continue
                }

                return AiExecutionResult.Success(
                    AiResponse(
                        providerId = provider.descriptor.providerId,
                        output = output,
                        fallbackUsed = attempted.size > 1,
                        attemptedProviders = attempted.toList()
                    )
                )
            } catch (_: Throwable) {
                // Continue to the next eligible provider.
            }
        }

        return AiExecutionResult.Failure(
            capability = request.capability,
            attemptedProviders = attempted,
            message = "All eligible providers failed for ${request.capability}"
        )
    }
}