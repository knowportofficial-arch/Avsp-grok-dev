package com.avsp.pro.core.pipeline

import com.avsp.pro.script.contract.ScriptPackage

/**
 * P9.2: the last scene is ONLY a short spoken call to action, at most 3 seconds
 * (≈ 5 words). Anything longer - from the AI or the offline writer - is replaced.
 */
object CtaRule {
    const val MAX_WORDS = 5

    fun spoken(language: String): String = com.avsp.pro.settings.BrandKit.spokenCta(language) ?: when (language.lowercase()) {
        "bn" -> "লাইক, শেয়ার আর ফলো করুন!"
        "hi" -> "लाइक, शेयर और फ़ॉलो करें!"
        else -> "Like, share and follow!"
    }

    fun isShort(text: String): Boolean {
        val words = text.trim().split(Regex("""\s+""")).filter { it.any(Char::isLetterOrDigit) }
        return words.isNotEmpty() && words.size <= MAX_WORDS && text.length <= 40
    }

    /** Returns the same instance when nothing needed changing. */
    fun apply(script: ScriptPackage, language: String): ScriptPackage {
        if (script.scenes.size < 2) return script
        val last = script.scenes.maxByOrNull { it.order } ?: return script
        // P22.1: with a channel name set, the call to action always names the channel.
        val channel = com.avsp.pro.settings.BrandKit.channel
        if (isShort(last.narration) && (channel.isBlank() || last.narration.contains(channel, ignoreCase = true))) return script
        val cta = spoken(language)
        return script.copy(
            cta = cta,
            scenes = script.scenes.map { sc ->
                if (sc.sceneId != last.sceneId) sc
                else sc.copy(narration = cta, onScreenText = cta.trimEnd('!', '.'))
            }
        )
    }
}
