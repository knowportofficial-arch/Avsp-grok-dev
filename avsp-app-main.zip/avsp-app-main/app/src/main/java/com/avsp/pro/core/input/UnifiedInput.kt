﻿package com.avsp.pro.core.input

/**
 * Canonical input types for AVSP Unified Input Intelligence.
 *
 * This layer is deliberately independent from OCR, AI, TTS, video,
 * publishing, camera, or external-provider implementations.
 */
enum class UnifiedInputType {
    TEXT,
    URL,
    YOUTUBE,
    SCREENSHOT,
    IMAGE,
    SCREEN_RECORDING,
    VIDEO,
    AUDIO,
    PDF_DOCUMENT,
    DOCUMENT,
    CAMERA_CAPTURE,
    MEDIA_LIBRARY
}

/**
 * Canonical representation of one user-provided content input.
 *
 * locator is intentionally opaque:
 * it may be text, URL, content:// URI, file URI, path, or another
 * local media reference.
 */
data class UnifiedInput(
    val id: String,
    val type: UnifiedInputType,
    val locator: String,
    val displayName: String? = null,
    val mimeType: String? = null,
    val metadata: Map<String, String> = emptyMap()
)

/**
 * Result of classifying a raw input.
 */
data class UnifiedInputResult(
    val accepted: Boolean,
    val input: UnifiedInput? = null,
    val reason: String? = null
)
