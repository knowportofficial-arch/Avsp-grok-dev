package com.avsp.pro.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avsp.pro.core.contracts.MediaAsset
import com.avsp.pro.core.contracts.Project
import com.avsp.pro.core.error.AvspException
import com.avsp.pro.core.module.ModuleStatus
import com.avsp.pro.core.model.AspectRatio
import com.avsp.pro.core.model.ProjectStatus
import com.avsp.pro.core.ui.UiState
import com.avsp.pro.logs.AvspLogger
import com.avsp.pro.media.BundledMediaSeeder
import com.avsp.pro.repository.ModuleStatusRepository
import com.avsp.pro.repository.ProjectRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ProjectDashboard(
    val project: Project,
    val assets: List<MediaAsset>,
    val modules: List<ModuleStatus>
)

/** P2 one-tap production state shown on the project screen. */
sealed class AutoProduceState {
    data object Idle : AutoProduceState()
    data class Running(val stepIndex: Int, val label: String, val detail: String) : AutoProduceState()
    data class Done(val title: String, val provider: String, val uri: String?, val displayName: String?, val durationMs: Long, val note: String? = null, val kit: com.avsp.pro.core.pipeline.PublishKit? = null, val thumbnail: String? = null) : AutoProduceState()
    data class Failed(val message: String) : AutoProduceState()
}

class ProjectDetailViewModel(
    private val projectRepository: ProjectRepository,
    private val moduleStatusRepository: ModuleStatusRepository,
    private val logger: AvspLogger,
    private val bundledMediaSeeder: BundledMediaSeeder,
    private val autoProducer: com.avsp.pro.core.pipeline.AutoProducer? = null,
    private val blogExporter: com.avsp.pro.core.pipeline.BlogExporter? = null,
    private val smartEdit: com.avsp.pro.edit.SmartEditService? = null,
    private val readyVideo: com.avsp.pro.edit.ReadyVideoService? = null
) : ViewModel() {

    /** P19: an already-edited video -> SEO text + thumbnail, nothing re-edited. */
    sealed class ReadyState {
        data object Idle : ReadyState()
        data class Working(val label: String) : ReadyState()
        data class Done(val outcome: com.avsp.pro.edit.ReadyVideoService.Outcome) : ReadyState()
        data class Failed(val message: String) : ReadyState()
    }

    private val _ready = MutableStateFlow<ReadyState>(ReadyState.Idle)
    val ready: StateFlow<ReadyState> = _ready.asStateFlow()

    fun readyToPost(projectId: String, editedUri: String? = null) {
        val service = readyVideo ?: return
        if (_ready.value is ReadyState.Working) return
        viewModelScope.launch {
            _ready.value = ReadyState.Working("Starting…")
            _ready.value = try {
                ReadyState.Done(service.run(projectId, editedUri) { _ready.value = ReadyState.Working(it) })
            } catch (e: Throwable) {
                logger.error("SEO", "Ready to post failed", details = e.message, projectId = projectId)
                ReadyState.Failed(e.message ?: "Could not prepare the video")
            }
        }
    }

    /** P12: smart edit of the project's own video. */
    sealed class EditState {
        data object Idle : EditState()
        data class Working(val label: String) : EditState()
        data class Done(val outcome: com.avsp.pro.edit.SmartEditService.Outcome) : EditState()
        data class Failed(val message: String) : EditState()
    }

    private val _edit = MutableStateFlow<EditState>(EditState.Idle)
    val edit: StateFlow<EditState> = _edit.asStateFlow()

    fun smartEdit(projectId: String, targetMs: Long? = null) {
        val service = smartEdit ?: return
        if (_edit.value is EditState.Working) return
        viewModelScope.launch {
            _edit.value = EditState.Working("Starting…")
            try {
                _edit.value = EditState.Done(service.run(projectId, targetMs) { _edit.value = EditState.Working(it) })
                load(projectId)
            } catch (e: Throwable) {
                logger.error("EDIT", "Smart edit failed", details = e.message, projectId = projectId)
                _edit.value = EditState.Failed(e.message ?: "Smart edit failed")
            }
        }
    }

    /** P10 blog: text blog (HTML + Markdown) and photo blog (carousel slides). */
    sealed class BlogState {
        data object Idle : BlogState()
        data class Working(val label: String) : BlogState()
        data class TextDone(val blog: com.avsp.pro.core.pipeline.BlogExporter.TextBlog) : BlogState()
        data class PhotoDone(val blog: com.avsp.pro.core.pipeline.BlogExporter.PhotoBlog) : BlogState()
        data class Failed(val message: String) : BlogState()
    }

    private val _blog = MutableStateFlow<BlogState>(BlogState.Idle)
    val blog: StateFlow<BlogState> = _blog.asStateFlow()
    val blogAvailable: Boolean get() = blogExporter != null

    /** P11: "photos" (free pictures) or "doodle" (hand-drawn animation) look for new videos. */
    fun setStyle(projectId: String, style: String) {
        viewModelScope.launch {
            runCatching {
                val p = projectRepository.openProject(projectId)
                projectRepository.updateProject(p.copy(metadata = p.metadata + ("visual.style" to style)))
                logger.info("M1", "Look set to $style", projectId = projectId)
                load(projectId)
            }
        }
    }

    fun makeBlog(projectId: String, photo: Boolean) {
        val exporter = blogExporter ?: return
        if (_blog.value is BlogState.Working) return
        viewModelScope.launch {
            _blog.value = BlogState.Working(if (photo) "Making photo blog…" else "Making text blog…")
            try {
                _blog.value = if (photo) {
                    BlogState.PhotoDone(exporter.makePhotoBlog(projectId) { _blog.value = BlogState.Working(it) })
                } else {
                    BlogState.TextDone(exporter.makeTextBlog(projectId) { _blog.value = BlogState.Working(it) })
                }
            } catch (e: Throwable) {
                logger.error("BLOG", "Blog failed", details = e.message, projectId = projectId)
                _blog.value = BlogState.Failed(e.message ?: "Blog could not be made")
            }
        }
    }

    private val _auto = MutableStateFlow<AutoProduceState>(AutoProduceState.Idle)
    val auto: StateFlow<AutoProduceState> = _auto.asStateFlow()

    val autoAvailable: Boolean get() = autoProducer != null

    /** P33: one line per extra version being made / made. */
    data class VersionJob(val label: String, val status: String, val uri: String? = null, val projectId: String? = null)
    private val _versions = MutableStateFlow<List<VersionJob>>(emptyList())
    val versions: StateFlow<List<VersionJob>> = _versions.asStateFlow()

    /** P33: makes the same video in other languages and/or shapes, one after another. */
    fun makeVersions(projectId: String, durationSeconds: Int, combos: List<Pair<com.avsp.pro.core.model.ProjectLanguage, com.avsp.pro.core.model.AspectRatio>>) {
        val producer = autoProducer ?: return
        if (combos.isEmpty() || _versions.value.any { it.status.endsWith("…") }) return
        _versions.value = combos.map { (l, a) -> VersionJob("${l.displayName} ${a.label}", "Waiting…") }
        viewModelScope.launch {
            combos.forEachIndexed { i, (l, a) ->
                fun set(j: VersionJob) { _versions.value = _versions.value.toMutableList().also { it[i] = j } }
                val label = "${l.displayName} ${a.label}"
                set(VersionJob(label, "Making…"))
                runCatching {
                    val id = producer.cloneAs(projectId, l, a)
                    val r = producer.produce(id, durationSeconds) { p -> set(VersionJob(label, p.step.label + "…", projectId = id)) }
                    set(VersionJob(label, "Ready · ${r.video.durationMs / 1000}s", r.video.exportedUri, id))
                }.onFailure { set(VersionJob(label, "Failed: ${it.message?.take(80)}")) }
            }
        }
    }

    /** P31: the creator's instructions saved for the next version, then a fresh video is made with them. */
    fun remakeWith(projectId: String, durationSeconds: Int, instructions: String) {
        viewModelScope.launch {
            runCatching {
                val p = projectRepository.openProject(projectId)
                projectRepository.updateProject(p.copy(metadata = p.metadata + (com.avsp.pro.core.pipeline.AutoProducer.INSTRUCTIONS_KEY to instructions.trim().take(800))))
            }
            autoProduce(projectId, durationSeconds)
        }
    }

    fun autoProduce(projectId: String, durationSeconds: Int) {
        val producer = autoProducer ?: return
        if (_auto.value is AutoProduceState.Running) return
        viewModelScope.launch {
            _auto.value = AutoProduceState.Running(1, "Writing script", "")
            try {
                val r = producer.produce(projectId, durationSeconds) { p ->
                    _auto.value = AutoProduceState.Running(p.step.ordinal + 1, p.step.label, p.detail)
                }
                _auto.value = AutoProduceState.Done(
                    title = r.title,
                    provider = r.scriptProvider,
                    uri = r.video.exportedUri,
                    displayName = r.video.exportedDisplayName,
                    durationMs = r.video.durationMs,
                    note = r.stockNote,
                    kit = r.kit,
                    thumbnail = r.thumbnail
                )
                load(projectId)
            } catch (e: Throwable) {
                val msg = (e as? AvspException)?.errorInfo?.message ?: e.message ?: "Production failed"
                logger.error("AUTO", "Auto produce failed", details = msg, projectId = projectId)
                _auto.value = AutoProduceState.Failed(msg)
            }
        }
    }

    private val _state = MutableStateFlow<UiState<ProjectDashboard>>(UiState.Idle)
    val state: StateFlow<UiState<ProjectDashboard>> = _state.asStateFlow()

    /** P29: the project's language (for the poll wording when posting a blog). */
    @Volatile var languageCode: String = "en"
        private set
    @Volatile var aspect: com.avsp.pro.core.model.AspectRatio = com.avsp.pro.core.model.AspectRatio.RATIO_9_16
        private set

    fun load(projectId: String) {
        viewModelScope.launch {
            _state.value = UiState.Loading
            try {
                val project = projectRepository.openProject(projectId)
                languageCode = project.language.code
                aspect = project.aspectRatio
                bundledMediaSeeder.ensureForProject(projectId)
                val assets = projectRepository.listMediaAssets(projectId)
                val modules = moduleStatusRepository.getAll()
                _state.value = UiState.Success(
                    ProjectDashboard(project = project, assets = assets, modules = modules)
                )
            } catch (e: Exception) {
                val msg = (e as? AvspException)?.errorInfo?.message ?: e.message ?: "Failed to open project"
                logger.error("M1", "Project detail failed", details = msg, projectId = projectId)
                _state.value = UiState.Error(msg, recoverable = true)
            }
        }
    }

    fun updateAspectRatio(projectId: String, aspectRatio: AspectRatio) {
        viewModelScope.launch {
            try {
                val current = projectRepository.openProject(projectId)
                projectRepository.updateProject(
                    current.copy(
                        aspectRatio = aspectRatio,
                        duration = null,
                        outputPath = null,
                        status = ProjectStatus.DRAFT,
                        updatedAt = System.currentTimeMillis()
                    )
                )
                load(projectId)
            } catch (e: Exception) {
                val msg = (e as? AvspException)?.errorInfo?.message ?: e.message ?: "Aspect ratio update failed"
                _state.value = UiState.Error(msg)
            }
        }
    }

    fun rename(projectId: String, newName: String) {
        viewModelScope.launch {
            try {
                projectRepository.renameProject(projectId, newName)
                load(projectId)
            } catch (e: Exception) {
                val msg = (e as? AvspException)?.errorInfo?.message ?: e.message ?: "Rename failed"
                _state.value = UiState.Error(msg)
            }
        }
    }
}
