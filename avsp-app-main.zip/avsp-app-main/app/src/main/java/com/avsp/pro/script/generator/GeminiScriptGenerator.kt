package com.avsp.pro.script.generator

import com.avsp.pro.script.contract.ScriptGenerationRequest
import com.avsp.pro.script.contract.ScriptMetadata
import com.avsp.pro.script.contract.ScriptPackage
import com.avsp.pro.script.contract.ScriptScene
import com.avsp.pro.script.contract.ScriptValidation
import com.avsp.pro.script.contract.ShotType
import com.avsp.pro.script.contract.TransitionIntent
import com.avsp.pro.script.contract.ValidationStatus
import com.avsp.pro.script.language.ScriptLanguageRegistry
import com.avsp.pro.script.validation.ScriptValidator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.util.UUID
import kotlin.math.max
import kotlin.math.roundToLong

/**
 * P2: real AI script writing through Google Gemini (free-tier API key).
 *
 * The key is read from the encrypted SecureConfigStore (Settings -> AI key);
 * it is never logged or shown. Output is parsed into the existing
 * ScriptPackage contract, so M3/M4 work unchanged.
 */
class GeminiScriptGenerator(
    private val apiKey: () -> String?,
    private val http: (String, String, String) -> String = ::postJson,
    /* P2.2: asks Google which models this key can use (models get retired). */
    private val listModels: (String) -> String = ::getModels,
    private val retryPause: () -> Unit = { Thread.sleep(3_000) },
    /* P3.1: whole AI attempt is time-boxed; when Google is overloaded we go offline fast. */
    private val now: () -> Long = System::currentTimeMillis,
    private val budgetMs: Long = BUDGET_MS,
    /* P9: all saved keys, key 1 first; the next key is tried when one is rejected or out of quota. */
    private val apiKeys: () -> List<String> = { listOfNotNull(apiKey()?.trim()?.takeIf { it.isNotEmpty() }) },
    /* P9: told which key number worked, so it is tried first next time. */
    private val onKeyWorked: (Int) -> Unit = {},
    /* P9.3: the quota pause survives app restarts ("until|keySet"). */
    private val loadPause: () -> String? = { null },
    private val savePause: (String) -> Unit = {}
) : ScriptGenerator {

    @Volatile
    private var discovered: List<String>? = null

    @Volatile private var quotaKeySet: Int = 0
    @Volatile private var quotaPauseUntil: Long = 0L
    @Volatile private var lastGood: String? = null

    /** Model ids to try, best first: discovered flash models, then known names. */
    internal fun modelsToTry(key: String): List<String> {
        val found = discovered ?: runCatching { rankModels(listModels(key)) }.getOrDefault(emptyList())
            .also { if (it.isNotEmpty()) discovered = it }
        // P17: the model that last worked goes first (the newest is often "high demand"), then the
        // newest models this key can see; old fixed names only when the list is unavailable.
        return (listOfNotNull(lastGood) + found.take(3) + (if (found.isEmpty()) MODELS else emptyList())).distinct()
    }

    override val providerId: String = PROVIDER_ID
    override val displayName: String = "Gemini AI"
    override val mode: GeneratorMode = GeneratorMode.REMOTE

    override suspend fun generate(request: ScriptGenerationRequest): ScriptPackage =
        withContext(Dispatchers.IO) {
            val keys = apiKeys().map { it.trim() }.filter { it.isNotEmpty() }.distinct()
            require(keys.isNotEmpty()) { "AI key not configured" }
            // P9.2 speed: every key was out of quota a moment ago - go offline at once instead of
            // spending ~15 s on requests that will fail again. A new/changed key list lifts the pause.
            val keySet = keys.hashCode()
            if (quotaPauseUntil == 0L) runCatching {
                loadPause()?.split('|')?.takeIf { it.size == 2 }?.let { (u, k) -> quotaPauseUntil = u.toLong(); quotaKeySet = k.toInt() }
            }
            if (keySet == quotaKeySet && now() < quotaPauseUntil) {
                throw IllegalStateException("Gemini quota used up - paused for ${(quotaPauseUntil - now()) / 60_000 + 1} min (add another key in Settings)")
            }

            val targetMs = request.duration.resolveTargetMs()
            val sceneCount = sceneCountFor(targetMs)
            val prompt = buildPrompt(request, targetMs, sceneCount)
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject()
                    .put("responseMimeType", "application/json")
                    .put("temperature", 0.8))
                .toString()

            val errors = mutableListOf<String>()
            val busy = mutableListOf<Pair<Int, String>>()
            val start = now()
            fun outOfTime() = now() - start > budgetMs
            fun tag(i: Int) = if (keys.size > 1) "key ${i + 1} " else ""
            for ((ki, key) in keys.withIndex()) {
                if (outOfTime()) break
                var keyRefused = false
                for (model in modelsToTry(key)) {
                    if (outOfTime()) { errors += "time limit ${budgetMs / 1000}s reached"; break }
                    try {
                        val raw = http(ENDPOINT.format(model), key, body)
                        val text = extractText(raw)
                        val pkg = toPackage(request, parseScript(text), targetMs, model)
                        lastGood = model
                        if (ki > 0) runCatching { onKeyWorked(ki) }
                        return@withContext pkg
                    } catch (t: Throwable) {
                        errors += "${tag(ki)}$model: ${t.message?.take(120)}"
                        if (isBusy(t.message)) busy += ki to model
                        // Rejected key (401/403/400 bad key) - no other model will work with it.
                        if (isRejected(t.message)) { keyRefused = true; break }
                    }
                }
                if (keyRefused) continue
            }
            // P2.3: "high demand" (503/429) is temporary - one short retry on the busy models.
            for ((ki, model) in busy.take(2)) {
                if (outOfTime()) break
                try {
                    retryPause()
                    val raw = http(ENDPOINT.format(model), keys[ki], body)
                    val text = extractText(raw)
                    val pkg = toPackage(request, parseScript(text), targetMs, model)
                    if (ki > 0) runCatching { onKeyWorked(ki) }
                    return@withContext pkg
                } catch (t: Throwable) {
                    errors += "${tag(ki)}$model (retry): ${t.message?.take(80)}"
                }
            }
            if (errors.isNotEmpty() && errors.all { isQuota(it) || it.contains("HTTP 404") || it.contains("time limit") } && errors.any { isQuota(it) }) {
                quotaKeySet = keySet
                quotaPauseUntil = now() + QUOTA_PAUSE_MS
                runCatching { savePause("$quotaPauseUntil|$quotaKeySet") }
            }
            throw IllegalStateException("Gemini script generation failed: " + errors.joinToString(" | "))
        }

    internal fun buildPrompt(request: ScriptGenerationRequest, targetMs: Long, sceneCount: Int): String {
        val language = ScriptLanguageRegistry.resolve(request.languageCode).displayName
        val seconds = targetMs / 1000
        // P27: the cloud voices speak ~2.6 words/s once pauses are trimmed - a 30 s video came out 18 s.
        val words = (seconds * 2.6).toInt()
        val minWords = (words * 0.85).toInt()
        return buildString {
            appendLine("You are a real Indian creator writing your own short video - not a demo, not a template.")
            appendLine("Write a $seconds-second ${request.platform.name.replace('_', ' ').lowercase()} video script in $language about:")
            appendLine(request.topic.trim().take(4000))
            appendLine()
            appendLine("Audience: ${request.audience.name.lowercase()}. Style: ${request.contentType.name.lowercase()}. Aspect ${request.aspectRatioLabel}.")
            request.userInstructions?.takeIf { it.isNotBlank() }?.let { appendLine("Creator instructions: $it") }
            request.factualRequirements?.takeIf { it.isNotBlank() }?.let { appendLine("Facts that must be respected: $it") }
            appendLine("Rules: exactly $sceneCount scenes; total narration between $minWords and $words words (fill the full $seconds seconds); first scene is a strong hook;")
            appendLine("the first scene is the hook about the topic itself; the LAST scene is ONLY a short call to action (like, follow, share), at most 5 words, under 3 seconds;")
            appendLine("spoken, natural sentences; no emojis or hashtags in narration;")
            appendLine("onScreenText max 6 words; do not invent statistics.")
            // P22.3: sound like a real person, not a demo.
            appendLine("VOICE: talk like a person showing it for real - concrete, specific, sensory. Never use filler such as")
            appendLine("'welcome to', 'in this video', 'let's dive in', 'amazing', 'you won't believe', 'stay tuned', 'without further ado'.")
            appendLine("Every narration line says ONE concrete thing that can be SEEN on screen at that moment.")
            appendLine("MATCH: visualDescription = exactly what the viewer sees while this line is spoken (same subject, same action).")
            appendLine("bRoll = a 2-4 word ENGLISH stock-video search for that same shot, concrete nouns + action")
            appendLine("(e.g. 'onions frying in pan', 'train arriving platform'); never abstract words like 'success' or 'journey'.")
            appendLine("onScreenText = the key words of that same line, so voice, caption and picture say the same thing.")
            // P28: "I'm here" live event (Puja pandal, mela...): first person, present tense, what can be seen there.
            if (request.topic.contains("LIVE EVENT:")) {
                appendLine("LIVE EVENT: the creator is there right now and films it. Speak in first person, present tense ('I'm at…', 'Look at…', 'Listen to the dhak…').")
                appendLine("Scene 1 says where and which day (place name and festival day exactly as given). Each scene shows one thing the creator can film there: pandal front, idol close-up, lights, dhak, aarti, crowd, food.")
                appendLine("Never invent the pandal's theme, budget, artist, history or awards - describe only what is visible. Last scene: invite viewers to visit or follow.")
            }
            // P22.2/P22.3: recipes show the full procedure like a real cooking short.
            if (Regex("(?i)recipe|cook|bake|রান্না|रेसिपी|बनाने|curry|soup|biryani|dish|chicken|mutton|fish|paneer|dal").containsMatchIn(request.topic)) {
                appendLine("RECIPE (real cooking short): one scene per cooking step IN ORDER, never skip a step.")
                appendLine("Each step names exact amounts, heat and minutes in the narration.")
                appendLine("onScreenText for a step = ingredient label in this style: '300g Onions - sliced', '2 tbsp Mustard oil', 'Chicken 500g - 10 min marinate'.")
                appendLine("visualDescription and bRoll show that exact action (e.g. 'slicing onions', 'frying onions golden', 'adding chicken to pan').")
                appendLine("Scene 2 may list the main ingredients (onScreenText starts 'Ingredients:', up to 12 words). The last content scene shows the finished dish and a serving tip.")
            }
            // P3.2: news accuracy - the model padded a headline-only source with invented details.
            appendLine("ACCURACY: use ONLY facts stated in the source text above. Never invent names, places, times, numbers,")
            appendLine("causes, quotes, injuries or events. If the source is short, keep the script short: say what is known")
            appendLine("and that more details are awaited. For crime, accidents or deaths use a calm, neutral, respectful tone;")
            appendLine("no sensational words (shocking, terrifying, horrific). Hard limit: at most $words words of narration in total.")
            appendLine("Return ONLY JSON: {\"title\":\"\",\"hook\":\"\",\"introduction\":\"\",\"cta\":\"\",\"ending\":\"\",")
            appendLine("\"scenes\":[{\"narration\":\"\",\"onScreenText\":\"\",\"visualDescription\":\"\",\"bRoll\":\"\"}]}")
        }
    }

    internal data class ParsedScript(
        val title: String,
        val hook: String,
        val introduction: String,
        val cta: String,
        val ending: String,
        val scenes: List<ParsedScene>
    )

    internal data class ParsedScene(
        val narration: String,
        val onScreenText: String,
        val visualDescription: String,
        val bRoll: String
    )

    internal fun extractText(raw: String): String {
        val root = JSONObject(raw)
        val parts = root.getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        return sb.toString()
    }

    internal fun parseScript(text: String): ParsedScript {
        val start = text.indexOf('{')
        val end = text.lastIndexOf('}')
        require(start >= 0 && end > start) { "AI reply has no JSON" }
        val o = JSONObject(text.substring(start, end + 1))
        val arr = o.optJSONArray("scenes") ?: JSONArray()
        val scenes = (0 until arr.length()).mapNotNull { i ->
            val s = arr.optJSONObject(i) ?: return@mapNotNull null
            val narration = s.optString("narration").trim()
            if (narration.isEmpty()) null
            else ParsedScene(
                narration = narration,
                onScreenText = s.optString("onScreenText").trim(),
                visualDescription = s.optString("visualDescription").trim(),
                bRoll = s.optString("bRoll").trim()
            )
        }
        require(scenes.size >= 2) { "AI reply has fewer than 2 scenes" }
        return ParsedScript(
            title = o.optString("title").trim(),
            hook = o.optString("hook").trim(),
            introduction = o.optString("introduction").trim(),
            cta = o.optString("cta").trim(),
            ending = o.optString("ending").trim(),
            scenes = scenes
        )
    }

    internal fun toPackage(
        request: ScriptGenerationRequest,
        parsed: ParsedScript,
        targetMs: Long,
        model: String
    ): ScriptPackage {
        val language = ScriptLanguageRegistry.resolve(request.languageCode)
        val weights = parsed.scenes.map { max(20, it.narration.length) }
        val durations = distribute(targetMs, weights)
        val last = parsed.scenes.size - 1
        val scenes = parsed.scenes.mapIndexed { i, s ->
            ScriptScene(
                sceneId = when (i) { 0 -> "scn_hook"; last -> "scn_outro"; else -> "scn_" + i.toString().padStart(2, '0') },
                order = i,
                durationMs = durations[i],
                narration = s.narration,
                onScreenText = s.onScreenText,
                visualDescription = s.visualDescription,
                shotType = when (i) { 0 -> ShotType.INTRO; last -> ShotType.OUTRO; else -> if (i % 2 == 0) ShotType.B_ROLL else ShotType.MEDIUM },
                cameraDirection = "",
                bRollSuggestion = s.bRoll,
                transition = if (i == last) TransitionIntent.FADE else TransitionIntent.CUT,
                notes = when (i) { 0 -> "Hook"; last -> "CTA / Ending"; else -> "Body" }
            )
        }
        val now = System.currentTimeMillis()
        val draft = ScriptPackage(
            version = ScriptPackage.CURRENT_VERSION,
            projectId = request.projectId,
            scriptId = "scr_" + UUID.randomUUID().toString().replace("-", "").take(16),
            topic = request.topic.trim(),
            language = language.code,
            title = parsed.title.ifBlank { language.titleFor(request.topic.trim()) },
            hook = parsed.hook.ifBlank { scenes.first().narration },
            introduction = parsed.introduction,
            scenes = scenes,
            cta = parsed.cta.ifBlank { language.ctaFor(request.topic.trim()) },
            ending = parsed.ending,
            estimatedDurationMs = scenes.sumOf { it.durationMs },
            targetDurationMs = targetMs,
            estimatedNarrationDurationMs = scenes.sumOf { minOf(it.durationMs, max(1_000L, (it.narration.length / 13.0 * 1000).roundToLong())) },
            validation = ScriptValidation(true, ValidationStatus.VALID),
            metadata = ScriptMetadata(
                contentType = request.contentType,
                audience = request.audience,
                platform = request.platform,
                aspectRatio = request.aspectRatioLabel,
                generatorId = if (model.contains(":")) model else "$PROVIDER_ID:$model",
                generatorMode = mode.name,
                createdAt = now,
                updatedAt = now,
                userInstructions = request.userInstructions,
                factualRequirements = request.factualRequirements
            )
        )
        return draft.copy(validation = ScriptValidator.validatePackage(draft, request.durationToleranceRatio))
    }

    private fun distribute(totalMs: Long, weights: List<Int>): List<Long> {
        val sum = weights.sum().toDouble()
        val raw = weights.map { max(ScriptValidator.MIN_SCENE_MS, (totalMs * it / sum).roundToLong()) }.toMutableList()
        var diff = totalMs - raw.sum()
        var i = 0
        while (diff != 0L && i < raw.size * 10_000) {
            val idx = i % raw.size
            if (diff > 0) { raw[idx]++; diff-- }
            else if (raw[idx] > ScriptValidator.MIN_SCENE_MS) { raw[idx]--; diff++ }
            i++
        }
        return raw
    }

    companion object {
        const val PROVIDER_ID = "gemini"
        private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"
        /** Total time allowed for all Gemini calls of one script. */
        const val BUDGET_MS = 55_000L   // P21.4: 25 s timed out on the phone (gemini-3.x flash)

        /** The key itself was refused (not overload, not quota): skip its other models. */
        internal fun isRejected(message: String?): Boolean =
            message != null && (message.contains("HTTP 401") || message.contains("HTTP 403") ||
                (message.contains("HTTP 400") && message.contains("API key", ignoreCase = true)))

        internal const val QUOTA_PAUSE_MS = 10 * 60_000L

        internal fun isQuota(message: String): Boolean =
            message.contains("HTTP 429") && message.contains("quota", ignoreCase = true)

        internal fun isBusy(message: String?): Boolean =
            message != null && (message.contains("HTTP 503") || message.contains("HTTP 429") || message.contains("high demand", ignoreCase = true))

        private val MODELS = listOf("gemini-flash-latest", "gemini-2.5-flash", "gemini-2.0-flash")

        private val EXCLUDED = listOf("lite", "image", "tts", "live", "audio", "embedding", "vision", "thinking", "8b")
        private val VERSION = Regex("gemini-(\\d+(?:\\.\\d+)?)")

        /** Text-generation "flash" models from a ListModels reply, newest stable first. */
        internal fun rankModels(raw: String): List<String> {
            val arr = JSONObject(raw).optJSONArray("models") ?: return emptyList()
            data class M(val id: String, val version: Double, val preview: Boolean)
            val out = mutableListOf<M>()
            for (i in 0 until arr.length()) {
                val m = arr.optJSONObject(i) ?: continue
                val id = m.optString("name").removePrefix("models/")
                val methods = m.optJSONArray("supportedGenerationMethods")
                val gen = methods != null && (0 until methods.length()).any { methods.optString(it) == "generateContent" }
                if (!gen || !id.contains("flash") || EXCLUDED.any { id.contains(it) }) continue
                val version = VERSION.find(id)?.groupValues?.get(1)?.toDoubleOrNull() ?: 0.0
                val preview = id.contains("preview") || id.contains("exp")
                out += M(id, version, preview)
            }
            return out.sortedWith(compareBy<M> { it.preview }.thenByDescending { it.version }.thenBy { it.id.length })
                .map { it.id }
        }

        private fun getModels(key: String): String {
            val c = java.net.URI("https://generativelanguage.googleapis.com/v1beta/models?pageSize=200").toURL()
                .openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 6_000
                c.readTimeout = 8_000
                c.setRequestProperty("x-goog-api-key", key)
                check(c.responseCode in 200..299) { "ListModels HTTP ${c.responseCode}" }
                return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            } finally {
                c.disconnect()
            }
        }

        fun sceneCountFor(targetMs: Long): Int = when {
            targetMs <= 30_000L -> 4
            targetMs <= 60_000L -> 6
            targetMs <= 120_000L -> 8
            else -> 10
        }

        private fun postJson(url: String, key: String, body: String): String {
            val c = java.net.URI(url).toURL().openConnection() as HttpURLConnection
            try {
                c.requestMethod = "POST"
                c.connectTimeout = 6_000
                c.readTimeout = 28_000   // P21.4: newer "thinking" flash models need longer than 12 s
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = c.responseCode
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                check(code in 200..299) {
                    val reason = runCatching {
                        JSONObject(text).optJSONObject("error")?.optString("message").orEmpty()
                    }.getOrDefault("")
                    "HTTP $code ${reason.take(160)}".trim()
                }
                return text
            } finally {
                c.disconnect()
            }
        }
    }
}

/**
 * Tries the AI generator first; on any failure (no network, quota, bad key)
 * falls back to the offline generator so the user is never blocked.
 */
class FallbackScriptGenerator(
    private val primary: ScriptGenerator,
    private val fallback: ScriptGenerator,
    private val onFallback: (Throwable) -> Unit = {}
) : ScriptGenerator {
    override val providerId: String get() = primary.providerId
    override val displayName: String get() = "${primary.displayName} (offline fallback)"
    override val mode: GeneratorMode get() = primary.mode

    override suspend fun generate(request: ScriptGenerationRequest): ScriptPackage =
        try {
            val result = primary.generate(request)
            if (result.validation.isValid) result else fallback.generate(request).also { onFallback(IllegalStateException("AI script invalid: " + result.validation.errors.joinToString())) }
        } catch (t: Throwable) {
            onFallback(t)
            fallback.generate(request)
        }
}
