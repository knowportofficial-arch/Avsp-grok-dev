package com.avsp.pro.video.engine

import com.avsp.pro.video.contract.VideoCaptionInput

object TimedCaptionSelector {
    fun active(captions: List<VideoCaptionInput>, timeMs: Long): List<VideoCaptionInput> =
        captions.filter { timeMs >= it.startMs && timeMs < it.endMs }
}