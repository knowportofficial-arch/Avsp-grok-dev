﻿package com.avsp.pro.screen.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.util.Log
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.min

class ScreenIntelligenceAnalyzer {

    companion object {
        private const val LOG_TAG = "AVSP-V2"
        private const val STEP = 1000L
        private const val MAX = 600
        private const val SIZE = 48

        /*
         * P0 frame-local privacy: dense re-sampling (privacy only).
         * Applied only inside 1-second intervals where sensitive data
         * exists AND the screen moved or the sensitive layout changed.
         */
        private const val PRIVACY_DENSE_STEP_MS = 200L
        private const val PRIVACY_MAX_DENSE_SAMPLES = 1200
        private const val PRIVACY_DENSE_VISUAL_THRESHOLD = 0.010f
        private const val PRIVACY_END_SAMPLE_OFFSET_MS = 40L

        /*
         * P1 context privacy.
         * FACE_MIN_SIZE: smallest face (fraction of frame width) to detect;
         * small enough for ID-card thumbnails in document lists.
         * FACE_MARGIN_*: censor slightly more than the detector's box.
         */
        private const val FACE_MIN_SIZE = 0.04f
        private const val FACE_MARGIN_X = 0.15f
        private const val FACE_MARGIN_Y = 0.20f

        /*
         * P1 transition veil (48x48 luminance signature, 0..1):
         *  - VEIL_RAW_THRESHOLD: minimum plain change between two samples
         *  - VEIL_UNEXPLAINED_THRESHOLD: change that remains after the best
         *    vertical/horizontal shift. Scrolling a list measured raw ~0.20
         *    but unexplained ~0.02 (no veil); app-switch / zoom animations
         *    measured unexplained 0.06 - 0.93 on the 2026-10-08 recording.
         */
        /*
         * P1.1 calibration on the original 2026-10-08 18:53 recording:
         * app-switch / launcher animations measured unexplained 0.10-0.37;
         * ID-card pan/zoom and list motion 0.05-0.09 (tracked boxes handle
         * those). 0.05 darkened 9 s of a 29 s video; 0.10 keeps only real
         * transitions. Only dense windows (<= 400 ms) are veiled.
         */
        private const val VEIL_RAW_THRESHOLD = 0.10f
        private const val VEIL_UNEXPLAINED_THRESHOLD = 0.10f
        private const val VEIL_MAX_WINDOW_MS = 400L
        private const val REGION_VEIL_MIN_UNEXPLAINED = 0.03f
    }

    fun analyze(
        context: Context,
        projectId: String,
        video: File,
        relative: String
    ): ScreenIntelligenceResult {

        require(video.exists())

        val retriever = MediaMetadataRetriever()

        val latin =
            TextRecognition.getClient(
                TextRecognizerOptions.DEFAULT_OPTIONS
            )

        val devanagari =
            TextRecognition.getClient(
                DevanagariTextRecognizerOptions.Builder().build()
            )

        /*
         * P1: faces are personal data (ID photos, profile pictures).
         * If the detector cannot be created, analysis continues without
         * faces (text privacy must never be lost because of it).
         */
        val faces: FaceDetector? =
            runCatching {
                FaceDetection.getClient(
                    FaceDetectorOptions.Builder()
                        .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
                        .setMinFaceSize(FACE_MIN_SIZE)
                        .build()
                )
            }.onFailure {
                Log.e(LOG_TAG, "Face detector unavailable; faces will not be masked", it)
            }.getOrNull()

        return try {

            Log.i(
                LOG_TAG,
                "Analyzer START file=${video.absolutePath} " +
                    "exists=${video.exists()} size=${video.length()}"
            )

            retriever.setDataSource(video.absolutePath)

            val duration =
                retriever.extractMetadata(
                    MediaMetadataRetriever.METADATA_KEY_DURATION
                )?.toLongOrNull() ?: 0L

            /*
             * Recordings longer than MAX seconds previously stopped being
             * analysed (and therefore redacted) after MAX samples.
             * Widen the step instead so the WHOLE video is sampled.
             * For recordings <= MAX seconds the step stays exactly STEP.
             */
            val step =
                maxOf(STEP, (duration + MAX - 1L) / MAX)

            val count =
                min(
                    MAX,
                    ((duration + step - 1L) / step)
                        .toInt()
                        .coerceAtLeast(1)
                )

            val frames =
                mutableListOf<ScreenFrameAnalysis>()

            /* Sparse samples whose OCR failed: not evidence of absence. */
            val failedOcrTimestamps =
                mutableSetOf<Long>()

            var previousSignature: FloatArray? = null

            /* P1: per-sample data for context privacy and transition veils. */
            val faceBoxesByTime =
                HashMap<Long, List<RectF>>()

            val signaturesByTime =
                HashMap<Long, FloatArray>()

            for (i in 0 until count) {

                val timestamp =
                    min(duration, i * step)

                val bitmap =
                    retriever.getFrameAtTime(
                        timestamp * 1000L,
                        MediaMetadataRetriever.OPTION_CLOSEST
                    ) ?: continue

                val signature = signature(bitmap)

                val visualDiff =
                    previousSignature?.let {
                        difference(it, signature)
                    } ?: 1f

                val visualBounds =
                    previousSignature?.let {
                        differenceBounds(it, signature)
                    }

                val frameOcr =
                    ocrForPrivacy(
                        bitmap,
                        latin,
                        devanagari
                    )

                if (frameOcr == null) {
                    failedOcrTimestamps += timestamp
                }

                faceBoxesByTime[timestamp] =
                    detectFaces(bitmap, faces)

                signaturesByTime[timestamp] = signature

                frames += ScreenFrameAnalysis(
                    timestampMs = timestamp,
                    ocr = frameOcr ?: emptyList(),
                    visualChangeScore = visualDiff,
                    visualChangeBounds = visualBounds
                )

                previousSignature = signature

                bitmap.recycle()
            }

            /*
             * ------------------------------------------------
             * PRIVACY-FIRST SENSITIVE DATA SCAN
             * ------------------------------------------------
             *
             * Raw OCR is scanned here.
             * Findings retain the source text for redaction
             * metadata, but generated narration never receives
             * the raw value.
             */
            val sensitive =
                mutableListOf<SensitiveFinding>()

            frames.forEach { frame ->

                sensitive +=
                    privacyFindings(
                        timestampMs = frame.timestampMs,
                        lines = frame.ocr,
                        faceBoxes = faceBoxesByTime[frame.timestampMs].orEmpty()
                    )
            }

            val uniqueSensitive =
                sensitive.distinctBy {
                    "${it.timestampMs}|${it.type}|${it.sourceText}|${it.bounds}"
                }

            /*
             * ------------------------------------------------
             * P0 FRAME-LOCAL PRIVACY PLAN
             * ------------------------------------------------
             *
             * Privacy-only dense pass + track building.
             * Does NOT modify frames, events, interaction
             * inference or cut suggestions.
             */
            val privacyPlan =
                buildPrivacyPlan(
                    retriever = retriever,
                    latin = latin,
                    devanagari = devanagari,
                    faces = faces,
                    durationMs = duration,
                    frames = frames,
                    sparseFindings = uniqueSensitive,
                    failedOcrTimestamps = failedOcrTimestamps,
                    sparseSignatures = signaturesByTime
                )

            /*
             * ------------------------------------------------
             * TIMELINE EVENTS
             * ------------------------------------------------
             */
            val events =
                mutableListOf<ScreenTimelineEvent>()

            if (frames.isNotEmpty()) {
                events += ScreenTimelineEvent(
                    timestampMs = 0L,
                    type = ScreenEventType.START,
                    title = "Recording started",
                    summary = "Beginning of captured screen session.",
                    confidence = 1f
                )
            }

            frames.forEachIndexed { index, frame ->

                val previousText =
                    frames
                        .getOrNull(index - 1)
                        ?.ocr
                        ?.joinToString("\n") { it.text }
                        .orEmpty()

                val rawText =
                    frame.ocr
                        .joinToString("\n") { it.text }

                val safeText =
                    ScreenSensitiveSanitizer
                        .privacySafeForNarration(rawText)

                if (
                    index > 0 &&
                    safeText.isNotBlank() &&
                    safeText !=
                    ScreenSensitiveSanitizer
                        .privacySafeForNarration(previousText)
                ) {

                    events += ScreenTimelineEvent(
                        timestampMs = frame.timestampMs,
                        type = ScreenEventType.TEXT_CHANGED,
                        title = "Screen text changed",
                        summary = safeText,
                        confidence = .85f,
                        sensitive = uniqueSensitive.any {
                            it.timestampMs == frame.timestampMs
                        }
                    )
                }

                if (frame.visualChangeScore > .075f) {

                    events += ScreenTimelineEvent(
                        timestampMs = frame.timestampMs,
                        type = ScreenEventType.VISUAL_CHANGE,
                        title = "Visual change",
                        bounds = frame.visualChangeBounds,
                        summary =
                            "The screen changed substantially.",
                        confidence =
                            min(
                                1f,
                                frame.visualChangeScore * 4f
                            )
                    )

                    if (
                        frame.visualChangeBounds != null &&
                        frame.visualChangeScore >= 0.075f &&
                        frame.visualChangeBounds.width() <= 0.70f &&
                        frame.visualChangeBounds.height() <= 0.70f &&
                        (frame.visualChangeBounds.width() *
                            frame.visualChangeBounds.height()) <= 0.35f
                    ) {
                        events += ScreenTimelineEvent(
                            timestampMs = frame.timestampMs,
                            type = ScreenEventType.INFERRED_INTERACTION,
                            title = "Likely interaction region",
                            summary =
                                "A localized screen change may indicate an interaction.",
                            confidence =
                                min(
                                    1f,
                                    frame.visualChangeScore * 3f
                                ),
                            sensitive = false,
                            bounds = frame.visualChangeBounds
                        )
                    }
                }
            }

            /*
             * ------------------------------------------------
             * V27.3 TEMPORAL INTERACTION STABILIZATION
             * ------------------------------------------------
             *
             * Spatial interaction inference remains V27.2.
             * Suppress only near-duplicate inferred interaction
             * events that occur within 4 seconds and substantially
             * overlap the previous inferred region.
             *
             * Separate interactions are preserved.
             */
            val stabilizedEvents =
                mutableListOf<ScreenTimelineEvent>()

            var lastInferredInteraction: ScreenTimelineEvent? = null

            events.forEach { event ->

                if (event.type != ScreenEventType.INFERRED_INTERACTION) {
                    stabilizedEvents += event
                    return@forEach
                }

                val previous = lastInferredInteraction

                if (
                    previous != null &&
                    event.bounds != null &&
                    previous.bounds != null &&
                    event.timestampMs >= previous.timestampMs &&
                    event.timestampMs - previous.timestampMs <= 4000L
                ) {
                    val a = previous.bounds
                    val b = event.bounds

                    val left = maxOf(a.left, b.left)
                    val top = maxOf(a.top, b.top)
                    val right = minOf(a.right, b.right)
                    val bottom = minOf(a.bottom, b.bottom)

                    val intersectionArea =
                        if (right > left && bottom > top) {
                            (right - left) * (bottom - top)
                        } else {
                            0f
                        }

                    val smallerArea =
                        minOf(
                            a.width() * a.height(),
                            b.width() * b.height()
                        )

                    val overlapRatio =
                        if (smallerArea > 0f) {
                            intersectionArea / smallerArea
                        } else {
                            0f
                        }

                    if (overlapRatio >= 0.55f) {
                        return@forEach
                    }
                }

                stabilizedEvents += event
                lastInferredInteraction = event
            }

            /*
             * ------------------------------------------------
             * FINAL INTERACTION MODULE HARDENING
             * ------------------------------------------------
             *
             * Keep only structurally valid inferred interaction
             * events after temporal stabilization.
             *
             * Exact Android touch/click events are intentionally
             * NOT claimed here; these remain video-derived
             * interaction inferences.
             */
            val validatedEvents =
                stabilizedEvents.filter { event ->

                    if (event.type != ScreenEventType.INFERRED_INTERACTION) {
                        true
                    } else {
                        val bounds = event.bounds

                        if (bounds == null) {
                            false
                        } else {
                            val width = bounds.width()
                            val height = bounds.height()
                            val area = width * height

                            bounds.left >= 0f &&
                                bounds.top >= 0f &&
                                bounds.right <= 1f &&
                                bounds.bottom <= 1f &&
                                width > 0f &&
                                height > 0f &&
                                width <= 0.70f &&
                                height <= 0.70f &&
                                area <= 0.35f &&
                                event.confidence > 0f
                        }
                    }
                }

            events.clear()
            events += validatedEvents

            uniqueSensitive
                .groupBy { it.timestampMs }
                .forEach { (timestamp, findings) ->

                    events += ScreenTimelineEvent(
                        timestampMs = timestamp,
                        type = ScreenEventType.SENSITIVE_DATA,
                        title = "Sensitive data detected",
                        summary =
                            findings
                                .map {
                                    it.type.name
                                        .lowercase(Locale.ROOT)
                                }
                                .distinct()
                                .joinToString(", "),
                        confidence = .95f,
                        sensitive = true
                    )
                }

            frames.lastOrNull()?.let {

                events += ScreenTimelineEvent(
                    timestampMs = it.timestampMs,
                    type = ScreenEventType.END,
                    title = "Recording ended",
                    summary = "End of captured screen session.",
                    confidence = 1f
                )
            }

            /*
             * ------------------------------------------------
             * CUT SUGGESTIONS
             * ------------------------------------------------
             */
            val cuts =
                mutableListOf<ScreenCutSuggestion>()

            var lowActivityStart: Long? = null

            fun closeCut(end: Long) {

                val start =
                    lowActivityStart ?: return

                lowActivityStart = null

                if (end - start >= 2000L) {

                    cuts += ScreenCutSuggestion(
                        startMs = start,
                        endMs = end,
                        reason =
                            "Low visual change and no OCR activity.",
                        confidence = .72f
                    )
                }
            }

            frames.forEach { frame ->

                val sensitiveAtFrame =
                    uniqueSensitive.any {
                        it.timestampMs == frame.timestampMs
                    }

                if (
                    frame.visualChangeScore < .018f &&
                    frame.ocr.isEmpty() &&
                    !sensitiveAtFrame
                ) {

                    if (lowActivityStart == null) {
                        lowActivityStart = frame.timestampMs
                    }

                } else {
                    closeCut(frame.timestampMs)
                }
            }

            frames.lastOrNull()?.let {
                closeCut(it.timestampMs)
            }

            /*
             * ------------------------------------------------
             * PRIVACY-SAFE CONTENT SCRIPT
             * ------------------------------------------------
             *
             * IMPORTANT:
             * Raw OCR never enters generatedScript.
             */
            val script =
                buildContentScript(
                    frames = frames,
                    events = events,
                    sensitive = uniqueSensitive,
                    durationMs = duration
                )

            Log.i(
                LOG_TAG,
                "Analyzer DONE " +
                    "durationMs=$duration " +
                    "frames=${frames.size} " +
                    "events=${events.size} " +
                    "sensitive=${uniqueSensitive.size} " +
                    "cuts=${cuts.size} " +
                    "privacyTracks=${privacyPlan.tracks.size} " +
                    "privacySamples=${privacyPlan.sampleTimesMs.size} " +
                    "privacyDense=${privacyPlan.denseSampleCount}"
            )

            ScreenIntelligenceResult(
                schemaVersion = 2,
                projectId = projectId,
                sourceVideoRelativePath = relative,
                durationMs = duration,
                sampledFrameCount = frames.size,
                frames = frames,
                events = events.sortedBy {
                    it.timestampMs
                },
                sensitiveFindings = uniqueSensitive,
                cutSuggestions = cuts,
                generatedScript = script,
                generatedAtEpochMs =
                    System.currentTimeMillis(),
                privacyPlan = privacyPlan
            )

        } finally {

            runCatching {
                latin.close()
            }

            runCatching {
                devanagari.close()
            }

            runCatching {
                faces?.close()
            }

            retriever.release()
        }
    }

    private fun buildContentScript(
        frames: List<ScreenFrameAnalysis>,
        events: List<ScreenTimelineEvent>,
        sensitive: List<SensitiveFinding>,
        durationMs: Long
    ): String {

        val sections =
            mutableListOf<String>()

        sections += "SCREEN CONTENT INTELLIGENCE SCRIPT"

        sections +=
            "Duration: ${durationMs / 1000L}s"

        sections +=
            "Privacy policy: " +
                ScreenSensitiveSanitizer.privacyPolicyText()

        if (sensitive.isNotEmpty()) {

            val types =
                sensitive
                    .map { it.type.name }
                    .distinct()
                    .joinToString(", ")

            sections +=
                "Sensitive data detected: $types"

            sections +=
                "Sensitive values have been removed from narration."
        }

        /*
         * Deduplicate consecutive OCR states.
         */
        var previous = ""

        frames.forEach { frame ->

            val raw =
                frame.ocr
                    .joinToString(" ") { it.text }
                    .trim()

            if (raw.isBlank()) return@forEach

            val safe =
                ScreenSensitiveSanitizer
                    .privacySafeForNarration(raw)

            if (
                safe.isNotBlank() &&
                safe != previous
            ) {

                sections +=
                    "[${time(frame.timestampMs)}] $safe"

                previous = safe
            }
        }

        if (
            sections.size <= 3 &&
            events.none {
                it.type == ScreenEventType.VISUAL_CHANGE
            }
        ) {

            sections +=
                "No meaningful narration-ready screen text " +
                    "was detected beyond the available OCR."
        }

        sections +=
            "FINAL NARRATION RULE: " +
                "Use TTS-generated narration only. " +
                "Original recording audio is analysis-only " +
                "and must not be included in final rendering."

        return sections.joinToString("\n")
    }

    /**
     * Behaviour-identical to the original OCR function:
     * failures produce an empty list.
     */
    @Suppress("unused")
    private fun ocr(
        bitmap: Bitmap,
        latin: TextRecognizer,
        devanagari: TextRecognizer
    ): List<ScreenOcrText> =
        ocrForPrivacy(bitmap, latin, devanagari) ?: emptyList()

    /**
     * Same OCR as before, but returns null when BOTH recognizers failed
     * (timeout/error). Privacy tracking must not treat a failed OCR
     * sample as proof that sensitive content was absent.
     */
    private fun ocrForPrivacy(
        bitmap: Bitmap,
        latin: TextRecognizer,
        devanagari: TextRecognizer
    ): List<ScreenOcrText>? {

        val output =
            mutableListOf<ScreenOcrText>()

        val image =
            InputImage.fromBitmap(bitmap, 0)

        fun addText(
            result: com.google.mlkit.vision.text.Text
        ) {

            result.textBlocks.forEach { block ->

                block.lines.forEach { line ->

                    val box =
                        line.boundingBox
                            ?: return@forEach

                    val text =
                        line.text.trim()

                    if (text.isNotBlank()) {

                        output += ScreenOcrText(
                            text = text,
                            bounds = RectF(
                                box.left.toFloat() /
                                    bitmap.width,

                                box.top.toFloat() /
                                    bitmap.height,

                                box.right.toFloat() /
                                    bitmap.width,

                                box.bottom.toFloat() /
                                    bitmap.height
                            ),
                            confidence = .9f
                        )
                    }
                }
            }
        }

        val latinResult =
            runCatching {
                Tasks.await(
                    latin.process(image),
                    1500,
                    TimeUnit.MILLISECONDS
                )
            }
                .getOrNull()

        latinResult?.let(::addText)

        val devanagariResult =
            runCatching {
                Tasks.await(
                    devanagari.process(image),
                    1500,
                    TimeUnit.MILLISECONDS
                )
            }
                .getOrNull()

        devanagariResult?.let(::addText)

        if (latinResult == null && devanagariResult == null) {
            return null
        }

        return output.distinctBy {
            "${it.text}|${it.bounds}"
        }
    }

    /**
     * P0 frame-local privacy plan.
     *
     * 1. Sparse (1 s) findings are reused as-is.
     * 2. Inside every sparse interval that contains sensitive data AND
     *    where the screen moved / the sensitive layout changed / OCR
     *    failed, frames are re-sampled every PRIVACY_DENSE_STEP_MS and
     *    OCR'd again (privacy only).
     * 3. The final frame is always sampled so the last region ends where
     *    the content actually ends.
     * 4. Observations are linked into motion tracks by ScreenPrivacyTracker.
     *
     * Any failure in the dense pass falls back to a sparse-only plan;
     * it never removes sparse coverage.
     */
    private fun buildPrivacyPlan(
        retriever: MediaMetadataRetriever,
        latin: TextRecognizer,
        devanagari: TextRecognizer,
        faces: FaceDetector?,
        durationMs: Long,
        frames: List<ScreenFrameAnalysis>,
        sparseFindings: List<SensitiveFinding>,
        failedOcrTimestamps: Set<Long>,
        sparseSignatures: Map<Long, FloatArray> = emptyMap()
    ): ScreenPrivacyPlan {

        val sparseSamples =
            frames
                .map { it.timestampMs }
                .filter { it !in failedOcrTimestamps }

        val sparseObservations =
            sparseFindings.map { it.toPrivacyObservation() }

        val findingsByTime =
            sparseFindings.groupBy { it.timestampMs }

        val denseObservations =
            mutableListOf<PrivacyObservation>()

        val denseSamples =
            mutableListOf<Long>()

        /* P1: dense-sample signatures + whether privacy data was present. */
        val denseSignatures =
            HashMap<Long, FloatArray>()

        val denseHasPrivacy =
            HashSet<Long>()

        try {
            val targets =
                java.util.TreeSet<Long>()

            for (i in 1 until frames.size) {
                val a = frames[i - 1]
                val b = frames[i]

                val fa = findingsByTime[a.timestampMs].orEmpty()
                val fb = findingsByTime[b.timestampMs].orEmpty()

                if (fa.isEmpty() && fb.isEmpty()) continue

                val moved =
                    b.visualChangeScore >= PRIVACY_DENSE_VISUAL_THRESHOLD

                val layoutChanged =
                    !samePrivacyLayout(fa, fb)

                val ocrFailed =
                    a.timestampMs in failedOcrTimestamps ||
                        b.timestampMs in failedOcrTimestamps

                if (!moved && !layoutChanged && !ocrFailed) continue

                var t = a.timestampMs + PRIVACY_DENSE_STEP_MS
                while (t < b.timestampMs) {
                    targets += t
                    t += PRIVACY_DENSE_STEP_MS
                }
            }

            val lastFrame = frames.lastOrNull()
            val endSample =
                (durationMs - PRIVACY_END_SAMPLE_OFFSET_MS).coerceAtLeast(0L)

            var finalTarget: Long? = null

            if (lastFrame != null && endSample > lastFrame.timestampMs) {
                val lastHasPrivacy =
                    findingsByTime[lastFrame.timestampMs].orEmpty().isNotEmpty() ||
                        lastFrame.timestampMs in failedOcrTimestamps

                if (lastHasPrivacy) {
                    var t = lastFrame.timestampMs + PRIVACY_DENSE_STEP_MS
                    while (t < endSample) {
                        targets += t
                        t += PRIVACY_DENSE_STEP_MS
                    }
                }

                finalTarget = endSample
            }

            /*
             * Bounded cost. The final frame is always kept; remaining
             * intervals beyond the cap keep sparse (1-sample-step) coverage.
             */
            val selected =
                targets.take(
                    if (finalTarget != null) PRIVACY_MAX_DENSE_SAMPLES - 1
                    else PRIVACY_MAX_DENSE_SAMPLES
                ).toMutableList()

            finalTarget?.let { selected += it }

            val totalTargets =
                targets.size + (if (finalTarget != null) 1 else 0)

            if (totalTargets > selected.size) {
                Log.w(
                    LOG_TAG,
                    "Privacy dense sampling capped at ${selected.size} " +
                        "of $totalTargets targets"
                )
            }

            for (t in selected) {

                val bitmap =
                    retriever.getFrameAtTime(
                        t * 1000L,
                        MediaMetadataRetriever.OPTION_CLOSEST
                    ) ?: continue

                var faceBoxes: List<RectF> = emptyList()
                var denseSignature: FloatArray? = null

                val lines =
                    try {
                        denseSignature = signature(bitmap)
                        faceBoxes =
                            if (faceNearby(t, frames, sparseFindings)) detectFaces(bitmap, faces)
                            else emptyList()
                        ocrForPrivacy(bitmap, latin, devanagari)
                    } finally {
                        bitmap.recycle()
                    }

                if (lines == null) continue

                denseSamples += t
                denseSignature?.let { denseSignatures[t] = it }

                val found =
                    privacyFindings(
                        timestampMs = t,
                        lines = lines,
                        faceBoxes = faceBoxes
                    )

                if (found.isNotEmpty()) denseHasPrivacy += t

                found.forEach { finding ->
                    denseObservations += finding.toPrivacyObservation()
                }
            }

        } catch (t: Throwable) {
            Log.e(
                LOG_TAG,
                "Privacy dense pass failed; using sparse-only privacy plan",
                t
            )
            denseObservations.clear()
            denseSamples.clear()
            denseSignatures.clear()
            denseHasPrivacy.clear()
        }

        val veils =
            try {
                buildTransitionVeils(
                    signatures = sparseSignatures
                        .filterKeys { it !in failedOcrTimestamps } + denseSignatures,
                    privacyTimes = findingsByTime.keys + denseHasPrivacy
                )
            } catch (t: Throwable) {
                Log.e(LOG_TAG, "Transition veil detection failed; no veils", t)
                emptyList()
            }

        // P3: pop-up / dialer open animations (partial-screen change).
        val regionVeils =
            try {
                val sigs = sparseSignatures.filterKeys { it !in failedOcrTimestamps } + denseSignatures
                val boxesByTime = (sparseObservations + denseObservations).groupBy({ it.timestampMs }, { it.box })
                ScreenPrivacyTracker.regionVeils(
                    times = sigs.keys.toList(),
                    changed = { a, b ->
                        val sa = sigs[a]; val sb = sigs[b]
                        if (sa == null || sb == null || sa.size != sb.size) null
                        // A scroll is explained by a shift and already tracked per box.
                        else if (ScreenPrivacyTracker.unexplainedChange(sa, sb, SIZE) < REGION_VEIL_MIN_UNEXPLAINED) null
                        else differenceBounds(sa, sb)?.let { r -> PrivacyBox(r.left, r.top, r.right, r.bottom) }
                    },
                    boxesAt = { boxesByTime[it].orEmpty() },
                    maxWindowMs = VEIL_MAX_WINDOW_MS
                ).filter { rv -> veils.none { v -> rv.startMs >= v.startMs && rv.endMs <= v.endMs } }
            } catch (t: Throwable) {
                Log.e(LOG_TAG, "Region veil detection failed; none", t)
                emptyList()
            }
        if (regionVeils.isNotEmpty()) Log.i(LOG_TAG, "Privacy region veils=${regionVeils.size}")

        if (veils.isNotEmpty()) {
            Log.i(
                LOG_TAG,
                "Privacy transition veils=${veils.size} " +
                    "totalMs=${veils.sumOf { it.endMs - it.startMs }}"
            )
        }

        return ScreenPrivacyTracker.build(
            observations = sparseObservations + denseObservations,
            sampleTimesMs = sparseSamples + denseSamples,
            durationMs = durationMs,
            denseSampleCount = denseSamples.size,
            veils = veils + regionVeils
        )
    }

    /**
     * P1 transition veils.
     *
     * Between two consecutive privacy samples whose whole-screen picture
     * changed strongly (app switch, recent-apps zoom, launcher animation)
     * AND where sensitive data was present on either side, per-box tracking
     * cannot follow scaling content. The whole frame is covered for that
     * window instead.
     */
    private fun buildTransitionVeils(
        signatures: Map<Long, FloatArray>,
        privacyTimes: Set<Long>
    ): List<PrivacyVeil> {

        val times = signatures.keys.sorted()
        val veils = mutableListOf<PrivacyVeil>()

        for (i in 1 until times.size) {
            val a = times[i - 1]
            val b = times[i]
            if (b - a > VEIL_MAX_WINDOW_MS) continue
            if (a !in privacyTimes && b !in privacyTimes) continue

            val sa = signatures[a] ?: continue
            val sb = signatures[b] ?: continue
            if (sa.size != sb.size) continue

            if (
                difference(sa, sb) >= VEIL_RAW_THRESHOLD &&
                ScreenPrivacyTracker.unexplainedChange(sa, sb, SIZE) >= VEIL_UNEXPLAINED_THRESHOLD
            ) {
                val last = veils.lastOrNull()
                if (last != null && last.endMs >= a) {
                    veils[veils.size - 1] = last.copy(endMs = b)
                } else {
                    veils += PrivacyVeil(a, b)
                }
            }
        }
        return veils
    }

    /**
     * P1: all privacy findings for one sample.
     *  - pattern findings per OCR line (sanitizer, with false-positive filter)
     *  - context findings across lines (labelled values, ID-card value bands,
     *    contact names)
     *  - faces
     */
    private fun privacyFindings(
        timestampMs: Long,
        lines: List<ScreenOcrText>,
        faceBoxes: List<RectF>
    ): List<SensitiveFinding> {

        val out =
            mutableListOf<SensitiveFinding>()

        lines.forEach { line ->
            out += ScreenSensitiveSanitizer.findings(
                timestampMs = timestampMs,
                text = line.text,
                bounds = line.bounds,
                confidence = line.confidence
            )
        }

        try {
            ScreenContextPrivacy.detect(
                lines.map { line ->
                    PrivacyTextLine(
                        text = line.text,
                        box = PrivacyBox(
                            line.bounds.left,
                            line.bounds.top,
                            line.bounds.right,
                            line.bounds.bottom
                        )
                    )
                }
            ).forEach { f ->
                out += SensitiveFinding(
                    timestampMs = timestampMs,
                    type = f.type,
                    maskedText = f.maskedText,
                    bounds = RectF(f.box.left, f.box.top, f.box.right, f.box.bottom),
                    confidence = .8f,
                    sourceText = f.sourceText
                )
            }
        } catch (t: Throwable) {
            Log.e(LOG_TAG, "Context privacy failed at ${timestampMs}ms", t)
        }

        faceBoxes.forEach { box ->
            out += SensitiveFinding(
                timestampMs = timestampMs,
                type = SensitiveDataType.FACE,
                maskedText = "[FACE]",
                bounds = box,
                confidence = .8f,
                sourceText = ""
            )
        }

        return out
    }

    /**
     * P1.1 speed: dense samples run face detection only when a neighbouring
     * sparse (1 s) sample found a face. Faces that appear between two sparse
     * samples are still caught by the next sparse sample.
     */
    private fun faceNearby(
        timeMs: Long,
        frames: List<ScreenFrameAnalysis>,
        sparseFindings: List<SensitiveFinding>
    ): Boolean {
        val before = frames.lastOrNull { it.timestampMs <= timeMs }?.timestampMs
        val after = frames.firstOrNull { it.timestampMs >= timeMs }?.timestampMs
        return sparseFindings.any {
            it.type == SensitiveDataType.FACE &&
                (it.timestampMs == before || it.timestampMs == after)
        }
    }

    /** P1: face boxes (normalized, with margin). Detector failure = no faces. */
    private fun detectFaces(
        bitmap: Bitmap,
        detector: FaceDetector?
    ): List<RectF> {

        if (detector == null) return emptyList()

        val result =
            runCatching {
                Tasks.await(
                    detector.process(InputImage.fromBitmap(bitmap, 0)),
                    1500,
                    TimeUnit.MILLISECONDS
                )
            }.getOrNull() ?: return emptyList()

        val w = bitmap.width.toFloat().coerceAtLeast(1f)
        val h = bitmap.height.toFloat().coerceAtLeast(1f)

        return result.mapNotNull { face ->
            val b = face.boundingBox
            val mx = b.width() * FACE_MARGIN_X
            val my = b.height() * FACE_MARGIN_Y
            val left = ((b.left - mx) / w).coerceIn(0f, 1f)
            val top = ((b.top - my) / h).coerceIn(0f, 1f)
            val right = ((b.right + mx) / w).coerceIn(0f, 1f)
            val bottom = ((b.bottom + my) / h).coerceIn(0f, 1f)
            if (right > left && bottom > top) RectF(left, top, right, bottom) else null
        }
    }

    /**
     * True when both samples show the same sensitive items at
     * (almost) the same positions. Tolerant to OCR box jitter.
     */
    private fun samePrivacyLayout(
        a: List<SensitiveFinding>,
        b: List<SensitiveFinding>
    ): Boolean {

        fun covered(
            from: List<SensitiveFinding>,
            into: List<SensitiveFinding>
        ): Boolean =
            from.all { x ->
                val kx = ScreenPrivacyTracker.normalizeKey(x.sourceText)
                into.any { y ->
                    x.type == y.type &&
                        kx == ScreenPrivacyTracker.normalizeKey(y.sourceText) &&
                        abs(x.bounds.centerX() - y.bounds.centerX()) < 0.03f &&
                        abs(x.bounds.centerY() - y.bounds.centerY()) < 0.03f
                }
            }

        return covered(a, b) && covered(b, a)
    }

    private fun SensitiveFinding.toPrivacyObservation(): PrivacyObservation =
        PrivacyObservation(
            timestampMs = timestampMs,
            type = type,
            box = PrivacyBox(
                bounds.left,
                bounds.top,
                bounds.right,
                bounds.bottom
            ),
            key = if (sourceText.isBlank()) "#${type.name}"
            else ScreenPrivacyTracker.normalizeKey(sourceText)
        )

    private fun signature(
        bitmap: Bitmap
    ): FloatArray {

        val scaled =
            Bitmap.createScaledBitmap(
                bitmap,
                SIZE,
                SIZE,
                true
            )

        val result =
            FloatArray(SIZE * SIZE)

        var index = 0

        for (y in 0 until SIZE) {

            for (x in 0 until SIZE) {

                val pixel =
                    scaled.getPixel(x, y)

                val red =
                    (pixel shr 16) and 255

                val green =
                    (pixel shr 8) and 255

                val blue =
                    pixel and 255

                result[index++] =
                    (red + green + blue) / 765f
            }
        }

        scaled.recycle()

        return result
    }

    private fun difference(
        a: FloatArray,
        b: FloatArray
    ): Float {

        var total = 0f

        for (i in a.indices) {
            total += abs(a[i] - b[i])
        }

        return total / a.size
    }

    private fun time(
        milliseconds: Long
    ): String {

        val seconds =
            milliseconds / 1000L

        return "%02d:%02d".format(
            Locale.US,
            seconds / 60L,
            seconds % 60L
        )
    }
    private fun differenceBounds(
        a: FloatArray,
        b: FloatArray
    ): RectF? {
        if (a.size != b.size || a.isEmpty()) return null

        val grid = 48
        val totalCells = grid * grid

        fun findBestComponent(threshold: Float): RectF? {

            val changed = BooleanArray(totalCells)

            for (i in 0 until totalCells) {
                changed[i] =
                    kotlin.math.abs(a[i] - b[i]) >= threshold
            }

            val visited = BooleanArray(totalCells)
            val queue = IntArray(totalCells)

            var found = false
            var bestScore = 0f

            var bestMinX = grid
            var bestMinY = grid
            var bestMaxX = -1
            var bestMaxY = -1

            for (startCell in 0 until totalCells) {
                if (!changed[startCell] || visited[startCell]) continue

                var head = 0
                var tail = 0

                queue[tail++] = startCell
                visited[startCell] = true

                var count = 0
                var minX = grid
                var minY = grid
                var maxX = -1
                var maxY = -1

                while (head < tail) {
                    val cell = queue[head++]

                    val x = cell % grid
                    val y = cell / grid

                    count++

                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y

                    if (x > 0) {
                        val n = cell - 1
                        if (changed[n] && !visited[n]) {
                            visited[n] = true
                            queue[tail++] = n
                        }
                    }

                    if (x < grid - 1) {
                        val n = cell + 1
                        if (changed[n] && !visited[n]) {
                            visited[n] = true
                            queue[tail++] = n
                        }
                    }

                    if (y > 0) {
                        val n = cell - grid
                        if (changed[n] && !visited[n]) {
                            visited[n] = true
                            queue[tail++] = n
                        }
                    }

                    if (y < grid - 1) {
                        val n = cell + grid
                        if (changed[n] && !visited[n]) {
                            visited[n] = true
                            queue[tail++] = n
                        }
                    }
                }

                if (count < 4) continue

                val widthCells = maxX - minX + 1
                val heightCells = maxY - minY + 1

                val widthRatio =
                    widthCells.toFloat() / grid.toFloat()

                val heightRatio =
                    heightCells.toFloat() / grid.toFloat()

                val boxArea =
                    widthCells.toFloat() *
                    heightCells.toFloat() /
                    totalCells.toFloat()

                // V27.2: reject broad screen-level changes.
                if (widthRatio > 0.55f) continue
                if (heightRatio > 0.55f) continue
                if (boxArea > 0.25f) continue

                val density =
                    count.toFloat() /
                    (widthCells * heightCells).toFloat()

                // Prefer compact, dense localized changes.
                val score =
                    density * 2f +
                    count.toFloat() / totalCells.toFloat()

                if (!found || score > bestScore) {
                    found = true
                    bestScore = score

                    bestMinX = minX
                    bestMinY = minY
                    bestMaxX = maxX
                    bestMaxY = maxY
                }
            }

            if (!found) return null

            val padding = 2

            val left =
                (bestMinX - padding)
                    .coerceAtLeast(0)
                    .toFloat() / grid

            val top =
                (bestMinY - padding)
                    .coerceAtLeast(0)
                    .toFloat() / grid

            val right =
                (bestMaxX + padding + 1)
                    .coerceAtMost(grid)
                    .toFloat() / grid

            val bottom =
                (bestMaxY + padding + 1)
                    .coerceAtMost(grid)
                    .toFloat() / grid

            return RectF(left, top, right, bottom)
        }

        // V27.2 strong precision pass.
        val strong = findBestComponent(0.20f)

        if (strong != null) return strong

        // V27.2 fallback for weaker changes.
        return findBestComponent(0.12f)
    }
}

