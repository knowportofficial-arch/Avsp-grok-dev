package com.avsp.pro.settings

/**
 * P9: several API keys per provider (master prompt: "multiple API keys per
 * provider with fallback"). Keys live in the encrypted [SecureConfigStore]
 * under numbered slots - slot 1 is the original name, so a key saved by an
 * older build simply becomes key 1:
 *
 *   AI_API, AI_API#2, AI_API#3, AI_API#4
 *
 * Keys are never logged or shown in full: the UI shows [mask] ("••••ABCD")
 * and logs refer to keys only by number.
 */
object ApiKeyRing {
    /** P17: up to 10 keys per provider. */
    const val MAX_KEYS = 10

    fun slot(name: String, index: Int): String = if (index == 0) name else "$name#${index + 1}"

    /** Saved keys in order (key 1 first), blanks and duplicates removed. */
    fun keys(store: SecureConfigStore?, name: String): List<String> {
        if (store == null) return emptyList()
        return (0 until MAX_KEYS)
            .mapNotNull { i -> runCatching { store.getSecret(slot(name, i)) }.getOrNull()?.trim()?.takeIf { it.isNotEmpty() } }
            .distinct()
    }

    sealed class AddResult {
        data class Added(val number: Int) : AddResult()
        data object Duplicate : AddResult()
        data object Full : AddResult()
        data object Blank : AddResult()
    }

    fun add(store: SecureConfigStore, name: String, value: String): AddResult {
        val key = value.trim()
        if (key.isEmpty()) return AddResult.Blank
        val current = keys(store, name)
        if (key in current) return AddResult.Duplicate
        if (current.size >= MAX_KEYS) return AddResult.Full
        write(store, name, current + key)
        return AddResult.Added(current.size + 1)
    }

    data class BulkResult(val added: Int, val duplicates: Int, val rejected: Int, val full: Int)

    /** P17: paste many keys at once - one per line (spaces / commas also separate). */
    fun addMany(store: SecureConfigStore, name: String, text: String, accept: (String) -> Boolean = { true }): BulkResult {
        var added = 0; var dup = 0; var bad = 0; var full = 0
        text.split(Regex("""[\s,;]+""")).map { it.trim().trim('"', '\'') }.filter { it.isNotEmpty() }.forEach { k ->
            if (!accept(k)) { bad++; return@forEach }
            when (add(store, name, k)) {
                is AddResult.Added -> added++
                AddResult.Duplicate -> dup++
                AddResult.Full -> full++
                AddResult.Blank -> Unit
            }
        }
        return BulkResult(added, dup, bad, full)
    }

    /** Removes key number [index] (0-based) and closes the gap, so key 1 always exists when any key does. */
    fun remove(store: SecureConfigStore, name: String, index: Int) {
        val current = keys(store, name)
        if (index !in current.indices) return
        write(store, name, current.filterIndexed { i, _ -> i != index })
    }

    /** Moves key [index] to the front (used after it worked, so it is tried first next time). */
    fun promote(store: SecureConfigStore, name: String, index: Int) {
        val current = keys(store, name)
        if (index <= 0 || index !in current.indices) return
        write(store, name, listOf(current[index]) + current.filterIndexed { i, _ -> i != index })
    }

    private fun write(store: SecureConfigStore, name: String, list: List<String>) {
        for (i in 0 until MAX_KEYS) {
            val v = list.getOrNull(i)
            if (v != null) store.putSecret(slot(name, i), v) else store.clearSecret(slot(name, i))
        }
    }

    /** "••••ABCD" - never more than the last 4 characters. */
    fun mask(key: String): String {
        val k = key.trim()
        return if (k.length <= 8) "••••" else "••••" + k.takeLast(4)
    }

    /** True when an error means "this key can't be used now - try the next key". */
    fun isKeyProblem(message: String?): Boolean {
        if (message == null) return false
        return listOf("HTTP 400", "HTTP 401", "HTTP 403", "HTTP 429", "API key", "API_KEY", "quota", "PERMISSION_DENIED")
            .any { message.contains(it, ignoreCase = true) }
    }
}
