﻿package com.avsp.pro.m9

/**
 * M9.5 credential storage boundary.
 *
 * This module stores opaque credential material behind an abstraction.
 * OAuth authorization, token exchange, network transmission and
 * external publishing remain outside M9.5.
 *
 * Secrets are never included in presence/status objects.
 */
enum class M9CredentialType {
    OAUTH_ACCESS_TOKEN,
    OAUTH_REFRESH_TOKEN,
    API_KEY
}

data class M9CredentialKey(
    val providerId: String,
    val type: M9CredentialType
)

data class M9CredentialPresence(
    val providerId: String,
    val accessTokenPresent: Boolean,
    val refreshTokenPresent: Boolean,
    val apiKeyPresent: Boolean
)

interface M9CredentialStore {

    fun put(
        key: M9CredentialKey,
        secret: String
    )

    fun get(
        key: M9CredentialKey
    ): String?

    fun remove(
        key: M9CredentialKey
    )

    fun clearProvider(
        providerId: String
    )

    fun contains(
        key: M9CredentialKey
    ): Boolean

    fun presence(
        providerId: String
    ): M9CredentialPresence
}

/**
 * Deterministic in-memory implementation used by M9.5 tests.
 *
 * This is NOT claimed to be production persistent secure storage.
 */
class M9InMemoryCredentialStore : M9CredentialStore {

    private val values =
        mutableMapOf<M9CredentialKey, String>()

    override fun put(
        key: M9CredentialKey,
        secret: String
    ) {
        require(key.providerId.trim().isNotEmpty()) {
            "Provider ID is required."
        }

        require(secret.isNotEmpty()) {
            "Credential secret must not be empty."
        }

        values[key] = secret
    }

    override fun get(
        key: M9CredentialKey
    ): String? {
        return values[key]
    }

    override fun remove(
        key: M9CredentialKey
    ) {
        values.remove(key)
    }

    override fun clearProvider(
        providerId: String
    ) {
        val normalized = providerId.trim()

        values.keys
            .filter { it.providerId == normalized }
            .toList()
            .forEach { values.remove(it) }
    }

    override fun contains(
        key: M9CredentialKey
    ): Boolean {
        return values.containsKey(key)
    }

    override fun presence(
        providerId: String
    ): M9CredentialPresence {

        val normalized = providerId.trim()

        return M9CredentialPresence(
            providerId = normalized,
            accessTokenPresent = values.containsKey(
                M9CredentialKey(
                    normalized,
                    M9CredentialType.OAUTH_ACCESS_TOKEN
                )
            ),
            refreshTokenPresent = values.containsKey(
                M9CredentialKey(
                    normalized,
                    M9CredentialType.OAUTH_REFRESH_TOKEN
                )
            ),
            apiKeyPresent = values.containsKey(
                M9CredentialKey(
                    normalized,
                    M9CredentialType.API_KEY
                )
            )
        )
    }
}

/**
 * Safe-facing helper.
 *
 * It exposes credential presence only.
 * It does not expose credential contents.
 */
object M9CredentialBoundary {

    fun hasCredential(
        store: M9CredentialStore,
        providerId: String,
        type: M9CredentialType
    ): Boolean {
        return store.contains(
            M9CredentialKey(
                providerId.trim(),
                type
            )
        )
    }

    fun presence(
        store: M9CredentialStore,
        providerId: String
    ): M9CredentialPresence {
        return store.presence(providerId.trim())
    }

    fun clearProvider(
        store: M9CredentialStore,
        providerId: String
    ) {
        store.clearProvider(providerId.trim())
    }
}
