﻿package com.avsp.pro.m9

import java.io.File

enum class M9PlatformPublishStatus {
    READY,
    PUBLISHED,
    PROCESSING,
    FAILED,
    NOT_CONFIGURED
}

data class M9PlatformPublishResult(
    val platform: M9Platform,
    val status: M9PlatformPublishStatus,
    val providerMode: M9ProviderMode,
    val authState: M9AuthState,
    val externalId: String?,
    val message: String,
    val realOperationPerformed: Boolean
)

enum class M9MultiPlatformStatus {
    READY,
    PARTIAL,
    PUBLISHED,
    FAILED
}

data class M9MultiPlatformPublishResult(
    val projectId: String,
    val jobId: String,
    val status: M9MultiPlatformStatus,
    val results: List<M9PlatformPublishResult>,
    val successfulPlatforms: Set<M9Platform>,
    val failedPlatforms: Set<M9Platform>,
    val notConfiguredPlatforms: Set<M9Platform>
)

object M9MultiPlatformPublisher {

    fun prepare(job: M9Job): M9MultiPlatformPublishResult {

        require(job.status == M9Status.READY) {
            "M9.3 multi-platform publishing requires job status READY."
        }

        require(job.projectId.isNotBlank()) {
            "M9.3 requires a projectId."
        }

        require(job.videoPath.isNotBlank()) {
            "M9.3 requires a videoPath."
        }

        val videoFile = File(job.videoPath)

        require(videoFile.exists()) {
            "M9.3 video does not exist."
        }

        require(videoFile.isFile) {
            "M9.3 video path is not a file."
        }

        require(job.title.isNotBlank()) {
            "M9.3 requires a title."
        }

        require(job.platforms.isNotEmpty()) {
            "M9.3 requires at least one publishing platform."
        }

        val results = job.platforms
            .sortedBy { it.name }
            .map { platform ->
                evaluatePlatform(job, videoFile, platform)
            }

        val successful = results
            .filter {
                it.status == M9PlatformPublishStatus.PUBLISHED ||
                    it.status == M9PlatformPublishStatus.PROCESSING
            }
            .map { it.platform }
            .toSet()

        val failed = results
            .filter { it.status == M9PlatformPublishStatus.FAILED }
            .map { it.platform }
            .toSet()

        val notConfigured = results
            .filter { it.status == M9PlatformPublishStatus.NOT_CONFIGURED }
            .map { it.platform }
            .toSet()

        val overall = when {
            successful.isNotEmpty() && failed.isEmpty() && notConfigured.isEmpty() ->
                M9MultiPlatformStatus.PUBLISHED

            successful.isNotEmpty() ->
                M9MultiPlatformStatus.PARTIAL

            else ->
                M9MultiPlatformStatus.FAILED
        }

        return M9MultiPlatformPublishResult(
            projectId = job.projectId,
            jobId = job.jobId,
            status = overall,
            results = results,
            successfulPlatforms = successful,
            failedPlatforms = failed,
            notConfiguredPlatforms = notConfigured
        )
    }

    private fun evaluatePlatform(
        job: M9Job,
        videoFile: File,
        platform: M9Platform
    ): M9PlatformPublishResult {

        val providerId = M9ProviderId.valueOf(platform.name)
        val provider = M9PublishingProviderRegistry.get(providerId)
        val auth = provider.authState()

        if (provider.capabilities.mode == M9ProviderMode.NOT_CONFIGURED) {
            return M9PlatformPublishResult(
                platform = platform,
                status = M9PlatformPublishStatus.NOT_CONFIGURED,
                providerMode = provider.capabilities.mode,
                authState = auth.state,
                externalId = null,
                message = "Provider $platform is not configured. No upload was performed.",
                realOperationPerformed = false
            )
        }

        val result = provider.publish(
            M9PublishRequest(
                jobId = job.jobId,
                projectId = job.projectId,
                videoFile = videoFile,
                title = job.title,
                provider = providerId
            )
        )

        val status = when (result.state) {
            M9UploadState.PUBLISHED ->
                M9PlatformPublishStatus.PUBLISHED

            M9UploadState.PROCESSING ->
                M9PlatformPublishStatus.PROCESSING

            M9UploadState.FAILED ->
                M9PlatformPublishStatus.FAILED

            M9UploadState.PARTIAL ->
                M9PlatformPublishStatus.FAILED

            else ->
                M9PlatformPublishStatus.FAILED
        }

        return M9PlatformPublishResult(
            platform = platform,
            status = status,
            providerMode = provider.capabilities.mode,
            authState = auth.state,
            externalId = result.externalId,
            message = result.message,
            realOperationPerformed = result.realOperationPerformed
        )
    }
}
