﻿/*
 * AVSP M9.10
 *
 * User-facing Publish Center integration.
 *
 * Scope:
 * - Reuse existing M9.8 preflight.
 * - Reuse existing M9.9 execution orchestration.
 * - Expose explicit provider/auth/runtime state to UI.
 * - Never fake external publishing.
 * - Never expose credentials.
 *
 * External OAuth/upload remains NOT_CONFIGURED until a real
 * provider implementation and credentials are configured.
 */
package com.avsp.pro.m9

data class M9PublishUiState(
    val status: String = "DRAFT",
    val message: String = "",
    val provider: String = "",
    val providerMode: String = "",
    val authState: String = "",
    val realOperationPerformed: Boolean = false,
    val externalId: String? = null
)

object M9PublishingUiIntegration {

    fun providerState(provider: M9ProviderId): M9PublishUiState {
        val p = M9PublishingProviderRegistry.get(provider)
        val auth = p.authState()

        return M9PublishUiState(
            status = "NOT_CONFIGURED",
            message = auth.message,
            provider = provider.name,
            providerMode = p.capabilities.mode.name,
            authState = auth.state.name,
            realOperationPerformed = false,
            externalId = null
        )
    }
}
