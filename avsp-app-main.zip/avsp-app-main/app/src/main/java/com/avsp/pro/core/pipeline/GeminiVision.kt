package com.avsp.pro.core.pipeline

import android.graphics.Bitmap
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection

/**
 * P18.1: when the text in a photo can't be read well (hand-written notes, a
 * diagram, a poster with art), the user's own Gemini key looks at the picture
 * and explains it in plain sentences - without any private details.
 */
object GeminiVision {
    private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"
    private val MODELS = listOf("gemini-flash-latest", "gemini-flash-lite-latest")

    fun prompt(language: String = "English") =
        "Explain this picture for a short social-media video, in $language. Say what it is and the 3-5 most useful facts or ideas it shows, " +
            "as plain sentences a narrator can read aloud. Do not read out codes, passwords, user IDs, IP addresses, phone numbers, " +
            "account numbers, e-mail addresses or anyone's private details - describe them generally instead (for example 'the login details'). " +
            "No headings, no lists, no markdown."

    /** Description, or null (no key, offline, refused). Blocking - call off the main thread. */
    fun describe(bitmap: Bitmap, keys: List<String>, language: String = "English"): String? {
        if (keys.isEmpty()) return null
        val scale = minOf(1f, 1280f / maxOf(bitmap.width, bitmap.height))
        val small = if (scale < 1f) Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt(), (bitmap.height * scale).toInt(), true) else bitmap
        val jpg = ByteArrayOutputStream().also { small.compress(Bitmap.CompressFormat.JPEG, 85, it) }.toByteArray()
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
            .put(JSONObject().put("text", prompt(language)))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", java.util.Base64.getEncoder().encodeToString(jpg)))))))
            .put("generationConfig", JSONObject().put("temperature", 0.3))
            .toString()
        for (key in keys.take(3)) for (model in MODELS) {
            val text = runCatching { extract(post(ENDPOINT.format(model), key, body)) }.getOrNull()
            if (!text.isNullOrBlank()) return text.trim()
        }
        return null
    }

    fun extract(raw: String): String = runCatching {
        val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
            .replace(Regex("""[*#`]+"""), "").replace(Regex("""\n{2,}"""), "\n").trim()
    }.getOrDefault("")

    private fun post(url: String, key: String, body: String): String {
        val c = java.net.URI(url).toURL().openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = 8_000; c.readTimeout = 25_000
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            check(c.responseCode in 200..299) { "HTTP ${c.responseCode}" }
            return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        } finally { c.disconnect() }
    }
}
