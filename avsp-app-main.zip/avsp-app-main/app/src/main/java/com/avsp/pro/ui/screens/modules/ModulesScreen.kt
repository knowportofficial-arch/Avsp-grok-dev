package com.avsp.pro.ui.screens.modules

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.avsp.pro.core.module.ModuleRunStatus
import com.avsp.pro.core.module.ModuleStatus
import com.avsp.pro.core.ui.UiState
import com.avsp.pro.ui.components.ErrorState
import com.avsp.pro.ui.components.LoadingState
import com.avsp.pro.ui.viewmodel.ModulesViewModel

/** Plain-language name and job of each internal module (M1-M9). */
private val FRIENDLY = mapOf(
    "M1" to ("App & projects" to "Projects, storage and settings"),
    "M2" to ("Script writer" to "Writes the video script (Gemini AI or built-in offline writer)"),
    "M3" to ("Voice-over" to "Reads the script aloud with the phone's voice"),
    "M4" to ("Video maker" to "Builds the final video with scenes and captions"),
    "M5" to ("Sources" to "Reads text, links, YouTube, files and screen recordings"),
    "M6" to ("Camera" to "Guided filming with the camera"),
    "M7" to ("Vision" to "Recognises text and faces (privacy blur)"),
    "M8" to ("Timeline" to "Creative timeline and editing"),
    "M9" to ("Publishing" to "Title, description, hashtags and sharing")
)

/** Settings > Advanced > Studio tools: is every part of the app working? */
@Composable
fun ModulesScreen(viewModel: ModulesViewModel, onBack: () -> Unit = {}) {
    val state by viewModel.state.collectAsState()
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Back") }
            TextButton(onClick = viewModel::refresh) { Text("Refresh") }
        }
        Text("Studio tools", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Every part of AVSP and whether it is working.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )
        when (val s = state) {
            is UiState.Idle, is UiState.Loading -> LoadingState("Checking…")
            is UiState.Error -> ErrorState(s.message, onRetry = viewModel::refresh)
            is UiState.Success -> {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(s.data, key = { it.moduleId }) { mod -> ToolRow(mod) }
                }
            }
        }
    }
}

@Composable
private fun ToolRow(mod: ModuleStatus) {
    val (name, job) = FRIENDLY[mod.moduleId] ?: (mod.displayName to "")
    val problem = mod.status == ModuleRunStatus.FAILED || mod.error != null
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(name, style = MaterialTheme.typography.titleMedium)
                if (job.isNotBlank()) {
                    Text(
                        job,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                }
                mod.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Text(
                    "${mod.moduleId} · v${mod.version}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.45f)
                )
            }
            val color = if (problem) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
            Text(
                if (problem) "Problem" else "Ready",
                style = MaterialTheme.typography.labelMedium,
                color = color,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(color.copy(alpha = 0.12f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}
