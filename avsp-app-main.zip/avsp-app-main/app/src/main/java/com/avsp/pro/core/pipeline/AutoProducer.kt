package com.avsp.pro.core.pipeline

import com.avsp.pro.audio.contract.AudioGenerationRequest
import com.avsp.pro.audio.repository.AudioRepository
import com.avsp.pro.core.contracts.Project
import com.avsp.pro.logs.AvspLogger
import com.avsp.pro.repository.ProjectRepository
import com.avsp.pro.script.contract.DurationRequest
import com.avsp.pro.script.contract.ScriptGenerationRequest
import com.avsp.pro.script.language.ScriptLanguageRegistry
import com.avsp.pro.script.repository.ScriptRepository
import com.avsp.pro.video.contract.VideoRenderResult
import com.avsp.pro.video.repository.VideoRepository
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.withPermit

/**
 * P2 ONE-TAP PRODUCTION
 *
 * Project (any source) -> AI script -> voice-over -> rendered MP4 exported to
 * the gallery, using the existing M2 / M3 / M4 repositories unchanged.
 * Every step reports progress; any failure stops with a plain-language reason
 * and the work done so far stays saved (the user can continue manually).
 */
class AutoProducer(
    private val projectRepository: ProjectRepository,
    private val scriptRepository: ScriptRepository,
    private val audioRepository: AudioRepository,
    private val videoRepository: VideoRepository,
    private val logger: AvspLogger,
    private val storage: com.avsp.pro.storage.AvspStorage? = null,
    private val stock: com.avsp.pro.media.PexelsStockProvider? = null,
    /** P8: free pictures without any key (Openverse) when Pexels is missing or rejected. */
    private val pictures: com.avsp.pro.media.OpenverseImageProvider? = null,
    /** P12: thumbnail from the best moment of the video's pictures, with the title on it. */
    private val thumbnails: com.avsp.pro.edit.ThumbnailMaker? = null,
    /** P16: the user's phone gallery (used first when turned on in Settings). */
    private val gallery: com.avsp.pro.media.GalleryLibrary? = null,
    /** P17: Pixabay / Unsplash photos with the user's own free keys. */
    private val keyedPhotos: com.avsp.pro.media.KeyedPhotoProvider? = null
) {

    enum class Step(val label: String) {
        SCRIPT("Writing script"),
        VISUALS("Finding visuals"),
        VOICE("Recording voice-over"),
        VIDEO("Rendering video"),
        DONE("Done")
    }

    data class Progress(val step: Step, val detail: String = "")

    data class Result(
        val title: String,
        val scriptProvider: String,
        val video: VideoRenderResult,
        /** P2.2: plain-language note about stock video, or null. */
        val stockNote: String? = null,
        /** P3: title, description and hashtags ready to post. */
        val kit: PublishKit? = null,
        /** P12: 9:16 thumbnail (content Uri) or null. */
        val thumbnail: String? = null
    )

    suspend fun produce(
        projectId: String,
        durationSeconds: Int = 60,
        onProgress: (Progress) -> Unit = {}
    ): Result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        /* P2.1: all steps run off the main thread (TTS init needs the main looper free). */
        produceInternal(projectId, durationSeconds, onProgress)
    }

    private suspend fun produceInternal(
        projectId: String,
        durationSeconds: Int,
        onProgress: (Progress) -> Unit
    ): Result {
        val project = projectRepository.openProject(projectId)
        onProgress(Progress(Step.SCRIPT, "Topic: ${project.name}"))
        val script = writeScript(projectId, topicFor(project), durationSeconds)
        return finishInternal(projectId, script, null, onProgress)
    }

    /** P22.1 "Auto" length: as long as the content needs - short topic ~45 s, a long article up to 5 min. */
    fun autoSeconds(topic: String): Int {
        val words = topic.split(Regex("\\s+")).count { it.length > 1 }
        val steps = Regex("(?im)^\\s*(step\\s*\\d+|\\d+[.)])").findAll(topic).count()
        return when {
            steps >= 6 || words > 900 -> 300
            steps >= 3 || words > 450 -> 180
            words > 200 -> 120
            words > 80 -> 60
            else -> 45
        }
    }

    /**
     * P33 OTHER VERSIONS: the same story as a new project in another language and/or shape
     * (9:16 Shorts/Reels, 16:9 YouTube, 4:5 / 1:1 feed). The creator's own photos and clips come along;
     * the script is written fresh in that language. Returns the new project id.
     */
    suspend fun cloneAs(projectId: String, language: com.avsp.pro.core.model.ProjectLanguage, aspect: com.avsp.pro.core.model.AspectRatio): String =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val p = projectRepository.openProject(projectId)
            val created = projectRepository.createProject(
                name = (p.name.substringBefore(" · ") + " · " + language.displayName + " " + aspect.label).take(118),
                description = p.description, aspectRatio = aspect, language = language,
                metadata = p.metadata + ("version.of" to projectId)
            )
            // The language chosen here wins over the language detected from the text.
            val fixed = if (created.language == language) created else projectRepository.updateProject(created.copy(language = language))
            val store = storage
            if (store != null) projectRepository.listMediaAssets(projectId)
                .filter { a -> !a.tags.contains("stock") && !a.tags.contains("m4-test") && a.tags.none { it.startsWith("scene:") } &&
                    (a.mimeType.startsWith("image/") || a.mimeType.startsWith("video/")) }
                .forEach { a ->
                    runCatching {
                        val src = java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, a.relativePath, projectId))
                        val dst = java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, a.relativePath, fixed.projectId))
                        dst.parentFile?.mkdirs(); src.copyTo(dst, overwrite = true)
                        projectRepository.addMediaAsset(a.copy(assetId = a.assetId + "_" + fixed.projectId.takeLast(6), projectId = fixed.projectId))
                    }
                }
            logger.info("AUTO", "Version: ${language.code} ${aspect.label} of $projectId", projectId = fixed.projectId)
            fixed.projectId
        }

    /** P7 manual mode, step 2: script from the (possibly edited) topic. */
    suspend fun writeScript(projectId: String, topic: String, durationSeconds: Int): com.avsp.pro.script.contract.ScriptPackage =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val project = projectRepository.openProject(projectId)
            val language = project.language.code.takeIf { ScriptLanguageRegistry.isSupported(it) } ?: "en"
            val script = scriptRepository.generate(
                ScriptGenerationRequest(
                    projectId = projectId,
                    topic = topic.take(6000),
                    languageCode = language,
                    duration = DurationRequest.Explicit((if (durationSeconds <= 0) autoSeconds(topic) else durationSeconds).coerceIn(15, 600) * 1000L),
                    aspectRatioLabel = project.aspectRatio.label,
                    // P31: "Change & remake" - the creator's own instructions for the next version.
                    userInstructions = project.metadata[INSTRUCTIONS_KEY]?.takeIf { it.isNotBlank() }
                )
            )
            check(script.validation.isValid) {
                "Script could not be written: " + script.validation.errors.joinToString("; ")
            }
            logger.info("AUTO", "Script ready via ${script.metadata.generatorId}", projectId = projectId)
            script
        }

    /** P22.4 picture preview: what each scene will show, before voice + video are made. */
    data class ScenePicture(val sceneId: String, val path: String, val video: Boolean, val credit: String?)

    /** Pictures the user turned down ("Another picture"), per project - never offered again. */
    private val rejected = java.util.concurrent.ConcurrentHashMap<String, MutableSet<String>>()

    /** Finds pictures for [scenes] (keeps ones already found) and returns every scene's current picture. */
    suspend fun previewPictures(projectId: String, script: com.avsp.pro.script.contract.ScriptPackage, scenes: Set<String>): Map<String, ScenePicture> =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            fetchStock(projectRepository.openProject(projectId), script, scenes, keepExisting = true)
            picturesFor(projectId, script)
        }

    /** Replaces one scene's picture with a different one; null when nothing else matches. */
    suspend fun anotherPicture(projectId: String, script: com.avsp.pro.script.contract.ScriptPackage, sceneId: String): ScenePicture? =
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            val current = stockAsset(projectId, script.scriptId, sceneId)
            if (current != null) rejected.getOrPut(projectId) { java.util.concurrent.ConcurrentHashMap.newKeySet() } += sourceIds(current)
            val added = fetchStock(projectRepository.openProject(projectId), script, setOf(sceneId), keepExisting = false)
            if (added == 0) return@withContext null
            picturesFor(projectId, script)[sceneId]
        }

    /** Drops the found picture of scenes the user switched to their own media or animation. */
    suspend fun dropPictures(projectId: String, scriptId: String, scenes: Set<String>) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        scenes.forEach { id -> stockAsset(projectId, scriptId, id)?.let { projectRepository.removeMediaAsset(it.assetId) } }
    }

    suspend fun picturesFor(projectId: String, script: com.avsp.pro.script.contract.ScriptPackage): Map<String, ScenePicture> {
        val store = storage ?: return emptyMap()
        return projectRepository.listMediaAssets(projectId).mapNotNull { a ->
            val sceneId = a.tags.firstOrNull { it.startsWith("stock:${script.scriptId}:") }?.substringAfterLast(':') ?: return@mapNotNull null
            val f = java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, a.relativePath, projectId))
            if (!f.exists()) null
            else sceneId to ScenePicture(sceneId, f.absolutePath, a.mimeType.startsWith("video/"),
                a.tags.firstOrNull { it.startsWith("credit:") }?.removePrefix("credit:") ?: if (a.tags.contains("gallery")) "your gallery" else null)
        }.toMap()
    }

    private suspend fun stockAsset(projectId: String, scriptId: String, sceneId: String) =
        projectRepository.listMediaAssets(projectId).firstOrNull { a -> a.tags.contains("stock:$scriptId:$sceneId") }

    /** P10: free pictures for a script's scenes, unless they were already fetched (blog without a video). */
    suspend fun ensurePictures(projectId: String, script: com.avsp.pro.script.contract.ScriptPackage) {
        val have = projectRepository.listMediaAssets(projectId).any { a -> a.tags.any { it.startsWith("stock:${script.scriptId}:") } }
        if (have) return
        runCatching { fetchStock(projectRepository.openProject(projectId), script, null) }
            .onFailure { logger.warning("BLOG", "Pictures skipped", details = it.message, projectId = projectId) }
    }

    /**
     * Steps after the script: visuals -> voice -> video. [stockScenes]: null = automatic
     * (stock for every scene when the project has no own media); a set = only those scenes
     * (manual mode, where the user chose "free stock" per scene).
     */
    suspend fun finish(
        projectId: String,
        script: com.avsp.pro.script.contract.ScriptPackage,
        stockScenes: Set<String>?,
        onProgress: (Progress) -> Unit = {}
    ): Result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        finishInternal(projectId, script, stockScenes, onProgress)
    }

    private suspend fun finishInternal(
        projectId: String,
        incoming: com.avsp.pro.script.contract.ScriptPackage,
        stockScenes: Set<String>?,
        onProgress: (Progress) -> Unit
    ): Result {
        val project = projectRepository.openProject(projectId)
        // P9.2: the outro is only a short call to action (≤ 3 s spoken).
        // P23: an outro the creator said in their own voice is kept as it is.
        val ownOutro = storage != null && incoming.scenes.maxByOrNull { it.order }?.let {
            com.avsp.pro.audio.OwnVoice.has(storage, projectId, incoming.scriptId, it.sceneId) } == true
        val script = (if (ownOutro) incoming else CtaRule.apply(incoming, project.language.code)).let { fixed ->
            if (fixed === incoming) incoming
            else runCatching { scriptRepository.updateEdited(fixed) }.getOrElse { incoming }
        }
        onProgress(Progress(Step.VISUALS, "${script.scenes.size} scenes + voice"))
        lastStockNote = null
        val started = System.currentTimeMillis()
        // P15: free mood-matched music downloads in the background while voice + pictures are made.
        val musicJob = storage?.let { store ->
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                val t0 = System.currentTimeMillis()
                runCatching {
                    val text = listOf(script.title, script.topic, script.scenes.joinToString(" ") { it.narration }).joinToString(" ")
                    val mood = com.avsp.pro.media.FreeMusicProvider.mood(text)
                    val dir = java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, "audio", projectId))
                    val got = com.avsp.pro.media.FreeMusicProvider(dir).fetch(mood, (projectId + script.scriptId).hashCode())
                    logger.info("AUTO", "Free music: ${got.track.title} (${mood.name}, ${got.file.length() / 1024} KB, ${System.currentTimeMillis() - t0} ms)", projectId = projectId)
                }.onFailure { logger.warning("AUTO", "Free music skipped - using AVSP's own music", details = it.message, projectId = projectId) }
            }
        }
        // P9.2 speed: voice and pictures are made at the same time (they don't depend on each other).
        val (stockCount, audio) = kotlinx.coroutines.coroutineScope {
            val visuals = async { fetchStock(project, script, stockScenes) }
            val voice = async { audioRepository.generate(AudioGenerationRequest(projectId = projectId)) }
            visuals.await() to voice.await()
        }
        // Give the music a few more seconds at most; otherwise this video keeps the generated music.
        musicJob?.let { j -> kotlinx.coroutines.withTimeoutOrNull(5_000) { j.join() } }
        if (stockCount > 0) logger.info("AUTO", "Stock clips added: $stockCount", projectId = projectId)
        logger.info("AUTO", "Voice ready via ${audio.provider} (${audio.totalDurationMs} ms); visuals+voice took ${System.currentTimeMillis() - started} ms", projectId = projectId)
        onProgress(Progress(Step.VOICE, "${audio.totalDurationMs / 1000}s of narration"))

        onProgress(Progress(Step.VIDEO, "${audio.totalDurationMs / 1000}s of narration"))
        val renderStart = System.currentTimeMillis()
        val video = videoRepository.render(projectId)
        logger.info("AUTO", "Video exported ${video.exportedDisplayName} (render ${System.currentTimeMillis() - renderStart} ms)", projectId = projectId)

        onProgress(Progress(Step.DONE, video.exportedDisplayName ?: video.outputRelativePath))
        val credits = runCatching {
            projectRepository.listMediaAssets(projectId)
                .filter { a -> a.tags.any { it.startsWith("stock:${script.scriptId}:") } }
                .mapNotNull { a -> a.tags.firstOrNull { it.startsWith("credit:") }?.removePrefix("credit:") }
                .distinct()
        }.getOrDefault(emptyList())
        val kit = runCatching { PublishKit.from(script, project.aspectRatio.height > project.aspectRatio.width) }.getOrNull()
            ?.let { k -> if (credits.isEmpty()) k else k.copy(description = (k.description + "\n\nPictures: " + credits.joinToString("; ")).take(PublishKit.MAX_DESCRIPTION + 400)) }
            ?.let { k ->
                // P15: CC BY music must be credited.
                val music = storage?.let { store -> runCatching {
                    com.avsp.pro.media.FreeMusicProvider.cached(java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, "audio/music", projectId)))?.second
                }.getOrNull() }
                if (music.isNullOrBlank()) k else k.copy(description = (k.description + "\n" + music).take(PublishKit.MAX_DESCRIPTION + 600))
            }
        val thumb = runCatching { makeThumbnail(project, script, video) }
            .onFailure { logger.warning("AUTO", "Thumbnail skipped", details = it.message, projectId = projectId) }.getOrNull()
        return Result(script.title, script.metadata.generatorId, video, lastStockNote, kit, thumb)
    }

    /** P12: best picture/clip moment used in this video + its title. Falls back to the video itself (doodles, cards). */
    private suspend fun makeThumbnail(project: Project, script: com.avsp.pro.script.contract.ScriptPackage, video: VideoRenderResult): String? {
        val maker = thumbnails ?: return null
        val store = storage ?: return null
        val doodle = project.metadata["visual.style"] == "doodle"
        val assets = projectRepository.listMediaAssets(project.projectId).filter { a ->
            !a.tags.contains("m4-test") && (a.mimeType.startsWith("image/") || a.mimeType.startsWith("video/")) &&
                (a.tags.contains("own") || (!doodle && a.tags.any { it.startsWith("stock:${script.scriptId}:") }) || a.tags.any { it.startsWith("scene:${script.scriptId}:") })
        }
        val sources = assets.mapNotNull { a ->
            val f = java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, a.relativePath, project.projectId))
            if (!f.exists()) null
            else if (a.mimeType.startsWith("image/")) com.avsp.pro.edit.ThumbnailMaker.Source.Image(f)
            else com.avsp.pro.edit.ThumbnailMaker.Source.Video(android.net.Uri.fromFile(f), 0L.coerceAtLeast(runCatching {
                val r = android.media.MediaMetadataRetriever(); try { r.setDataSource(f.absolutePath); r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L } finally { r.release() }
            }.getOrDefault(0L)))
        }
        val fallback = com.avsp.pro.edit.ThumbnailMaker.Source.Video(android.net.Uri.fromFile(java.io.File(video.outputAbsolutePath)), video.durationMs)
        val stem = "AVSP_" + project.projectId.takeLast(8) + "_" + System.currentTimeMillis() / 1000
        val t = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { maker.make(sources, script.title.ifBlank { project.name }, stem, fallback) }
        if (t != null) logger.info("AUTO", "Thumbnail made from ${if (sources.isEmpty()) "the video" else "${sources.size} pictures/clips"}", projectId = project.projectId)
        return t?.portrait?.toString()
    }

    /**
     * P2: one free stock clip per scene (Pexels) when a key is configured and
     * the project has no own photos/videos. Any failure leaves that scene to
     * the designed scene card. Returns the number of clips added.
     */
    @Volatile
    private var lastStockNote: String? = null

    private suspend fun fetchStock(
        project: Project,
        script: com.avsp.pro.script.contract.ScriptPackage,
        onlyScenes: Set<String>? = null,
        /** P22.4: scenes that already have a picture (chosen in the preview) keep it. */
        keepExisting: Boolean = true
    ): Int = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val store = storage ?: return@withContext 0
        if (stock == null && pictures == null) return@withContext 0
        // P11: doodle look = hand-drawn animation, no picture search (also faster).
        if (onlyScenes == null && project.metadata["visual.style"] == "doodle") return@withContext 0
        val own = projectRepository.listMediaAssets(project.projectId).filter {
            (it.mimeType.startsWith("video/") || it.mimeType.startsWith("image/")) &&
                !it.tags.contains("m4-test") && !it.tags.contains("stock")
        }
        // P9: the user's own photos/videos cover the first scenes (in order); only the
        // remaining scenes get free pictures instead of plain cards.
        val ownCovered: Set<String> = if (onlyScenes == null) {
            script.scenes.sortedBy { it.order }.take(own.count { a -> a.tags.none { it.startsWith("scene:") } })
                .map { it.sceneId }.toSet()
        } else emptySet()
        val portrait = project.aspectRatio.height > project.aspectRatio.width
        val last = script.scenes.maxByOrNull { it.order }?.sceneId
        val pexelsOk = java.util.concurrent.atomic.AtomicBoolean(stock?.isConfigured == true)
        val existing = projectRepository.listMediaAssets(project.projectId)
        val haveScene = if (!keepExisting) emptySet() else existing.mapNotNull { a ->
            a.tags.firstOrNull { it.startsWith("stock:${script.scriptId}:") }?.substringAfterLast(':')
                ?.takeIf { java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, a.relativePath, project.projectId)).exists() }
        }.toSet()
        // Pictures already in this video or turned down by the user are not used again.
        val usedPictures = (rejected[project.projectId].orEmpty() + existing.filter { a -> a.tags.any { it.startsWith("stock:${script.scriptId}:") } }.flatMap { sourceIds(it) }).toMutableSet()
        lastStockNote = null
        val targets = script.scenes.filter { scene ->
            !(onlyScenes != null && scene.sceneId !in onlyScenes) &&
                scene.sceneId !in ownCovered && scene.sceneId !in haveScene &&
                !(scene.sceneId == last && script.scenes.size > 1) // CTA outro keeps its designed card
        }
        val galleryItems = gallery?.takeIf { it.enabled }?.let { g ->
            runCatching { g.index(maxNew = 40, budgetMs = 4_000); g.load().values.toList() }.getOrNull()
        }.orEmpty()
        if (gallery?.enabled == true) logger.info("AUTO", "Gallery: ${galleryItems.count { it.labels.isNotEmpty() }} tagged photos/videos to match", projectId = project.projectId)
        val galleryUsed = java.util.concurrent.atomic.AtomicInteger(0)
        /** One scene: true = picture/clip added, false = designed card, null = nothing to search for. */
        suspend fun one(scene: com.avsp.pro.script.contract.ScriptScene): Boolean? {
                val query = listOf(scene.bRollSuggestion, scene.visualDescription, scene.onScreenText, project.name)
                    .firstOrNull { it.isNotBlank() } ?: return null
                // 0) P16: a matching photo/video from the user's own gallery (opt-in).
                if (galleryItems.isNotEmpty()) {
                    val words = (keywordsForPictures(query, "").split(' ') + keywordsForPictures(project.name, "").split(' ').take(2)).filter { it.isNotBlank() }
                    val item = synchronized(usedPictures) {
                        com.avsp.pro.media.GalleryLibrary.match(galleryItems, words, usedPictures).also { if (it != null) usedPictures.add(it.key) }
                    }
                    if (item != null) try {
                        val relative = "media/stock/${script.scriptId}_${scene.sceneId}_g." + (if (item.video) "mp4" else "jpg")
                        val file = java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, relative, project.projectId))
                        gallery!!.copyTo(item, file)
                        projectRepository.addMediaAsset(
                            com.avsp.pro.core.contracts.MediaAsset(
                                assetId = "stock_${script.scriptId}_${scene.sceneId}",
                                projectId = project.projectId,
                                fileName = file.name,
                                relativePath = relative,
                                mimeType = if (item.video) "video/mp4" else "image/jpeg",
                                sizeBytes = file.length(),
                                createdAt = System.currentTimeMillis(),
                                tags = listOf("stock", "gallery", "stock:${script.scriptId}:${scene.sceneId}", "gallery:${item.key}")
                            )
                        )
                        galleryUsed.incrementAndGet()
                        logger.info("AUTO", "Gallery ${if (item.video) "video" else "photo"} for ${scene.sceneId}: ${item.labels.take(4).joinToString()}", projectId = project.projectId)
                        return true
                    } catch (e: Exception) {
                        logger.warning("AUTO", "Gallery item skipped for ${scene.sceneId}", details = e.message, projectId = project.projectId)
                    }
                }
                // 1) Pexels video clip (needs a working free key)
                if (pexelsOk.get() && stock != null) {
                    try {
                        val clip = stock.search(query, portrait, skip = synchronized(usedPictures) { usedPictures.toSet() })
                        if (clip != null) {
                            val relative = "media/stock/${script.scriptId}_${scene.sceneId}.mp4"
                            val file = java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, relative, project.projectId))
                            stock.fetch(clip, file)
                            // P16: a cut-off download would break the render - check it plays first.
                            val okClip = runCatching {
                                val r = android.media.MediaMetadataRetriever()
                                try { r.setDataSource(file.absolutePath); (r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) > 500 } finally { r.release() }
                            }.getOrDefault(false)
                            if (!okClip) { file.delete(); throw IllegalStateException("downloaded clip is unreadable (${file.length()} bytes)") }
                            projectRepository.addMediaAsset(
                                com.avsp.pro.core.contracts.MediaAsset(
                                    assetId = "stock_${script.scriptId}_${scene.sceneId}",
                                    projectId = project.projectId,
                                    fileName = file.name,
                                    relativePath = relative,
                                    mimeType = "video/mp4",
                                    sizeBytes = file.length(),
                                    createdAt = System.currentTimeMillis(),
                                    tags = listOf("stock", "stock:${script.scriptId}:${scene.sceneId}", "pexels:${clip.id}", "credit:Pexels")
                                )
                            )
                            return true
                        }
                    } catch (e: Exception) {
                        logger.warning("AUTO", "Stock clip skipped for ${scene.sceneId}", details = e.message, projectId = project.projectId)
                        if (e.message?.contains("401") == true || e.message?.contains("403") == true) {
                            pexelsOk.set(false)
                            lastStockNote = "Pexels key was rejected - free Openverse pictures used instead. Check the key in Settings."
                        }
                    }
                }
                // 1a) P19: a free Pixabay VIDEO clip (moving pictures beat stills)
                val kc = keyedPhotos
                if (kc != null && kc.isConfigured()) {
                    val clip = shotQueries(project.name, query).asSequence()
                        .flatMap { w -> runCatching { kc.clipCandidates(w, portrait) }.getOrDefault(emptyList()).asSequence() }
                        .firstOrNull { c -> synchronized(usedPictures) { usedPictures.add(c.id) } }
                    if (clip != null) try {
                        val relative = "media/stock/${script.scriptId}_${scene.sceneId}_px.mp4"
                        val file = java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, relative, project.projectId))
                        kc.fetchClip(clip, file)
                        val okClip = runCatching {
                            val r = android.media.MediaMetadataRetriever()
                            try { r.setDataSource(file.absolutePath); (r.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) > 500 } finally { r.release() }
                        }.getOrDefault(false)
                        if (!okClip) { file.delete(); throw IllegalStateException("clip unreadable") }
                        projectRepository.addMediaAsset(
                            com.avsp.pro.core.contracts.MediaAsset(
                                assetId = "stock_${script.scriptId}_${scene.sceneId}",
                                projectId = project.projectId,
                                fileName = file.name,
                                relativePath = relative,
                                mimeType = "video/mp4",
                                sizeBytes = file.length(),
                                createdAt = System.currentTimeMillis(),
                                tags = listOf("stock", "stock:${script.scriptId}:${scene.sceneId}", clip.id, "credit:${clip.credit}")
                            )
                        )
                        return true
                    } catch (e: Exception) {
                        logger.warning("AUTO", "Pixabay clip skipped for ${scene.sceneId}", details = e.message, projectId = project.projectId)
                    }
                }
                // 1b) P17: Pixabay / Unsplash photo (user's free keys)
                val kp = keyedPhotos
                if (kp != null && kp.isConfigured()) {
                    val pick = shotQueries(project.name, query).asSequence()
                        .flatMap { w -> runCatching { kp.candidates(w, portrait) }.getOrDefault(emptyList()).asSequence() }
                        .firstOrNull { c -> synchronized(usedPictures) { usedPictures.add(c.id) } }
                    if (pick != null) try {
                        val relative = "media/stock/${script.scriptId}_${scene.sceneId}.jpg"
                        val file = java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, relative, project.projectId))
                        kp.fetch(pick, file)
                        projectRepository.addMediaAsset(
                            com.avsp.pro.core.contracts.MediaAsset(
                                assetId = "stock_${script.scriptId}_${scene.sceneId}",
                                projectId = project.projectId,
                                fileName = file.name,
                                relativePath = relative,
                                mimeType = "image/jpeg",
                                sizeBytes = file.length(),
                                createdAt = System.currentTimeMillis(),
                                tags = listOf("stock", "stock:${script.scriptId}:${scene.sceneId}", pick.id, "credit:${pick.credit}")
                            )
                        )
                        return true
                    } catch (e: Exception) {
                        logger.warning("AUTO", "Keyed photo skipped for ${scene.sceneId}", details = e.message, projectId = project.projectId)
                    }
                }
                // 2) Free openly-licensed photograph (no key), best match of topic + scene words
                val pics = pictures
                if (pics != null) {
                    val topicWords = keywordsForPictures(project.name, "").split(' ').take(2).joinToString(" ")
                    val sceneWords = keywordsForPictures(query, "").split(' ').filter { it !in topicWords }.take(2).joinToString(" ")
                    val tries = listOf("$topicWords $sceneWords".trim(), topicWords, sceneWords)
                        .filter { it.isNotBlank() }.distinct()
                    var done = false
                    val misses = mutableListOf<String>()
                    for (q in tries) {
                        if (done) break
                        val list = runCatching { pics.candidates(q, portrait) }.getOrElse {
                            if (it.message?.contains("429") == true) {
                                Thread.sleep(2500)
                                runCatching { pics.candidates(q, portrait) }.getOrElse { e2 -> misses += "'$q': ${e2.message}"; emptyList() }
                            } else { misses += "'$q': ${it.javaClass.simpleName} ${it.message}"; emptyList() }
                        }.filterNot { c -> synchronized(usedPictures) { usedPictures.contains(c.id) } }
                        if (list.isEmpty() && misses.none { it.startsWith("'$q'") }) misses += "'$q': no match"
                        for (pic in list.take(3)) {
                            // Reserve the picture first so two scenes fetched at once never share it.
                            if (!synchronized(usedPictures) { usedPictures.add(pic.id) }) continue
                            try {
                                val relative = "media/stock/${script.scriptId}_${scene.sceneId}.jpg"
                                val file = java.io.File(store.resolve(com.avsp.pro.storage.StorageArea.PROJECT_DATA, relative, project.projectId))
                                pics.fetch(pic, file)
                                projectRepository.addMediaAsset(
                                    com.avsp.pro.core.contracts.MediaAsset(
                                        assetId = "stock_${script.scriptId}_${scene.sceneId}",
                                        projectId = project.projectId,
                                        fileName = file.name,
                                        relativePath = relative,
                                        mimeType = "image/jpeg",
                                        sizeBytes = file.length(),
                                        createdAt = System.currentTimeMillis(),
                                        tags = listOf("stock", "stock:${script.scriptId}:${scene.sceneId}", "openverse:${pic.id}", "credit:${pic.credit}")
                                    )
                                )
                                done = true
                                break
                            } catch (e: Exception) {
                                logger.warning("AUTO", "Free picture skipped for ${scene.sceneId}", details = e.message, projectId = project.projectId)
                                if (e.message?.contains("429") == true) Thread.sleep(1500)
                            }
                        }
                    }
                    if (done) return true
                    logger.warning("AUTO", "No free picture for ${scene.sceneId}", details = misses.joinToString(" | ").take(400), projectId = project.projectId)
                }
                return false
        }
        // P9.2 speed: scenes are fetched 3 at a time instead of one after another.
        val gate = kotlinx.coroutines.sync.Semaphore(3)
        val results = kotlinx.coroutines.coroutineScope {
            targets.map { sc -> async { gate.withPermit { runCatching { one(sc) }.getOrDefault(false) } } }.awaitAll()
        }
        val added = results.count { it == true }
        val cards = results.count { it == false }
        if (cards > 0 && lastStockNote == null && added > 0) lastStockNote = "Some scenes had no matching picture and use designed cards."
        if (galleryUsed.get() > 0) lastStockNote = listOfNotNull("${galleryUsed.get()} picture(s) from your phone gallery used - check before posting.", lastStockNote).joinToString(" ")
        logger.info("AUTO", "Visuals: $added pictures/clips, $cards cards", projectId = project.projectId)
        added
    }

    /** P22.3: the scene's own shot words first (what the line talks about), then shot + topic, then topic. */
    private fun shotQueries(topic: String, query: String): List<String> {
        val shot = keywordsForPictures(query, "")
        val t = keywordsForPictures(topic, "").split(' ').take(2)
        return listOf(shot, (t + shot.split(' ').take(2)).distinct().joinToString(" "), t.joinToString(" "))
            .map { it.trim() }.filter { it.isNotBlank() }.distinct()
    }

    /** Ids of the picture behind an asset (Pexels / Pixabay / Openverse / gallery), for "never again". */
    private fun sourceIds(a: com.avsp.pro.core.contracts.MediaAsset): List<String> =
        a.tags.filterNot { it == "stock" || it == "gallery" || it.startsWith("stock:") || it.startsWith("credit:") }
            .map { it.removePrefix("pexels:").removePrefix("openverse:").removePrefix("gallery:") }

    /** Short search words for picture sites (2-4 words, no filler). */
    private fun keywordsForPictures(query: String, fallback: String): String {
        val stop = setOf("the", "a", "an", "and", "or", "of", "to", "in", "on", "for", "with", "is", "are", "this", "that",
            "shot", "scene", "close", "up", "view", "showing", "footage", "video", "image", "clip")
        val words = (query.ifBlank { fallback }).lowercase().split(Regex("""[^\p{L}\p{N}]+"""))
            .filter { it.length > 2 && it !in stop }
            .distinct()
        return words.take(4).joinToString(" ")
    }

    companion object {
        /** P31: project metadata key with the creator's remake instructions. */
        const val INSTRUCTIONS_KEY = "script.instructions"

        /** Builds the AI topic from the project's name, description and attached sources. */
        fun topicFor(project: Project): String = buildString {
            append(project.name.trim())
            project.description.trim().takeIf { it.isNotEmpty() && it != project.name.trim() }?.let {
                append("\n\n").append(it)
            }
            val count = project.metadata["source.bundle.count"]?.toIntOrNull() ?: 0
            for (i in 0 until count) {
                val title = project.metadata["source.$i.title"].orEmpty()
                val text = project.metadata["source.$i.text"].orEmpty()
                val ref = project.metadata["source.$i.reference"].orEmpty()
                val piece = listOf(title, text.take(1500), ref.takeIf { text.isBlank() }.orEmpty())
                    .filter { it.isNotBlank() }
                    .joinToString(" - ")
                if (piece.isNotBlank()) append("\n\nSource ${i + 1}: ").append(piece)
            }
        }.take(4000)
    }
}
