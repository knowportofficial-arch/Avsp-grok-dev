package com.avsp.pro.edit

/**
 * P12 SMART EDIT: decides which parts of a clip to keep (pure, testable).
 *
 * Talking video ([talkingCut]): keep the speech, trim dead air at both ends,
 * shorten long pauses to a natural beat, drop filler-only bits and earlier
 * takes of a repeated sentence, and skip unusable picture between speech.
 *
 * B-roll / clips without speech ([bestWindow]): the best-looking stretch of
 * exactly the length a scene needs, avoiding the weak first/last moments.
 */
object EditPlanner {
    data class Keep(val startMs: Long, val endMs: Long) {
        val durationMs get() = endMs - startMs
    }

    /** Text heard in one speech segment (from the transcriber), if known. */
    data class Heard(val startMs: Long, val endMs: Long, val text: String)

    const val PAD_BEFORE_MS = 120L
    const val PAD_AFTER_MS = 160L
    const val KEEP_PAUSE_MS = 600L      // pauses up to this length are natural - keep
    const val BEAT_MS = 250L            // longer pauses are shortened to this

    private val FILLER = Regex(
        """^(um+|uh+|umm+|hmm+|erm+|ah+|like|you know|so+|okay so|matlab|mane|মানে|ইয়ে|এই যে|मतलब|वो|अच्छा|हां|हाँ|aa+|ee+)[\s.,!?।]*$""",
        RegexOption.IGNORE_CASE
    )

    fun isFiller(text: String): Boolean = FILLER.matches(text.trim())

    /** Same sentence said again (a retake): most words of the earlier take reappear. */
    fun isRetake(earlier: String, later: String): Boolean {
        val a = words(earlier); val b = words(later)
        if (a.size < 3 || b.size < 3) return false
        val common = a.count { it in b }
        return common.toFloat() / a.size >= 0.7f
    }

    private fun words(s: String) = s.lowercase().split(Regex("""[^\p{L}\p{N}]+""")).filter { it.length > 1 }.toSet()

    /**
     * @param speech speech segments of the clip
     * @param totalMs clip length
     * @param heard transcript per segment (optional) - enables filler and retake removal
     * @param quality picture scores (optional) - long silent stretches with bad picture are cut harder
     */
    fun talkingCut(
        speech: List<SpeechSegmenter.Segment>,
        totalMs: Long,
        heard: List<Heard> = emptyList(),
        quality: List<ClipQuality.Score> = emptyList()
    ): List<Keep> {
        if (speech.isEmpty()) return emptyList()
        // 1) Drop segments that are only a filler word, and earlier takes of a repeated sentence.
        val textOf = { s: SpeechSegmenter.Segment ->
            heard.filter { it.startMs < s.endMs && it.endMs > s.startMs }.joinToString(" ") { it.text }.trim()
        }
        val texts = speech.map(textOf)
        val keepSeg = speech.indices.filter { i ->
            val t = texts[i]
            val filler = t.isNotEmpty() && isFiller(t)
            val retake = t.isNotEmpty() && texts.drop(i + 1).take(2).any { later -> later.isNotEmpty() && isRetake(t, later) }
            !filler && !retake
        }.map { speech[it] }
        if (keepSeg.isEmpty()) return emptyList()

        // 2) Pad, then join segments; shorten long pauses to a beat.
        val out = mutableListOf<Keep>()
        for (s in keepSeg) {
            val start = (s.startMs - PAD_BEFORE_MS).coerceAtLeast(0)
            val end = (s.endMs + PAD_AFTER_MS).coerceAtMost(totalMs)
            val last = out.lastOrNull()
            if (last == null) { out += Keep(start, end); continue }
            val gap = start - last.endMs
            when {
                gap <= 0 -> out[out.lastIndex] = Keep(last.startMs, maxOf(last.endMs, end))
                gap <= KEEP_PAUSE_MS && !badPicture(quality, last.endMs, start) -> out[out.lastIndex] = Keep(last.startMs, end)
                else -> {
                    // Keep a short beat after the previous sentence, cut the rest of the pause.
                    out[out.lastIndex] = Keep(last.startMs, minOf(last.endMs + BEAT_MS / 2, start))
                    out += Keep(maxOf(start - BEAT_MS / 2, last.endMs), end)
                }
            }
        }
        // 3) P14: padding / beats that fall on a dark picture (fade to black, lens covered) are dropped.
        val trimmed = out.map { k ->
            val inside = keepSeg.filter { it.endMs > k.startMs && it.startMs < k.endMs }
            if (inside.isEmpty() || quality.isEmpty()) return@map k
            val sStart = inside.first().startMs.coerceAtLeast(k.startMs)
            val sEnd = inside.last().endMs.coerceAtMost(k.endMs)
            val darkLead = quality.any { it.timeMs >= k.startMs - 500 && it.timeMs < sStart && it.brightness < DARK }
            val darkTail = quality.any { it.timeMs > sEnd && it.timeMs <= k.endMs + 500 && it.brightness < DARK }
            Keep(if (darkLead) sStart else k.startMs, if (darkTail) sEnd else k.endMs)
        }
        return trimmed.filter { it.durationMs >= 200 }
    }

    private const val DARK = 0.08f

    private fun badPicture(q: List<ClipQuality.Score>, from: Long, to: Long): Boolean {
        val inGap = q.filter { it.timeMs in from..to }
        return inGap.isNotEmpty() && inGap.map { it.score }.average() < 0.25
    }

    /**
     * P18 SHORT FROM A LONG VIDEO: the best run of consecutive kept parts that fits
     * in [targetMs] - many words per second, a good picture, starting on a new
     * sentence. A single part longer than the target is cut at the target.
     */
    fun highlight(keeps: List<Keep>, targetMs: Long, heard: List<Heard> = emptyList(), quality: List<ClipQuality.Score> = emptyList()): List<Keep> {
        if (keeps.isEmpty() || keeps.sumOf { it.durationMs } <= targetMs) return keeps
        fun words(k: Keep) = heard.filter { it.startMs < k.endMs && it.endMs > k.startMs }.sumOf { h -> h.text.split(' ').count { it.isNotBlank() } }
        fun look(k: Keep): Double = quality.filter { it.timeMs in k.startMs..k.endMs }.map { it.score.toDouble() }.average().takeIf { !it.isNaN() } ?: 0.6
        var best: List<Keep> = listOf(Keep(keeps[0].startMs, keeps[0].startMs + minOf(targetMs, keeps[0].durationMs)))
        var bestScore = -1.0
        for (i in keeps.indices) {
            var total = 0L
            val run = mutableListOf<Keep>()
            for (j in i until keeps.size) {
                val k = keeps[j]
                if (total + k.durationMs > targetMs) {
                    if (run.isEmpty()) run += Keep(k.startMs, k.startMs + targetMs)
                    break
                }
                run += k; total += k.durationMs
            }
            val dur = run.sumOf { it.durationMs }.coerceAtLeast(1)
            val w = run.sumOf { words(it) }
            val fill = dur.toDouble() / targetMs                       // use most of the time
            val pace = if (heard.isEmpty()) 0.5 else minOf(1.0, w / (dur / 1000.0) / 3.0)   // ~3 words/s is lively
            val pic = run.map { look(it) * it.durationMs }.sum() / dur
            val opener = if (i == 0) 0.05 else 0.0                     // the real start usually introduces the topic
            val score = 1.2 * fill + 1.0 * pace + 0.6 * pic + opener
            if (score > bestScore) { bestScore = score; best = run.toList() }
        }
        return best
    }

    /** Best stretch of exactly [targetMs] (or the whole clip if shorter). */
    fun bestWindow(quality: List<ClipQuality.Score>, clipMs: Long, targetMs: Long, edgeMs: Long = 500, avoid: List<Keep> = emptyList()): Keep {
        if (clipMs <= targetMs) return Keep(0, clipMs)
        val margin = minOf(edgeMs, (clipMs - targetMs) / 2)
        if (quality.isEmpty()) {
            // No analysis: the middle of the clip is usually better than its first frames.
            val start = ((clipMs - targetMs) / 2).coerceAtLeast(margin)
            return Keep(start, start + targetMs)
        }
        var best = Keep(margin, margin + targetMs)
        var bestScore = -1.0
        var start = margin
        val step = 250L
        while (start + targetMs <= clipMs - margin || start == margin) {
            val inside = quality.filter { it.timeMs >= start && it.timeMs < start + targetMs }
            var s = if (inside.isEmpty()) 0.0 else inside.map { it.score.toDouble() }.average() - 0.15 * inside.count { it.score < 0.2f } / inside.size
            // P13: a part already shown in another scene is a last resort (no repeated shots).
            val overlap = avoid.sumOf { a -> (minOf(a.endMs, start + targetMs) - maxOf(a.startMs, start)).coerceAtLeast(0) }
            s -= 0.8 * overlap / targetMs
            if (s > bestScore) { bestScore = s; best = Keep(start, start + targetMs) }
            if (start + targetMs >= clipMs - margin) break
            start += step
        }
        return best
    }

    /** Time in the edited video for a time in the original (for captions), or null if cut out. */
    fun mapTime(keeps: List<Keep>, originalMs: Long): Long? {
        var acc = 0L
        for (k in keeps) {
            if (originalMs in k.startMs until k.endMs) return acc + (originalMs - k.startMs)
            acc += k.durationMs
        }
        return null
    }
}
