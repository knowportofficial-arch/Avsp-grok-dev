package com.avsp.pro.edit

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * P14 SOUND for a smart-edited video (pure, testable, all generated on the
 * phone - nothing licensed):
 *  - [voiceGain]: one gain that brings the speech to a steady level (~-18 dBFS RMS)
 *    without clipping its peaks
 *  - [bed]: quiet original music under the whole video, ducked while someone
 *    speaks, plus a soft "whoosh" on every cut
 */
object SoundBed {
    const val RATE = 22_050
    private const val TARGET_RMS = 0.125      // ≈ -18 dBFS
    private const val MAX_PEAK = 0.95

    /** Gain for the original voice: louder when quiet, never pushing peaks past [MAX_PEAK]. */
    fun voiceGain(pcm: ShortArray, rate: Int, speech: List<SpeechSegmenter.Segment>): Float {
        var sum = 0.0; var n = 0L; var peak = 0
        for (s in speech) {
            val a = (s.startMs * rate / 1000).toInt().coerceIn(0, pcm.size)
            val b = (s.endMs * rate / 1000).toInt().coerceIn(a, pcm.size)
            for (i in a until b) { val v = pcm[i].toInt(); sum += v.toDouble() * v; n++; if (abs(v) > peak) peak = abs(v) }
        }
        if (n == 0L || sum <= 0.0) return 1f
        val rms = sqrt(sum / n) / 32768.0
        val want = TARGET_RMS / rms
        val peakLimit = if (peak == 0) want else MAX_PEAK / (peak / 32768.0)
        return min(want, peakLimit).coerceIn(0.6, 4.0).toFloat()
    }

    /**
     * Music + whooshes for [lengthMs] of edited video. [speech] are the spoken
     * parts on the EDITED timeline; [cuts] are the cut times on it.
     */
    fun bed(lengthMs: Long, speech: List<LongRange>, cuts: List<Long>, musicPeak: Double = 0.07, rate: Int = RATE): ShortArray {
        val n = (lengthMs * rate / 1000).toInt().coerceAtLeast(0)
        val out = ShortArray(n)
        if (n == 0) return out
        val chords = listOf(
            doubleArrayOf(220.00, 261.63, 329.63), doubleArrayOf(174.61, 220.00, 261.63),
            doubleArrayOf(261.63, 329.63, 392.00), doubleArrayOf(196.00, 246.94, 293.66)
        )
        val chordLen = 2 * rate
        val ramp = 0.18 * rate                                   // 180 ms duck ramps
        var duck = 1.0
        for (i in 0 until n) {
            val ms = i * 1000L / rate
            val speaking = speech.any { ms in it }
            val target = if (speaking) 0.3 else 1.0
            duck += (target - duck) / ramp
            val c = chords[(i / chordLen) % chords.size]
            val pos = (i % chordLen).toDouble() / chordLen
            val env = min(1.0, pos / 0.2) * min(1.0, (1.0 - pos) / 0.2)
            val t = i.toDouble() / rate
            var v = 0.0
            for ((k, f) in c.withIndex()) v += sin(2 * PI * f * t) * (if (k == 0) 0.45 else 0.3)
            // Gentle pulse on the beat (100 bpm) so it feels like music, not a drone.
            val beat = (t * 100 / 60) % 1.0
            v *= 0.8 + 0.2 * exp(-beat * 6)
            out[i] = (v / 1.05 * env * duck * musicPeak * 32767).toInt().coerceIn(-32767, 32767).toShort()
        }
        // Whoosh: band-limited noise swelling into the cut and fading after it.
        val rnd = java.util.Random(11)
        for (cut in cuts) {
            val from = ((cut - 260) * rate / 1000).toInt()
            val len = (380L * rate / 1000).toInt()
            var lp = 0.0; var lp2 = 0.0
            for (k in 0 until len) {
                val i = from + k
                if (i !in 0 until n) continue
                val x = k.toDouble() / len
                val env = if (x < 0.68) (x / 0.68) * (x / 0.68) else (1 - x) / 0.32
                val alpha = 0.04 + 0.30 * x                      // rising brightness
                lp += alpha * (rnd.nextGaussian() - lp)
                lp2 += alpha * (lp - lp2)
                val v = out[i] + lp2 * env * 0.5 * 32767
                out[i] = v.toInt().coerceIn(-32767, 32767).toShort()
            }
        }
        return out
    }

    fun wav(pcm: ShortArray, rate: Int = RATE): ByteArray {
        val b = java.nio.ByteBuffer.allocate(44 + pcm.size * 2).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt(36 + pcm.size * 2); b.put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()); b.putInt(16); b.putShort(1); b.putShort(1); b.putInt(rate); b.putInt(rate * 2); b.putShort(2); b.putShort(16)
        b.put("data".toByteArray()); b.putInt(pcm.size * 2)
        pcm.forEach { b.putShort(it) }
        return b.array()
    }

    /** Words of a caption with their own times (longer words get more time). */
    fun wordTimes(text: String, startMs: Long, endMs: Long): List<Triple<String, Long, Long>> {
        val words = text.split(Regex("""\s+""")).filter { it.isNotBlank() }
        if (words.isEmpty()) return emptyList()
        val weights = words.map { it.length + 2 }
        val total = weights.sum().toDouble()
        var t = startMs.toDouble()
        val span = (endMs - startMs).coerceAtLeast(1)
        return words.mapIndexed { i, w ->
            val d = span * weights[i] / total
            val r = Triple(w, t.toLong(), if (i == words.lastIndex) endMs else (t + d).toLong())
            t += d
            r
        }
    }
}
