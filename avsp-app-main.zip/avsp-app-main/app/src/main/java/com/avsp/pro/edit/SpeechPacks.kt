package com.avsp.pro.edit

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionSupport
import android.speech.RecognitionSupportCallback
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

/**
 * P17: the phone's free OFFLINE speech packs for captions (English, Hindi,
 * Bengali). Shows which are ready and asks Android to download the missing ones.
 */
object SpeechPacks {
    val LANGS = listOf("en-IN" to "English (India)", "hi-IN" to "Hindi", "bn-IN" to "Bengali")

    enum class State { READY, DOWNLOADING, CAN_DOWNLOAD, NOT_OFFERED, UNKNOWN }

    private fun intent(locale: String) = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, locale)
    }

    /** State of one language (Android 13+; older phones -> UNKNOWN). */
    suspend fun state(context: Context, locale: String): State {
        if (Build.VERSION.SDK_INT < 33 || !SpeechRecognizer.isOnDeviceRecognitionAvailable(context)) return State.UNKNOWN
        val main = Handler(Looper.getMainLooper())
        return withTimeoutOrNull(6_000) {
            suspendCancellableCoroutine<State> { cont ->
                main.post {
                    val r = runCatching { SpeechRecognizer.createOnDeviceSpeechRecognizer(context) }.getOrNull()
                    if (r == null) { if (cont.isActive) cont.resume(State.UNKNOWN); return@post }
                    fun done(s: State) { main.post { runCatching { r.destroy() } }; if (cont.isActive) cont.resume(s) }
                    runCatching {
                        r.checkRecognitionSupport(intent(locale), context.mainExecutor, object : RecognitionSupportCallback {
                            override fun onSupportResult(s: RecognitionSupport) {
                                done(when {
                                    s.installedOnDeviceLanguages.any { it.equals(locale, true) } -> State.READY
                                    s.pendingOnDeviceLanguages.any { it.equals(locale, true) } -> State.DOWNLOADING
                                    s.supportedOnDeviceLanguages.any { it.equals(locale, true) } -> State.CAN_DOWNLOAD
                                    else -> State.NOT_OFFERED
                                })
                            }
                            override fun onError(error: Int) = done(State.UNKNOWN)
                        })
                    }.onFailure { done(State.UNKNOWN) }
                }
            }
        } ?: State.UNKNOWN
    }

    /** Asks Android to download the pack (it continues in the background, needs internet). */
    fun download(context: Context, locale: String) {
        if (Build.VERSION.SDK_INT < 33) return
        Handler(Looper.getMainLooper()).post {
            runCatching {
                val r = SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
                r.triggerModelDownload(intent(locale))
                Handler(Looper.getMainLooper()).postDelayed({ runCatching { r.destroy() } }, 3_000)
            }
        }
    }

    fun label(s: State) = when (s) {
        State.READY -> "✓ ready offline"
        State.DOWNLOADING -> "downloading…"
        State.CAN_DOWNLOAD -> "not downloaded yet"
        State.NOT_OFFERED -> "not offered offline on this phone - your Gemini key is used instead"
        State.UNKNOWN -> "status unknown"
    }
}
