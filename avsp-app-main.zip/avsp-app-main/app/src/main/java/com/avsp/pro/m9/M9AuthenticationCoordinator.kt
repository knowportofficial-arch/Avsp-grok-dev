﻿package com.avsp.pro.m9

/**
 * M9.7 authentication coordinator.
 *
 * Bridges:
 *   M9.4 -> authentication configuration/readiness
 *   M9.6 -> secure local credential storage
 *
 * The coordinator exposes authentication state only.
 * It never returns credential contents.
 *
 * It does NOT:
 * - launch OAuth
 * - exchange authorization codes
 * - refresh tokens
 * - transmit credentials
 * - upload media
 * - publish externally
 */
data class M9AuthenticationResolution(
    val providerId: String,
    val protocol: M9AuthProtocol,
    val readiness: M9AuthReadiness,
    val credentialPresent: Boolean,
    val message: String
)

object M9AuthenticationCoordinator {

    fun resolve(
        configuration: M9ProviderAuthConfiguration,
        credentialStore: M9CredentialStore
    ): M9AuthenticationResolution {

        val providerId = configuration.providerId.trim()

        if (providerId.isBlank()) {
            return M9AuthenticationResolution(
                providerId = "",
                protocol = configuration.protocol,
                readiness = M9AuthReadiness.INVALID,
                credentialPresent = false,
                message = "Provider ID is required."
            )
        }

        if (!configuration.enabled) {
            return M9AuthenticationResolution(
                providerId = providerId,
                protocol = configuration.protocol,
                readiness = M9AuthReadiness.CONFIGURATION_REQUIRED,
                credentialPresent = false,
                message = "Provider is disabled."
            )
        }

        if (configuration.protocol == M9AuthProtocol.NONE) {
            return M9AuthenticationResolution(
                providerId = providerId,
                protocol = configuration.protocol,
                readiness = M9AuthReadiness.NOT_REQUIRED,
                credentialPresent = false,
                message = "No authentication is required for this provider."
            )
        }

        val configured =
            M9ProviderAuthBoundary.evaluate(
                configuration.copy(
                    credentialPresent = false
                )
            )

        if (
            configured.readiness == M9AuthReadiness.INVALID ||
            configured.readiness == M9AuthReadiness.CONFIGURATION_REQUIRED
        ) {
            return M9AuthenticationResolution(
                providerId = providerId,
                protocol = configuration.protocol,
                readiness = configured.readiness,
                credentialPresent = false,
                message = configured.message
            )
        }

        val credentialPresent =
            when (configuration.protocol) {

                M9AuthProtocol.OAUTH2 ->
                    credentialStore.contains(
                        M9CredentialKey(
                            providerId,
                            M9CredentialType.OAUTH_ACCESS_TOKEN
                        )
                    )

                M9AuthProtocol.API_KEY ->
                    credentialStore.contains(
                        M9CredentialKey(
                            providerId,
                            M9CredentialType.API_KEY
                        )
                    )

                M9AuthProtocol.NONE ->
                    false
            }

        if (!credentialPresent) {
            return M9AuthenticationResolution(
                providerId = providerId,
                protocol = configuration.protocol,
                readiness = M9AuthReadiness.READY_FOR_AUTH,
                credentialPresent = false,
                message = "Provider configuration is valid. Authentication has not occurred."
            )
        }

        return M9AuthenticationResolution(
            providerId = providerId,
            protocol = configuration.protocol,
            readiness = M9AuthReadiness.AUTHENTICATED,
            credentialPresent = true,
            message = "Authentication credential is available through the secure credential boundary. Token use remains outside M9.7."
        )
    }
}
