﻿package com.avsp.pro.screen.capture

import android.graphics.RectF

enum class ScreenEventType {
    TEXT_CHANGED,
    VISUAL_CHANGE,
    INFERRED_INTERACTION,
    SENSITIVE_DATA,
    START,
    END
}

enum class SensitiveDataType {
    PHONE,
    EMAIL,
    AADHAAR,
    PAN,
    OTP,
    CARD,
    IP_ADDRESS,
    URL,
    NAME,
    NUMBER,

    /* P1 context privacy */
    FACE,
    ID_FIELD,
    CONTACT_NAME
}

data class ScreenOcrText(
    val text: String,
    val bounds: RectF,
    val confidence: Float
)

data class ScreenTimelineEvent(
    val timestampMs: Long,
    val type: ScreenEventType,
    val title: String,
    val summary: String,
    val confidence: Float,
    val sensitive: Boolean = false,
    val bounds: RectF? = null
)

data class SensitiveFinding(
    val timestampMs: Long,
    val type: SensitiveDataType,
    val maskedText: String,
    val bounds: RectF,
    val confidence: Float,
    val sourceText: String
)

data class ScreenCutSuggestion(
    val startMs: Long,
    val endMs: Long,
    val reason: String,
    val confidence: Float
)

data class ScreenFrameAnalysis(
    val timestampMs: Long,
    val ocr: List<ScreenOcrText>,
    val visualChangeScore: Float,
    val visualChangeBounds: RectF? = null
)

data class ScreenIntelligenceResult(
    val schemaVersion: Int,
    val projectId: String,
    val sourceVideoRelativePath: String,
    val durationMs: Long,
    val sampledFrameCount: Int,
    val frames: List<ScreenFrameAnalysis>,
    val events: List<ScreenTimelineEvent>,
    val sensitiveFindings: List<SensitiveFinding>,
    val cutSuggestions: List<ScreenCutSuggestion>,
    val generatedScript: String,
    val generatedAtEpochMs: Long,
    /*
     * P0 frame-local privacy plan (motion-aware tracks).
     * Default keeps every existing constructor call source-compatible.
     */
    val privacyPlan: ScreenPrivacyPlan = ScreenPrivacyPlan.EMPTY
)



