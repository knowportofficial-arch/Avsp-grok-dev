package com.avsp.pro.edit

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * P13 SMART EDIT fallback: when the phone has no offline speech pack, the
 * user's own free Gemini key turns the speech into text. We already know where
 * each speech segment is (from the sound levels), so Gemini only writes the
 * words for each numbered segment - the times stay exact for captions and cuts.
 * Only the speech parts are sent (silence is cut out), in pieces of ≤ 3 min.
 */
class GeminiTranscriber(private val keys: () -> List<String>) {

    fun available(): Boolean = keys().isNotEmpty()

    /** Never throws: returns what was heard (possibly nothing) and a note. */
    fun transcribe(audio: MediaAnalysis.Audio, segments: List<SpeechSegmenter.Segment>, language: String): Transcriber.Result {
        val keyList = keys().map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        if (keyList.isEmpty() || segments.isEmpty()) return Transcriber.Result(emptyList(), null)
        val heard = mutableListOf<EditPlanner.Heard>()
        var error: String? = null
        for (batch in batches(segments, 180_000L)) {
            val wav = wavOf(audio, batch)
            val prompt = prompt(batch, language)
            var done = false
            for (key in keyList) {
                for (model in MODELS) {
                    val r = runCatching { post(model, key, body(prompt, wav)) }
                    r.onSuccess { raw ->
                        heard += parse(extractText(raw), batch)
                        done = true
                    }.onFailure { error = it.message }
                    if (done) break
                    if (error?.contains("HTTP 401") == true || error?.contains("HTTP 403") == true) break
                }
                if (done) break
            }
        }
        android.util.Log.i("AVSP", "Gemini transcript: ${heard.size} parts heard, error=${error ?: "none"}")
        val note = when {
            heard.isNotEmpty() -> "Words read with your Gemini key."
            error != null -> "Speech could not be read online (${error!!.take(60)}) - cuts use sound levels only."
            else -> null
        }
        return Transcriber.Result(heard.sortedBy { it.startMs }, note)
    }

    private fun post(model: String, key: String, body: String): String {
        val c = java.net.URI(ENDPOINT.format(model)).toURL().openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 8_000
            c.readTimeout = 45_000
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("x-goog-api-key", key)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            check(code in 200..299) { "HTTP $code" }
            return text
        } finally {
            c.disconnect()
        }
    }

    companion object {
        private const val ENDPOINT = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"
        private val MODELS = listOf("gemini-2.5-flash", "gemini-flash-latest", "gemini-2.0-flash")
        /** Silence put between segments in the audio we send, so Gemini hears them apart. */
        const val GAP_MS = 700L

        fun languageName(code: String) = when (code.lowercase()) {
            "bn" -> "Bengali"
            "hi" -> "Hindi"
            else -> "English (or whatever language is spoken)"
        }

        /** Segments grouped so each request carries at most [maxMs] of speech. */
        fun batches(segments: List<SpeechSegmenter.Segment>, maxMs: Long): List<List<SpeechSegmenter.Segment>> {
            val out = mutableListOf<MutableList<SpeechSegmenter.Segment>>()
            var acc = 0L
            for (s in segments) {
                val d = s.endMs - s.startMs
                if (out.isEmpty() || acc + d > maxMs) { out += mutableListOf<SpeechSegmenter.Segment>(); acc = 0 }
                out.last() += s; acc += d + GAP_MS
            }
            return out
        }

        /** Where each segment sits in the condensed audio we send (segments + gaps). */
        fun condensedTimes(batch: List<SpeechSegmenter.Segment>): List<Pair<Long, Long>> {
            var t = 0L
            return batch.map { s -> val start = t; t += s.endMs - s.startMs; val r = start to t; t += GAP_MS; r }
        }

        fun prompt(batch: List<SpeechSegmenter.Segment>, language: String): String {
            val list = condensedTimes(batch).mapIndexed { i, (a, b) -> "${i + 1}) " + String.format(java.util.Locale.US, "%.1f-%.1f s", a / 1000.0, b / 1000.0) }
            return buildString {
                append("Transcribe this audio exactly as spoken. Language: ${languageName(language)}. ")
                append("It has ${batch.size} speech parts separated by short silences, at these times:\n")
                append(list.joinToString("\n"))
                append("\nReply ONLY with a JSON array, one item per part in order: [{\"i\":1,\"text\":\"...\"}]. ")
                append("Write the words in the language's own script, keep fillers like um/uh, keep repeated sentences, do not translate or summarise. ")
                append("Use an empty text for a part with no words.")
            }
        }

        fun body(prompt: String, wav: ByteArray): String = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
                .put(JSONObject().put("text", prompt))
                .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "audio/wav")
                    .put("data", java.util.Base64.getEncoder().encodeToString(wav)))))))
            .put("generationConfig", JSONObject().put("temperature", 0).put("responseMimeType", "application/json"))
            .toString()

        fun extractText(raw: String): String = runCatching {
            val parts = JSONObject(raw).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
            (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
        }.getOrDefault("")

        /** Gemini's JSON -> words with the ORIGINAL video times of each segment. */
        fun parse(text: String, batch: List<SpeechSegmenter.Segment>): List<EditPlanner.Heard> {
            val json = text.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            val arr = runCatching { JSONArray(json.substring(json.indexOf('['), json.lastIndexOf(']') + 1)) }.getOrNull() ?: return emptyList()
            val out = mutableListOf<EditPlanner.Heard>()
            for (k in 0 until arr.length()) {
                val o = arr.optJSONObject(k) ?: continue
                val i = o.optInt("i", k + 1) - 1
                val words = o.optString("text").trim()
                val s = batch.getOrNull(i) ?: continue
                if (words.isNotEmpty()) out += EditPlanner.Heard(s.startMs, s.endMs, words)
            }
            return out
        }

        /** Only the speech, with [GAP_MS] of silence between parts, as a 16-bit mono WAV. */
        fun wavOf(audio: MediaAnalysis.Audio, batch: List<SpeechSegmenter.Segment>): ByteArray {
            val rate = audio.sampleRate
            val gap = (GAP_MS * rate / 1000).toInt()
            val pieces = batch.map { s ->
                val from = (s.startMs * rate / 1000).toInt().coerceIn(0, audio.pcm.size)
                val to = (s.endMs * rate / 1000).toInt().coerceIn(from, audio.pcm.size)
                from to to
            }
            val n = pieces.sumOf { it.second - it.first } + gap * (pieces.size - 1).coerceAtLeast(0)
            val bb = ByteBuffer.allocate(44 + n * 2).order(ByteOrder.LITTLE_ENDIAN)
            bb.put("RIFF".toByteArray()); bb.putInt(36 + n * 2); bb.put("WAVE".toByteArray())
            bb.put("fmt ".toByteArray()); bb.putInt(16); bb.putShort(1); bb.putShort(1); bb.putInt(rate); bb.putInt(rate * 2); bb.putShort(2); bb.putShort(16)
            bb.put("data".toByteArray()); bb.putInt(n * 2)
            pieces.forEachIndexed { i, (a, b) ->
                if (i > 0) repeat(gap) { bb.putShort(0) }
                for (j in a until b) bb.putShort(audio.pcm[j])
            }
            return bb.array()
        }
    }
}
