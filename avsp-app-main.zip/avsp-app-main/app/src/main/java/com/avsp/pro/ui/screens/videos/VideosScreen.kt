package com.avsp.pro.ui.screens.videos

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

/** A finished video exported to Movies/AVSP. */
data class ExportedVideo(
    val uri: Uri,
    val displayName: String,
    val durationMs: Long,
    val addedAtMs: Long,
    val projectId: String?
)

private val EXPORT_NAME = Regex("""AVSP_(prj_[0-9a-zA-Z]+)_\d{8}_\d{6}""")

/** Newest first. Only videos AVSP itself saved (Movies/AVSP/...). */
suspend fun loadExportedVideos(context: Context, limit: Int = 200): List<ExportedVideo> =
    withContext(Dispatchers.IO) {
        val out = mutableListOf<ExportedVideo>()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.DATE_ADDED
        )
        val (selection, args) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            "${MediaStore.Video.Media.RELATIVE_PATH} LIKE ?" to arrayOf("Movies/AVSP%")
        } else {
            "${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?" to arrayOf("AVSP_%")
        }
        runCatching {
            context.contentResolver.query(
                collection, projection, selection, args,
                "${MediaStore.Video.Media.DATE_ADDED} DESC"
            )?.use { c ->
                val id = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val name = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val dur = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val added = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                while (c.moveToNext() && out.size < limit) {
                    val display = c.getString(name).orEmpty()
                    out += ExportedVideo(
                        uri = ContentUris.withAppendedId(collection, c.getLong(id)),
                        displayName = display,
                        durationMs = c.getLong(dur),
                        addedAtMs = c.getLong(added) * 1000L,
                        projectId = EXPORT_NAME.find(display)?.groupValues?.get(1)
                    )
                }
            }
        }
        out
    }

fun playVideo(context: Context, uri: Uri) {
    val view = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, "video/mp4")
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { context.startActivity(view) }
}

fun shareVideo(context: Context, uri: Uri, text: String) {
    val send = Intent(Intent.ACTION_SEND)
        .setType("video/mp4")
        .putExtra(Intent.EXTRA_STREAM, uri)
        .putExtra(Intent.EXTRA_TEXT, text)
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    runCatching { context.startActivity(Intent.createChooser(send, "Share video")) }
}

fun formatDuration(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return if (s >= 60) "%d:%02d".format(s / 60, s % 60) else "0:%02d".format(s)
}

fun formatWhen(ms: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(ms))

/** Portrait thumbnail of a video (first frame), with a play badge. */
@Composable
fun VideoThumb(uri: Uri, width: Dp, height: Dp, durationMs: Long? = null) {
    val context = LocalContext.current
    val bitmap by produceState<Bitmap?>(initialValue = null, uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    context.contentResolver.loadThumbnail(uri, Size(270, 480), null)
                } else {
                    MediaMetadataRetriever().run {
                        try {
                            setDataSource(context, uri)
                            getFrameAtTime(500_000L)
                        } finally {
                            release()
                        }
                    }
                }
            }.getOrNull()
        }
    }
    Box(
        modifier = Modifier
            .width(width)
            .height(height)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center
    ) {
        bitmap?.let {
            Image(
                bitmap = it.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(Color.Black.copy(alpha = 0.45f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Filled.PlayArrow, contentDescription = "Play", tint = Color.White)
        }
        durationMs?.takeIf { it > 0 }?.let {
            Text(
                formatDuration(it),
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(6.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color.Black.copy(alpha = 0.55f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}

/**
 * "My videos": every finished video AVSP saved, newest first,
 * with play / share / open project.
 */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun VideosScreen(
    loadProjectNames: suspend () -> Map<String, String>,
    onOpenProject: (String) -> Unit,
    onMakeVideo: () -> Unit
) {
    val context = LocalContext.current
    var videos by remember { mutableStateOf<List<ExportedVideo>?>(null) }
    var names by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var reload by remember { mutableStateOf(0) }

    // P22.1: posting status from the Google Sheet, and Delete (to the phone's Trash).
    var sheetRows by remember { mutableStateOf<Map<String, com.avsp.pro.publish.SheetPublisher.Row>>(emptyMap()) }
    LaunchedEffect(reload) {
        names = runCatching { loadProjectNames() }.getOrDefault(emptyMap())
        videos = loadExportedVideos(context)
        sheetRows = withContext(Dispatchers.IO) { com.avsp.pro.ui.screens.publish.PostLog.rows(context) }
    }
    val trash = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == android.app.Activity.RESULT_OK) reload++
    }
    var deleteFor by remember { mutableStateOf<ExportedVideo?>(null) }
    var showQueue by remember { mutableStateOf(false) }
    deleteFor?.let { dv ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { deleteFor = null },
            title = { Text("Delete this video?") },
            text = { Text("It goes to the phone's Trash (you can restore it for 30 days). Posted copies on YouTube etc. are not touched.") },
            confirmButton = {
                TextButton(onClick = {
                    deleteFor = null
                    runCatching {
                        if (Build.VERSION.SDK_INT >= 30) {
                            val pi = MediaStore.createTrashRequest(context.contentResolver, listOf(dv.uri), true)
                            trash.launch(androidx.activity.result.IntentSenderRequest.Builder(pi.intentSender).build())
                        } else {
                            context.contentResolver.delete(dv.uri, null, null); reload++
                        }
                        com.avsp.pro.ui.screens.publish.PostLog.forget(context, dv.uri.toString())
                    }.onFailure { android.widget.Toast.makeText(context, "Could not delete: ${it.message}", android.widget.Toast.LENGTH_LONG).show() }
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleteFor = null }) { Text("Cancel") } }
        )
    }

    // P30: posting queue (videos, blogs, polls) - the app's own view of the publishing sheet.
    if (showQueue) { com.avsp.pro.ui.screens.publish.PublishQueue(onClose = { showQueue = false; reload++ }); return }
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("My videos", style = MaterialTheme.typography.headlineMedium)
            Row {
                TextButton(onClick = { showQueue = true }) { Text("Posting queue") }
                TextButton(onClick = { reload++ }) { Text("Refresh") }
            }
        }
        val list = videos
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            list.isEmpty() -> Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No videos yet", style = MaterialTheme.typography.titleLarge)
                Text(
                    "Videos you make are saved here and in your gallery (Movies/AVSP).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    modifier = Modifier.padding(vertical = 12.dp)
                )
                androidx.compose.material3.Button(onClick = onMakeVideo) { Text("Make a video") }
            }
            else -> {
                Text(
                    "${list.size} video${if (list.size == 1) "" else "s"} · also in your gallery (Movies/AVSP)",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                // P21.7: any finished video can be sent to the approval sheet from here.
                var postFor by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<Pair<ExportedVideo, String>?>(null) }
                postFor?.let { (pv, pt) ->
                    androidx.compose.material3.AlertDialog(
                        onDismissRequest = { postFor = null },
                        title = { Text(pt, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                        text = { com.avsp.pro.ui.screens.publish.SendForApprovalRow(videoUri = pv.uri.toString(), project = pt, title = pt, kit = null, thumbnail = null, projectId = pv.projectId) },
                        confirmButton = { TextButton(onClick = { postFor = null }) { Text("Close") } }
                    )
                }
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(list, key = { it.uri.toString() }) { v ->
                        val title = v.projectId?.let { names[it] } ?: "AVSP video"
                        Card(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(modifier = Modifier.clickable { playVideo(context, v.uri) }) {
                                    VideoThumb(v.uri, 72.dp, 128.dp, v.durationMs)
                                }
                                Column(
                                    modifier = Modifier.weight(1f),
                                    verticalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Text(
                                        title,
                                        style = MaterialTheme.typography.titleMedium,
                                        maxLines = 3,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "${formatDuration(v.durationMs)} · ${formatWhen(v.addedAtMs)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                    )
                                    val row = com.avsp.pro.ui.screens.publish.PostLog.rowId(context, v.uri.toString())?.let { sheetRows[it] }
                                    if (row != null) {
                                        val posted = row.status.startsWith("Posted")
                                        Text(
                                            (if (posted) "✅ " else if (row.status.startsWith("Retry")) "⚠️ " else "⏳ ") + row.status.take(60) +
                                                (row.views?.let { " · $it views" } ?: "") + (row.likes?.let { " · $it likes" } ?: ""),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = if (posted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                                        )
                                        // P24: approve / post now straight from the app.
                                        val waiting = row.status == "Waiting approval" || row.status == "Approved" || row.status.startsWith("Retry")
                                        if (waiting) {
                                            val scope = androidx.compose.runtime.rememberCoroutineScope()
                                            var busy by remember(row.id) { mutableStateOf(false) }
                                            fun act(now: Boolean) {
                                                busy = true
                                                scope.launch {
                                                    val r = withContext(Dispatchers.IO) { runCatching { (context.applicationContext as com.avsp.pro.AvspApplication).container.publisher.approve(row.id, now) } }
                                                    busy = false
                                                    android.widget.Toast.makeText(context, r.fold({ s -> if (now) "Posting: $s" else "Approved - posts at its time" }, { e -> "Sheet: ${e.message}" }), android.widget.Toast.LENGTH_LONG).show()
                                                    reload++
                                                }
                                            }
                                            androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                                if (!row.approved) OutlinedButton(onClick = { act(false) }, enabled = !busy) { Text("Approve") }
                                                androidx.compose.material3.Button(onClick = { act(true) }, enabled = !busy) { Text(if (busy) "Working…" else "Post now") }
                                            }
                                            if (row.approved && row.schedule.isNotBlank()) Text("Approved · posts at " + runCatching { java.time.Instant.parse(row.schedule).atZone(java.time.ZoneId.systemDefault())
                                                .format(java.time.format.DateTimeFormatter.ofPattern("d MMM, h:mm a")) }.getOrDefault(row.schedule),
                                                style = MaterialTheme.typography.labelSmall)
                                        }
                                        row.links.firstOrNull()?.let { link ->
                                            TextButton(onClick = { runCatching { context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(link))) } }) {
                                                Text(if (link.contains("youtu")) "Open on YouTube" else "Open post")
                                            }
                                        }
                                    }
                                    androidx.compose.foundation.layout.FlowRow(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                        OutlinedButton(onClick = { shareVideo(context, v.uri, title) }) {
                                            Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Text(" Share")
                                        }
                                        TextButton(onClick = { postFor = v to title }) { Text("Post…") }
                                        TextButton(onClick = { deleteFor = v }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
                                        v.projectId?.takeIf { names.containsKey(it) }?.let { id ->
                                            TextButton(onClick = { onOpenProject(id) }) { Text("Project") }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
