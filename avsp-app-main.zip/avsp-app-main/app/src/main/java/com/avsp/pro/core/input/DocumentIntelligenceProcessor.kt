﻿package com.avsp.pro.core.input

import com.avsp.pro.ai.AiCapability
import com.avsp.pro.ai.AiExecutionResult
import com.avsp.pro.ai.AiOrchestrator
import com.avsp.pro.ai.AiRequest
import com.avsp.pro.script.contract.AudienceType
import com.avsp.pro.script.contract.ContentType
import com.avsp.pro.script.contract.DurationRequest
import com.avsp.pro.script.contract.ScriptGenerationRequest
import com.avsp.pro.script.contract.TargetPlatform

/**
 * M16 — Document Intelligence.
 *
 * REAL:
 * - Consumes M15 ProcessedDocument.
 * - Normalizes bounded local text.
 * - Detects language using Unicode/script evidence.
 * - Detects headings/sections and bullet-style key points.
 * - Produces deterministic summary/topic/entity candidates.
 * - Chunks large text without exceeding the configured chunk bound.
 * - Produces script-ready source material.
 * - Can call the existing provider-independent AiOrchestrator.
 * - Can create an existing M2 ScriptGenerationRequest without changing M2.
 *
 * NOT IMPLEMENTED HERE:
 * - PDF text extraction.
 * - PDF OCR.
 * - DOCX/PPTX/XLSX semantic parsing.
 * - Network download.
 * - Upload/publishing.
 * - Vendor-specific AI implementation.
 *
 * IMPORTANT:
 * M15 PDF processing intentionally returns text == null.
 * M16 never invents PDF text. PDF input therefore returns a truthful
 * NO_TEXT_CONTENT result until a dedicated PDF extraction/OCR module exists.
 */
object DocumentIntelligenceProcessor {

    const val DEFAULT_MAX_TEXT_CHARS = 100_000
    const val DEFAULT_CHUNK_CHARS = 12_000
    const val DEFAULT_CHUNK_OVERLAP = 500
    const val DEFAULT_SUMMARY_SENTENCES = 3
    const val MAX_KEY_POINTS = 8
    const val MAX_TOPICS = 8
    const val MAX_ENTITIES = 12

    enum class Status {
        READY,
        READY_WITHOUT_AI,
        EMPTY_CONTENT,
        NO_TEXT_CONTENT,
        UNSUPPORTED
    }

    enum class AiStatus {
        NOT_REQUESTED,
        NOT_CONFIGURED,
        SUCCESS,
        FAILED
    }

    data class DocumentSection(
        val index: Int,
        val heading: String?,
        val text: String
    )

    data class DocumentChunk(
        val index: Int,
        val text: String,
        val startOffset: Int,
        val endOffset: Int
    )

    data class DocumentIntelligenceResult(
        val input: UnifiedInput,
        val sourceKind: DocumentContentProcessor.ContentKind,
        val status: Status,
        val aiStatus: AiStatus,
        val languageCode: String,
        val normalizedText: String,
        val title: String,
        val sections: List<DocumentSection>,
        val summary: String,
        val keyPoints: List<String>,
        val topics: List<String>,
        val entities: List<String>,
        val chunks: List<DocumentChunk>,
        val scriptReadyText: String,
        val factualRequirements: String,
        val warnings: List<String> = emptyList(),
        val aiProviderId: String? = null
    ) {
        fun toScriptGenerationRequest(
            projectId: String,
            duration: DurationRequest = DurationRequest.ShortForm,
            contentType: ContentType = ContentType.EXPLAINER,
            audience: AudienceType = AudienceType.GENERAL,
            platform: TargetPlatform = TargetPlatform.YOUTUBE_SHORTS,
            aspectRatioLabel: String = "9:16",
            userInstructions: String? = null
        ): ScriptGenerationRequest {
            val safeTopic = when {
                title.isNotBlank() -> title
                topics.isNotEmpty() -> topics.take(3).joinToString(", ")
                else -> "Document-based content"
            }

            return ScriptGenerationRequest(
                projectId = projectId,
                topic = safeTopic,
                languageCode = languageCode,
                duration = duration,
                aspectRatioLabel = aspectRatioLabel,
                contentType = contentType,
                audience = audience,
                platform = platform,
                userInstructions = userInstructions
                    ?: "Use the following M16 document intelligence as source material:\n$scriptReadyText",
                factualRequirements = factualRequirements
            )
        }
    }

    suspend fun process(
        document: DocumentContentProcessor.ProcessedDocument,
        aiOrchestrator: AiOrchestrator? = null,
        enableAi: Boolean = true,
        maxTextChars: Int = DEFAULT_MAX_TEXT_CHARS,
        chunkChars: Int = DEFAULT_CHUNK_CHARS,
        chunkOverlap: Int = DEFAULT_CHUNK_OVERLAP
    ): DocumentIntelligenceResult {
        require(maxTextChars > 0)
        require(chunkChars > 0)
        require(chunkOverlap >= 0)
        require(chunkOverlap < chunkChars)

        val sourceText = document.text

        if (sourceText == null) {
            return DocumentIntelligenceResult(
                input = document.input,
                sourceKind = document.kind,
                status = if (document.kind == DocumentContentProcessor.ContentKind.PDF) {
                    Status.NO_TEXT_CONTENT
                } else {
                    Status.EMPTY_CONTENT
                },
                aiStatus = AiStatus.NOT_REQUESTED,
                languageCode = "und",
                normalizedText = "",
                title = titleFromInput(document.input),
                sections = emptyList(),
                summary = "",
                keyPoints = emptyList(),
                topics = emptyList(),
                entities = emptyList(),
                chunks = emptyList(),
                scriptReadyText = "",
                factualRequirements = "Source content text is unavailable; do not invent document facts.",
                warnings = if (document.kind == DocumentContentProcessor.ContentKind.PDF) {
                    listOf(
                        "M15 provided PDF metadata/page count but no extracted PDF text.",
                        "PDF text extraction/OCR is NOT_IMPLEMENTED in M16."
                    )
                } else {
                    listOf("Document content text is unavailable.")
                }
            )
        }

        val normalized = normalize(sourceText).take(maxTextChars)

        if (normalized.isBlank()) {
            return DocumentIntelligenceResult(
                input = document.input,
                sourceKind = document.kind,
                status = Status.EMPTY_CONTENT,
                aiStatus = AiStatus.NOT_REQUESTED,
                languageCode = "und",
                normalizedText = "",
                title = titleFromInput(document.input),
                sections = emptyList(),
                summary = "",
                keyPoints = emptyList(),
                topics = emptyList(),
                entities = emptyList(),
                chunks = emptyList(),
                scriptReadyText = "",
                factualRequirements = "Document contains no usable text.",
                warnings = listOf("No usable text remained after normalization.")
            )
        }

        val language = detectLanguage(normalized)
        val sections = detectSections(normalized)
        val keyPoints = extractKeyPoints(normalized)
        val summary = summarizeDeterministically(normalized)
        val topics = extractTopics(normalized)
        val entities = extractEntities(normalized)
        val chunks = chunk(normalized, chunkChars, chunkOverlap)

        val title = titleFromDocument(document.input, sections, normalized)

        val scriptReady = buildScriptReadyText(
            title = title,
            summary = summary,
            keyPoints = keyPoints,
            sections = sections
        )

        var aiStatus = AiStatus.NOT_REQUESTED
        var aiProviderId: String? = null
        var aiSummary = ""

        if (enableAi && aiOrchestrator != null) {
            when (
                val aiResult = aiOrchestrator.execute(
                    AiRequest(
                        capability = AiCapability.SUMMARIZATION,
                        input = buildAiPrompt(
                            title = title,
                            languageCode = language,
                            text = normalized
                        ),
                        metadata = mapOf(
                            "module" to "M16",
                            "sourceType" to document.kind.name,
                            "languageCode" to language
                        )
                    )
                )
            ) {
                is AiExecutionResult.Success -> {
                    aiStatus = AiStatus.SUCCESS
                    aiProviderId = aiResult.response.providerId
                    aiSummary = aiResult.response.output.trim()
                }

                is AiExecutionResult.Failure -> {
                    aiStatus = AiStatus.NOT_CONFIGURED
                }
            }
        } else if (enableAi) {
            aiStatus = AiStatus.NOT_CONFIGURED
        }

        val finalSummary = if (aiSummary.isNotBlank()) aiSummary else summary

        return DocumentIntelligenceResult(
            input = document.input,
            sourceKind = document.kind,
            status = if (aiStatus == AiStatus.NOT_REQUESTED) {
                Status.READY_WITHOUT_AI
            } else {
                Status.READY
            },
            aiStatus = aiStatus,
            languageCode = language,
            normalizedText = normalized,
            title = title,
            sections = sections,
            summary = finalSummary,
            keyPoints = keyPoints,
            topics = topics,
            entities = entities,
            chunks = chunks,
            scriptReadyText = buildScriptReadyText(
                title = title,
                summary = finalSummary,
                keyPoints = keyPoints,
                sections = sections
            ),
            factualRequirements =
                "Use the supplied document as the factual source. Do not invent unsupported facts. " +
                    "Preserve uncertainty and attribution when present.",
            warnings = buildList {
                if (document.truncated) {
                    add("M15 content was truncated before M16 processing.")
                }
                if (aiStatus == AiStatus.NOT_CONFIGURED) {
                    add("No available M16 AI provider; deterministic extraction used.")
                }
                if (aiStatus == AiStatus.SUCCESS) {
                    add("AI summary generated through provider-independent AiOrchestrator.")
                }
            },
            aiProviderId = aiProviderId
        )
    }

    private fun normalize(text: String): String =
        text.replace("\r\n", "\n")
            .replace('\r', '\n')
            .lines()
            .map { it.trim().replace(Regex("[\\t ]+"), " ") }
            .joinToString("\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()

    private fun detectLanguage(text: String): String {
        val bengali = text.count { it in '\u0980'..'\u09FF' }
        val devanagari = text.count { it in '\u0900'..'\u097F' }
        val latin = text.count { it in 'A'..'Z' || it in 'a'..'z' }

        return when {
            bengali > devanagari && bengali > latin / 3 -> "bn"
            devanagari > bengali && devanagari > latin / 3 -> "hi"
            latin > 0 -> "en"
            else -> "und"
        }
    }

    private fun detectSections(text: String): List<DocumentSection> {
        val lines = text.lines()
        val sections = mutableListOf<DocumentSection>()
        var heading: String? = null
        val body = StringBuilder()
        var index = 0

        fun flush() {
            val value = body.toString().trim()
            if (value.isNotBlank() || heading != null) {
                sections += DocumentSection(
                    index = index++,
                    heading = heading,
                    text = value
                )
            }
            body.clear()
            heading = null
        }

        for (line in lines) {
            val trimmed = line.trim()

            if (trimmed.isBlank()) {
                if (body.isNotBlank() || heading != null) flush()
                continue
            }

            if (isHeading(trimmed)) {
                if (body.isNotBlank() || heading != null) flush()
                heading = trimmed.trim('#', '*', ':', ' ')
            } else {
                if (body.isNotEmpty()) body.append('\n')
                body.append(trimmed)
            }
        }

        if (body.isNotBlank() || heading != null) flush()

        if (sections.isEmpty()) {
            return listOf(
                DocumentSection(
                    index = 0,
                    heading = null,
                    text = text
                )
            )
        }

        return sections.take(100)
    }

    private fun isHeading(line: String): Boolean {
        if (line.startsWith("#")) return true

        val words = line.split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty() || words.size > 12 || line.length > 120) return false

        val first = line.firstOrNull() ?: return false
        return first.isUpperCase() &&
            !line.endsWith(".") &&
            !line.endsWith(",") &&
            !line.endsWith("?") &&
            !line.endsWith("!")
    }

    private fun extractKeyPoints(text: String): List<String> {
        val bullets = text.lines()
            .map { it.trim() }
            .filter {
                it.startsWith("- ") ||
                    it.startsWith("* ") ||
                    it.startsWith("• ") ||
                    Regex("^\\d+[.)]\\s+").containsMatchIn(it)
            }
            .map {
                it.replace(Regex("^[-*•]\\s+"), "")
                    .replace(Regex("^\\d+[.)]\\s+"), "")
                    .trim()
            }
            .filter { it.length >= 8 }

        if (bullets.isNotEmpty()) {
            return bullets.distinct().take(MAX_KEY_POINTS)
        }

        return sentenceList(text)
            .sortedByDescending { scoreSentence(it) }
            .take(MAX_KEY_POINTS)
            .sortedBy { text.indexOf(it).coerceAtLeast(0) }
    }

    private fun summarizeDeterministically(text: String): String =
        sentenceList(text)
            .take(DEFAULT_SUMMARY_SENTENCES)
            .joinToString(" ")

    private fun sentenceList(text: String): List<String> =
        text.replace("\n", " ")
            .split(Regex("(?<=[.!?।])\\s+"))
            .map { it.trim() }
            .filter { it.length >= 20 }
            .distinct()

    private fun scoreSentence(sentence: String): Int {
        var score = 0
        val lower = sentence.lowercase()

        val markers = listOf(
            "important", "because", "therefore", "result",
            "key", "main", "first", "second", "finally",
            "কারণ", "গুরুত্বপূর্ণ", "প্রধান", "ফলে",
            "क्योंकि", "महत्वपूर्ण", "मुख्य"
        )

        for (marker in markers) {
            if (lower.contains(marker)) score += 2
        }

        if (sentence.length in 50..220) score += 2
        return score
    }

    private fun extractTopics(text: String): List<String> {
        val stopWords = setOf(
            "the", "and", "that", "this", "with", "from", "for", "are",
            "was", "were", "have", "has", "will", "into", "about", "which",
            "এবং", "এই", "সেই", "থেকে", "জন্য", "করা", "হয়",
            "और", "यह", "उस", "से", "के", "लिए", "है", "हैं"
        )

        return Regex("[\\p{L}][\\p{L}\\p{M}\\-]{2,}")
            .findAll(text.lowercase())
            .map { it.value }
            .filter { it !in stopWords }
            .groupingBy { it }
            .eachCount()
            .entries
            .sortedWith(
                compareByDescending<Map.Entry<String, Int>> { it.value }
                    .thenBy { it.key }
            )
            .take(MAX_TOPICS)
            .map { it.key }
    }

    private fun extractEntities(text: String): List<String> {
        val latinEntities = Regex("\\b[A-Z][A-Za-z0-9&.-]*(?:\\s+[A-Z][A-Za-z0-9&.-]*){0,3}\\b")
            .findAll(text)
            .map { it.value.trim() }
            .filter { it.length >= 2 }

        return latinEntities
            .distinct()
            .take(MAX_ENTITIES)
            .toList()
    }

    private fun chunk(
        text: String,
        chunkChars: Int,
        overlap: Int
    ): List<DocumentChunk> {
        if (text.length <= chunkChars) {
            return listOf(
                DocumentChunk(
                    index = 0,
                    text = text,
                    startOffset = 0,
                    endOffset = text.length
                )
            )
        }

        val result = mutableListOf<DocumentChunk>()
        var start = 0
        var index = 0

        while (start < text.length) {
            var end = minOf(start + chunkChars, text.length)

            if (end < text.length) {
                val boundary = text.lastIndexOfAny(
                    charArrayOf('.', '!', '?', '।', '\n'),
                    startIndex = end
                )

                if (boundary > start + (chunkChars / 2)) {
                    end = boundary + 1
                }
            }

            if (end <= start) {
                end = minOf(start + chunkChars, text.length)
            }

            result += DocumentChunk(
                index = index++,
                text = text.substring(start, end).trim(),
                startOffset = start,
                endOffset = end
            )

            if (end >= text.length) break

            start = maxOf(start + 1, end - overlap)
        }

        return result
    }

    private fun titleFromInput(input: UnifiedInput): String =
        input.displayName?.trim().orEmpty()

    private fun titleFromDocument(
        input: UnifiedInput,
        sections: List<DocumentSection>,
        text: String
    ): String {
        val supplied = titleFromInput(input)
        if (supplied.isNotBlank()) return supplied

        val heading = sections.firstOrNull { !it.heading.isNullOrBlank() }?.heading
        if (!heading.isNullOrBlank()) return heading

        return sentenceList(text).firstOrNull()?.take(100).orEmpty()
    }

    private fun buildScriptReadyText(
        title: String,
        summary: String,
        keyPoints: List<String>,
        sections: List<DocumentSection>
    ): String = buildString {
        if (title.isNotBlank()) appendLine("TITLE: $title")
        if (summary.isNotBlank()) {
            appendLine("SUMMARY:")
            appendLine(summary)
        }

        if (keyPoints.isNotEmpty()) {
            appendLine()
            appendLine("KEY POINTS:")
            keyPoints.forEach { appendLine("- $it") }
        }

        if (sections.isNotEmpty()) {
            appendLine()
            appendLine("SOURCE STRUCTURE:")
            sections.take(20).forEach { section ->
                val heading = section.heading ?: "Section ${section.index + 1}"
                appendLine("$heading: ${section.text.take(600)}")
            }
        }
    }.trim()

    private fun buildAiPrompt(
        title: String,
        languageCode: String,
        text: String
    ): String = """
        You are the M16 document-intelligence layer of AVSP.
        Summarize the supplied document faithfully.
        Do not invent facts.
        Preserve uncertainty and attribution.
        Language: $languageCode
        Title: $title

        Return only a concise source-grounded summary suitable for downstream
        script generation.

        DOCUMENT:
        $text
    """.trimIndent()
}

