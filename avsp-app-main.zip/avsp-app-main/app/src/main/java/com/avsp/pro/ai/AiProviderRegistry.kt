package com.avsp.pro.ai

/**
 * Runtime registry. Providers can be registered/unregistered without changing
 * callers. Selection is capability-driven, not vendor-name-driven.
 */
class AiProviderRegistry(
    initialProviders: List<AiProvider> = emptyList()
) {
    private val providers = LinkedHashMap<String, AiProvider>()

    init {
        initialProviders.forEach(::register)
    }

    fun register(provider: AiProvider) {
        providers[provider.descriptor.providerId] = provider
    }

    fun unregister(providerId: String) {
        providers.remove(providerId)
    }

    fun all(): List<AiProvider> = providers.values.toList()

    fun find(providerId: String): AiProvider? = providers[providerId]

    fun candidates(request: AiRequest): List<AiProvider> {
        val capabilityMatches = providers.values
            .asSequence()
            .filter { request.capability in it.descriptor.capabilities }
            .filter { it.descriptor.providerId !in request.excludedProviderIds }
            .filter { it.descriptor.state == AiProviderState.AVAILABLE }
            .sortedWith(
                compareByDescending<AiProvider> {
                    if (it.descriptor.providerId == request.preferredProviderId) 1 else 0
                }.thenByDescending { it.descriptor.priority }
            )
            .toList()

        return capabilityMatches
    }
}