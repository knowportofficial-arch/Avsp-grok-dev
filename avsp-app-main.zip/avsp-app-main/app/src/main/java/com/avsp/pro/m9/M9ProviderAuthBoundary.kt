﻿package com.avsp.pro.m9

/**
 * M9.4 authentication/configuration boundary.
 *
 * This module deliberately does NOT perform OAuth, token exchange,
 * API-key transmission, upload, or publication.
 *
 * It only determines whether a provider has enough non-secret
 * configuration to enter the authentication boundary.
 */
enum class M9AuthProtocol {
    NONE,
    OAUTH2,
    API_KEY
}

enum class M9AuthReadiness {
    NOT_REQUIRED,
    CONFIGURATION_REQUIRED,
    READY_FOR_AUTH,
    AUTHENTICATED,
    EXPIRED,
    INVALID
}

data class M9ProviderAuthConfiguration(
    val providerId: String,
    val protocol: M9AuthProtocol,
    val enabled: Boolean = true,
    val clientId: String = "",
    val redirectUri: String = "",
    val scopes: Set<String> = emptySet(),
    /**
     * This is only a presence flag.
     *
     * The actual secret/token MUST NOT be stored in this model.
     */
    val credentialPresent: Boolean = false
)

data class M9ProviderAuthStatus(
    val providerId: String,
    val protocol: M9AuthProtocol,
    val readiness: M9AuthReadiness,
    val configured: Boolean,
    val credentialPresent: Boolean,
    val message: String
)

object M9ProviderAuthBoundary {

    fun evaluate(
        configuration: M9ProviderAuthConfiguration
    ): M9ProviderAuthStatus {

        val providerId = configuration.providerId.trim()

        if (providerId.isBlank()) {
            return M9ProviderAuthStatus(
                providerId = "",
                protocol = configuration.protocol,
                readiness = M9AuthReadiness.INVALID,
                configured = false,
                credentialPresent = false,
                message = "Provider ID is required."
            )
        }

        if (!configuration.enabled) {
            return M9ProviderAuthStatus(
                providerId = providerId,
                protocol = configuration.protocol,
                readiness = M9AuthReadiness.CONFIGURATION_REQUIRED,
                configured = false,
                credentialPresent = false,
                message = "Provider is disabled."
            )
        }

        if (configuration.protocol == M9AuthProtocol.NONE) {
            return M9ProviderAuthStatus(
                providerId = providerId,
                protocol = configuration.protocol,
                readiness = M9AuthReadiness.NOT_REQUIRED,
                configured = true,
                credentialPresent = false,
                message = "No authentication is required for this provider."
            )
        }

        if (configuration.protocol == M9AuthProtocol.OAUTH2) {
            if (configuration.clientId.isBlank()) {
                return M9ProviderAuthStatus(
                    providerId = providerId,
                    protocol = configuration.protocol,
                    readiness = M9AuthReadiness.CONFIGURATION_REQUIRED,
                    configured = false,
                    credentialPresent = false,
                    message = "OAuth client ID is required."
                )
            }

            if (!isValidRedirectUri(configuration.redirectUri)) {
                return M9ProviderAuthStatus(
                    providerId = providerId,
                    protocol = configuration.protocol,
                    readiness = M9AuthReadiness.INVALID,
                    configured = false,
                    credentialPresent = false,
                    message = "A valid HTTPS redirect URI is required."
                )
            }

            if (configuration.scopes.isEmpty()) {
                return M9ProviderAuthStatus(
                    providerId = providerId,
                    protocol = configuration.protocol,
                    readiness = M9AuthReadiness.CONFIGURATION_REQUIRED,
                    configured = false,
                    credentialPresent = false,
                    message = "At least one OAuth scope is required."
                )
            }

            if (!configuration.credentialPresent) {
                return M9ProviderAuthStatus(
                    providerId = providerId,
                    protocol = configuration.protocol,
                    readiness = M9AuthReadiness.READY_FOR_AUTH,
                    configured = true,
                    credentialPresent = false,
                    message = "OAuth configuration is ready. Authentication has not occurred."
                )
            }

            return M9ProviderAuthStatus(
                providerId = providerId,
                protocol = configuration.protocol,
                readiness = M9AuthReadiness.AUTHENTICATED,
                configured = true,
                credentialPresent = true,
                message = "Authentication credential is reported as present. Token use remains outside M9.4."
            )
        }

        if (configuration.protocol == M9AuthProtocol.API_KEY) {
            if (!configuration.credentialPresent) {
                return M9ProviderAuthStatus(
                    providerId = providerId,
                    protocol = configuration.protocol,
                    readiness = M9AuthReadiness.READY_FOR_AUTH,
                    configured = true,
                    credentialPresent = false,
                    message = "API-key provider is configured but no credential is present."
                )
            }

            return M9ProviderAuthStatus(
                providerId = providerId,
                protocol = configuration.protocol,
                readiness = M9AuthReadiness.AUTHENTICATED,
                configured = true,
                credentialPresent = true,
                message = "API-key credential is reported as present. Secret transmission remains outside M9.4."
            )
        }

        return M9ProviderAuthStatus(
            providerId = providerId,
            protocol = configuration.protocol,
            readiness = M9AuthReadiness.INVALID,
            configured = false,
            credentialPresent = false,
            message = "Unsupported authentication protocol."
        )
    }

    private fun isValidRedirectUri(value: String): Boolean {
        val uri = value.trim()

        if (uri.isBlank()) {
            return false
        }

        if (!uri.startsWith("https://", ignoreCase = true)) {
            return false
        }

        return uri.length > "https://".length
    }
}
