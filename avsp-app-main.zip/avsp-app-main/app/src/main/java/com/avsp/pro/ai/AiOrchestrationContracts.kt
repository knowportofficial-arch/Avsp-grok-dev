package com.avsp.pro.ai

/**
 * Provider-independent AI capability taxonomy.
 *
 * The orchestration layer is deliberately independent from M2's ScriptGenerator
 * so existing M2 contracts remain stable. Module adapters can be added later
 * without changing provider selection semantics.
 */
enum class AiCapability {
    RESEARCH,
    SUMMARIZATION,
    SCRIPT,
    TRANSLATION,
    VISION,
    OCR,
    SPEECH_TO_TEXT,
    TTS,
    CAPTIONS,
    SCENE_UNDERSTANDING,
    CREATIVE_PLANNING,
    ANALYTICS
}

enum class AiProviderMode {
    MOCK,
    LOCAL,
    REMOTE
}

enum class AiProviderState {
    AVAILABLE,
    UNAVAILABLE,
    RATE_LIMITED,
    FAILED,
    DISABLED
}

data class AiProviderDescriptor(
    val providerId: String,
    val displayName: String,
    val mode: AiProviderMode,
    val capabilities: Set<AiCapability>,
    val state: AiProviderState = AiProviderState.AVAILABLE,
    val priority: Int = 0
)

data class AiRequest(
    val capability: AiCapability,
    val input: String,
    val preferredProviderId: String? = null,
    val excludedProviderIds: Set<String> = emptySet(),
    val metadata: Map<String, String> = emptyMap()
)

data class AiResponse(
    val providerId: String,
    val output: String,
    val fallbackUsed: Boolean,
    val attemptedProviders: List<String>
)

sealed interface AiExecutionResult {
    data class Success(val response: AiResponse) : AiExecutionResult
    data class Failure(
        val capability: AiCapability,
        val attemptedProviders: List<String>,
        val message: String
    ) : AiExecutionResult
}

interface AiProvider {
    val descriptor: AiProviderDescriptor

    suspend fun execute(request: AiRequest): String
}