﻿package com.avsp.pro.core.dailypost

import com.avsp.pro.ui.screens.dailypost.DailyPostCategory
import com.avsp.pro.ui.screens.dailypost.DailyPostGeography
import com.avsp.pro.ui.screens.dailypost.DailyPostItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import android.util.Xml
import java.net.HttpURLConnection
import java.net.URL

interface DailyPostProvider {
    suspend fun load(): List<DailyPostItem>
}

class RssDailyPostProvider(
    private val feeds: List<RssFeed>
) : DailyPostProvider {

    override suspend fun load(): List<DailyPostItem> = withContext(Dispatchers.IO) {
        feeds.flatMap { feed ->
            runCatching { readFeed(feed) }.getOrDefault(emptyList())
        }
    }

    private fun readFeed(feed: RssFeed): List<DailyPostItem> {
        val connection = (URL(feed.url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 10000
            requestMethod = "GET"
            setRequestProperty("User-Agent", "AVSP-DailyPost/1.0")
        }

        return try {
            if (connection.responseCode !in 200..299) return emptyList()

            val parser = Xml.newPullParser()
            parser.setInput(connection.inputStream, "UTF-8")

            val result = mutableListOf<DailyPostItem>()
            var event = parser.eventType
            var insideItem = false
            var title = ""
            var link = ""
            var date = ""
            var description = ""
            var currentTag = ""

            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> {
                        currentTag = parser.name
                        if (parser.name.equals("item", true) ||
                            parser.name.equals("entry", true)
                        ) {
                            insideItem = true
                            title = ""
                            link = ""
                            date = ""
                            description = ""
                        }
                    }

                    XmlPullParser.TEXT -> {
                        if (insideItem) {
                            when (currentTag.lowercase()) {
                                "title" -> title += parser.text
                                "link" -> link += parser.text
                                "pubdate", "published", "updated", "dc:date" ->
                                    date += parser.text
                                "description", "summary", "content" ->
                                    description += parser.text
                            }
                        }
                    }

                    XmlPullParser.END_TAG -> {
                        val tag = parser.name.lowercase()

                        if ((tag == "item" || tag == "entry") && insideItem) {
                            val cleanTitle = title.trim()
                            val cleanDate = date.trim()
                            val cleanDescription = description
                                .replace(Regex("<[^>]*>"), " ")
                                .replace(Regex("\\s+"), " ")
                                .trim()

                            if (
                                cleanTitle.isNotBlank() &&
                                cleanDate.isNotBlank() &&
                                link.isNotBlank()
                            ) {
                                result += DailyPostItem(
                                    id = "${feed.id}:${cleanTitle.hashCode()}",
                                    title = cleanTitle,
                                    category = feed.category,
                                    geography = feed.geography,
                                    date = cleanDate,
                                    source = feed.source,
                                    summary = cleanDescription.take(700),
                                    relevance = feed.relevance,
                                    videoAngle = "Explain what happened, why it matters today, and the key visual evidence."
                                )
                            }

                            insideItem = false
                        }

                        currentTag = ""
                    }
                }

                event = parser.next()
            }

            result
        } finally {
            connection.disconnect()
        }
    }
}

data class RssFeed(
    val id: String,
    val url: String,
    val source: String,
    val category: DailyPostCategory,
    val geography: DailyPostGeography,
    val relevance: String
)
