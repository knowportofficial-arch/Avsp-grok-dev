package com.avsp.pro.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.avsp.pro.audio.engine.SmartVoiceEngine
import com.avsp.pro.storage.AvspStorage
import com.avsp.pro.storage.StorageArea
import java.io.ByteArrayOutputStream

/**
 * P23 OWN VOICE: the creator says the intro / outro (or any scene) in their own voice.
 * The recording is kept as that scene's voice-over (24 kHz mono WAV, silence trimmed, the
 * same format as the AI voices) and turned into text for the captions; or only the words
 * are kept and the AI voice reads them.
 */
object OwnVoice {
    const val RATE = 24_000

    fun relative(scriptId: String, sceneId: String) = "audio/own/${scriptId}_$sceneId.wav"

    fun has(storage: AvspStorage, projectId: String, scriptId: String, sceneId: String): Boolean =
        runCatching { storage.exists(StorageArea.PROJECT_DATA, relative(scriptId, sceneId), projectId) }.getOrDefault(false)

    fun read(storage: AvspStorage, projectId: String, scriptId: String, sceneId: String): ByteArray? = runCatching {
        java.io.File(storage.resolve(StorageArea.PROJECT_DATA, relative(scriptId, sceneId), projectId))
            .takeIf { it.exists() && it.length() > 44 + RATE / 5 }?.readBytes()
    }.getOrNull()

    fun save(storage: AvspStorage, projectId: String, scriptId: String, sceneId: String, wav: ByteArray) =
        storage.save(StorageArea.PROJECT_DATA, relative(scriptId, sceneId), wav, projectId)

    fun delete(storage: AvspStorage, projectId: String, scriptId: String, sceneId: String) {
        runCatching { storage.delete(StorageArea.PROJECT_DATA, relative(scriptId, sceneId), projectId) }
    }

    /** Words of a WAV recording (Gemini, the user's own key); null when it could not be read. */
    fun transcribe(wav: ByteArray, language: String, keys: () -> List<String>): String? {
        val tr = com.avsp.pro.edit.GeminiTranscriber(keys)
        if (!tr.available()) return null
        val pcm = ShortArray((wav.size - 44) / 2) { i -> ((wav[44 + i * 2].toInt() and 0xff) or (wav[45 + i * 2].toInt() shl 8)).toShort() }
        val ms = pcm.size * 1000L / RATE
        val r = tr.transcribe(com.avsp.pro.edit.MediaAnalysis.Audio(pcm, RATE), listOf(com.avsp.pro.edit.SpeechSegmenter.Segment(0, ms)), language)
        return r.heard.joinToString(" ") { it.text.trim() }.trim().ifBlank { null }
    }

    /** Microphone recorder: start, show [level], stop -> trimmed WAV. */
    class Recorder {
        @Volatile var level = 0f
            private set
        @Volatile private var running = false
        private var thread: Thread? = null
        private val pcm = ByteArrayOutputStream()
        val elapsedMs: Long get() = pcm.size() * 1000L / (RATE * 2)

        @SuppressLint("MissingPermission")   // the screen asks for RECORD_AUDIO first
        fun start(): Boolean {
            if (running) return true
            val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            if (min <= 0) return false
            val rec = runCatching {
                AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 4)
            }.getOrNull() ?: return false
            if (rec.state != AudioRecord.STATE_INITIALIZED) { rec.release(); return false }
            synchronized(pcm) { pcm.reset() }
            running = true
            rec.startRecording()
            thread = Thread {
                val buf = ShortArray(min)
                val bytes = ByteArray(min * 2)
                try {
                    while (running) {
                        val n = rec.read(buf, 0, buf.size)
                        if (n <= 0) continue
                        var peak = 0
                        for (i in 0 until n) {
                            val v = buf[i].toInt(); if (kotlin.math.abs(v) > peak) peak = kotlin.math.abs(v)
                            bytes[i * 2] = (v and 0xff).toByte(); bytes[i * 2 + 1] = ((v shr 8) and 0xff).toByte()
                        }
                        level = (peak / 32768f).coerceIn(0f, 1f)
                        synchronized(pcm) { pcm.write(bytes, 0, n * 2) }
                        if (pcm.size() > RATE * 2 * 120) running = false   // 2 minutes at most
                    }
                } finally {
                    runCatching { rec.stop() }; rec.release()
                }
            }.apply { name = "avsp-own-voice"; start() }
            return true
        }

        /** Stops and returns the recording (silence before/after removed), or null if almost nothing was said. */
        fun stop(): ByteArray? {
            running = false
            thread?.join(1_500); thread = null
            val raw = synchronized(pcm) { pcm.toByteArray() }
            if (raw.size < RATE) return null   // < 0.5 s
            val wav = SmartVoiceEngine.trimSilence(SmartVoiceEngine.pcmToWav(raw, RATE))
            return wav.takeIf { SmartVoiceEngine.durationMs(it) >= 400 }
        }
    }
}
