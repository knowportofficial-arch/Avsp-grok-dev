package com.avsp.pro.core.pipeline

/**
 * P10 BLOG: the same project that makes the video also makes
 *  - a TEXT BLOG (article: title, intro, sections with pictures, key facts, credits, CTA)
 *  - a PHOTO BLOG (carousel slides: cover, one slide per scene, CTA slide)
 * Built offline from the script and the understood sources - no key needed.
 */
data class Blog(
    val title: String,
    val intro: String,
    val sections: List<Section>,
    val keyFacts: List<String>,
    val cta: String,
    val credits: List<String>,
    val hashtags: List<String>
) {
    data class Section(val heading: String, val body: String, val pictureIndex: Int?)

    /** Plain text / Markdown version (copy-paste into any blog editor). */
    fun markdown(): String = buildString {
        append("# ").append(title).append("\n\n")
        if (intro.isNotBlank()) append(intro).append("\n\n")
        sections.forEach { s ->
            if (s.heading.isNotBlank()) append("## ").append(s.heading).append("\n\n")
            append(s.body).append("\n\n")
        }
        if (keyFacts.isNotEmpty()) {
            append("## Key facts\n\n")
            keyFacts.forEach { append("- ").append(it).append('\n') }
            append('\n')
        }
        if (cta.isNotBlank()) append("**").append(cta).append("**\n\n")
        if (hashtags.isNotEmpty()) append(hashtags.joinToString(" ")).append("\n\n")
        if (credits.isNotEmpty()) append("Pictures: ").append(credits.joinToString("; ")).append('\n')
    }.trim() + "\n"
}

object BlogContent {

    data class SceneText(val narration: String, val onScreen: String)

    fun build(
        title: String,
        scenes: List<SceneText>,
        sourceText: String,
        cta: String,
        pictureCount: Int,
        credits: List<String> = emptyList(),
        hashtags: List<String> = emptyList()
    ): Blog {
        val body = scenes.dropLast(if (scenes.size > 1) 1 else 0) // last scene is the spoken CTA
        val intro = body.firstOrNull()?.narration?.let(::clean).orEmpty()
            .let { if (it.contains("Here is what you need to know", ignoreCase = true)) "" else it }
        val rest = body.drop(1) // first scene is the intro (or a filler hook that is left out)
        var pic = 0
        val sections = rest.mapNotNull { sc ->
            val text = clean(sc.narration)
            if (text.isBlank()) return@mapNotNull null
            val raw = clean(sc.onScreen).trimEnd('.', '!', '?', '…').removeSuffix("...").trim()
            // A heading that is only the paragraph's first words ("It is located…") adds nothing.
            val heading = raw.takeIf { h -> h.isNotBlank() && !text.startsWith(h, ignoreCase = true) && !sc.onScreen.trim().endsWith("…") }.orEmpty()
            Blog.Section(heading, text, if (pic < pictureCount) pic++ else null)
        }
        val used = (listOf(intro) + sections.map { it.body }).joinToString(" ").lowercase()
        // The source's first line is often just the title ("Kharagpur"): drop it so it doesn't glue onto a fact.
        val sourceBody = sourceText.lines().dropWhile { it.isBlank() || clean(it).equals(clean(title), ignoreCase = true) }.joinToString("\n")
        val facts = sentences(sourceBody)
            .filter { s -> s.length in 25..220 && !similarToAny(s, used) && !s.equals(title, true) }
            .distinct()
            .take(6)
        return Blog(
            title = clean(title).ifBlank { "My story" },
            intro = intro,
            sections = sections,
            keyFacts = facts,
            cta = clean(cta),
            credits = credits.distinct(),
            hashtags = hashtags
        )
    }

    internal fun clean(s: String): String =
        SourceText.stripReferenceNoise(s).replace(Regex("""\s+([,.;:!?।)])"""), "$1").replace(Regex("""\s+"""), " ").trim()

    internal fun sentences(text: String): List<String> =
        text.lines().filterNot { it.startsWith("Shows:") || it.startsWith("Channel:") }
            .joinToString(" ")
            .let(::clean)
            .split(Regex("""(?<=[.!?।])\s+"""))
            .map { it.trim() }
            .filter { it.split(' ').size >= 4 }

    private fun similarToAny(sentence: String, used: String): Boolean {
        val words = sentence.lowercase().split(Regex("""[^\p{L}\p{N}]+""")).filter { it.length > 3 }
        if (words.isEmpty()) return true
        val hit = words.count { used.contains(it) }
        return hit.toDouble() / words.size >= 0.7
    }

    /** Escapes text for HTML. */
    fun esc(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    /** Self-contained HTML article; [pictures] are JPEG bytes, embedded so the file works anywhere. */
    fun html(blog: Blog, pictures: List<ByteArray>, language: String = "en"): String = buildString {
        fun img(i: Int?): String {
            val bytes = i?.let { pictures.getOrNull(it) } ?: return ""
            val b64 = java.util.Base64.getEncoder().encodeToString(bytes)
            return "<img src=\"data:image/jpeg;base64,$b64\" alt=\"\">"
        }
        append("<!doctype html><html lang=\"").append(esc(language)).append("\"><head><meta charset=\"utf-8\">")
        append("<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>").append(esc(blog.title)).append("</title>")
        append("<style>body{margin:0;background:#f6f7f9;color:#1d232b;font:17px/1.65 system-ui,-apple-system,'Noto Sans','Noto Sans Bengali','Noto Sans Devanagari',sans-serif}")
        append("main{max-width:720px;margin:0 auto;padding:28px 18px 48px;background:#fff}h1{font-size:30px;line-height:1.25;margin:8px 0 14px}")
        append("h2{font-size:21px;margin:28px 0 8px}img{width:100%;border-radius:12px;margin:10px 0 4px;display:block}")
        append(".intro{font-size:19px;color:#36414d}.facts{background:#eef7f5;border-radius:12px;padding:12px 18px 12px 34px}")
        append(".cta{margin-top:28px;padding:14px 18px;border-radius:12px;background:#0f766e;color:#fff;font-weight:600;text-align:center}")
        append(".tags{color:#0f766e;margin-top:16px}.credits{color:#6b7480;font-size:13px;margin-top:22px}</style></head><body><main>")
        append("<h1>").append(esc(blog.title)).append("</h1>")
        if (pictures.isNotEmpty() && blog.sections.none { it.pictureIndex == 0 }) append(img(0))
        if (blog.intro.isNotBlank()) append("<p class=\"intro\">").append(esc(blog.intro)).append("</p>")
        blog.sections.forEach { s ->
            if (s.heading.isNotBlank()) append("<h2>").append(esc(s.heading)).append("</h2>")
            append(img(s.pictureIndex))
            append("<p>").append(esc(s.body)).append("</p>")
        }
        if (blog.keyFacts.isNotEmpty()) {
            append("<h2>Key facts</h2><ul class=\"facts\">")
            blog.keyFacts.forEach { append("<li>").append(esc(it)).append("</li>") }
            append("</ul>")
        }
        if (blog.cta.isNotBlank()) append("<div class=\"cta\">").append(esc(blog.cta)).append("</div>")
        if (blog.hashtags.isNotEmpty()) append("<p class=\"tags\">").append(esc(blog.hashtags.joinToString(" "))).append("</p>")
        if (blog.credits.isNotEmpty()) append("<p class=\"credits\">Pictures: ").append(esc(blog.credits.joinToString("; "))).append("</p>")
        // P22.4: the creator's own name, not the app's.
        val by = com.avsp.pro.settings.BrandKit.channel.ifBlank { null }
        append("<p class=\"credits\">").append(if (by != null) "© " + esc(by) else "").append("</p></main></body></html>")
    }
}
