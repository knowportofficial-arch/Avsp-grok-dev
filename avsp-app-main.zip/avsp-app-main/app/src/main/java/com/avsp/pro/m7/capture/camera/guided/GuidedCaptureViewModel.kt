package com.avsp.pro.m7.capture.camera.guided

import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import androidx.camera.core.ImageProxy
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avsp.pro.m7.capture.camera.CameraController
import com.avsp.pro.m7.capture.camera.model.CameraProfile
import com.avsp.pro.m7.capture.camera.model.CameraShotType
import com.avsp.pro.m7.capture.camera.vision.VisualAnalysisResult
import com.avsp.pro.m7.capture.camera.vision.VisualAnalyzer
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/**
 * M6 — Guided Capture ViewModel.
 *
 * Independently runnable/testable: does not depend on the existing AI CameraViewModel,
 * ShotMission engine, or vision/planner subsystems. Consumes a plain [GuidedCaptureTemplate]
 * and produces MP4 + metadata.json + thumbnail.jpg per clip via [GuidedCaptureStorage].
 *
 * android:image-analysis is bound (CameraController.bindCamera requires a VisualAnalyzer) but
 * this ViewModel supplies a no-op analyzer -- no AI tagging or quality analysis is performed
 * here, per the M6 spec constraint. M7 is responsible for any downstream analysis.
 */
class GuidedCaptureViewModel(
    private val appContext: Context,
    private val cameraController: CameraController = CameraController(appContext),
    private val storage: GuidedCaptureStorage = GuidedCaptureStorage(appContext)
) : ViewModel() {

    private val _state = MutableStateFlow(GuidedCaptureState())
    val state: StateFlow<GuidedCaptureState> = _state

    private val selfTimer = SelfTimer()
    private var recordingProgressJob: kotlinx.coroutines.Job? = null
    private var recordingStartedAtMs: Long = 0L

    /**
     * M6.2 (FIX 3) — hardens the narrow lifecycle edge case where a self-timer's countdown
     * completion callback could already be queued on the main thread at the moment the
     * ViewModel is cleared (back navigation / activity destruction). Set as the very first
     * statement in onCleared(), checked as the very first statement in
     * startCaptureForCurrentClip() -- the only entry point a stale timer callback can reach.
     * This does not change SelfTimer's design; it's a guard at the call site.
     */
    @Volatile
    private var isCleared = false

    private val noOpVisualAnalyzer = object : VisualAnalyzer {
        override fun analyzeFrame(imageProxy: ImageProxy, tiltRollDegrees: Float): VisualAnalysisResult {
            imageProxy.close()
            return VisualAnalysisResult()
        }
        override fun close() {}
    }

    // ---------------- P25 live tips ----------------
    @Volatile private var lastTipAt = 0L
    @Volatile private var aiWanted = false
    @Volatile private var aiDoneForClip = -1
    @Volatile private var tilt = 0f

    private val aiKeys: List<String> by lazy {
        runCatching {
            val c = (appContext.applicationContext as com.avsp.pro.AvspApplication).container
            com.avsp.pro.settings.ApiKeyRing.keys(c.secureConfigStore, com.avsp.pro.settings.SecureConfigKeys.AI_API)
        }.getOrDefault(emptyList())
    }

    private val liveAnalyzer = object : VisualAnalyzer {
        override fun analyzeFrame(imageProxy: ImageProxy, tiltRollDegrees: Float): VisualAnalysisResult {
            val now = System.currentTimeMillis()
            val st = _state.value
            val active = st.phase == GuidedCapturePhase.READY || st.phase == GuidedCapturePhase.COUNTDOWN || st.phase == GuidedCapturePhase.RECORDING
            if (active && now - lastTipAt >= 500) {
                lastTipAt = now
                runCatching {
                    val plane = imageProxy.planes[0]
                    val buf = plane.buffer; buf.rewind()
                    val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                    val s = LiveTips.stats(bytes, imageProxy.width, imageProxy.height, plane.rowStride)
                    val tip = LiveTips.tip(s, tilt, st.currentClip?.frontCamera == true)
                    if (tip != _state.value.liveTip) _state.update { it.copy(liveTip = tip) }
                }
            }
            if (aiWanted && st.phase == GuidedCapturePhase.READY) {
                aiWanted = false
                val clip = st.currentClip
                val jpeg = runCatching {
                    val b = imageProxy.toBitmap()
                    val rot = imageProxy.imageInfo.rotationDegrees
                    val scale = 480f / maxOf(b.width, b.height)
                    val m = android.graphics.Matrix().apply { postScale(scale, scale); postRotate(rot.toFloat()) }
                    val small = android.graphics.Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
                    java.io.ByteArrayOutputStream().also { small.compress(android.graphics.Bitmap.CompressFormat.JPEG, 70, it) }.toByteArray()
                }.getOrNull()
                if (jpeg != null && clip != null) {
                    _state.update { it.copy(aiChecking = true) }
                    viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                        val r = LiveTips.askAi(jpeg, clip.instruction, clip.category, aiKeys)
                        _state.update { it.copy(aiChecking = false, aiTip = r?.tip ?: it.aiTip, aiOk = r?.ok ?: false) }
                    }
                }
            }
            imageProxy.close()
            return VisualAnalysisResult()
        }
        override fun close() {}
    }

    /** "✨ AI check": the AI looks at the next frame and says if it shows this scene's shot. */
    fun askAiTip() {
        if (aiKeys.isEmpty()) { _state.update { it.copy(aiTip = "Add a Gemini key in Settings for AI tips", aiOk = false) }; return }
        aiWanted = true
    }

    fun toggleAiTips() = _state.update { it.copy(aiTips = !it.aiTips, aiTip = null) }

    /** Called when a scene's camera is ready: one automatic AI look after the phone settles. */
    private fun scheduleAutoAiTip() {
        val index = _state.value.currentClipIndex
        if (!_state.value.aiTips || aiKeys.isEmpty() || aiDoneForClip == index) return
        aiDoneForClip = index
        _state.update { it.copy(aiTip = null) }
        viewModelScope.launch {
            kotlinx.coroutines.delay(2_500)
            val s = _state.value
            if (s.currentClipIndex == index && s.phase == GuidedCapturePhase.READY && s.aiTips) aiWanted = true
        }
    }

    fun loadTemplate(template: GuidedCaptureTemplate) {
        _state.update {
            GuidedCaptureState(
                template = template,
                currentClipIndex = 0,
                phase = GuidedCapturePhase.READY,
                autoCapture = it.autoCapture
            )
        }
    }

    /** Test #11 — permission denial path. Call after the caller's permission-request flow resolves. */
    fun onPermissionResult(cameraGranted: Boolean, audioGranted: Boolean) {
        if (!cameraGranted) {
            _state.update {
                it.copy(
                    phase = GuidedCapturePhase.ERROR,
                    errorMessage = "Camera permission was denied. Guided capture requires camera access."
                )
            }
            return
        }
        // Audio denial is non-fatal: recording proceeds without sound (matches existing CameraController behavior).
        _state.update { it.copy(phase = GuidedCapturePhase.READY) }
    }

    suspend fun bindCamera(lifecycleOwner: LifecycleOwner, previewView: PreviewView) {
        val clip = _state.value.currentClip ?: return
        val lensFacing = if (clip.frontCamera) androidx.camera.core.CameraSelector.LENS_FACING_FRONT else androidx.camera.core.CameraSelector.LENS_FACING_BACK
        val profile = CameraProfile(
            shotType = CameraShotType.WIDE,
            resolution = clip.resolution,
            frameRate = clip.frameRate,
            lensFacing = lensFacing,
            isGridOverlayEnabled = _state.value.isGridEnabled,
            preferredAspectRatio = clip.aspectRatio,
            enforceRequestedFrameRate = true,
            // P20: slow motion asks for 120 fps (falls back to 60, then the phone's normal rate).
            requestedFpsOverride = if (clip.slowMotion) 120 else null,
            stabilize = clip.stabilize && clip.mediaType == GuidedClipMediaType.VIDEO
        )
        val result = cameraController.bindCamera(lifecycleOwner, previewView, profile, liveAnalyzer) {}
        result.onFailure { e ->
            _state.update { it.copy(phase = GuidedCapturePhase.ERROR, errorMessage = e.message ?: "Failed to bind camera") }
            return
        }
        // M6.1: request the clip's orientation be applied to capture output (see
        // CameraController.applyOrientation KDoc for exactly what this can and can't guarantee).
        cameraController.applyOrientation(clip.orientation)
        val range = cameraController.exposureCompensationRange() ?: 0..0
        // P20: the shot's lens (0.5x ultra-wide / 2x / 3x); the user's own pick wins after a retake.
        val zoom = _state.value.zoomRatio ?: clip.zoomRatio
        zoom?.let { z -> kotlinx.coroutines.delay(150); cameraController.setZoomSafe(z) }
        val caps = runCatching { cameraController.proCaps(lensFacing) }.getOrNull()
        _state.update { it.copy(exposureIndex = 0, exposureRange = range, caps = caps, boundFps = cameraController.boundFpsUpper) }
        if (_state.value.pro.isActive()) applyPro(_state.value.pro)
        _state.update { it.copy(liveTip = null) }
        scheduleAutoAiTip()
    }

    fun toggleFlash() {
        val next = !_state.value.isFlashOn
        cameraController.toggleTorch(next)
        _state.update { it.copy(isFlashOn = next) }
    }

    fun toggleGrid() {
        _state.update { it.copy(isGridEnabled = !it.isGridEnabled) }
    }

    fun onDeviceOrientationChanged(degrees: Int) {
        _state.update { it.copy(deviceOrientationDegrees = degrees) }
    }

    fun setExposureIndex(index: Int) {
        cameraController.setExposureCompensation(index)
        _state.update { it.copy(exposureIndex = index) }
    }

    /** M6 feature #11: starts the self-timer (if the clip specifies one), then begins capture. */
    fun beginCapture(timerOverride: Int? = null) {
        val clip = _state.value.currentClip ?: return
        if (_state.value.phase != GuidedCapturePhase.READY) return
        val seconds = maxOf(timerOverride ?: 0, clip.timerSeconds)
        if (seconds > 0) {
            _state.update { it.copy(phase = GuidedCapturePhase.COUNTDOWN, countdownSecondsRemaining = seconds, steadyProgress = 0f) }
            selfTimer.start(
                scope = viewModelScope,
                seconds = seconds,
                onTick = { remaining -> _state.update { it.copy(countdownSecondsRemaining = remaining) } },
                onFinished = { startCaptureForCurrentClip() }
            )
        } else {
            startCaptureForCurrentClip()
        }
    }

    fun cancelCountdown() {
        selfTimer.cancel()
        _state.update { it.copy(phase = GuidedCapturePhase.READY, countdownSecondsRemaining = 0) }
    }

    private fun startCaptureForCurrentClip() {
        if (isCleared) return // M6.2 (FIX 3): a stale self-timer callback must not start a recording
        val template = _state.value.template ?: return
        val clip = _state.value.currentClip ?: return

        val prepared = storage.prepareClipStorage(template.templateId, clip.clipId)
        if (prepared is GuidedCaptureStorage.StorageResult.Failed) {
            // Test #12 — storage failure path.
            _state.update { it.copy(phase = GuidedCapturePhase.ERROR, errorMessage = "Storage error: ${prepared.reason}") }
            return
        }
        val ready = prepared as GuidedCaptureStorage.StorageResult.Ready

        if (_state.value.autoCapture) beep()
        when (clip.mediaType) {
            GuidedClipMediaType.VIDEO -> startVideoCapture(clip, ready)
            GuidedClipMediaType.PHOTO -> startPhotoCapture(clip, ready)
        }
    }

    private fun startVideoCapture(clip: GuidedClipSpec, ready: GuidedCaptureStorage.StorageResult.Ready) {
        _state.update {
            it.copy(
                phase = GuidedCapturePhase.RECORDING,
                elapsedMs = 0L,
                targetDurationMs = clip.targetDurationSeconds * 1000L
            )
        }
        recordingStartedAtMs = System.currentTimeMillis()

        cameraController.startRecordingToFile(
            targetFile = ready.videoFile,
            onEvent = { event -> handleVideoRecordEvent(event, clip, ready) },
            onError = { e ->
                // Test #13 — interrupted recording path.
                stopRecordingProgressTicker()
                _state.update { it.copy(phase = GuidedCapturePhase.ERROR, errorMessage = "Recording failed: ${e.message}") }
            },
            withAudio = clip.withAudio && !clip.slowMotion
        )

        recordingProgressJob = viewModelScope.launch {
            while (_state.value.phase == GuidedCapturePhase.RECORDING) {
                val elapsed = System.currentTimeMillis() - recordingStartedAtMs
                _state.update { it.copy(elapsedMs = elapsed) }
                if (elapsed >= clip.targetDurationSeconds * 1000L) {
                    stopRecording()
                    break
                }
                kotlinx.coroutines.delay(100L)
            }
        }
    }

    private fun handleVideoRecordEvent(
        event: VideoRecordEvent,
        clip: GuidedClipSpec,
        ready: GuidedCaptureStorage.StorageResult.Ready
    ) {
        when (event) {
            is VideoRecordEvent.Finalize -> {
                stopRecordingProgressTicker()
                if (event.hasError()) {
                    // Test #13 — interrupted recording path.
                    _state.update {
                        it.copy(
                            phase = GuidedCapturePhase.ERROR,
                            errorMessage = "Recording finalized with error code ${event.error}"
                        )
                    }
                    return
                }
                finalizeVideoClip(clip, ready)
            }
            else -> Unit
        }
    }

    /** Public so the UI's "stop early" control can end a clip before its target duration. */
    fun stopRecording() {
        cameraController.stopRecording()
    }

    private fun stopRecordingProgressTicker() {
        recordingProgressJob?.cancel()
        recordingProgressJob = null
    }

    private fun finalizeVideoClip(clip: GuidedClipSpec, ready: GuidedCaptureStorage.StorageResult.Ready) {
        _state.update { it.copy(phase = GuidedCapturePhase.SAVING) }
        viewModelScope.launch {
            val thumbOk = storage.writeThumbnail(ready.videoFile, ready.thumbFile)
            val durationMs = System.currentTimeMillis() - recordingStartedAtMs
            val location = bestEffortLocation()

            // M6.1: inspect the ACTUAL recorded file rather than assuming the request succeeded.
            val inspected = ClipInspector.inspectVideo(ready.videoFile)

            val requestedWidth = clip.resolution.width
            val requestedHeight = clip.resolution.height
            val requestedFps = clip.frameRate.targetFps
            val requestedAspectLabel = clip.aspectRatio.displayName

            val dimensionsVerified = inspected != null
            val fpsVerified = inspected?.measuredFps != null

            val effectiveWidth = inspected?.displayWidth ?: requestedWidth
            val effectiveHeight = inspected?.displayHeight ?: requestedHeight
            val effectiveFps = inspected?.measuredFps?.let { Math.round(it).toInt() } ?: requestedFps

            val actualAspectClassification = inspected?.let {
                AspectRatioValidator.classify(it.displayWidth, it.displayHeight)
            }
            val actualAspectLabel = when (actualAspectClassification) {
                AspectRatioValidator.Classification.PORTRAIT_9_16 -> "9:16"
                AspectRatioValidator.Classification.LANDSCAPE_16_9 -> "16:9"
                AspectRatioValidator.Classification.OTHER -> "OTHER"
                null -> null
            }
            val aspectMatchesRequest = inspected?.let {
                AspectRatioValidator.matches(it.displayWidth, it.displayHeight, clip.aspectRatio)
            }
            val actualOrientationLabel = inspected?.let {
                if (it.displayWidth < it.displayHeight) "PORTRAIT" else "LANDSCAPE"
            }

            val metadata = ClipMetadata(
                clipId = clip.clipId,
                category = clip.category,
                date = GuidedCaptureStorage.currentDate(),
                time = GuidedCaptureStorage.currentTime(),
                durationMs = durationMs,
                width = effectiveWidth,
                height = effectiveHeight,
                fps = effectiveFps,
                orientation = clip.orientation.name,
                requestedWidth = requestedWidth,
                requestedHeight = requestedHeight,
                requestedFps = requestedFps,
                requestedAspectRatio = requestedAspectLabel,
                actualFps = inspected?.measuredFps,
                actualAspectRatio = actualAspectLabel,
                actualOrientation = actualOrientationLabel,
                dimensionsVerified = dimensionsVerified,
                fpsVerified = fpsVerified,
                aspectRatioMatchesRequest = aspectMatchesRequest,
                latitude = location?.latitude,
                longitude = location?.longitude,
                device = storage.deviceLabel(),
                file = ready.videoFile.absolutePath
            )
            val jsonOk = storage.writeMetadataJson(ready.jsonFile, metadata)
            if (!jsonOk) {
                _state.update { it.copy(phase = GuidedCapturePhase.ERROR, errorMessage = "Failed to write clip metadata JSON.") }
                return@launch
            }

            _state.update {
                it.copy(
                    phase = GuidedCapturePhase.REVIEW,
                    lastRecordedFile = ready.videoFile.absolutePath,
                    lastRecordedThumbnail = if (thumbOk) ready.thumbFile.absolutePath else null,
                    completedClips = it.completedClips + metadata
                )
            }
            scheduleAutoNext()
        }
    }

    private fun startPhotoCapture(clip: GuidedClipSpec, ready: GuidedCaptureStorage.StorageResult.Ready) {
        _state.update { it.copy(phase = GuidedCapturePhase.SAVING) }
        cameraController.takePhotoToFile(
            targetFile = File(ready.clipDir, "clip.jpg"),
            onImageSaved = { file ->
                viewModelScope.launch {
                    val location = bestEffortLocation()
                    val inspected = ClipInspector.inspectPhoto(file)

                    val requestedWidth = clip.resolution.width
                    val requestedHeight = clip.resolution.height
                    val requestedAspectLabel = clip.aspectRatio.displayName
                    val dimensionsVerified = inspected != null

                    val effectiveWidth = inspected?.width ?: requestedWidth
                    val effectiveHeight = inspected?.height ?: requestedHeight

                    val actualAspectClassification = inspected?.let { AspectRatioValidator.classify(it.width, it.height) }
                    val actualAspectLabel = when (actualAspectClassification) {
                        AspectRatioValidator.Classification.PORTRAIT_9_16 -> "9:16"
                        AspectRatioValidator.Classification.LANDSCAPE_16_9 -> "16:9"
                        AspectRatioValidator.Classification.OTHER -> "OTHER"
                        null -> null
                    }
                    val aspectMatchesRequest = inspected?.let {
                        AspectRatioValidator.matches(it.width, it.height, clip.aspectRatio)
                    }
                    val actualOrientationLabel = inspected?.let {
                        if (it.width < it.height) "PORTRAIT" else "LANDSCAPE"
                    }

                    val metadata = ClipMetadata(
                        clipId = clip.clipId,
                        category = clip.category,
                        date = GuidedCaptureStorage.currentDate(),
                        time = GuidedCaptureStorage.currentTime(),
                        durationMs = 0L,
                        width = effectiveWidth,
                        height = effectiveHeight,
                        fps = 0,
                        orientation = clip.orientation.name,
                        requestedWidth = requestedWidth,
                        requestedHeight = requestedHeight,
                        requestedFps = 0,
                        requestedAspectRatio = requestedAspectLabel,
                        actualFps = null, // not applicable to still photos
                        actualAspectRatio = actualAspectLabel,
                        actualOrientation = actualOrientationLabel,
                        dimensionsVerified = dimensionsVerified,
                        fpsVerified = false, // fps is N/A for photos, never claimed verified
                        aspectRatioMatchesRequest = aspectMatchesRequest,
                        latitude = location?.latitude,
                        longitude = location?.longitude,
                        device = storage.deviceLabel(),
                        file = file.absolutePath
                    )
                    val jsonOk = storage.writeMetadataJson(ready.jsonFile, metadata)
                    if (!jsonOk) {
                        _state.update { it.copy(phase = GuidedCapturePhase.ERROR, errorMessage = "Failed to write clip metadata JSON.") }
                        return@launch
                    }
                    _state.update {
                        it.copy(
                            phase = GuidedCapturePhase.REVIEW,
                            lastRecordedFile = file.absolutePath,
                            lastRecordedThumbnail = file.absolutePath,
                            completedClips = it.completedClips + metadata
                        )
                    }
                    scheduleAutoNext()
                }
            },
            onError = { e ->
                _state.update { it.copy(phase = GuidedCapturePhase.ERROR, errorMessage = "Photo capture failed: ${e.message}") }
            }
        )
    }

    /** M6 feature #18 — retake: discards the just-captured clip and re-enters capture for the same clip. */
    fun retake() {
        autoNextJob?.cancel()
        val lastMetadata = _state.value.completedClips.lastOrNull()
        if (lastMetadata != null) {
            try { File(lastMetadata.file).delete() } catch (_: Exception) {}
        }
        _state.update {
            it.copy(
                phase = GuidedCapturePhase.READY,
                elapsedMs = 0L,
                lastRecordedFile = null,
                lastRecordedThumbnail = null,
                completedClips = it.completedClips.dropLast(1)
            )
        }
    }

    // ---------------- P20.1 auto-capture ----------------
    private var lastAccel: FloatArray? = null
    private var steadySinceMs = 0L
    private var autoNextJob: kotlinx.coroutines.Job? = null

    fun toggleAutoCapture() {
        steadySinceMs = 0L
        _state.update { it.copy(autoCapture = !it.autoCapture, steadyProgress = 0f) }
    }

    /** Accelerometer reading: steady + level for 1.5 s while ready -> 2 s countdown -> records. */
    fun onMotion(x: Float, y: Float, z: Float) {
        // P25: roll of an upright phone (flat on a table counts as level)
        tilt = if (kotlin.math.abs(z) > 7f) 0f else Math.toDegrees(kotlin.math.atan2(x.toDouble(), y.toDouble())).toFloat().let { r ->
            when { r > 45f -> r - 90f; r < -45f -> r + 90f; else -> r }   // landscape holds count from their own level
        }
        val prev = lastAccel
        lastAccel = floatArrayOf(x, y, z)
        val st = _state.value
        val clip = st.currentClip
        if (!st.autoCapture || st.phase != GuidedCapturePhase.READY || clip == null) {
            steadySinceMs = 0L
            if (st.steadyProgress != 0f) _state.update { it.copy(steadyProgress = 0f) }
            return
        }
        val delta = if (prev == null) 99f else kotlin.math.abs(x - prev[0]) + kotlin.math.abs(y - prev[1]) + kotlin.math.abs(z - prev[2])
        val roll = Math.toDegrees(kotlin.math.atan2(x.toDouble(), y.toDouble()))
        val flat = kotlin.math.abs(z) > 8.5f   // P21.4: lying flat / filming straight down (food, desk) counts as level
        val level = flat || if (clip.orientation == com.avsp.pro.m7.capture.camera.model.CaptureOrientation.PORTRAIT) kotlin.math.abs(roll) < 12
        else kotlin.math.abs(kotlin.math.abs(roll) - 90) < 12
        val now = android.os.SystemClock.elapsedRealtime()
        if (delta < 0.6f && level) { if (steadySinceMs == 0L) steadySinceMs = now } else steadySinceMs = 0L
        val p = if (steadySinceMs == 0L) 0f else ((now - steadySinceMs) / 1500f).coerceAtMost(1f)
        if (kotlin.math.abs(p - st.steadyProgress) >= 0.05f || (p == 0f && st.steadyProgress != 0f)) _state.update { it.copy(steadyProgress = p) }
        if (p >= 1f) {
            steadySinceMs = 0L
            beep()
            beginCapture(timerOverride = 2)
        }
    }

    /** In auto mode a good shot moves on to the next scene after 3 s (Retake stops it). */
    private fun scheduleAutoNext() {
        if (!_state.value.autoCapture) return
        val index = _state.value.currentClipIndex
        autoNextJob?.cancel()
        autoNextJob = viewModelScope.launch {
            kotlinx.coroutines.delay(3_000)
            val s = _state.value
            if (s.autoCapture && s.phase == GuidedCapturePhase.REVIEW && s.currentClipIndex == index && !s.isLastClip) acceptAndAdvance()
        }
    }

    private fun beep() {
        runCatching {
            val tone = android.media.ToneGenerator(android.media.AudioManager.STREAM_NOTIFICATION, 70)
            tone.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 150)
            viewModelScope.launch { kotlinx.coroutines.delay(400); tone.release() }
        }
    }

    /** P20.0.2: Retry after an error stays on the same scene (earlier shots are kept). */
    fun retryCurrent(template: GuidedCaptureTemplate) {
        if (_state.value.template == null) { loadTemplate(template); return }
        stopRecordingProgressTicker()
        _state.update { it.copy(phase = GuidedCapturePhase.READY, errorMessage = null, elapsedMs = 0L) }
    }

    /** P20: no shot for this scene - it gets a phone / free / generated picture instead. */
    fun skip() {
        val clip = _state.value.currentClip ?: return
        if (_state.value.phase != GuidedCapturePhase.READY) return
        _state.update { it.copy(skippedClipIds = it.skippedClipIds + clip.clipId) }
        if (_state.value.isLastClip) _state.update { it.copy(phase = GuidedCapturePhase.COMPLETE) }
        else _state.update { it.copy(currentClipIndex = it.currentClipIndex + 1, elapsedMs = 0L, zoomRatio = null) }
    }

    /** P20: stop the shoot now; scenes not filmed are filled automatically. */
    fun finishNow() {
        if (_state.value.phase == GuidedCapturePhase.RECORDING) return
        _state.update { it.copy(phase = GuidedCapturePhase.COMPLETE) }
    }

    fun setZoom(ratio: Float) {
        cameraController.setZoomSafe(ratio)
        _state.update { it.copy(zoomRatio = ratio) }
    }

    fun togglePro() = _state.update { it.copy(showPro = !it.showPro) }

    fun setPro(pro: ProSettings) {
        _state.update { it.copy(pro = pro) }
        applyPro(pro)
    }

    private fun applyPro(pro: ProSettings) {
        val manual = pro.iso != null && pro.exposureNs != null && _state.value.caps?.manualSensor == true
        cameraController.applyPro(if (manual) pro.iso else null, if (manual) pro.exposureNs else null, pro.whiteBalance, pro.aeLock)
    }

    fun lockFocus(previewView: androidx.camera.view.PreviewView, lock: Boolean) {
        cameraController.lockFocus(previewView, lock)
        _state.update { it.copy(pro = it.pro.copy(focusLock = lock)) }
    }

    /** P20: free the camera when the shoot screen closes (the host screen stays open). */
    fun release() {
        selfTimer.cancel()
        stopRecordingProgressTicker()
        cameraController.unbind()
    }

    /** Accepts the last captured clip and advances to the next clip, or COMPLETE if this was the last. */
    fun acceptAndAdvance() {
        val state = _state.value
        if (state.isLastClip) {
            _state.update { it.copy(phase = GuidedCapturePhase.COMPLETE) }
        } else {
            _state.update {
                it.copy(
                    phase = GuidedCapturePhase.READY,
                    currentClipIndex = it.currentClipIndex + 1,
                    elapsedMs = 0L,
                    zoomRatio = null,
                    lastRecordedFile = null,
                    lastRecordedThumbnail = null
                )
            }
        }
    }

    private fun bestEffortLocation(): Location? {
        val fineGranted = ContextCompat.checkSelfPermission(
            appContext, android.Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(
            appContext, android.Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        if (!fineGranted && !coarseGranted) return null

        return try {
            val lm = appContext.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return null
            val providers = lm.getProviders(true)
            providers.mapNotNull { provider ->
                try { lm.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
            }.maxByOrNull { it.time }
        } catch (_: Exception) {
            null
        }
    }

    override fun onCleared() {
        isCleared = true
        super.onCleared()
        selfTimer.cancel()
        stopRecordingProgressTicker()
        cameraController.unbind()
    }
}
