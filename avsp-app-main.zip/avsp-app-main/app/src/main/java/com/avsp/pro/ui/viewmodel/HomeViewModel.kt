package com.avsp.pro.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.avsp.pro.core.contracts.Project
import com.avsp.pro.core.error.AvspException
import com.avsp.pro.core.module.ModuleStatus
import com.avsp.pro.core.ui.UiState
import com.avsp.pro.logs.AvspLogger
import com.avsp.pro.m5.UnifiedInputResult
import com.avsp.pro.repository.ModuleStatusRepository
import com.avsp.pro.repository.ProjectRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/** Home-level content workspace state. M5 remains the analysis owner; M1 owns orchestration/UI. */
data class HomeDashboard(
    val projectCount: Int,
    val recentProjects: List<Project>,
    val modules: List<ModuleStatus>,
    val m1Status: String
)

class HomeViewModel(
    private val projectRepository: ProjectRepository,
    private val moduleStatusRepository: ModuleStatusRepository,
    private val logger: AvspLogger,
    private val sourceReader: com.avsp.pro.core.pipeline.SourceReader? = null,
    private val storage: com.avsp.pro.storage.AvspStorage? = null,
    private val appContext: android.content.Context? = null
) : ViewModel() {

    /** P5: plain-language progress while sources are being read ("Reading the YouTube video…"). */
    private val _working = MutableStateFlow<String?>(null)
    val working: StateFlow<String?> = _working.asStateFlow()

    private val _state = MutableStateFlow<UiState<HomeDashboard>>(UiState.Idle)
    val state: StateFlow<UiState<HomeDashboard>> = _state.asStateFlow()

    private val _actionError = MutableStateFlow<String?>(null)
    val actionError: StateFlow<String?> = _actionError.asStateFlow()

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _state.value = UiState.Loading
            try {
                moduleStatusRepository.ensureDefaults()
                val projects = projectRepository.listProjects()
                val modules = moduleStatusRepository.getAll()
                val m1 = modules.find { it.moduleId == "M1" }?.status?.name ?: "READY"
                _state.value = UiState.Success(
                    HomeDashboard(
                        projectCount = projects.size,
                        recentProjects = projects.sortedByDescending { it.updatedAt }.take(6),
                        modules = modules,
                        m1Status = m1
                    )
                )
            } catch (e: Exception) {
                val msg = (e as? AvspException)?.errorInfo?.message ?: e.message ?: "Failed to load home"
                logger.error("M1", "Home load failed", details = msg)
                _state.value = UiState.Error(msg)
            }
        }
    }

    /**
     * Creates one AVSP project from a unified source bundle. The source data is stored as
     * project metadata so downstream modules can consume it without inventing a second project type.
     */
    fun createProjectFromSources(
        name: String,
        description: String,
        sources: List<UnifiedInputResult>,
        onCreated: (Project) -> Unit
    ) {
        if (_working.value != null) return
        viewModelScope.launch {
            try {
                require(sources.isNotEmpty()) { "Add at least one content source" }
                // UNDERSTAND: read every source (link, text, photo, PDF, video) before anything else.
                val understood = sources.map { src ->
                    _working.value = when (src.kind) {
                        com.avsp.pro.m5.UnifiedInputKind.YOUTUBE -> "Reading the YouTube video…"
                        com.avsp.pro.m5.UnifiedInputKind.URL -> "Reading the web page…"
                        com.avsp.pro.m5.UnifiedInputKind.TEXT -> "Reading your text…"
                        else -> "Looking at ${src.title.ifBlank { "your file" }}…"
                    }
                    sourceReader?.understand(src) ?: src
                }
                understood.forEach { u ->
                    logger.info("M5", "Source understood: ${u.kind} ${u.mimeType.orEmpty()} '${u.title.take(60)}' ${u.text.length} chars")
                    u.warnings.lastOrNull()?.let { w -> logger.warning("M5", "Source note: ${w.take(200)}") }
                }
                val sourceMetadata = buildMap {
                    put("source.bundle.version", "2")
                    put("source.bundle.count", understood.size.toString())
                    understood.forEachIndexed { index, source ->
                        put("source.$index.kind", source.kind.name)
                        put("source.$index.reference", source.reference)
                        if (source.title.isNotBlank()) put("source.$index.title", source.title)
                        if (source.mimeType != null) put("source.$index.mimeType", source.mimeType)
                        if (source.youtubeId != null) put("source.$index.youtubeId", source.youtubeId)
                        if (source.text.isNotBlank()) put("source.$index.text", source.text.take(6000))
                    }
                }
                val bestTitle = understood.map { it.title.trim() }
                    .firstOrNull { it.isNotBlank() && !it.startsWith("http") && it != "Text input" }
                    ?: "My video"
                _working.value = "Creating the project…"
                val project = projectRepository.createProject(
                    name = name.ifBlank { bestTitle.take(90) },
                    description = description,
                    metadata = sourceMetadata
                )
                importLocalMedia(project.projectId, understood)
                _actionError.value = null
                refresh()
                onCreated(project)
            } catch (e: Exception) {
                val msg = (e as? AvspException)?.errorInfo?.message
                    ?: e.message
                    ?: "Could not create project"
                logger.error("M1", "Unified content project creation failed", details = msg)
                _actionError.value = msg
            } finally {
                _working.value = null
            }
        }
    }

    /** P19: more text, links, photos, videos or files added to an EXISTING project. */
    fun addSourcesToProject(projectId: String, sources: List<UnifiedInputResult>, onDone: () -> Unit) {
        if (_working.value != null) return
        viewModelScope.launch {
            try {
                require(sources.isNotEmpty()) { "Add at least one thing first" }
                val understood = sources.map { src ->
                    _working.value = "Reading ${src.title.ifBlank { "your item" }.take(40)}…"
                    sourceReader?.understand(src) ?: src
                }
                val project = projectRepository.openProject(projectId)
                val start = project.metadata["source.bundle.count"]?.toIntOrNull() ?: 0
                val extra = buildMap {
                    put("source.bundle.version", "2")
                    put("source.bundle.count", (start + understood.size).toString())
                    understood.forEachIndexed { k, source ->
                        val index = start + k
                        put("source.$index.kind", source.kind.name)
                        put("source.$index.reference", source.reference)
                        if (source.title.isNotBlank()) put("source.$index.title", source.title)
                        if (source.mimeType != null) put("source.$index.mimeType", source.mimeType)
                        if (source.youtubeId != null) put("source.$index.youtubeId", source.youtubeId)
                        if (source.text.isNotBlank()) put("source.$index.text", source.text.take(6000))
                    }
                }
                projectRepository.updateProject(project.copy(metadata = project.metadata + extra))
                importLocalMedia(projectId, understood, offset = start)
                logger.info("M5", "Added ${understood.size} item(s) to the project", projectId = projectId)
                _actionError.value = null
                onDone()
            } catch (e: Exception) {
                _actionError.value = e.message ?: "Could not add to the project"
            } finally {
                _working.value = null
            }
        }
    }

    /** Photos and videos the user picked become the project's own visuals (used before stock or cards). */
    private suspend fun importLocalMedia(projectId: String, sources: List<UnifiedInputResult>, offset: Int = 0) {
        val ctx = appContext ?: return
        val store = storage ?: return
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            sources.forEachIndexed { i, src ->
                val mime = src.mimeType.orEmpty()
                if (!(mime.startsWith("image/") || mime.startsWith("video/"))) return@forEachIndexed
                runCatching {
                    val uri = android.net.Uri.parse(src.reference)
                    val ext = when {
                        mime.startsWith("video/") -> "mp4"
                        mime == "image/png" -> "png"
                        mime == "image/webp" -> "webp"
                        else -> "jpg"
                    }
                    val relative = "media/own/source_${offset + i}_${System.currentTimeMillis()}.$ext"
                    var size = 0L
                    store.openOutput(com.avsp.pro.storage.StorageArea.PROJECT_DATA, relative, projectId).use { out ->
                        ctx.contentResolver.openInputStream(uri)?.use { input -> size = input.copyTo(out) }
                    }
                    projectRepository.addMediaAsset(
                        com.avsp.pro.core.contracts.MediaAsset(
                            assetId = "own_${projectId}_${offset + i}_${System.currentTimeMillis() % 100000}",
                            projectId = projectId,
                            fileName = src.title.ifBlank { "media_$i.$ext" },
                            relativePath = relative,
                            mimeType = mime,
                            sizeBytes = size,
                            createdAt = System.currentTimeMillis() + i,
                            tags = listOf("own", "source")
                        )
                    )
                }.onFailure { logger.warning("M5", "Could not import ${src.title}", details = it.message, projectId = projectId) }
            }
        }
    }

    /** Home quick actions (record screen / camera): an empty project to attach the capture to. */
    fun createQuickProject(name: String, onCreated: (Project) -> Unit) {
        viewModelScope.launch {
            try {
                val project = projectRepository.createProject(name = name)
                _actionError.value = null
                refresh()
                onCreated(project)
            } catch (e: Exception) {
                val msg = (e as? AvspException)?.errorInfo?.message ?: e.message ?: "Could not create project"
                logger.error("M1", "Quick project creation failed", details = msg)
                _actionError.value = msg
            }
        }
    }

    /** P28: "I'm here" event -> a project with the place, day and location; then Manual / Plan & shoot. */
    fun createEventProject(info: com.avsp.pro.capture.EventInfo, language: com.avsp.pro.core.model.ProjectLanguage, onCreated: (Project) -> Unit) {
        viewModelScope.launch {
            try {
                val name = listOfNotNull(info.day?.substringAfter("- ")?.trim(), info.what.ifBlank { info.place }).joinToString(" at ").take(110)
                val project = projectRepository.createProject(
                    name = name.ifBlank { "Live event" }, description = info.topic(), language = language, metadata = info.metadata()
                )
                logger.info("EVENT", "Event project: ${info.folder}", projectId = project.projectId)
                _actionError.value = null
                refresh()
                onCreated(project)
            } catch (e: Exception) {
                _actionError.value = (e as? AvspException)?.errorInfo?.message ?: e.message ?: "Could not create the event project"
            }
        }
    }

    fun clearActionError() {
        _actionError.value = null
    }
}

