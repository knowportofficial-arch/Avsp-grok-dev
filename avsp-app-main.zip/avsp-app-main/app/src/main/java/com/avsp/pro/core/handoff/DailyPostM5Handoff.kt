﻿package com.avsp.pro.core.handoff

import com.avsp.pro.ui.screens.dailypost.DailyPostItem

/**
 * Canonical handoff from verified Daily Post content into the
 * existing M5 Unified Input pipeline.
 *
 * This class deliberately contains no AI call and no network operation.
 * M5 remains responsible for input normalization.
 */
data class DailyPostM5Handoff(
    val sourceId: String,
    val title: String,
    val source: String,
    val date: String,
    val summary: String,
    val relevance: String,
    val videoAngle: String
) {
    fun asInputText(): String = buildString {
        appendLine("TITLE: $title")
        appendLine("DATE: $date")
        appendLine("SOURCE: $source")
        appendLine()
        appendLine("SUMMARY:")
        appendLine(summary)
        appendLine()
        appendLine("WHY IT MATTERS:")
        appendLine(relevance)
        appendLine()
        appendLine("VIDEO ANGLE:")
        appendLine(videoAngle)
    }

    companion object {
        fun from(post: DailyPostItem): DailyPostM5Handoff =
            DailyPostM5Handoff(
                sourceId = post.id,
                title = post.title,
                source = post.source,
                date = post.date,
                summary = post.summary,
                relevance = post.relevance,
                videoAngle = post.videoAngle
            )
    }
}
