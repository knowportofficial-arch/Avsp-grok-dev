﻿package com.avsp.pro.video

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.avsp.pro.storage.FileAvspStorage
import com.avsp.pro.storage.StorageArea
import com.avsp.pro.video.contract.VideoRenderPlan
import com.avsp.pro.video.contract.VideoSceneInput
import com.avsp.pro.video.engine.Media3VideoEngine
import com.avsp.pro.audio.wav.WavEncoder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.runBlocking
import java.io.File

@RunWith(AndroidJUnit4::class)
class M4BackgroundMusicRenderTest {

    private data class FormatCase(
        val name: String,
        val width: Int,
        val height: Int
    )

    @Test
    fun realRender_backgroundMusic_and_formatDimensions_areVerified() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val storage = FileAvspStorage(context)

        val formats = listOf(
            FormatCase("9x16", 1080, 1920),
            FormatCase("16x9", 1920, 1080),
            FormatCase("4x5", 1080, 1350),
            FormatCase("1x1", 1080, 1080)
        )

        formats.forEach { format ->
            val projectId = "m4_real_music_${format.name}"
            storage.ensureProjectLayout(projectId)

            val visualRelative = "media/test_intro.mp4"
            val narrationRelative = "audio/test_narration.wav"
            val musicRelative = "audio/background_music.wav"

            context.assets.open("m4_test_clips/01_INTRO.mp4").use { input ->
                storage.save(
                    StorageArea.PROJECT_DATA,
                    visualRelative,
                    input.readBytes(),
                    projectId
                )
            }

            storage.save(
                StorageArea.PROJECT_DATA,
                narrationRelative,
                WavEncoder.synthesizeToneWav(
                    seedText = "m4 narration ${format.name}",
                    durationMs = 4000L,
                    frequencyHz = 440.0
                ),
                projectId
            )

            storage.save(
                StorageArea.PROJECT_DATA,
                musicRelative,
                WavEncoder.synthesizeToneWav(
                    seedText = "m4 background music ${format.name}",
                    durationMs = 4000L,
                    frequencyHz = 660.0
                ),
                projectId
            )

            val plan = VideoRenderPlan(
                projectId = projectId,
                scriptId = "m4_script",
                audioPackageId = "m4_audio",
                language = "en",
                totalDurationMs = 4000L,
                width = format.width,
                height = format.height,
                fps = 30,
                scenes = listOf(
                    VideoSceneInput(
                        sceneId = "m4_scene",
                        order = 0,
                        startMs = 0L,
                        endMs = 4000L,
                        durationMs = 4000L,
                        audioRelativePath = narrationRelative,
                        visualRelativePath = visualRelative,
                        visualMimeType = "video/mp4"
                    )
                ),
                musicRelativePath = musicRelative
            )

            val validation = com.avsp.pro.video.validation.VideoValidator.validatePlan(plan)
            assertTrue(validation.isValid)

            val engine = Media3VideoEngine(context, storage)
            val result = engine.render(plan)

            assertEquals(projectId, result.projectId)
            assertEquals("video/final.mp4", result.outputRelativePath)
            assertTrue(File(result.outputAbsolutePath).exists())

            assertEquals(format.width, result.width)

            assertEquals(format.height, result.height)

            assertTrue(result.durationMs >= 3500L)
            assertTrue(result.durationMs <= 4500L)

            assertTrue(result.videoCodec.isNotEmpty())

            assertTrue(result.audioCodec.isNotEmpty())

            assertTrue(result.status.isNotEmpty())
        }
    }
}




