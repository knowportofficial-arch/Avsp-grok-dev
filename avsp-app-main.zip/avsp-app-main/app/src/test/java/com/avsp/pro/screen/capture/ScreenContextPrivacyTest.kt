package com.avsp.pro.screen.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * P1 context privacy tests (pure JVM).
 *
 * Layouts mirror the device recording of 2026-10-08 (voter ID card in
 * Adobe Scan, phone dialer, launcher, AVSP screen).
 */
class ScreenContextPrivacyTest {

    private fun line(text: String, l: Float, t: Float, r: Float, b: Float) =
        PrivacyTextLine(text, PrivacyBox(l, t, r, b))

    private fun covers(findings: List<ContextPrivacyFinding>, x: Float, y: Float) =
        findings.any { x >= it.box.left && x <= it.box.right && y >= it.box.top && y <= it.box.bottom }

    /* ---------------- P3: launcher icon labels ---------------- */

    private val homeScreen = listOf(
        line("Aadhaar", 0.06f, 0.10f, 0.20f, 0.12f),
        line("Wallet", 0.30f, 0.10f, 0.42f, 0.12f),
        line("Notebook", 0.53f, 0.10f, 0.70f, 0.12f),
        line("Files", 0.80f, 0.10f, 0.90f, 0.12f),
        line("Phone", 0.07f, 0.90f, 0.19f, 0.92f),
        line("Contacts", 0.29f, 0.90f, 0.45f, 0.92f),
        line("Messages", 0.54f, 0.90f, 0.71f, 0.92f),
        line("Camera", 0.79f, 0.90f, 0.93f, 0.92f)
    )

    @Test
    fun launcher_icon_labels_are_not_masked() {
        assertEquals(emptyList<ContextPrivacyFinding>(), ScreenContextPrivacy.detect(homeScreen))
        assertEquals(8, ScreenContextPrivacy.launcherLabels(homeScreen).size)
    }

    @Test
    fun contact_list_names_are_still_masked_next_to_tabs() {
        val dialer = listOf(
            line("Rahul Sharma", 0.20f, 0.30f, 0.50f, 0.32f),
            line("Priya Das", 0.20f, 0.38f, 0.42f, 0.40f),
            line("Keypad", 0.06f, 0.94f, 0.20f, 0.96f),
            line("Recents", 0.38f, 0.94f, 0.54f, 0.96f),
            line("Contacts", 0.74f, 0.94f, 0.92f, 0.96f)
        )
        val f = ScreenContextPrivacy.detect(dialer)
        assertTrue(f.any { it.sourceText == "Rahul Sharma" })
        assertTrue(f.any { it.sourceText == "Priya Das" })
    }

    /* ---------------- identity card ---------------- */

    private val voterCard = listOf(
        line("ELECTION COMMISSION OF INDIA", 0.30f, 0.20f, 0.95f, 0.22f),
        line("IDENTITY CARD", 0.05f, 0.24f, 0.30f, 0.26f),
        line("Elector's Name", 0.05f, 0.50f, 0.30f, 0.52f),
        line(": Angur Maiti", 0.48f, 0.50f, 0.70f, 0.52f),
        line("Father / Mother /", 0.05f, 0.58f, 0.27f, 0.60f),
        line("Husband's Name", 0.05f, 0.61f, 0.30f, 0.63f),
        line("Sex", 0.05f, 0.69f, 0.10f, 0.71f),
        line(": Female", 0.48f, 0.69f, 0.62f, 0.71f),
        line("Age as on 01.01.2008", 0.05f, 0.75f, 0.40f, 0.77f)
    )

    @Test
    fun id_card_elector_name_on_separate_line_is_masked() {
        val f = ScreenContextPrivacy.detect(voterCard)
        assertTrue(covers(f, 0.60f, 0.51f))
        assertTrue(f.any { it.sourceText == "Angur Maiti" })
    }

    @Test
    fun id_card_unreadable_script_rows_under_values_are_masked() {
        // Bengali name (row below the English value) is NOT in OCR at all.
        val f = ScreenContextPrivacy.detect(voterCard)
        assertTrue("bengali elector name", covers(f, 0.60f, 0.545f))
        assertTrue("bengali father name", covers(f, 0.60f, 0.665f))
        assertTrue("english father value", covers(f, 0.60f, 0.62f))
        assertTrue("sex value", covers(f, 0.55f, 0.70f))
    }

    @Test
    fun id_card_labels_and_header_stay_visible() {
        val f = ScreenContextPrivacy.detect(voterCard)
        assertFalse("label column", covers(f, 0.12f, 0.51f))
        assertFalse("label column 2", covers(f, 0.12f, 0.62f))
        assertFalse("header", covers(f, 0.60f, 0.21f))
    }

    @Test
    fun sex_and_age_are_not_labels_outside_identity_documents() {
        val f = ScreenContextPrivacy.detect(
            listOf(
                line("Sex", 0.05f, 0.30f, 0.10f, 0.32f),
                line(": Female", 0.48f, 0.30f, 0.62f, 0.32f)
            )
        )
        assertTrue(f.isEmpty())
    }

    /* ---------------- labelled values anywhere ---------------- */

    @Test
    fun inline_label_value_is_masked() {
        val f = ScreenContextPrivacy.detect(listOf(line("Name: Rahul Kumar", 0.10f, 0.40f, 0.60f, 0.42f)))
        assertEquals(1, f.size)
        assertEquals("Rahul Kumar", f[0].sourceText)
        assertTrue(f[0].box.left > 0.20f)
    }

    @Test
    fun father_name_inline_is_masked() {
        val f = ScreenContextPrivacy.detect(listOf(line("Father's Name - Joydeb Maiti", 0.10f, 0.40f, 0.80f, 0.42f)))
        assertTrue(f.any { it.sourceText == "Joydeb Maiti" })
    }

    @Test
    fun hindi_label_value_is_masked() {
        val f = ScreenContextPrivacy.detect(listOf(line("नाम: राम कुमार", 0.10f, 0.40f, 0.60f, 0.42f)))
        assertTrue(f.any { it.sourceText == "राम कुमार" })
    }

    @Test
    fun form_label_with_value_below_is_masked() {
        val f = ScreenContextPrivacy.detect(
            listOf(
                line("Name", 0.08f, 0.30f, 0.18f, 0.32f),
                line("Rahul Kumar", 0.08f, 0.33f, 0.40f, 0.35f)
            )
        )
        assertTrue(covers(f, 0.20f, 0.34f))
    }

    @Test
    fun ordinary_text_is_not_masked() {
        val f = ScreenContextPrivacy.detect(
            listOf(
                line("Name your project", 0.08f, 0.30f, 0.50f, 0.32f),
                line("Open the app and select Login", 0.08f, 0.40f, 0.70f, 0.42f),
                line("Settings", 0.08f, 0.50f, 0.30f, 0.52f)
            )
        )
        assertTrue(f.isEmpty())
    }

    /* ---------------- contact screens ---------------- */

    @Test
    fun dialer_contact_names_are_masked_ui_words_are_not() {
        val dialer = listOf(
            line("Dial", 0.05f, 0.03f, 0.16f, 0.06f),
            line("Prabir Poria Agni Cable", 0.10f, 0.08f, 0.62f, 0.10f),
            line("2:13 PM", 0.78f, 0.08f, 0.90f, 0.10f),
            line("Pinky", 0.10f, 0.18f, 0.22f, 0.20f),
            line("Jayantada", 0.10f, 0.22f, 0.30f, 0.24f),
            line("ABC", 0.46f, 0.30f, 0.54f, 0.315f),
            line("BSNL", 0.40f, 0.40f, 0.50f, 0.42f),
            line("Dial", 0.15f, 0.45f, 0.24f, 0.465f),
            line("Contacts", 0.40f, 0.45f, 0.58f, 0.465f),
            line("Favorites", 0.70f, 0.45f, 0.88f, 0.465f)
        )
        val f = ScreenContextPrivacy.detect(dialer)
        val names = f.filter { it.type == SensitiveDataType.CONTACT_NAME }.map { it.sourceText }.toSet()
        assertEquals(setOf("Prabir Poria Agni Cable", "Pinky", "Jayantada"), names)
    }

    @Test
    fun launcher_app_labels_are_not_contact_names() {
        val launcher = listOf(
            line("Telegram", 0.05f, 0.30f, 0.20f, 0.315f),
            line("Netflix", 0.25f, 0.30f, 0.40f, 0.315f),
            line("Phone", 0.45f, 0.30f, 0.60f, 0.315f),
            line("Truecaller", 0.05f, 0.50f, 0.20f, 0.515f)
        )
        assertTrue(ScreenContextPrivacy.detect(launcher).isEmpty())
    }

    @Test
    fun recent_apps_thumbnail_text_does_not_enable_contact_mode() {
        val recents = listOf(
            line("Dial", 0.62f, 0.40f, 0.66f, 0.405f),
            line("Contacts", 0.66f, 0.70f, 0.70f, 0.705f),
            line("Favorites", 0.72f, 0.70f, 0.76f, 0.705f),
            line("Telegram", 0.05f, 0.10f, 0.20f, 0.12f)
        )
        assertTrue(ScreenContextPrivacy.detect(recents).isEmpty())
    }

    /* ---------------- sanitizer false positives ---------------- */

    @Test
    fun version_suffix_is_not_a_number() {
        assertEquals(
            "AVSP Screen Capture V2",
            ScreenSensitiveSanitizer.sanitize("AVSP Screen Capture V2")
        )
        assertTrue(ScreenSensitiveSanitizer.sanitize("ID12345678").contains("REDACTED"))
        assertTrue(ScreenSensitiveSanitizer.sanitize("Call 9876543210").contains("3210"))
        assertFalse(ScreenSensitiveSanitizer.sanitize("Call 9876543210").contains("98765"))
    }

    @Test
    fun keypad_and_icon_digits_are_visual_noise_but_real_numbers_are_not() {
        fun noise(text: String, h: Float) =
            ScreenSensitiveSanitizer.scan(text).all { ScreenSensitiveSanitizer.isVisualNoise(it, text, h) }

        assertTrue("keypad 1", noise("1", 0.02f))
        assertTrue("nav 0", noise("0", 0.02f))
        assertTrue("icon glyph", noise("05", 0.05f))
        assertFalse("age 45 inside text", noise("Age 45 years", 0.02f))
        assertFalse("otp", noise("949147", 0.02f))
        assertFalse("short code in text", noise("Code 4521 sent", 0.02f))
    }
}
