package com.avsp.pro.publish

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SeoKitTest {
    @Test fun geminiAnswerBecomesAKit() {
        val s = SeoKit.parse("""```json
            {"title":"Kharagpur: India's Longest Railway Platform","description":"Did you know? Kharagpur has one of the longest platforms in the world.",
             "tags":["kharagpur","longest railway platform","iit kharagpur"],"hashtags":["#Kharagpur","IndianRailways","#shorts"],"chapters":[]}
            ```""")!!
        assertEquals(listOf("#Kharagpur", "#IndianRailways", "#shorts"), s.hashtags)
        val kit = s.kit()
        assertTrue(kit.description.contains("Tags: kharagpur, longest railway platform"))
        assertTrue(kit.caption.startsWith("Kharagpur: India's Longest"))
        assertNull(SeoKit.parse("not json"))
    }

    @Test fun phoneOnlyVersionFromTheWords() {
        val s = SeoKit.offline("Happy birthday my darling. Today we cut the birthday cake together. The cake was chocolate.", "Cake, Food, Leisure")
        assertEquals("Happy birthday my darling", s.title)          // label-style name is not used as a title
        assertTrue(s.tags.contains("birthday") && s.tags.contains("cake"))
        assertTrue(s.hashtags.last() == "#shorts")
    }
}
