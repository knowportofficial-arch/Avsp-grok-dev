﻿package com.avsp.pro.core.input

import com.avsp.pro.ai.AiCapability
import com.avsp.pro.ai.AiOrchestrator
import com.avsp.pro.ai.AiProvider
import com.avsp.pro.ai.AiProviderDescriptor
import com.avsp.pro.ai.AiProviderMode
import com.avsp.pro.ai.AiProviderRegistry
import com.avsp.pro.ai.AiProviderState
import com.avsp.pro.script.contract.DurationRequest
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class M16DocumentIntelligenceContractTest {

    private fun input(
        title: String = "Test Document"
    ) = UnifiedInput(id = "m16-test-1", type = UnifiedInputType.DOCUMENT,
        locator = "content://test/document",
        displayName = title
    )

    private fun document(
        text: String?,
        truncated: Boolean = false
    ) = DocumentContentProcessor.ProcessedDocument(
        input = input(),
        kind = DocumentContentProcessor.ContentKind.TEXT_DOCUMENT,
        pageCount = null,
        text = text,
        truncated = truncated
    )

    @Test
    fun deterministicExtractionProducesStructuredResult() = runTest {
        val result = DocumentIntelligenceProcessor.process(
            document = document(
                """
                Important Project Overview

                This document explains the AVSP project and its content workflow.
                The system accepts documents and converts source material into
                structured content for downstream script generation.

                - Document intelligence extracts key information.
                - Large documents are processed in bounded chunks.
                """.trimIndent()
            ),
            enableAi = false
        )

        assertTrue(result.status == DocumentIntelligenceProcessor.Status.READY_WITHOUT_AI)
        assertEquals(DocumentIntelligenceProcessor.AiStatus.NOT_REQUESTED, result.aiStatus)
        assertEquals("en", result.languageCode)
        assertTrue(result.normalizedText.isNotBlank())
        assertTrue(result.sections.isNotEmpty())
        assertTrue(result.summary.isNotBlank())
        assertTrue(result.keyPoints.isNotEmpty())
        assertTrue(result.topics.isNotEmpty())
        assertTrue(result.scriptReadyText.contains("KEY POINTS"))
    }

    @Test
    fun pdfWithoutTextIsNeverPretendedToBeExtracted() = runTest {
        val result = DocumentIntelligenceProcessor.process(
            DocumentContentProcessor.ProcessedDocument(
                input = UnifiedInput(id = "m16-test-1", type = UnifiedInputType.PDF_DOCUMENT,
                    locator = "content://test/file.pdf",
        displayName = "PDF"
                ),
                kind = DocumentContentProcessor.ContentKind.PDF,
                pageCount = 7,
                text = null
            ),
            enableAi = true
        )

        assertEquals(
            DocumentIntelligenceProcessor.Status.NO_TEXT_CONTENT,
            result.status
        )
        assertEquals("und", result.languageCode)
        assertTrue(result.warnings.any { it.contains("PDF text extraction") })
        assertTrue(result.scriptReadyText.isBlank())
    }

    @Test
    fun largeTextIsChunkedWithBoundedChunkSize() = runTest {
        val text = (1..5000)
            .joinToString(" ") { "document" }

        val result = DocumentIntelligenceProcessor.process(
            document = document(text),
            enableAi = false,
            chunkChars = 1000,
            chunkOverlap = 100
        )

        assertTrue(result.chunks.size > 1)
        assertTrue(result.chunks.all { it.text.length <= 1000 })
        assertEquals(0, result.chunks.first().startOffset)
    }

    @Test
    fun truncationWarningIsPreserved() = runTest {
        val result = DocumentIntelligenceProcessor.process(
            document = document(
                "This is valid source text.",
                truncated = true
            ),
            enableAi = false
        )

        assertTrue(result.warnings.any { it.contains("truncated") })
    }

    @Test
    fun languageDetectionSupportsBengaliAndHindi() = runTest {
        val bn = DocumentIntelligenceProcessor.process(
            document = document("এটি একটি বাংলা নথি। এখানে গুরুত্বপূর্ণ তথ্য রয়েছে।"),
            enableAi = false
        )

        val hi = DocumentIntelligenceProcessor.process(
            document = document("यह एक हिंदी दस्तावेज़ है। इसमें महत्वपूर्ण जानकारी है।"),
            enableAi = false
        )

        assertEquals("bn", bn.languageCode)
        assertEquals("hi", hi.languageCode)
    }

    @Test
    fun scriptRequestBridgeUsesExistingM2Contract() = runTest {
        val result = DocumentIntelligenceProcessor.process(
            document = document(
                "AVSP document explains the production workflow. " +
                    "The source should remain factual and traceable."
            ),
            enableAi = false
        )

        val request = result.toScriptGenerationRequest(
            projectId = "project-1",
            duration = DurationRequest.ShortForm
        )

        assertEquals("project-1", request.projectId)
        assertEquals("en", request.languageCode)
        assertEquals(DurationRequest.ShortForm, request.duration)
        assertTrue(request.topic.isNotBlank())
        assertTrue(request.userInstructions?.contains("M16") == true)
        assertTrue(request.factualRequirements?.contains("factual source") == true)
    }

    @Test
    fun availableAiProviderIsUsedThroughExistingOrchestrator() = runTest {
        val provider = object : AiProvider {
            override val descriptor = AiProviderDescriptor(
                providerId = "test-summary",
                displayName = "Test Summary Provider",
                mode = AiProviderMode.LOCAL,
                capabilities = setOf(AiCapability.SUMMARIZATION),
                state = AiProviderState.AVAILABLE,
                priority = 10
            )

            override suspend fun execute(
                request: com.avsp.pro.ai.AiRequest
            ): String = "AI summary from provider"
        }

        val orchestrator = AiOrchestrator(
            AiProviderRegistry(listOf(provider))
        )

        val result = DocumentIntelligenceProcessor.process(
            document = document(
                "This is a sufficiently long source document. " +
                    "It contains factual material for summarization."
            ),
            aiOrchestrator = orchestrator,
            enableAi = true
        )

        assertEquals(
            DocumentIntelligenceProcessor.AiStatus.SUCCESS,
            result.aiStatus
        )
        assertEquals("test-summary", result.aiProviderId)
        assertEquals("AI summary from provider", result.summary)
    }

    @Test
    fun unavailableAiFallsBackTruthfullyToDeterministicExtraction() = runTest {
        val result = DocumentIntelligenceProcessor.process(
            document = document(
                "This document contains useful source material. " +
                    "The deterministic extractor must remain usable."
            ),
            aiOrchestrator = AiOrchestrator(AiProviderRegistry()),
            enableAi = true
        )

        assertEquals(
            DocumentIntelligenceProcessor.AiStatus.NOT_CONFIGURED,
            result.aiStatus
        )
        assertTrue(result.summary.isNotBlank())
        assertTrue(
            result.warnings.any {
                it.contains("deterministic extraction")
            }
        )
    }

    @Test
    fun emptyTextReturnsEmptyContent() = runTest {
        val result = DocumentIntelligenceProcessor.process(
            document = document("   "),
            enableAi = false
        )

        assertEquals(
            DocumentIntelligenceProcessor.Status.EMPTY_CONTENT,
            result.status
        )
        assertTrue(result.summary.isBlank())
        assertTrue(result.scriptReadyText.isBlank())
    }
}


