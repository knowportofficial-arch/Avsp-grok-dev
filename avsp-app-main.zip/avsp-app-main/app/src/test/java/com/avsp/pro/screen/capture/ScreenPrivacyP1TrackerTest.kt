package com.avsp.pro.screen.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * P1 tracker tests: scroll-consistent association (no ghost columns),
 * smaller motion margin, keyless (face / ID band) tracks, transition veils.
 */
class ScreenPrivacyP1TrackerTest {

    private fun box(cx: Float, cy: Float, w: Float = 0.10f, h: Float = 0.02f) =
        PrivacyBox(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)

    private fun obs(t: Long, cx: Float, cy: Float, key: String, w: Float = 0.10f, h: Float = 0.02f) =
        PrivacyObservation(t, SensitiveDataType.NUMBER, box(cx, cy, w, h), key)

    private fun contains(outer: PrivacyBox, inner: PrivacyBox) =
        outer.left <= inner.left + 1e-4f && outer.top <= inner.top + 1e-4f &&
            outer.right >= inner.right - 1e-4f && outer.bottom >= inner.bottom - 1e-4f

    @Test
    fun repeated_short_key_follows_its_own_row_while_scrolling() {
        // Two rows show "26" (dates); one unique row anchors the scroll estimate.
        // Screen scrolls up by 0.15 between samples. P0 could link the lower
        // "26" (0.50) to the upper one's new position and sweep a tall box.
        val o = listOf(
            obs(0L, 0.7f, 0.30f, "26"),
            obs(0L, 0.7f, 0.50f, "26"),
            obs(0L, 0.3f, 0.40f, "fileoct0526"),
            obs(200L, 0.7f, 0.15f, "26"),
            obs(200L, 0.7f, 0.35f, "26"),
            obs(200L, 0.3f, 0.25f, "fileoct0526")
        )
        val plan = ScreenPrivacyTracker.build(o, listOf(0L, 200L), durationMs = 400L)

        val numberTracks = plan.tracks.filter { it.keyframes.first().box.centerX > 0.5f }
        assertEquals(2, numberTracks.size)
        numberTracks.forEach { track ->
            val dy = track.keyframes.last().box.centerY - track.keyframes.first().box.centerY
            assertEquals(-0.15f, dy, 0.01f)
        }
    }

    @Test
    fun no_ghost_columns_during_scroll() {
        // Fast scroll: 0.3 per 200 ms. Every censor box stays close to text height.
        val samples = (0L..1000L step 200L).toList()
        val o = samples.flatMap { t ->
            val shift = -0.3f * (t / 200f)
            listOf(
                obs(t, 0.5f, 1.4f + shift, "a1"),
                obs(t, 0.5f, 1.6f + shift, "b2")
            ).filter { it.box.centerY in 0.05f..0.95f }
        }
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 1000L)
        for (t in 0L..1000L step 10L) {
            plan.boxesAt(t).forEach { b ->
                assertTrue("box too tall at $t: ${b.height}", b.height <= 0.02f + 2 * 0.025f + 2 * 0.004f + 1e-4f)
            }
        }
    }

    @Test
    fun scrolling_text_is_still_covered_every_10ms() {
        val samples = (0L..1000L step 200L).toList()
        val truth = { t: Long -> 0.8f - 0.5f * (t / 1000f) }
        val o = samples.map { t -> obs(t, 0.5f, truth(t), "9876543210") }
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 1000L)
        for (t in 0L..1000L step 10L) {
            val content = box(0.5f, truth(t))
            assertTrue("leak at $t", plan.boxesAt(t).any { contains(it, content) })
        }
    }

    @Test
    fun keyless_face_track_follows_scroll_using_global_shift() {
        // Face key is "#FACE" (no text). It moves with the screen by 0.12;
        // its IoU with the previous position is 0, so only the shift helps.
        val o = listOf(
            obs(0L, 0.5f, 0.60f, "#FACE", w = 0.20f, h = 0.10f),
            obs(0L, 0.2f, 0.30f, "9876543210"),
            obs(200L, 0.5f, 0.48f, "#FACE", w = 0.20f, h = 0.10f),
            obs(200L, 0.2f, 0.18f, "9876543210")
        )
        val plan = ScreenPrivacyTracker.build(o, listOf(0L, 200L), durationMs = 400L)
        val faceTracks = plan.tracks.filter { it.keyframes.first().box.width > 0.15f }
        assertEquals(1, faceTracks.size)
        assertEquals(2, faceTracks[0].keyframes.size)
    }

    @Test
    fun transition_veil_covers_only_its_window() {
        val plan = ScreenPrivacyTracker.build(
            observations = emptyList(),
            sampleTimesMs = listOf(0L, 1000L),
            durationMs = 2000L,
            veils = listOf(PrivacyVeil(1000L, 1200L))
        )
        assertFalse(plan.isEmpty)
        assertFalse(plan.veilAt(999L))
        assertTrue(plan.veilAt(1000L))
        assertTrue(plan.veilAt(1100L))
        assertTrue(plan.veilAt(1200L))
        assertFalse(plan.veilAt(1201L))
    }

    /** Text-list-like 48x48 signature: white rows with darker "text" stripes. */
    private fun listSignature(offsetRows: Int): FloatArray {
        val n = 48
        val out = FloatArray(n * n)
        for (y in 0 until n) {
            val row = y + offsetRows
            for (x in 0 until n) {
                val text = (row % 6 == 2 || row % 6 == 3) && x in (4 + (row * 7) % 9)..(30 + (row * 5) % 14)
                out[y * n + x] = if (text) 0.25f else 0.95f
            }
        }
        return out
    }

    @Test
    fun scroll_is_explained_by_shift_but_zoom_is_not() {
        val a = listSignature(0)
        val scrolled = listSignature(10)
        var raw = 0f
        for (i in a.indices) raw += kotlin.math.abs(a[i] - scrolled[i])
        raw /= a.size
        assertTrue("scroll changes many cells (raw=$raw)", raw > 0.10f)
        assertTrue(
            "scroll is explained by a shift",
            ScreenPrivacyTracker.unexplainedChange(a, scrolled, 48) < 0.01f
        )

        // Zoom-out: the old picture shrinks to the centre on a dark background.
        val n = 48
        val zoomed = FloatArray(n * n) { 0.1f }
        for (y in 12 until 36) for (x in 12 until 36) {
            zoomed[y * n + x] = a[((y - 12) * 2) * n + (x - 12) * 2]
        }
        assertTrue(
            "zoom is not explained by a shift",
            ScreenPrivacyTracker.unexplainedChange(a, zoomed, 48) >= 0.05f
        )
    }

    @Test
    fun estimate_shift_ignores_ambiguous_and_keyless_keys() {
        val prev = listOf(
            "26" to box(0.7f, 0.30f),
            "26" to box(0.7f, 0.50f),
            "#FACE" to box(0.5f, 0.5f),
            "abc" to box(0.3f, 0.40f)
        )
        val cur = listOf(
            obs(1L, 0.7f, 0.10f, "26"),
            obs(1L, 0.7f, 0.35f, "26"),
            obs(1L, 0.5f, 0.1f, "#FACE"),
            obs(1L, 0.3f, 0.30f, "abc")
        )
        val s = ScreenPrivacyTracker.estimateShift(prev, cur)
        assertEquals(0f, s!!.first, 1e-4f)
        assertEquals(-0.10f, s.second, 1e-4f)
    }
}
