package com.avsp.pro.ai

import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AiOrchestrationTest {

    private class TestProvider(
        override val descriptor: AiProviderDescriptor,
        private val action: suspend (AiRequest) -> String
    ) : AiProvider {
        override suspend fun execute(request: AiRequest): String = action(request)
    }

    @Test
    fun capabilityMatchingExcludesUnsupportedProviders() {
        val registry = AiProviderRegistry(
            listOf(
                TestProvider(
                    AiProviderDescriptor(
                        providerId = "script",
                        displayName = "Script",
                        mode = AiProviderMode.REMOTE,
                        capabilities = setOf(AiCapability.SCRIPT)
                    )
                ) { "ok" },
                TestProvider(
                    AiProviderDescriptor(
                        providerId = "tts",
                        displayName = "TTS",
                        mode = AiProviderMode.LOCAL,
                        capabilities = setOf(AiCapability.TTS)
                    )
                ) { "voice" }
            )
        )

        val ids = registry.candidates(AiRequest(AiCapability.SCRIPT, "topic"))
            .map { it.descriptor.providerId }

        assertEquals(listOf("script"), ids)
    }

    @Test
    fun preferredProviderWinsWithinCapability() {
        val registry = AiProviderRegistry(
            listOf(
                TestProvider(
                    AiProviderDescriptor(
                        providerId = "a",
                        displayName = "A",
                        mode = AiProviderMode.REMOTE,
                        capabilities = setOf(AiCapability.SCRIPT),
                        priority = 100
                    )
                ) { "a" },
                TestProvider(
                    AiProviderDescriptor(
                        providerId = "b",
                        displayName = "B",
                        mode = AiProviderMode.REMOTE,
                        capabilities = setOf(AiCapability.SCRIPT),
                        priority = 1
                    )
                ) { "b" }
            )
        )

        val first = registry.candidates(
            AiRequest(AiCapability.SCRIPT, "topic", preferredProviderId = "b")
        ).first().descriptor.providerId

        assertEquals("b", first)
    }

    @Test
    fun failedProviderFallsBackToNextProvider() = runTest {
        val registry = AiProviderRegistry(
            listOf(
                TestProvider(
                    AiProviderDescriptor(
                        providerId = "primary",
                        displayName = "Primary",
                        mode = AiProviderMode.REMOTE,
                        capabilities = setOf(AiCapability.SUMMARIZATION),
                        priority = 10
                    )
                ) { error("simulated provider failure") },
                TestProvider(
                    AiProviderDescriptor(
                        providerId = "fallback",
                        displayName = "Fallback",
                        mode = AiProviderMode.LOCAL,
                        capabilities = setOf(AiCapability.SUMMARIZATION),
                        priority = 1
                    )
                ) { "fallback-output" }
            )
        )

        val result = AiOrchestrator(registry).execute(
            AiRequest(AiCapability.SUMMARIZATION, "source")
        )

        assertTrue(result is AiExecutionResult.Success)
        val success = result as AiExecutionResult.Success
        assertEquals("fallback", success.response.providerId)
        assertTrue(success.response.fallbackUsed)
        assertEquals(listOf("primary", "fallback"), success.response.attemptedProviders)
    }

    @Test
    fun unavailableProviderIsNotAttempted() = runTest {
        val registry = AiProviderRegistry(
            listOf(
                TestProvider(
                    AiProviderDescriptor(
                        providerId = "offline",
                        displayName = "Offline",
                        mode = AiProviderMode.REMOTE,
                        capabilities = setOf(AiCapability.RESEARCH),
                        state = AiProviderState.UNAVAILABLE
                    )
                ) { "should-not-run" }
            )
        )

        val result = AiOrchestrator(registry).execute(
            AiRequest(AiCapability.RESEARCH, "topic")
        )

        assertTrue(result is AiExecutionResult.Failure)
        assertTrue((result as AiExecutionResult.Failure).attemptedProviders.isEmpty())
    }

    @Test
    fun excludedProviderIsNotAttempted() = runTest {
        val registry = AiProviderRegistry(
            listOf(
                TestProvider(
                    AiProviderDescriptor(
                        providerId = "excluded",
                        displayName = "Excluded",
                        mode = AiProviderMode.REMOTE,
                        capabilities = setOf(AiCapability.SCRIPT)
                    )
                ) { "should-not-run" },
                TestProvider(
                    AiProviderDescriptor(
                        providerId = "usable",
                        displayName = "Usable",
                        mode = AiProviderMode.LOCAL,
                        capabilities = setOf(AiCapability.SCRIPT)
                    )
                ) { "usable-output" }
            )
        )

        val result = AiOrchestrator(registry).execute(
            AiRequest(
                capability = AiCapability.SCRIPT,
                input = "topic",
                excludedProviderIds = setOf("excluded")
            )
        )

        assertTrue(result is AiExecutionResult.Success)
        assertEquals("usable", (result as AiExecutionResult.Success).response.providerId)
    }
}