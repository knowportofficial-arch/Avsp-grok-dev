package com.avsp.pro.script.generator

import com.avsp.pro.script.contract.DurationRequest
import com.avsp.pro.script.contract.ScriptGenerationRequest
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class GeminiScriptGeneratorTest {
    private val req = ScriptGenerationRequest("p1", "Health benefits of mango", "en", DurationRequest.Explicit(60_000L))

    private fun reply(json: String) = """{"candidates":[{"content":{"parts":[{"text":${org.json.JSONObject.quote(json)}}]}}]}"""

    private val good = """{"title":"Mango Magic","hook":"Did you know?","introduction":"i","cta":"Follow for more","ending":"Bye",
      "scenes":[{"narration":"Did you know mangoes are full of vitamin C?","onScreenText":"Vitamin C","visualDescription":"mango","bRoll":"market"},
      {"narration":"They help digestion with natural fibre.","onScreenText":"Fibre","visualDescription":"","bRoll":""},
      {"narration":"Eat them fresh, not as sugary juice.","onScreenText":"Eat fresh","visualDescription":"","bRoll":""},
      {"narration":"Follow for more healthy food tips!","onScreenText":"Follow","visualDescription":"","bRoll":""}]}"""

    @Test fun parses_reply_into_valid_package_with_exact_duration() = runBlocking<Unit> {
        var sentKey = ""
        val g = GeminiScriptGenerator({ "KEY123" }, { _, key, _ -> sentKey = key; reply(good) }, { error("offline") })
        val p = g.generate(req)
        assertTrue(p.validation.errors.toString(), p.validation.isValid)
        assertEquals(4, p.scenes.size)
        assertEquals(60_000L, p.scenes.sumOf { it.durationMs })
        assertEquals("Mango Magic", p.title)
        assertEquals("scn_hook", p.scenes.first().sceneId)
        assertEquals("scn_outro", p.scenes.last().sceneId)
        assertTrue(p.metadata.generatorId.startsWith("gemini:"))
        assertEquals("KEY123", sentKey)
    }

    @Test fun json_wrapped_in_markdown_is_parsed() = runBlocking<Unit> {
        val g = GeminiScriptGenerator({ "K" }, { _, _, _ -> reply("```json\n$good\n```") }, { error("offline") })
        assertTrue(g.generate(req).validation.isValid)
    }

    @Test fun falls_back_to_next_model_then_offline() = runBlocking<Unit> {
        var calls = 0
        val g = GeminiScriptGenerator({ "K" }, { url, _, _ -> calls++; if (url.contains("gemini-2.0-flash")) reply(good) else throw IllegalStateException("HTTP 404") }, { error("offline") })
        assertTrue(g.generate(req).metadata.generatorId.endsWith("gemini-2.0-flash"))
        assertEquals(3, calls)

        var reason = ""
        val broken = GeminiScriptGenerator({ "K" }, { _, _, _ -> throw IllegalStateException("HTTP 429") }, { error("offline") })
        val f = FallbackScriptGenerator(broken, MockScriptGenerator()) { reason = it.message ?: "" }
        val p = f.generate(req)
        assertTrue(p.validation.isValid)
        assertEquals("mock", p.metadata.generatorId)
        assertTrue(reason.contains("429"))
    }

    @Test fun busy_model_is_retried_once() = runBlocking<Unit> {
        var calls = 0
        var pauses = 0
        val g = GeminiScriptGenerator({ "K" }, { url, _, _ ->
            calls++
            if (url.contains("gemini-flash-latest") && calls > 3) reply(good)
            else if (url.contains("gemini-flash-latest")) throw IllegalStateException("HTTP 503 This model is currently experiencing high demand")
            else throw IllegalStateException("HTTP 404 gone")
        }, { error("offline") }, { pauses++ })
        assertTrue(g.generate(req).metadata.generatorId.endsWith("gemini-flash-latest"))
        assertEquals(1, pauses)
        assertTrue(GeminiScriptGenerator.isBusy("HTTP 429 quota"))
        assertTrue(!GeminiScriptGenerator.isBusy("HTTP 404 gone"))
    }

    @Test fun slow_overloaded_service_stops_at_time_limit() = runBlocking<Unit> {
        var clock = 0L
        var calls = 0
        val g = GeminiScriptGenerator({ "K" }, { _, _, _ -> calls++; clock += 30_000L; throw IllegalStateException("HTTP 503 high demand") },
            { error("offline") }, { }, { clock }, 45_000L)
        val msg = runCatching { g.generate(req) }.exceptionOrNull()?.message.orEmpty()
        assertEquals(2, calls) // 0s -> 30s -> 60s: third call not started
        assertTrue(msg, msg.contains("time limit"))
    }

    @Test fun prompt_forbids_invented_facts() {
        val p = GeminiScriptGenerator({ "K" }, { _, _, _ -> "" }).buildPrompt(req, 60_000L, 5)
        assertTrue(p.contains("use ONLY facts stated in the source"))
        assertTrue(p.contains("at most 156 words")); assertTrue(p.contains("between 132 and 156 words"))
    }

    @Test fun missing_key_goes_offline() = runBlocking<Unit> {
        val f = FallbackScriptGenerator(GeminiScriptGenerator({ null }, { _, _, _ -> error("no call") }), MockScriptGenerator())
        assertEquals("mock", f.generate(req).metadata.generatorId)
    }

    @Test fun prompt_contains_topic_language_and_scene_count() {
        val g = GeminiScriptGenerator({ "K" })
        val prompt = g.buildPrompt(req.copy(languageCode = "bn"), 60_000L, 6)
        assertTrue(prompt.contains("Health benefits of mango"))
        assertTrue(prompt.contains("exactly 6 scenes"))
        assertTrue(prompt, prompt.contains("Bengali") || prompt.contains("বাংলা"))
    }

    @Test fun discovered_newest_stable_flash_model_is_tried_first() = runBlocking<Unit> {
        val list = """{"models":[
          {"name":"models/gemini-2.0-flash","supportedGenerationMethods":["generateContent"]},
          {"name":"models/gemini-3.8-flash","supportedGenerationMethods":["generateContent","countTokens"]},
          {"name":"models/gemini-3.8-flash-lite","supportedGenerationMethods":["generateContent"]},
          {"name":"models/gemini-4.0-flash-preview","supportedGenerationMethods":["generateContent"]},
          {"name":"models/gemini-3.8-flash-tts","supportedGenerationMethods":["generateContent"]},
          {"name":"models/text-embedding-004","supportedGenerationMethods":["embedContent"]}]}"""
        assertEquals("gemini-3.8-flash", GeminiScriptGenerator.rankModels(list).first())
        var used = ""
        val g = GeminiScriptGenerator({ "K" }, { url, _, _ -> used = url; reply(good) }, { list })
        g.generate(req)
        assertTrue(used, used.contains("gemini-3.8-flash:generateContent"))
    }

    @Test fun second_key_is_used_when_first_is_out_of_quota() = runBlocking<Unit> {
        val used = mutableListOf<String>()
        var worked = -1
        val g = GeminiScriptGenerator(
            apiKey = { "KEY_ONE" },
            http = { _, key, _ -> used += key; if (key == "KEY_ONE") throw IllegalStateException("HTTP 429 quota") else reply(good) },
            listModels = { error("offline") },
            retryPause = {},
            apiKeys = { listOf("KEY_ONE", "KEY_TWO") },
            onKeyWorked = { worked = it }
        )
        val pkg = g.generate(req)
        assertTrue(pkg.scenes.isNotEmpty())
        assertEquals("KEY_TWO", used.last())
        assertEquals(1, worked)
    }

    @Test fun rejected_key_skips_its_other_models() = runBlocking<Unit> {
        val used = mutableListOf<String>()
        val g = GeminiScriptGenerator(
            apiKey = { "BAD" },
            http = { _, key, _ -> used += key; if (key == "BAD") throw IllegalStateException("HTTP 403 forbidden") else reply(good) },
            listModels = { error("offline") },
            retryPause = {},
            apiKeys = { listOf("BAD", "GOOD") }
        )
        g.generate(req)
        assertEquals(listOf("BAD", "GOOD"), used)
    }

    @Test fun quota_exhausted_keys_are_paused_then_a_new_key_is_tried() = runBlocking<Unit> {
        var calls = 0
        var keys = listOf("K1")
        val g = GeminiScriptGenerator(
            apiKey = { "K1" },
            http = { _, key, _ -> calls++; if (key == "K1") throw IllegalStateException("HTTP 429 You exceeded your current quota") else reply(good) },
            listModels = { error("offline") },
            retryPause = {},
            apiKeys = { keys }
        )
        runCatching { g.generate(req) }
        val afterFirst = calls
        val second = runCatching { g.generate(req) }
        assertTrue(second.isFailure)
        assertEquals("paused: no new requests", afterFirst, calls)
        keys = listOf("K1", "K2")
        assertTrue(g.generate(req).scenes.isNotEmpty())
    }

    @Test fun quota_pause_survives_an_app_restart() = runBlocking<Unit> {
        var stored: String? = null
        var calls = 0
        fun make() = GeminiScriptGenerator(
            apiKey = { "K1" },
            http = { _, _, _ -> calls++; throw IllegalStateException("HTTP 429 You exceeded your current quota") },
            listModels = { error("offline") },
            retryPause = {},
            loadPause = { stored },
            savePause = { stored = it }
        )
        runCatching { make().generate(req) }
        assertTrue(stored != null)
        val before = calls
        assertTrue(runCatching { make().generate(req) }.isFailure) // new instance = app restarted
        assertEquals(before, calls)
    }
}
