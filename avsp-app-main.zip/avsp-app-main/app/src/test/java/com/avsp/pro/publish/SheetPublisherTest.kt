package com.avsp.pro.publish

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SheetPublisherTest {
    @Test fun onlyAppsScriptWebAppLinks() {
        assertTrue(SheetPublisher.isWebAppUrl("https://script.google.com/macros/s/AKfycbx_Ab-12/exec"))
        assertTrue(SheetPublisher.isWebAppUrl("https://script.google.com/a/example.com/macros/s/AKfy12/exec"))
        assertFalse(SheetPublisher.isWebAppUrl("https://script.google.com/macros/s/AKfy12/dev"))
        assertFalse(SheetPublisher.isWebAppUrl("http://evil.example/exec"))
    }

    @Test fun payloadCarriesVideoAndChoices() {
        val p = JSONObject(SheetPublisher.payload("tok", byteArrayOf(1, 2, 3), "v.mp4", null, "Proj", "Title", "Desc", listOf("#a"), listOf("YouTube", "Telegram"), 1_800_000_000_000))
        assertEquals("add", p.getString("action"))
        assertEquals("AQID", p.getString("video_b64"))
        assertEquals(2, p.getJSONArray("platforms").length())
        assertTrue(p.getString("schedule").startsWith("2027-01-15"))
        assertFalse(p.has("thumb_b64"))
        assertTrue(JSONObject(SheetPublisher.payload("t", byteArrayOf(1), "v", null, "", "", "", emptyList(), emptyList(), null)).isNull("schedule"))
    }

    @Test fun rowsFromSheet() {
        val rows = SheetPublisher.parseRows(JSONArray("""[{"ID":"a","Title":"T","Status":"Posted 09-Oct 19:00","Platforms":"YouTube","YouTube":"https://youtu.be/x","Views":120,"Likes":""}]"""))
        assertEquals(listOf("https://youtu.be/x"), rows.single().links)
        assertEquals(120L, rows.single().views)
        assertNull(rows.single().likes)
    }

    @Test fun scheduleChoicesAreInTheFuture() {
        val zone = java.time.ZoneId.of("Asia/Kolkata")
        val at = java.time.ZonedDateTime.of(2026, 10, 9, 20, 0, 0, 0, zone).toInstant().toEpochMilli()
        val o = SheetPublisher.scheduleOptions(at, zone)
        // P21.8: "Best time" comes first: 8 pm now -> tomorrow 7 pm.
        assertEquals("Best time (auto)", o.first().first)
        assertEquals(java.time.ZonedDateTime.of(2026, 10, 10, 19, 0, 0, 0, zone).toInstant().toEpochMilli(), o.first().second)
        assertEquals(null, o[1].second)
        assertFalse(o.any { it.first == "Today 7 PM" })   // already past 7 pm
        assertTrue(o.filter { it.second != null }.all { it.second!! > at })
    }

    @Test fun youtubeDetailsAreSentAndCategoryFollowsTheTopic() {
        val p = JSONObject(SheetPublisher.payload("t", byteArrayOf(1), "v", null, "", "", "", emptyList(), emptyList(), null,
            SheetPublisher.Extra(listOf("kharagpur", "railway"), "19", madeForKids = false, privacy = "unlisted", language = "bn")))
        assertEquals("19", p.getString("category")); assertEquals("unlisted", p.getString("privacy"))
        assertEquals(false, p.getBoolean("kids")); assertEquals(2, p.getJSONArray("tags").length()); assertEquals("bn", p.getString("language"))
        assertEquals("19", SheetPublisher.categoryFor("I am at Kharagpur railway platform"))
        assertEquals("26", SheetPublisher.categoryFor("Chicken soup recipe"))
        assertEquals("22", SheetPublisher.categoryFor("My birthday"))
    }

    @Test fun approveTickIsRead() {
        val rows = SheetPublisher.parseRows(JSONArray("""[{"ID":"a","Status":"Waiting approval","Approve":false},{"ID":"b","Status":"Approved","Approve":true,"Schedule":"2026-10-13T13:30:00.000Z"}]"""))
        assertFalse(rows[0].approved); assertTrue(rows[1].approved)
    }

    @Test fun todaySlotsAreTheRestOfTodaysGoodTimes() {
        val z = java.time.ZoneId.of("Asia/Kolkata")
        val tenAm = java.time.LocalDate.of(2026, 10, 13).atTime(10, 0).atZone(z).toInstant().toEpochMilli()
        val slots = SheetPublisher.todaySlots(5, tenAm, z).map { java.time.Instant.ofEpochMilli(it).atZone(z).toLocalTime().toString() }
        assertEquals(listOf("13:00", "18:00", "20:00", "22:00", "22:30"), slots)
    }
}
