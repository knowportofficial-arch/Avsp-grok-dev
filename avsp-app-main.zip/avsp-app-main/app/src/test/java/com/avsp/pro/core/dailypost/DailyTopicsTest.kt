package com.avsp.pro.core.dailypost

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class DailyTopicsTest {
    private val forecast = """{"current":{"temperature_2m":31.4,"relative_humidity_2m":78,"weather_code":2,"wind_speed_10m":11.6},
      "daily":{"weather_code":[63,80,1],"temperature_2m_max":[33.2,30.1,32.0],"temperature_2m_min":[25.6,24.9,25.0],
      "precipitation_probability_max":[75,40,5]}}"""

    @Test fun weather_report_reads_naturally() {
        val w = DailyTopics.weatherReport(forecast, "Kharagpur")
        assertEquals("Kharagpur weather: Rain, 33°C", w.title)
        assertTrue(w.text, w.text.startsWith("Weather today in Kharagpur: rain."))
        assertTrue(w.text, w.text.contains("31 degrees Celsius, with 78 percent humidity"))
        assertTrue(w.text, w.text.contains("Rain is very likely today, about 75 percent chance."))
        assertTrue(w.text, w.text.contains("Tomorrow: light showers, between 25 and 30 degrees."))
        assertTrue(w.text, w.text.endsWith("Carry an umbrella if you go out."))
        assertTrue("no symbols the voice would misread", !w.text.contains("°"))
    }

    @Test fun rashifal_is_stable_for_a_day_and_differs_by_sign() {
        val d = LocalDate.of(2026, 10, 9)
        assertEquals(DailyTopics.rashifal(d, 4), DailyTopics.rashifal(d, 4))
        assertTrue(DailyTopics.rashifal(d, 4).startsWith("Leo (Simha): "))
        assertTrue(DailyTopics.rashifal(d, 0) != DailyTopics.rashifal(d, 1))
        assertTrue(DailyTopics.rashifalAll(d).endsWith("just for fun and entertainment."))
        assertEquals(12, DailyTopics.SIGNS.size)
    }

    @Test fun jokes_trends_and_holidays_parse() {
        val jokes = DailyTopics.parseJokes("""{"error":false,"amount":2,"jokes":[{"joke":"I told my computer I needed a break, and it said no problem."},{"joke":"short"}]}""")
        assertEquals(1, jokes.size)
        val rss = """<rss><channel><item><title>Durga Puja 2026</title><ht:approx_traffic>200K+</ht:approx_traffic>
            <ht:news_item><ht:news_item_title><![CDATA[Pandals open across Kolkata &amp; Howrah]]></ht:news_item_title>
            <ht:news_item_snippet>Crowds gather</ht:news_item_snippet><ht:news_item_source>ABP</ht:news_item_source></ht:news_item></item></channel></rss>"""
        val t = DailyTopics.parseTrends(rss).single()
        assertEquals("Durga Puja 2026", t.title)
        assertEquals("200K+", t.traffic)
        assertEquals("Pandals open across Kolkata & Howrah", t.newsTitle)
        val h = DailyTopics.parseHolidays("""{"holidays":[{"text":"Christian feast day: Saint X","pages":[{"extract":"A saint."}]},
            {"text":"World Post Day","pages":[{"extract":"International day of the postal service."}]}]}""")
        assertEquals("World Post Day", DailyTopics.rankObservances(h).first().name)
    }

    @Test fun geocode_parses_first_result() {
        val c = DailyTopics.parseGeocode("""{"results":[{"name":"Kolkata","latitude":22.56,"longitude":88.36}]}""")!!
        assertEquals("Kolkata", c.name)
        assertEquals(88.36, c.lon, 0.001)
    }
}
