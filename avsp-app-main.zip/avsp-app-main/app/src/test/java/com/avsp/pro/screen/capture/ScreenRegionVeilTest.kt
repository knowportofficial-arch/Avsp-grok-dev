package com.avsp.pro.screen.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** P3: dialer pop-open animation must be covered between the two samples. */
class ScreenRegionVeilTest {
    private val name = PrivacyBox(0.25f, 0.30f, 0.75f, 0.33f)
    private val popup = PrivacyBox(0.10f, 0.20f, 0.90f, 0.60f)

    @Test fun popup_opening_over_contact_is_covered_between_samples() {
        val veils = ScreenPrivacyTracker.regionVeils(
            times = listOf(0L, 200L, 400L),
            changed = { a, _ -> if (a == 0L) popup else null },
            boxesAt = { if (it >= 200L) listOf(name) else emptyList() },
            maxWindowMs = 400L
        )
        assertEquals(1, veils.size)
        val v = veils.single()
        assertEquals(0L, v.startMs); assertEquals(200L, v.endMs)
        val b = v.box!!
        assertTrue(b.left <= popup.left && b.right >= popup.right && b.top <= popup.top && b.bottom >= popup.bottom)

        val plan = ScreenPrivacyPlan(emptyList(), listOf(0L, 200L, 400L), 1000L, veils = veils)
        assertEquals(1, plan.boxesAt(100L).size)
        assertEquals(0, plan.boxesAt(300L).size)
        assertTrue(!plan.veilAt(100L)) // not a whole-frame veil
    }

    @Test fun change_far_from_sensitive_text_or_tiny_is_ignored() {
        val far = ScreenPrivacyTracker.regionVeils(
            listOf(0L, 200L), { _, _ -> PrivacyBox(0.1f, 0.8f, 0.9f, 0.95f) }, { listOf(name) }, 400L
        )
        assertTrue(far.isEmpty())
        val tiny = ScreenPrivacyTracker.regionVeils(
            listOf(0L, 200L), { _, _ -> PrivacyBox(0.3f, 0.3f, 0.35f, 0.33f) }, { listOf(name) }, 400L
        )
        assertTrue(tiny.isEmpty())
        val slow = ScreenPrivacyTracker.regionVeils(listOf(0L, 1000L), { _, _ -> popup }, { listOf(name) }, 400L)
        assertTrue(slow.isEmpty())
    }
}
