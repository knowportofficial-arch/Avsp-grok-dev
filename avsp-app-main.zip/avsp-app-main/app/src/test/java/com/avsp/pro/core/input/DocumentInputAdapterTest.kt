﻿package com.avsp.pro.core.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class DocumentInputAdapterTest {

    @Test
    fun pdfMimeIsClassifiedAsPdf() {
        val result = DocumentInputAdapter.adapt(
            locator = "content://documents/101",
            displayName = "report.pdf",
            mimeType = "application/pdf"
        )

        assertNotNull(result)
        assertEquals(
            DocumentInputAdapter.DocumentInputKind.PDF,
            result!!.kind
        )
        assertEquals(
            UnifiedInputType.PDF_DOCUMENT,
            result.input.type
        )
    }

    @Test
    fun pdfExtensionIsClassifiedAsPdf() {
        val result = DocumentInputAdapter.adapt(
            locator = "/storage/emulated/0/Download/report.pdf",
            displayName = "report.pdf"
        )

        assertNotNull(result)
        assertEquals(
            UnifiedInputType.PDF_DOCUMENT,
            result!!.input.type
        )
    }

    @Test
    fun contentUriIsPreserved() {
        val locator =
            "content://com.android.providers.downloads.documents/document/42"

        val result = DocumentInputAdapter.adapt(
            locator = locator,
            displayName = "report.pdf",
            mimeType = "application/pdf"
        )

        assertNotNull(result)
        assertEquals(locator, result!!.input.locator)
    }

    @Test
    fun docxIsClassifiedAsDocument() {
        val result = DocumentInputAdapter.adapt(
            locator = "/storage/emulated/0/Documents/story.docx",
            displayName = "story.docx",
            mimeType =
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )

        assertNotNull(result)
        assertEquals(
            DocumentInputAdapter.DocumentInputKind.DOCUMENT,
            result!!.kind
        )
        assertEquals(
            UnifiedInputType.DOCUMENT,
            result.input.type
        )
    }

    @Test
    fun textMimeIsClassifiedAsDocument() {
        val result = DocumentInputAdapter.adapt(
            locator = "content://documents/202",
            displayName = "notes.txt",
            mimeType = "text/plain"
        )

        assertNotNull(result)
        assertEquals(
            UnifiedInputType.DOCUMENT,
            result!!.input.type
        )
    }

    @Test
    fun metadataIdentifiesM14() {
        val result = DocumentInputAdapter.adapt(
            locator = "content://documents/303",
            displayName = "report.pdf",
            mimeType = "application/pdf"
        )

        assertNotNull(result)
        assertEquals("M14", result!!.input.metadata["adapter"])
        assertEquals(
            "PDF",
            result.input.metadata["documentInputKind"]
        )
    }

    @Test
    fun queryAndFragmentDoNotBreakPdfExtension() {
        val result = DocumentInputAdapter.adapt(
            locator =
                "/storage/emulated/0/Download/report.pdf?download=1#page=2"
        )

        assertNotNull(result)
        assertEquals(
            UnifiedInputType.PDF_DOCUMENT,
            result!!.input.type
        )
    }

    @Test
    fun nonDocumentInputIsRejected() {
        val result = DocumentInputAdapter.adapt(
            locator = "content://media/external/video/404",
            displayName = "video.mp4",
            mimeType = "video/mp4"
        )

        assertNull(result)
    }

    @Test
    fun emptyLocatorIsRejected() {
        val result = DocumentInputAdapter.adapt(
            locator = "   ",
            displayName = "report.pdf",
            mimeType = "application/pdf"
        )

        assertNull(result)
    }
}
