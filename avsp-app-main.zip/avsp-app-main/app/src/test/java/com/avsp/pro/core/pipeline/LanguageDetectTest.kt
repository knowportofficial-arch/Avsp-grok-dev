package com.avsp.pro.core.pipeline

import com.avsp.pro.core.model.ProjectLanguage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class LanguageDetectTest {
    @Test fun textLanguageIsFoundFromItsLetters() {
        assertEquals(ProjectLanguage.BENGALI, ProjectLanguage.detect("আজ কলকাতায় দুর্গাপুজোর প্রস্তুতি চলছে।"))
        assertEquals(ProjectLanguage.HINDI, ProjectLanguage.detect("आज दिल्ली में बारिश होगी"))
        assertEquals(ProjectLanguage.ENGLISH, ProjectLanguage.detect("Easy chicken curry recipe"))
        assertEquals(ProjectLanguage.BENGALI, ProjectLanguage.detect("IIT Kharagpur এর প্রধান গেট আর ক্যাম্পাসের সকাল"))
        assertNull(ProjectLanguage.detect("123 456"))
    }
}
