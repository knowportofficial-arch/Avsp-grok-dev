﻿package com.avsp.pro.m9

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class M9AuthenticationCoordinatorTest {

    private fun youtubeConfiguration(): M9ProviderAuthConfiguration {
        return M9ProviderAuthConfiguration(
            providerId = "YOUTUBE",
            protocol = M9AuthProtocol.OAUTH2,
            clientId = "test-client",
            redirectUri = "https://example.com/oauth/callback",
            scopes = setOf("upload")
        )
    }

    @Test
    fun validOAuthConfigurationWithoutCredentialIsReadyForAuth() {
        val store = M9InMemoryCredentialStore()

        val result =
            M9AuthenticationCoordinator.resolve(
                youtubeConfiguration(),
                store
            )

        assertEquals(
            M9AuthReadiness.READY_FOR_AUTH,
            result.readiness
        )

        assertFalse(
            result.credentialPresent
        )
    }

    @Test
    fun storedOAuthAccessTokenProducesAuthenticatedState() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey(
                "YOUTUBE",
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            "opaque-test-token"
        )

        val result =
            M9AuthenticationCoordinator.resolve(
                youtubeConfiguration(),
                store
            )

        assertEquals(
            M9AuthReadiness.AUTHENTICATED,
            result.readiness
        )

        assertTrue(
            result.credentialPresent
        )
    }

    @Test
    fun refreshTokenAloneDoesNotClaimAuthenticatedAccessTokenState() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey(
                "YOUTUBE",
                M9CredentialType.OAUTH_REFRESH_TOKEN
            ),
            "opaque-refresh-token"
        )

        val result =
            M9AuthenticationCoordinator.resolve(
                youtubeConfiguration(),
                store
            )

        assertEquals(
            M9AuthReadiness.READY_FOR_AUTH,
            result.readiness
        )

        assertFalse(
            result.credentialPresent
        )
    }

    @Test
    fun apiKeyCredentialProducesAuthenticatedState() {
        val store = M9InMemoryCredentialStore()

        val configuration =
            M9ProviderAuthConfiguration(
                providerId = "WEB",
                protocol = M9AuthProtocol.API_KEY
            )

        store.put(
            M9CredentialKey(
                "WEB",
                M9CredentialType.API_KEY
            ),
            "opaque-api-key"
        )

        val result =
            M9AuthenticationCoordinator.resolve(
                configuration,
                store
            )

        assertEquals(
            M9AuthReadiness.AUTHENTICATED,
            result.readiness
        )

        assertTrue(
            result.credentialPresent
        )
    }

    @Test
    fun apiKeyWithoutCredentialIsReadyForAuth() {
        val store = M9InMemoryCredentialStore()

        val configuration =
            M9ProviderAuthConfiguration(
                providerId = "WEB",
                protocol = M9AuthProtocol.API_KEY
            )

        val result =
            M9AuthenticationCoordinator.resolve(
                configuration,
                store
            )

        assertEquals(
            M9AuthReadiness.READY_FOR_AUTH,
            result.readiness
        )

        assertFalse(
            result.credentialPresent
        )
    }

    @Test
    fun invalidOAuthConfigurationRemainsInvalid() {
        val store = M9InMemoryCredentialStore()

        val configuration =
            M9ProviderAuthConfiguration(
                providerId = "YOUTUBE",
                protocol = M9AuthProtocol.OAUTH2,
                clientId = "",
                redirectUri = "https://example.com/oauth/callback",
                scopes = setOf("upload")
            )

        val result =
            M9AuthenticationCoordinator.resolve(
                configuration,
                store
            )

        assertEquals(
            M9AuthReadiness.CONFIGURATION_REQUIRED,
            result.readiness
        )

        assertFalse(
            result.credentialPresent
        )
    }

    @Test
    fun disabledProviderCannotBecomeAuthenticatedFromStoredCredential() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey(
                "YOUTUBE",
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            "opaque-test-token"
        )

        val configuration =
            youtubeConfiguration().copy(
                enabled = false
            )

        val result =
            M9AuthenticationCoordinator.resolve(
                configuration,
                store
            )

        assertEquals(
            M9AuthReadiness.CONFIGURATION_REQUIRED,
            result.readiness
        )

        assertFalse(
            result.credentialPresent
        )
    }

    @Test
    fun noAuthProviderDoesNotNeedCredential() {
        val store = M9InMemoryCredentialStore()

        val configuration =
            M9ProviderAuthConfiguration(
                providerId = "WEB",
                protocol = M9AuthProtocol.NONE
            )

        val result =
            M9AuthenticationCoordinator.resolve(
                configuration,
                store
            )

        assertEquals(
            M9AuthReadiness.NOT_REQUIRED,
            result.readiness
        )

        assertFalse(
            result.credentialPresent
        )
    }

    @Test
    fun resultDoesNotExposeCredentialValue() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey(
                "YOUTUBE",
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            "SUPER_SECRET_TOKEN"
        )

        val result =
            M9AuthenticationCoordinator.resolve(
                youtubeConfiguration(),
                store
            )

        val rendered = result.toString()

        assertFalse(
            rendered.contains("SUPER_SECRET_TOKEN")
        )

        assertTrue(
            result.credentialPresent
        )
    }

    @Test
    fun providerIdentityIsPreserved() {
        val store = M9InMemoryCredentialStore()

        val result =
            M9AuthenticationCoordinator.resolve(
                youtubeConfiguration(),
                store
            )

        assertEquals(
            "YOUTUBE",
            result.providerId
        )

        assertEquals(
            M9AuthProtocol.OAUTH2,
            result.protocol
        )
    }
}
