package com.avsp.pro.audio.voice

import com.avsp.pro.audio.engine.TtsEngine
import com.avsp.pro.audio.engine.TtsProviderMode
import com.avsp.pro.audio.engine.TtsSynthesisRequest
import com.avsp.pro.audio.engine.TtsSynthesisResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class VoiceCatalogManualSelectionTest {

    @Test
    fun realEngineCatalogIsPreferred() {
        val engine = FakeEngine(
            listOf(
                VoiceProfile(
                    id = "bn-real",
                    providerId = "fake",
                    displayName = "Bengali Real",
                    languageCodes = setOf("bn"),
                    qualityScore = 0.90f
                )
            )
        )

        val catalog = VoiceIntelligenceCatalog.catalogFor(engine)

        assertEquals(listOf("bn-real"), catalog.map { it.id })
    }

    @Test
    fun manualVoiceSelectionIsExplicitAndDeterministic() {
        val voices = listOf(
            VoiceProfile("voice-a", "fake", "A", setOf("bn"), qualityScore = 1.0f),
            VoiceProfile("voice-b", "fake", "B", setOf("bn"), qualityScore = 0.1f)
        )

        val result = BestFitVoiceSelector.select(
            VoiceSelectionRequest(
                language = "bn",
                preferredVoiceId = "voice-b"
            ),
            voices
        )

        assertEquals("voice-b", result.selected.id)
        assertFalse(result.automatic)
    }

    private class FakeEngine(
        private val catalog: List<VoiceProfile>
    ) : TtsEngine {
        override val providerId: String = "fake"
        override val displayName: String = "Fake"
        override val mode: TtsProviderMode = TtsProviderMode.MOCK

        override fun isAvailable(): Boolean = true
        override fun supportedLanguages(): Set<String> = setOf("bn")
        override fun voices(): List<VoiceProfile> = catalog
        override fun supportsLanguage(languageCode: String): Boolean =
            languageCode.equals("bn", ignoreCase = true)

        override suspend fun synthesize(request: TtsSynthesisRequest): TtsSynthesisResult {
            error("Not used in catalog tests")
        }
    }
}