package com.avsp.pro.core.pipeline

import com.avsp.pro.script.contract.DurationRequest
import com.avsp.pro.script.contract.ScriptGenerationRequest
import com.avsp.pro.script.generator.SmartOfflineScriptGenerator
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class CtaRuleTest {
    private val script = runBlocking {
        SmartOfflineScriptGenerator().generate(
            ScriptGenerationRequest("p", "Monsoon reaches Kerala\nThe monsoon reached Kerala on Monday. Heavy rain is expected for three days. Schools in two districts are closed.", "en", DurationRequest.Explicit(30_000L))
        )
    }

    @Test fun offline_cta_is_already_short() {
        assertTrue(CtaRule.isShort(script.scenes.maxByOrNull { it.order }!!.narration))
        assertSame(script, CtaRule.apply(script, "en"))
    }

    @Test fun long_ai_cta_is_replaced_with_a_three_second_one() {
        val last = script.scenes.maxByOrNull { it.order }!!
        val long = script.copy(scenes = script.scenes.map {
            if (it.sceneId == last.sceneId) it.copy(narration = "If you liked this video please follow our channel for more updates like this every day") else it
        })
        val fixed = CtaRule.apply(long, "bn")
        assertEquals("লাইক, শেয়ার আর ফলো করুন!", fixed.scenes.first { it.sceneId == last.sceneId }.narration)
        assertEquals(long.scenes.size, fixed.scenes.size)
    }
}
