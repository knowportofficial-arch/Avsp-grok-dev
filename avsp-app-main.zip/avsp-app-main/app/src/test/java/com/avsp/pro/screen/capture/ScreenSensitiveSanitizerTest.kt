﻿package com.avsp.pro.screen.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScreenSensitiveSanitizerTest {

    @Test
    fun aadhaar_keeps_only_last_four() {

        val input =
            "Aadhaar: 1234 5678 9012"

        val output =
            ScreenSensitiveSanitizer.sanitize(input)

        assertEquals(
            "Aadhaar: XXXX XXXX 9012",
            output
        )

        assertFalse(output.contains("1234"))
        assertFalse(output.contains("5678"))
    }

    @Test
    fun otp_is_removed_before_script() {

        val input =
            "949147 is the OTP for login at BSNL COS"

        val output =
            ScreenSensitiveSanitizer.sanitize(input)

        assertTrue(output.contains("[OTP]"))
        assertFalse(output.contains("949147"))
    }

    @Test
    fun labelled_name_is_partially_masked() {

        val input =
            "Name: Rahul Kumar"

        val output =
            ScreenSensitiveSanitizer.sanitize(input)

        assertEquals(
            "Name: R*** K***",
            output
        )
    }

    @Test
    fun email_is_masked() {

        val input =
            "Email: person@example.com"

        val output =
            ScreenSensitiveSanitizer.sanitize(input)

        assertFalse(
            output.contains("person@example.com")
        )

        assertTrue(
            output.contains("***@example.com")
        )
    }

    @Test
    fun ordinary_text_is_not_changed() {

        val input =
            "Open the BSNL application and select Login."

        assertEquals(
            input,
            ScreenSensitiveSanitizer.sanitize(input)
        )
    }
}
