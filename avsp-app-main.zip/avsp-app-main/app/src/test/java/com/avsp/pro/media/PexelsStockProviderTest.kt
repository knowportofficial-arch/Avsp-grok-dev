package com.avsp.pro.media

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PexelsStockProviderTest {
    private val reply = """{"videos":[
      {"id":1,"duration":12,"video_files":[
        {"file_type":"video/mp4","width":1920,"height":1080,"link":"https://x/land.mp4"}]},
      {"id":2,"duration":9,"video_files":[
        {"file_type":"video/mp4","width":2160,"height":3840,"link":"https://x/4k.mp4"},
        {"file_type":"video/mp4","width":540,"height":960,"link":"https://x/sd.mp4"},
        {"file_type":"video/mp4","width":1080,"height":1920,"link":"https://x/hd.mp4"}]}]}"""

    @Test fun picks_largest_portrait_clip_up_to_1080() {
        val p = PexelsStockProvider({ "k" }, { _, _ -> reply })
        val c = p.search("mango", portrait = true)!!
        assertEquals("https://x/hd.mp4", c.url)
        assertEquals(2L, c.id)
    }

    @Test fun landscape_request_gets_landscape_clip() {
        val p = PexelsStockProvider({ "k" }, { _, _ -> reply })
        assertEquals("https://x/land.mp4", p.search("mango", portrait = false)!!.url)
    }

    @Test fun no_key_means_no_request() {
        val p = PexelsStockProvider({ null }, { _, _ -> error("must not call") })
        assertNull(p.search("mango", true))
    }

    @Test fun turned_down_clip_is_skipped() {
        val p = PexelsStockProvider({ "k" }, { _, _ -> reply })
        assertNull(p.search("mango", portrait = true, skip = setOf("2")))
        assertEquals(1L, p.search("mango", portrait = false, skip = setOf("2"))!!.id)
    }
}
