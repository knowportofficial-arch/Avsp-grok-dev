package com.avsp.pro.media

import com.avsp.pro.settings.KeyProviders
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KeyedPhotoProviderTest {
    @Test fun pixabayAndUnsplashRepliesBecomeCreditedPictures() {
        val px = KeyedPhotoProvider.parsePixabay("""{"hits":[{"id":7,"largeImageURL":"https://pixabay.com/a.jpg","imageWidth":1920,"imageHeight":2880,"user":"Ravi"}]}""")
        assertEquals("pixabay:7", px.single().id)
        assertEquals("Ravi / Pixabay (Pixabay License)", px.single().credit)
        val un = KeyedPhotoProvider.parseUnsplash("""{"results":[{"id":"ab","width":3000,"height":4000,"urls":{"regular":"https://images.unsplash.com/x"},"user":{"name":"Mia"}}]}""")
        assertEquals("Photo by Mia on Unsplash (Unsplash License)", un.single().credit)
    }

    @Test fun keysPastedInTheWrongBoxAreCaught() {
        val gemini = KeyProviders.byId(com.avsp.pro.settings.SecureConfigKeys.AI_API)
        val pixabay = KeyProviders.byId(KeyProviders.PIXABAY)
        assertTrue(gemini.looksRight("AIzaSyA1234567890abcdefghijklmnopqrstu"))
        assertFalse(gemini.looksRight("12345678-abcdef0123456789abcdef01"))
        assertTrue(pixabay.looksRight("12345678-abcdef0123456789abcdef01"))
        assertFalse(pixabay.looksRight("AIzaSyA1234567890abcdefghijklmnopqrstu"))
        assertEquals("✓ Working", KeyProviders.verdict(200))
        assertTrue(KeyProviders.verdict(429).contains("quota"))
    }

    @Test fun pixabayVideosBecomeClipsInThePhonesShape() {
        val raw = """{"hits":[
          {"id":1,"duration":12,"user":"Ana","videos":{"medium":{"url":"https://cdn.pixabay.com/a.mp4","width":1920,"height":1080,"size":9000000}}},
          {"id":2,"duration":9,"user":"Raj","videos":{"medium":{"url":"https://cdn.pixabay.com/b.mp4","width":1080,"height":1920,"size":8000000}}},
          {"id":3,"duration":240,"videos":{"medium":{"url":"https://cdn.pixabay.com/c.mp4","width":1080,"height":1920,"size":8000000}}}
        ]}"""
        val clips = KeyedPhotoProvider.parsePixabayVideos(raw, portrait = true)
        assertEquals(listOf("pixabay-video:2", "pixabay-video:1"), clips.map { it.id })
        assertEquals("Raj / Pixabay (Pixabay License)", clips.first().credit)
    }
}
