package com.avsp.pro.media

import com.avsp.pro.media.FreeMusicProvider.Mood
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FreeMusicProviderTest {
    @Test fun moodFollowsTheTopic() {
        assertEquals(Mood.CALM, FreeMusicProvider.mood("Drinking enough water keeps the body healthy"))
        assertEquals(Mood.FUN, FreeMusicProvider.mood("Today's funny jokes"))
        assertEquals(Mood.SPIRITUAL, FreeMusicProvider.mood("আজকের রাশিফল"))
        assertEquals(Mood.NEWS, FreeMusicProvider.mood("Flood in Assam: news update"))
        assertEquals(Mood.UPBEAT, FreeMusicProvider.mood("Best street food in Kolkata"))
    }

    @Test fun parseKeepsFreeDownloadableTracksInstrumentalFirst() {
        val raw = """{"results":[
          {"id":"a1","title":"Sunny Song (feat. Ana)","creator":"X","license":"by","source":"jamendo","url":"https://h/a.mp3","duration":150000,"filesize":3000000},
          {"id":"b2","title":"Morning Walk","creator":"Y","license":"by","source":"jamendo","url":"https://h/b.mp3","duration":180000},
          {"id":"c3","title":"Too big","creator":"Z","license":"cc0","source":"freesound","url":"https://h/c.mp3","duration":180000,"filesize":90000000},
          {"id":"d4","title":"NC track","creator":"Q","license":"by-nc","source":"jamendo","url":"https://h/d.mp3","duration":180000},
          {"id":"e5","title":"Blip","creator":"Q","license":"cc0","source":"freesound","url":"https://h/e.mp3","duration":4000}
        ]}"""
        val t = FreeMusicProvider.parse(raw)
        assertEquals(listOf("b2", "a1"), t.map { it.id })
        assertTrue(t.first().credit.contains("Morning Walk") && t.first().credit.contains("CC BY 4.0"))
    }

    @Test fun lighterJamendoCopyAndCache() {
        assertEquals("https://prod-1.storage.jamendo.com/?trackid=1&format=mp31", FreeMusicProvider.lighter("https://prod-1.storage.jamendo.com/?trackid=1&format=mp32"))
        assertEquals("https://x/a.mp3", FreeMusicProvider.lighter("https://x/a.mp3"))
        val dir = java.nio.file.Files.createTempDirectory("m").toFile()
        java.io.File(dir, "ov_a.mp3").writeBytes(ByteArray(60_000))
        assertEquals(null, FreeMusicProvider.cached(dir)) // no credit yet = not finished
        java.io.File(dir, "ov_a.mp3.credit.txt").writeText("Music: x")
        assertEquals("Music: x", FreeMusicProvider.cached(dir)?.second)
    }
}
