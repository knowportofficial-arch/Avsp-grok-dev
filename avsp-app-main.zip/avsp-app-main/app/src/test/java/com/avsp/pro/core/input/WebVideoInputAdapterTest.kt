﻿package com.avsp.pro.core.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class WebVideoInputAdapterTest {

    @Test
    fun youtubeWatchUrlBecomesYoutubeInput() {
        val result = WebVideoInputAdapter.adapt(
            "https://www.youtube.com/watch?v=test123"
        )

        assertNotNull(result)
        assertEquals(
            WebVideoInputAdapter.WebInputKind.YOUTUBE,
            result?.kind
        )
        assertEquals(
            UnifiedInputType.YOUTUBE,
            result?.input?.type
        )
    }

    @Test
    fun youtubeShortUrlBecomesYoutubeInput() {
        val result = WebVideoInputAdapter.adapt(
            "https://youtu.be/test123"
        )

        assertNotNull(result)
        assertEquals(
            UnifiedInputType.YOUTUBE,
            result?.input?.type
        )
    }

    @Test
    fun genericUrlBecomesUrlInput() {
        val result = WebVideoInputAdapter.adapt(
            "https://example.com/article"
        )

        assertNotNull(result)
        assertEquals(
            WebVideoInputAdapter.WebInputKind.URL,
            result?.kind
        )
        assertEquals(
            UnifiedInputType.URL,
            result?.input?.type
        )
    }

    @Test
    fun httpUrlIsAccepted() {
        val result = WebVideoInputAdapter.adapt(
            "http://example.com/test"
        )

        assertNotNull(result)
        assertEquals(
            UnifiedInputType.URL,
            result?.input?.type
        )
    }

    @Test
    fun nonHttpLocatorIsRejected() {
        val result = WebVideoInputAdapter.adapt(
            "/storage/emulated/0/video.mp4"
        )

        assertNull(result)
    }

    @Test
    fun metadataIdentifiesM12Adapter() {
        val result = WebVideoInputAdapter.adapt(
            "https://youtu.be/test123"
        )

        assertEquals(
            "M12",
            result?.input?.metadata?.get("adapter")
        )
        assertTrue(
            !result?.input?.id.isNullOrBlank()
        )
    }

    @Test
    fun originalUrlIsPreserved() {
        val source = "https://example.com/article?id=123"

        val result = WebVideoInputAdapter.adapt(source)

        assertEquals(
            source,
            result?.input?.locator
        )
    }
}
