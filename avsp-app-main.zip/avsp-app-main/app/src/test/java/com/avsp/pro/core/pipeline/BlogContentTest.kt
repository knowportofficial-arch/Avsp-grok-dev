package com.avsp.pro.core.pipeline

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BlogContentTest {
    private val scenes = listOf(
        BlogContent.SceneText("Kharagpur Book Fair 2026. Here is what you need to know.", "Kharagpur Book Fair 2026"),
        BlogContent.SceneText("The annual book fair opens on 15 November at the town hall .", "Opens 15 November"),
        BlogContent.SceneText("More than 120 publishers will take part this year.", "120 publishers"),
        BlogContent.SceneText("Entry is free for students.", "Free for students"),
        BlogContent.SceneText("Like, share and follow!", "Like, share and follow")
    )
    private val source = "Kharagpur Book Fair 2026\nThe annual book fair opens on 15 November at the town hall. " +
        "More than 120 publishers will take part this year. Entry is free for students. " +
        "A children's corner with story sessions runs every evening."

    @Test fun sections_follow_the_script_and_extra_source_facts_become_key_facts() {
        val blog = BlogContent.build("Kharagpur Book Fair 2026", scenes, source, "Like, share and follow!", pictureCount = 2)
        assertEquals("filler hook is not used as intro", "The annual book fair opens on 15 November at the town hall.", blog.sections.first().body)
        assertEquals(3, blog.sections.size)
        assertEquals(listOf(0, 1, null), blog.sections.map { it.pictureIndex })
        assertTrue(blog.keyFacts.toString(), blog.keyFacts.any { it.contains("children's corner") })
        assertFalse("facts already in sections are not repeated", blog.keyFacts.any { it.contains("120 publishers") })
        assertTrue(blog.markdown().startsWith("# Kharagpur Book Fair 2026\n"))
    }

    @Test fun html_is_self_contained_and_escaped() {
        val blog = BlogContent.build("Tea & <Toast>", scenes, source, "Follow!", pictureCount = 1, credits = listOf("Ann · CC BY"))
        val html = BlogContent.html(blog, listOf(byteArrayOf(1, 2, 3)))
        assertTrue(html.contains("<title>Tea &amp; &lt;Toast&gt;</title>"))
        assertTrue(html.contains("data:image/jpeg;base64,AQID"))
        assertTrue(html.contains("Pictures: Ann · CC BY"))
        assertFalse(html.contains("http"))
    }
}
