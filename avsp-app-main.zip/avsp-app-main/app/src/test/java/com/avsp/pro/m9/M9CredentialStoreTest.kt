﻿package com.avsp.pro.m9

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class M9CredentialStoreTest {

    @Test
    fun storesAndRetrievesOpaqueCredential() {
        val store = M9InMemoryCredentialStore()
        val key = M9CredentialKey("YOUTUBE", M9CredentialType.OAUTH_ACCESS_TOKEN)

        store.put(key, "secret-access-token")

        assertTrue(store.contains(key))
        assertEquals("secret-access-token", store.get(key))
    }

    @Test
    fun missingCredentialReturnsNull() {
        val store = M9InMemoryCredentialStore()
        val key = M9CredentialKey("FACEBOOK", M9CredentialType.OAUTH_ACCESS_TOKEN)

        assertNull(store.get(key))
        assertFalse(store.contains(key))
    }

    @Test
    fun presenceReportsCredentialTypes() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey("YOUTUBE", M9CredentialType.OAUTH_ACCESS_TOKEN),
            "access"
        )
        store.put(
            M9CredentialKey("YOUTUBE", M9CredentialType.OAUTH_REFRESH_TOKEN),
            "refresh"
        )

        val presence = store.presence("YOUTUBE")

        assertTrue(presence.accessTokenPresent)
        assertTrue(presence.refreshTokenPresent)
        assertFalse(presence.apiKeyPresent)
    }

    @Test
    fun removeDeletesSelectedCredential() {
        val store = M9InMemoryCredentialStore()
        val key = M9CredentialKey("YOUTUBE", M9CredentialType.OAUTH_ACCESS_TOKEN)

        store.put(key, "access")
        store.remove(key)

        assertFalse(store.contains(key))
        assertNull(store.get(key))
    }

    @Test
    fun clearProviderRemovesProviderCredentials() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey("YOUTUBE", M9CredentialType.OAUTH_ACCESS_TOKEN),
            "access"
        )
        store.put(
            M9CredentialKey("YOUTUBE", M9CredentialType.OAUTH_REFRESH_TOKEN),
            "refresh"
        )

        M9CredentialBoundary.clearProvider(store, "YOUTUBE")

        val presence = store.presence("YOUTUBE")

        assertFalse(presence.accessTokenPresent)
        assertFalse(presence.refreshTokenPresent)
    }

    @Test
    fun blankProviderIsRejected() {
        val store = M9InMemoryCredentialStore()
        var rejected = false

        try {
            store.put(
                M9CredentialKey("   ", M9CredentialType.API_KEY),
                "secret"
            )
        } catch (_: IllegalArgumentException) {
            rejected = true
        }

        assertTrue(rejected)
    }

    @Test
    fun emptySecretIsRejected() {
        val store = M9InMemoryCredentialStore()
        var rejected = false

        try {
            store.put(
                M9CredentialKey("WEB", M9CredentialType.API_KEY),
                ""
            )
        } catch (_: IllegalArgumentException) {
            rejected = true
        }

        assertTrue(rejected)
    }

    @Test
    fun presenceDoesNotContainSecretValue() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey("YOUTUBE", M9CredentialType.OAUTH_ACCESS_TOKEN),
            "VERY_SECRET_TOKEN"
        )

        val presence = M9CredentialBoundary.presence(store, "YOUTUBE")

        assertTrue(presence.accessTokenPresent)
        assertFalse(presence.toString().contains("VERY_SECRET_TOKEN"))
    }
}
