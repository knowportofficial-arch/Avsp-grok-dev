﻿package com.avsp.pro.m9

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class M9PublishingPreflightTest {

    private fun video(): File {
        return File.createTempFile(
            "avsp_m98_test_",
            ".mp4"
        ).apply {
            writeBytes(byteArrayOf(1, 2, 3, 4))
            deleteOnExit()
        }
    }

    private fun job(
        platforms: Set<M9Platform>
    ): M9Job {
        return M9Job(
            projectId = "m98-project",
            videoPath = video().absolutePath,
            title = "M9.8 Test",
            platforms = platforms,
            status = M9Status.READY
        )
    }

    private fun youtubeConfig(): M9ProviderAuthConfiguration {
        return M9ProviderAuthConfiguration(
            providerId = "YOUTUBE",
            protocol = M9AuthProtocol.OAUTH2,
            clientId = "test-client",
            redirectUri = "https://example.com/oauth/callback",
            scopes = setOf("upload")
        )
    }

    @Test
    fun authenticatedYoutubeIsReady() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey(
                "YOUTUBE",
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            "opaque-token"
        )

        val result =
            M9PublishingPreflight.evaluate(
                job(setOf(M9Platform.YOUTUBE)),
                mapOf("YOUTUBE" to youtubeConfig()),
                store
            )

        assertEquals(
            M9PreflightStatus.READY,
            result.status
        )

        assertTrue(
            result.readyPlatforms.contains(M9Platform.YOUTUBE)
        )

        assertTrue(
            result.blockedPlatforms.isEmpty()
        )
    }

    @Test
    fun missingYoutubeAuthenticationIsBlocked() {
        val result =
            M9PublishingPreflight.evaluate(
                job(setOf(M9Platform.YOUTUBE)),
                mapOf("YOUTUBE" to youtubeConfig()),
                M9InMemoryCredentialStore()
            )

        assertEquals(
            M9PreflightStatus.AUTHENTICATION_REQUIRED,
            result.status
        )

        assertTrue(
            result.blockedPlatforms.contains(M9Platform.YOUTUBE)
        )
    }

    @Test
    fun missingConfigurationIsBlocked() {
        val result =
            M9PublishingPreflight.evaluate(
                job(setOf(M9Platform.YOUTUBE)),
                emptyMap(),
                M9InMemoryCredentialStore()
            )

        assertEquals(
            M9PreflightStatus.CONFIGURATION_REQUIRED,
            result.status
        )
    }

    @Test
    fun multiplePlatformsAreEvaluatedIndependently() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey(
                "YOUTUBE",
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            "youtube-token"
        )

        val facebook =
            M9ProviderAuthConfiguration(
                providerId = "FACEBOOK",
                protocol = M9AuthProtocol.OAUTH2,
                clientId = "facebook-client",
                redirectUri = "https://example.com/facebook/callback",
                scopes = setOf("publish")
            )

        val result =
            M9PublishingPreflight.evaluate(
                job(
                    setOf(
                        M9Platform.YOUTUBE,
                        M9Platform.FACEBOOK
                    )
                ),
                mapOf(
                    "YOUTUBE" to youtubeConfig(),
                    "FACEBOOK" to facebook
                ),
                store
            )

        assertEquals(
            M9PreflightStatus.AUTHENTICATION_REQUIRED,
            result.status
        )

        assertTrue(
            result.readyPlatforms.contains(M9Platform.YOUTUBE)
        )

        assertTrue(
            result.blockedPlatforms.contains(M9Platform.FACEBOOK)
        )

        assertEquals(
            2,
            result.platforms.size
        )
    }

    @Test
    fun allAuthenticatedPlatformsAreReady() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey(
                "YOUTUBE",
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            "youtube-token"
        )

        store.put(
            M9CredentialKey(
                "FACEBOOK",
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            "facebook-token"
        )

        val facebook =
            M9ProviderAuthConfiguration(
                providerId = "FACEBOOK",
                protocol = M9AuthProtocol.OAUTH2,
                clientId = "facebook-client",
                redirectUri = "https://example.com/facebook/callback",
                scopes = setOf("publish")
            )

        val result =
            M9PublishingPreflight.evaluate(
                job(
                    setOf(
                        M9Platform.YOUTUBE,
                        M9Platform.FACEBOOK
                    )
                ),
                mapOf(
                    "YOUTUBE" to youtubeConfig(),
                    "FACEBOOK" to facebook
                ),
                store
            )

        assertEquals(
            M9PreflightStatus.READY,
            result.status
        )

        assertEquals(
            2,
            result.readyPlatforms.size
        )

        assertTrue(
            result.blockedPlatforms.isEmpty()
        )
    }

    @Test
    fun nonReadyJobIsRejected() {
        val result =
            M9PublishingPreflight.evaluate(
                job(setOf(M9Platform.YOUTUBE)).copy(
                    status = M9Status.DRAFT
                ),
                mapOf("YOUTUBE" to youtubeConfig()),
                M9InMemoryCredentialStore()
            )

        assertEquals(
            M9PreflightStatus.INVALID,
            result.status
        )
    }

    @Test
    fun missingVideoIsRejected() {
        val result =
            M9PublishingPreflight.evaluate(
                job(setOf(M9Platform.YOUTUBE)).copy(
                    videoPath =
                        File(
                            System.getProperty("java.io.tmpdir"),
                            "avsp_m98_missing.mp4"
                        ).absolutePath
                ),
                mapOf("YOUTUBE" to youtubeConfig()),
                M9InMemoryCredentialStore()
            )

        assertEquals(
            M9PreflightStatus.INVALID,
            result.status
        )
    }

    @Test
    fun emptyPlatformsAreRejected() {
        val result =
            M9PublishingPreflight.evaluate(
                job(emptySet()),
                emptyMap(),
                M9InMemoryCredentialStore()
            )

        assertEquals(
            M9PreflightStatus.INVALID,
            result.status
        )
    }

    @Test
    fun originalJobIsNotMutated() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey(
                "YOUTUBE",
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            "youtube-token"
        )

        val original =
            job(setOf(M9Platform.YOUTUBE))

        M9PublishingPreflight.evaluate(
            original,
            mapOf("YOUTUBE" to youtubeConfig()),
            store
        )

        assertEquals(
            M9Status.READY,
            original.status
        )
    }

    @Test
    fun credentialMaterialIsNotExposed() {
        val store = M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey(
                "YOUTUBE",
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            "SUPER_SECRET_TOKEN"
        )

        val result =
            M9PublishingPreflight.evaluate(
                job(setOf(M9Platform.YOUTUBE)),
                mapOf("YOUTUBE" to youtubeConfig()),
                store
            )

        assertFalse(
            result.toString().contains("SUPER_SECRET_TOKEN")
        )
    }
}
