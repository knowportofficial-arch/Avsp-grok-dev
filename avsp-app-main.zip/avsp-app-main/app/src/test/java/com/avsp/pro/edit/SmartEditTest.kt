package com.avsp.pro.edit

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.PI
import kotlin.math.sin

class SmartEditTest {
    private val rate = 16_000

    /** Room noise with "speech" bursts (voice-like tone with syllable gaps) at the given seconds. */
    private fun audio(totalS: Double, bursts: List<Pair<Double, Double>>): ShortArray {
        val rnd = java.util.Random(7)
        val pcm = ShortArray((totalS * rate).toInt())
        for (i in pcm.indices) {
            val t = i.toDouble() / rate
            var v = rnd.nextGaussian() * 60 // quiet room noise
            if (bursts.any { t >= it.first && t < it.second }) {
                val syllable = if (((t * 5) % 1.0) < 0.85) 1.0 else 0.25 // 5 syllables/s with small dips
                v += syllable * 6000 * sin(2 * PI * 180 * t) + 2000 * sin(2 * PI * 360 * t)
            }
            pcm[i] = v.toInt().coerceIn(-32768, 32767).toShort()
        }
        return pcm
    }

    @Test fun speech_is_found_with_word_gaps_merged() {
        val pcm = audio(12.0, listOf(1.0 to 3.0, 3.15 to 4.0, 7.0 to 9.5))
        val seg = SpeechSegmenter.segments(SpeechSegmenter.frameLevels(pcm, rate))
        assertEquals(seg.toString(), 2, seg.size)
        assertTrue(seg[0].startMs in 950..1100 && seg[0].endMs in 4000..4300)
        assertTrue(seg[1].startMs in 6950..7100 && seg[1].endMs in 9500..9800)
    }

    @Test fun dead_air_trimmed_and_long_pause_shortened() {
        val speech = listOf(SpeechSegmenter.Segment(1000, 4000), SpeechSegmenter.Segment(7000, 9500))
        val keeps = EditPlanner.talkingCut(speech, 12_000)
        // 1 s of dead air at the start and 2.5 s at the end are gone; the 3 s pause becomes a short beat.
        assertEquals(1000 - EditPlanner.PAD_BEFORE_MS, keeps.first().startMs)
        assertEquals(9500 + EditPlanner.PAD_AFTER_MS, keeps.last().endMs)
        val total = keeps.sumOf { it.durationMs }
        assertTrue("edited $total ms", total in 5900L..6400L)
        // Captions follow: 7.5 s in the original is about 4.1 s in the edit.
        val mapped = EditPlanner.mapTime(keeps, 7500)!!
        assertTrue("$mapped", mapped in 3800L..4400L)
        assertEquals(null, EditPlanner.mapTime(keeps, 5500))
    }

    @Test fun fillers_and_retakes_are_dropped() {
        val speech = listOf(
            SpeechSegmenter.Segment(0, 1500), SpeechSegmenter.Segment(2500, 3000),
            SpeechSegmenter.Segment(4000, 6000), SpeechSegmenter.Segment(7000, 9000)
        )
        val heard = listOf(
            EditPlanner.Heard(0, 1500, "Welcome to Kharagpur book fair"),
            EditPlanner.Heard(2500, 3000, "umm"),
            EditPlanner.Heard(4000, 6000, "The fair opens on fifteen November"),
            EditPlanner.Heard(7000, 9000, "The fair opens on 15 November at the town hall")
        )
        val keeps = EditPlanner.talkingCut(speech, 10_000, heard)
        assertTrue(EditPlanner.isFiller("umm"))
        assertTrue(EditPlanner.isFiller("মানে"))
        assertFalse(EditPlanner.isFiller("The fair opens"))
        assertTrue(EditPlanner.isRetake("The fair opens on fifteen November", "The fair opens on 15 November at the town hall"))
        assertEquals("filler at 2.5 s cut", null, EditPlanner.mapTime(keeps, 2700))
        assertEquals("first take at 5 s cut", null, EditPlanner.mapTime(keeps, 5000))
        assertTrue(EditPlanner.mapTime(keeps, 8000) != null)
    }

    @Test fun best_window_avoids_blurry_dark_and_frozen_moments() {
        fun frame(t: Long, value: Int, detail: Boolean) = ClipQuality.Sample(t, IntArray(64 * 36) { i ->
            if (detail && (i % 2 == 0)) (value + 60).coerceAtMost(255) else value
        }, 64, 36)
        // 0-3 s dark, 3-7 s good (detailed, changing), 7-10 s blurry flat.
        val samples = (0 until 20).map { k ->
            val t = k * 500L
            when {
                t < 3000 -> frame(t, 10, false)
                t < 7000 -> frame(t, 100 + (k % 3) * 8, true)
                else -> frame(t, 120, false)
            }
        }
        val q = ClipQuality.score(samples)
        val w = EditPlanner.bestWindow(q, 10_000, 3000)
        assertTrue("$w", w.startMs >= 2900 && w.endMs <= 7100)
        assertEquals(3000, w.durationMs)
        // Short clip: whole clip.
        assertEquals(EditPlanner.Keep(0, 2000), EditPlanner.bestWindow(q, 2000, 3000))
    }
}
