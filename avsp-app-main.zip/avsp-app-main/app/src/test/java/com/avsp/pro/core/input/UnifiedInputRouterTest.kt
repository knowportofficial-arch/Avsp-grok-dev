﻿package com.avsp.pro.core.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UnifiedInputRouterTest {

    @Test
    fun emptyInputIsRejected() {
        val result = UnifiedInputRouter.classify("   ")

        assertFalse(result.accepted)
        assertNotNull(result.reason)
    }

    @Test
    fun plainTextIsText() {
        val result = UnifiedInputRouter.classify("Create a Bengali news script")

        assertTrue(result.accepted)
        assertEquals(UnifiedInputType.TEXT, result.input?.type)
    }

    @Test
    fun genericHttpUrlIsUrl() {
        val result = UnifiedInputRouter.classify("https://example.com/article")

        assertEquals(UnifiedInputType.URL, result.input?.type)
    }

    @Test
    fun youtubeUrlIsYoutube() {
        val result = UnifiedInputRouter.classify("https://youtu.be/abc123")

        assertEquals(UnifiedInputType.YOUTUBE, result.input?.type)
    }

    @Test
    fun youtubeDomainIsYoutube() {
        val result = UnifiedInputRouter.classify(
            "https://www.youtube.com/watch?v=abc123"
        )

        assertEquals(UnifiedInputType.YOUTUBE, result.input?.type)
    }

    @Test
    fun imageMimeIsImage() {
        val result = UnifiedInputRouter.classify(
            "content://media/image/123",
            "image/jpeg"
        )

        assertEquals(UnifiedInputType.IMAGE, result.input?.type)
    }

    @Test
    fun screenshotMimeIsScreenshot() {
        val result = UnifiedInputRouter.classify(
            "content://media/image/123",
            "image/screenshot"
        )

        assertEquals(UnifiedInputType.SCREENSHOT, result.input?.type)
    }

    @Test
    fun videoMimeIsVideo() {
        val result = UnifiedInputRouter.classify(
            "/storage/emulated/0/video.mp4",
            "video/mp4"
        )

        assertEquals(UnifiedInputType.VIDEO, result.input?.type)
    }

    @Test
    fun screenRecordingNameIsScreenRecording() {
        val result = UnifiedInputRouter.classify(
            "/storage/emulated/0/ScreenRecording_001.mp4",
            "video/mp4",
            "ScreenRecording_001.mp4"
        )

        assertEquals(UnifiedInputType.SCREEN_RECORDING, result.input?.type)
    }

    @Test
    fun audioMimeIsAudio() {
        val result = UnifiedInputRouter.classify(
            "/storage/emulated/0/audio.m4a",
            "audio/mp4"
        )

        assertEquals(UnifiedInputType.AUDIO, result.input?.type)
    }

    @Test
    fun pdfMimeIsPdf() {
        val result = UnifiedInputRouter.classify(
            "content://documents/123",
            "application/pdf"
        )

        assertEquals(UnifiedInputType.PDF_DOCUMENT, result.input?.type)
    }

    @Test
    fun documentExtensionIsDocument() {
        val result = UnifiedInputRouter.classify(
            "/storage/emulated/0/report.docx"
        )

        assertEquals(UnifiedInputType.DOCUMENT, result.input?.type)
    }

    @Test
    fun everyAcceptedInputGetsId() {
        val result = UnifiedInputRouter.classify("hello")

        assertTrue(result.accepted)
        assertTrue(!result.input?.id.isNullOrBlank())
    }

    @Test
    fun originalLocatorIsPreserved() {
        val source = "https://example.com/test"

        val result = UnifiedInputRouter.classify(source)

        assertEquals(source, result.input?.locator)
    }
}
