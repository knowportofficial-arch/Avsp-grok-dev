package com.avsp.pro.screen.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScreenCaptureFileNamerTest {

    @Test
    fun createsExpectedVideoName() {
        val base =
            ScreenCaptureFileNamer.createBaseName(
                0L
            )

        assertTrue(base.startsWith("screen_"))
        assertEquals(
            "$base.mp4",
            ScreenCaptureFileNamer.videoName(base)
        )
    }

    @Test
    fun createsMetadataNameFromSameBase() {
        val base =
            "screen_20260925_120000_000"

        assertEquals(
            "screen_20260925_120000_000_metadata.json",
            ScreenCaptureFileNamer.metadataName(base)
        )
    }
}