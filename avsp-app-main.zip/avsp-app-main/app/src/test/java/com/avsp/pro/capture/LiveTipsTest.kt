package com.avsp.pro.capture

import com.avsp.pro.m7.capture.camera.guided.LiveTips
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LiveTipsTest {
    private fun frame(w: Int, h: Int, f: (Int, Int) -> Int) = ByteArray(w * h) { i -> f(i % w, i / w).toByte() }

    @Test fun darkFlatAndSharpFramesGetTheRightTip() {
        val dark = LiveTips.stats(frame(160, 120) { _, _ -> 20 }, 160, 120, 160)
        assertTrue(LiveTips.tip(dark, 0f, false)!!.startsWith("Too dark"))
        val flat = LiveTips.stats(frame(160, 120) { _, _ -> 120 }, 160, 120, 160)
        assertTrue(LiveTips.tip(flat, 0f, false)!!.startsWith("Blurry"))
        val sharp = LiveTips.stats(frame(160, 120) { x, y -> if ((x / 4 + y / 4) % 2 == 0) 60 else 190 }, 160, 120, 160)
        assertNull(LiveTips.tip(sharp, 0f, false))
        assertTrue(LiveTips.tip(sharp, 12f, false)!!.startsWith("Tilted"))
    }

    @Test fun aiReplyIsRead() {
        val t = LiveTips.parse("```json\n{\"ok\": false, \"tip\": \"Move closer to the pan\"}\n```")!!
        assertEquals("Move closer to the pan", t.tip)
        assertNull(LiveTips.parse("no idea"))
    }
}
