﻿package com.avsp.pro.m9

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class M9SecureCredentialStoreTest {

    @Test
    fun credentialTypesAreExplicitlySeparated() {
        val values = M9CredentialType.values()

        assertTrue(
            values.contains(
                M9CredentialType.OAUTH_ACCESS_TOKEN
            )
        )

        assertTrue(
            values.contains(
                M9CredentialType.OAUTH_REFRESH_TOKEN
            )
        )

        assertTrue(
            values.contains(
                M9CredentialType.API_KEY
            )
        )
    }

    @Test
    fun credentialKeyPreservesProviderAndType() {
        val key = M9CredentialKey(
            providerId = "YOUTUBE",
            type = M9CredentialType.OAUTH_ACCESS_TOKEN
        )

        assertEquals(
            "YOUTUBE",
            key.providerId
        )

        assertEquals(
            M9CredentialType.OAUTH_ACCESS_TOKEN,
            key.type
        )
    }

    @Test
    fun presenceNeverContainsCredentialMaterial() {
        val presence = M9CredentialPresence(
            providerId = "YOUTUBE",
            accessTokenPresent = true,
            refreshTokenPresent = true,
            apiKeyPresent = false
        )

        val rendered = presence.toString()

        assertFalse(
            rendered.contains("token")
        )

        assertFalse(
            rendered.contains("secret")
        )
    }

    @Test
    fun inMemoryStoreRemainsCompatibleWithSecureStoreContract() {
        val store: M9CredentialStore =
            M9InMemoryCredentialStore()

        val key = M9CredentialKey(
            providerId = "YOUTUBE",
            type = M9CredentialType.OAUTH_ACCESS_TOKEN
        )

        store.put(
            key,
            "test-token"
        )

        assertTrue(
            store.contains(key)
        )

        assertEquals(
            "test-token",
            store.get(key)
        )
    }

    @Test
    fun providerPresenceIsIndependentByProvider() {
        val store: M9CredentialStore =
            M9InMemoryCredentialStore()

        store.put(
            M9CredentialKey(
                "YOUTUBE",
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            "youtube-token"
        )

        store.put(
            M9CredentialKey(
                "FACEBOOK",
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            "facebook-token"
        )

        assertTrue(
            store.presence("YOUTUBE").accessTokenPresent
        )

        assertFalse(
            store.presence("YOUTUBE").apiKeyPresent
        )

        assertTrue(
            store.presence("FACEBOOK").accessTokenPresent
        )
    }

    @Test
    fun storageContractSupportsRemoval() {
        val store: M9CredentialStore =
            M9InMemoryCredentialStore()

        val key = M9CredentialKey(
            "WEB",
            M9CredentialType.API_KEY
        )

        store.put(
            key,
            "api-key"
        )

        assertTrue(
            store.contains(key)
        )

        store.remove(key)

        assertFalse(
            store.contains(key)
        )
    }
}
