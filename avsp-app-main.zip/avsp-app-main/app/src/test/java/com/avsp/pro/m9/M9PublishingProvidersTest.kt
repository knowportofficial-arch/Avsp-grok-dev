﻿package com.avsp.pro.m9

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class M9PublishingProvidersTest {

    private fun tempVideo(): File {
        return File.createTempFile("avsp-m92-", ".mp4").apply {
            writeText("test-video")
            deleteOnExit()
        }
    }

    private fun readyJob(): M9Job {
        val file = tempVideo()

        return M9Job(
            projectId = "project-m92",
            videoPath = file.absolutePath,
            title = "M9.2 Test Video",
            platforms = setOf(M9Platform.YOUTUBE),
            status = M9Status.READY
        )
    }

    @Test
    fun registryContainsEveryM9PlatformProvider() {
        val providers = M9PublishingProviderRegistry.all()

        assertEquals(
            M9ProviderId.entries.toSet(),
            providers.map { it.id }.toSet()
        )
    }

    @Test
    fun allProvidersAreExplicitlyNotConfigured() {
        M9PublishingProviderRegistry.all().forEach { provider ->
            assertEquals(M9ProviderMode.NOT_CONFIGURED, provider.capabilities.mode)
            assertFalse(provider.capabilities.supportsAuthentication)
            assertFalse(provider.capabilities.supportsUpload)
            assertFalse(provider.capabilities.supportsProcessingStatus)
            assertFalse(provider.capabilities.supportsPublicationConfirmation)
            assertFalse(provider.capabilities.supportsExternalId)
            assertEquals(M9AuthState.NOT_CONFIGURED, provider.authState().state)
        }
    }

    @Test
    fun providerDoesNotFakeSuccessfulUpload() {
        val provider = M9PublishingProviderRegistry.get(M9ProviderId.YOUTUBE)

        val result = provider.publish(
            M9PublishRequest(
                jobId = "job-1",
                projectId = "project-1",
                videoFile = tempVideo(),
                title = "Test",
                provider = M9ProviderId.YOUTUBE
            )
        )

        assertEquals(M9UploadState.FAILED, result.state)
        assertFalse(result.realOperationPerformed)
        assertTrue(result.message.contains("No upload was performed"))
        assertEquals(null, result.externalId)
    }

    @Test
    fun executorRejectsNonReadyJob() {
        val job = M9Job(
            projectId = "project",
            videoPath = tempVideo().absolutePath,
            title = "Test",
            platforms = setOf(M9Platform.YOUTUBE),
            status = M9Status.DRAFT
        )

        try {
            M9PublishingExecutor.execute(job, M9ProviderId.YOUTUBE)
            throw AssertionError("Expected IllegalArgumentException")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message!!.contains("READY"))
        }
    }

    @Test
    fun executorMovesNotConfiguredProviderToFailedWithoutClaimingUpload() {
        val job = readyJob()

        val result = M9PublishingExecutor.execute(
            job,
            M9ProviderId.YOUTUBE
        )

        assertEquals(M9Status.FAILED, result.jobStatus)
        assertEquals(M9UploadState.FAILED, result.publishResult.state)
        assertFalse(result.publishResult.realOperationPerformed)
        assertEquals(null, result.publishResult.externalId)
    }

    @Test
    fun executorRejectsMissingVideo() {
        val job = M9Job(
            projectId = "project",
            videoPath = "C:\\does-not-exist\\avsp-m92.mp4",
            title = "Test",
            platforms = setOf(M9Platform.YOUTUBE),
            status = M9Status.READY
        )

        try {
            M9PublishingExecutor.execute(job, M9ProviderId.YOUTUBE)
            throw AssertionError("Expected IllegalArgumentException")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message!!.contains("does not exist"))
        }
    }

    @Test
    fun capabilityRegistryIsComplete() {
        val capabilities = M9PublishingProviderRegistry.capabilities()

        assertEquals(M9ProviderId.entries.size, capabilities.size)
        assertNotNull(capabilities.firstOrNull { it.provider == M9ProviderId.YOUTUBE })
        assertNotNull(capabilities.firstOrNull { it.provider == M9ProviderId.FACEBOOK })
        assertNotNull(capabilities.firstOrNull { it.provider == M9ProviderId.INSTAGRAM })
        assertNotNull(capabilities.firstOrNull { it.provider == M9ProviderId.TELEGRAM })
        assertNotNull(capabilities.firstOrNull { it.provider == M9ProviderId.WEB })
    }
}
