package com.avsp.pro.core.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class M15DocumentContentProcessorContractTest {

    @Test
    fun pdfAdapterProducesPdfUnifiedInput() {
        val result = DocumentInputAdapter.adapt(
            locator = "content://documents/report.pdf",
            displayName = "report.pdf",
            mimeType = "application/pdf"
        )

        assertNotNull(result)
        assertEquals(UnifiedInputType.PDF_DOCUMENT, result!!.input.type)
        assertEquals(DocumentInputAdapter.DocumentInputKind.PDF, result.kind)
    }

    @Test
    fun textDocumentAdapterProducesDocumentUnifiedInput() {
        val result = DocumentInputAdapter.adapt(
            locator = "content://documents/readme.txt",
            displayName = "readme.txt",
            mimeType = "text/plain"
        )

        assertNotNull(result)
        assertEquals(UnifiedInputType.DOCUMENT, result!!.input.type)
        assertEquals(DocumentInputAdapter.DocumentInputKind.DOCUMENT, result.kind)
    }

    @Test
    fun docxAdapterProducesDocumentUnifiedInput() {
        val result = DocumentInputAdapter.adapt(
            locator = "content://documents/report.docx",
            displayName = "report.docx",
            mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        )

        assertNotNull(result)
        assertEquals(UnifiedInputType.DOCUMENT, result!!.input.type)
    }

    @Test
    fun pdfQueryAndFragmentAreRecognized() {
        val result = DocumentInputAdapter.adapt(
            locator = "content://documents/report.pdf?x=1#page=2",
            displayName = "report.pdf",
            mimeType = null
        )

        assertNotNull(result)
        assertEquals(UnifiedInputType.PDF_DOCUMENT, result!!.input.type)
    }

    @Test
    fun unsupportedVideoIsRejected() {
        val result = DocumentInputAdapter.adapt(
            locator = "content://documents/video.mp4",
            displayName = "video.mp4",
            mimeType = "video/mp4"
        )

        assertNull(result)
    }

    @Test
    fun blankLocatorIsRejected() {
        val result = DocumentInputAdapter.adapt(
            locator = "   ",
            displayName = "report.pdf",
            mimeType = "application/pdf"
        )

        assertNull(result)
    }

    @Test
    fun adapterMetadataIdentifiesM14Boundary() {
        val result = DocumentInputAdapter.adapt(
            locator = "content://documents/report.pdf",
            displayName = "report.pdf",
            mimeType = "application/pdf"
        )

        assertNotNull(result)
        assertEquals("M14", result!!.input.metadata["adapter"])
        assertEquals("PDF", result.input.metadata["documentInputKind"])
    }

    @Test
    fun m15ProcessorContractTypesAreAvailable() {
        assertEquals(
            DocumentContentProcessor.ContentKind.PDF,
            DocumentContentProcessor.ContentKind.valueOf("PDF")
        )
        assertEquals(
            DocumentContentProcessor.ContentKind.TEXT_DOCUMENT,
            DocumentContentProcessor.ContentKind.valueOf("TEXT_DOCUMENT")
        )
        assertTrue(
            DocumentContentProcessor.ContentKind.UNSUPPORTED !=
                DocumentContentProcessor.ContentKind.PDF
        )
    }
}
