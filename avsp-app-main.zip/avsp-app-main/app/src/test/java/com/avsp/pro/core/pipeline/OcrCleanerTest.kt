package com.avsp.pro.core.pipeline

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OcrCleanerTest {
    @Test fun noisyDiagramAndPrivateDetailsAreLeftOut() {
        val ocr = """
            CPAN OLT riANPORT coMPUTER|) static fP:
            to 160.774 Gateway - (o l60.
            171 VPN - user id: abcd
            Internet: userid: abcd password: xyz123
            The office network connects every computer to the internet.
        """.trimIndent()
        val r = OcrCleaner.clean(ocr)
        assertEquals("The office network connects every computer to the internet.", r.text)
        assertTrue("private ${r.privateLinesDropped}", r.privateLinesDropped >= 2)
        assertTrue(r.readable < 0.7f)
    }

    @Test fun normalPosterTextIsKept() {
        val r = OcrCleaner.clean("Drink more water\nStay healthy this summer\nIIT Kharagpur Open Day 2026")
        assertEquals(3, r.text.lines().size)
        assertEquals(0, r.privateLinesDropped)
        assertTrue(r.readable > 0.8f)
    }

    @Test fun wordShapes() {
        assertTrue(OcrCleaner.isWord("Kolkata")); assertTrue(OcrCleaner.isWord("IIT")); assertTrue(OcrCleaner.isWord("কলকাতা"))
        assertFalse(OcrCleaner.isWord("coMPUTER|)")); assertFalse(OcrCleaner.isWord("fP:")); assertFalse(OcrCleaner.isWord("l60."))
    }
}
