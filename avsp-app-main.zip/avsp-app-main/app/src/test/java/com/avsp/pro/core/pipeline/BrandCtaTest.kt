package com.avsp.pro.core.pipeline

import com.avsp.pro.settings.BrandKit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BrandCtaTest {
    @Test fun ctaNamesTheChannelAndStaysShort() {
        assertEquals("Follow Knowport for more!", BrandKit.spokenCta("en", "Knowport"))
        assertTrue(CtaRule.isShort(BrandKit.spokenCta("en", "Knowport")!!))
        assertTrue(CtaRule.isShort(BrandKit.spokenCta("bn", "Knowport")!!))
        assertEquals("Like • Follow @Knowport", BrandKit.ctaLine("en", "Knowport"))
        assertNull(BrandKit.spokenCta("en", " "))
    }

    @Test fun closingHashtagFitsTheTopic() {
        assertEquals(listOf("#Recipe", "#IndianFood"), PublishKit.topicTags("Easy Indian Chicken Curry Recipe", "en"))
        assertEquals(listOf("#News"), PublishKit.topicTags("Minister announces new rail line", "en"))
        assertEquals(emptyList<String>(), PublishKit.topicTags("Why the sky is blue", "en"))
    }
}
