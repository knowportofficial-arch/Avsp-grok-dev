package com.avsp.pro.edit

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class SoundBedTest {
    private fun level(p: ShortArray, fromMs: Long, toMs: Long, rate: Int = SoundBed.RATE): Double {
        val a = (fromMs * rate / 1000).toInt(); val b = (toMs * rate / 1000).toInt()
        return (a until b).map { abs(p[it].toInt()).toDouble() }.average()
    }

    @Test fun quietVoiceIsLiftedLoudVoiceIsNotClipped() {
        val quiet = ShortArray(16_000) { i -> (1200 * kotlin.math.sin(i * 0.07)).toInt().toShort() }
        val g = SoundBed.voiceGain(quiet, 16_000, listOf(SpeechSegmenter.Segment(0, 1000)))
        assertTrue("gain $g", g > 2f)
        val loud = ShortArray(16_000) { i -> (30_000 * kotlin.math.sin(i * 0.07)).toInt().toShort() }
        val g2 = SoundBed.voiceGain(loud, 16_000, listOf(SpeechSegmenter.Segment(0, 1000)))
        assertTrue("never clips: $g2", g2 * 30_000 <= 0.96 * 32768)
        assertEquals(1f, SoundBed.voiceGain(quiet, 16_000, emptyList()))
    }

    @Test fun musicDucksUnderSpeechAndWhooshMarksCut() {
        val bed = SoundBed.bed(8_000, speech = listOf(3_000L..6_000L), cuts = listOf(7_000L))
        assertEquals(8 * SoundBed.RATE, bed.size)
        val free = level(bed, 1_000, 2_500)
        val under = level(bed, 4_000, 5_500)
        assertTrue("ducked: $free vs $under", under < free * 0.5)
        val beforeCut = level(bed, 6_850, 7_000)
        val calm = level(bed, 6_300, 6_600)
        assertTrue("whoosh: $calm -> $beforeCut", beforeCut > calm * 1.3)
    }

    @Test fun wordsShareTheCaptionTime() {
        val w = SoundBed.wordTimes("it is located far", 1_000, 3_000)
        assertEquals(4, w.size)
        assertEquals(1_000, w.first().second)
        assertEquals(3_000, w.last().third)
        assertTrue(w.zipWithNext().all { (a, b) -> a.third == b.second || abs(a.third - b.second) <= 1 })
        assertTrue("longer word, more time", (w[2].third - w[2].second) > (w[1].third - w[1].second))
    }
}
