package com.avsp.pro.screen.capture
import android.graphics.RectF
import com.google.common.truth.Truth.assertThat
import org.junit.Test
class ScreenIntelligenceContractTest {
 @Test fun normalizedBoundsAreNormalized(){val r=RectF(0.1f,0.2f,0.9f,0.8f);assertThat(r.left).isAtLeast(0f);assertThat(r.right).isAtMost(1f);assertThat(r.top).isAtLeast(0f);assertThat(r.bottom).isAtMost(1f)}
 @Test fun sensitiveEventIsMarked(){val e=ScreenTimelineEvent(1,ScreenEventType.SENSITIVE_DATA,"Sensitive data detected","phone",.95f,true);assertThat(e.sensitive).isTrue()}
}
