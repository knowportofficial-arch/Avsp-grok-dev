package com.avsp.pro.edit

import com.avsp.pro.video.engine.VideoClipPlanner
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartClipTest {
    private fun scores(vararg v: Pair<Long, Float>) = v.map { (t, s) -> ClipQuality.Score(t, s, 0.5f, 0.05f, 0.03f) }

    @Test fun longClipPlaysFromItsBestPart() {
        val p = VideoClipPlanner.pieces(20_000, 5_000, windowStartMs = 9_000)
        assertEquals(listOf(VideoClipPlanner.Piece(9_000, 14_000, 5_000)), p)
        // Window past the end is pulled back inside the clip.
        assertEquals(15_000, VideoClipPlanner.pieces(20_000, 5_000, 18_000).single().startMs)
        // Short clips still loop from 0 and sum exactly.
        assertEquals(7_000, VideoClipPlanner.pieces(3_000, 7_000, 1_000).sumOf { it.durationMs })
    }

    @Test fun secondUseOfSameClipShowsAnotherPart() {
        val q = (0 until 40).map { i -> i * 500L to (if (i in 8..16) 0.95f else 0.6f) }.let { scores(*it.toTypedArray()) }
        val first = EditPlanner.bestWindow(q, 20_000, 4_000)
        assertTrue("best part first: $first", first.startMs in 3_500..4_500)
        val second = EditPlanner.bestWindow(q, 20_000, 4_000, avoid = listOf(first))
        assertTrue("no overlap: $first / $second", second.startMs >= first.endMs || second.endMs <= first.startMs)
    }

    @Test fun geminiAnswerKeepsOriginalTimes() {
        val segs = listOf(SpeechSegmenter.Segment(2_000, 5_000), SpeechSegmenter.Segment(9_000, 12_500))
        val times = GeminiTranscriber.condensedTimes(segs)
        assertEquals(listOf(0L to 3_000L, 3_700L to 7_200L), times)
        val heard = GeminiTranscriber.parse("```json\n[{\"i\":1,\"text\":\"Hello friends\"},{\"i\":2,\"text\":\"\"}]\n```", segs)
        assertEquals(listOf(EditPlanner.Heard(2_000, 5_000, "Hello friends")), heard)
        assertEquals(emptyList<EditPlanner.Heard>(), GeminiTranscriber.parse("sorry, no", segs))
    }

    @Test fun longSpeechIsSentInPieces() {
        val segs = (0 until 10).map { SpeechSegmenter.Segment(it * 60_000L, it * 60_000L + 50_000) }
        val b = GeminiTranscriber.batches(segs, 180_000)
        assertEquals(10, b.sumOf { it.size })
        assertTrue(b.all { batch -> batch.sumOf { it.endMs - it.startMs } <= 180_000 })
        val wav = GeminiTranscriber.wavOf(MediaAnalysis.Audio(ShortArray(16_000 * 10), 16_000), listOf(SpeechSegmenter.Segment(1_000, 2_000), SpeechSegmenter.Segment(5_000, 6_000)))
        assertEquals(44 + 2 * (16_000 + 11_200 + 16_000), wav.size)
    }

    @Test fun paddingOnBlackPictureIsDropped() {
        val speech = listOf(SpeechSegmenter.Segment(2_000, 5_000), SpeechSegmenter.Segment(9_000, 12_000))
        // Picture is black from 5.0 to 9.2 s (a fade between shots).
        val q = (0 until 28).map { i -> val t = i * 500L; ClipQuality.Score(t, if (t in 5_000..9_200) 0f else 0.8f, if (t in 5_000..9_200) 0.02f else 0.5f, 0.05f, 0.03f) }
        val keeps = EditPlanner.talkingCut(speech, 14_000, quality = q)
        assertEquals(2, keeps.size)
        assertEquals(5_000, keeps[0].endMs)
        assertEquals(9_000, keeps[1].startMs)
    }

    @Test fun shortPicksTheLivelyPartThatFits() {
        val keeps = listOf(EditPlanner.Keep(0, 20_000), EditPlanner.Keep(25_000, 45_000), EditPlanner.Keep(50_000, 75_000), EditPlanner.Keep(80_000, 100_000))
        val heard = listOf(
            EditPlanner.Heard(0, 20_000, "slow intro words here"),
            EditPlanner.Heard(25_000, 45_000, List(60) { "w" }.joinToString(" ")),
            EditPlanner.Heard(50_000, 75_000, List(70) { "w" }.joinToString(" ")),
            EditPlanner.Heard(80_000, 100_000, "the end")
        )
        val short = EditPlanner.highlight(keeps, 60_000, heard)
        assertEquals(listOf(keeps[1], keeps[2]), short)
        assertTrue(short.sumOf { it.durationMs } <= 60_000)
        // One long part is cut at the target; a video already short enough is kept whole.
        assertEquals(30_000L, EditPlanner.highlight(listOf(EditPlanner.Keep(0, 90_000)), 30_000).single().durationMs)
        assertEquals(keeps.take(1), EditPlanner.highlight(keeps.take(1), 60_000))
    }
}
