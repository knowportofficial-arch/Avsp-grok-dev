package com.avsp.pro.screen.capture

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ScreenSensitiveNumbersTest {
    private fun hidden(text: String) = ScreenSensitiveSanitizer.scan(text).map { it.sourceText.trim() }

    @Test fun everydayNumbersStayClear() {
        listOf("10:45 AM", "Battery 85%", "09/10/2026", "Price ₹499", "Version 2.3.1", "3 new messages", "Oct 2026", "Step 2 of 5", "500 views")
            .forEach { assertTrue("$it should stay clear: ${hidden(it)}", hidden(it).isEmpty()) }
    }

    @Test fun sensitiveNumbersAreHidden() {
        assertTrue(hidden("A/c balance: 52,340").isNotEmpty())
        assertTrue(hidden("Customer ID 4471").isNotEmpty())
        assertTrue(hidden("Ref no 88421093").isNotEmpty())
        assertTrue(hidden("CVV 123").isNotEmpty())
        assertTrue(hidden("98765").isNotEmpty())              // number being typed in the dialer
        assertTrue(hidden("Call 9876543210 now").isNotEmpty()) // phone rule
        assertTrue(hidden("Your OTP is 482913").isNotEmpty())
    }

    @Test fun yearAloneIsNotPrivate() {
        assertFalse(ScreenSensitiveSanitizer.isSensitiveNumber("2026", 0, 4))
    }
}
