﻿package com.avsp.pro.core.handoff

import com.avsp.pro.ui.screens.dailypost.DailyPostCategory
import com.avsp.pro.ui.screens.dailypost.DailyPostGeography
import com.avsp.pro.ui.screens.dailypost.DailyPostItem
import org.junit.Assert.assertTrue
import org.junit.Test

class DailyPostM5HandoffTest {

    @Test
    fun preserves_verified_daily_post_context_for_m5() {
        val post = DailyPostItem(
            id = "daily-1",
            title = "Test title",
            category = DailyPostCategory.NEWS,
            geography = DailyPostGeography.NATIONAL,
            date = "2026-09-30",
            source = "Verified Source",
            summary = "Verified summary",
            relevance = "Why this matters",
            videoAngle = "Short video angle"
        )

        val handoff = DailyPostM5Handoff.from(post)
        val text = handoff.asInputText()

        assertTrue(text.contains("Test title"))
        assertTrue(text.contains("2026-09-30"))
        assertTrue(text.contains("Verified Source"))
        assertTrue(text.contains("Verified summary"))
        assertTrue(text.contains("Why this matters"))
        assertTrue(text.contains("Short video angle"))
    }

    @Test
    fun empty_summary_does_not_create_fake_content() {
        val post = DailyPostItem(
            id = "daily-2",
            title = "Real title",
            category = DailyPostCategory.HISTORY,
            geography = DailyPostGeography.LOCAL,
            date = "2026-09-30",
            source = "Real Source",
            summary = "",
            relevance = "",
            videoAngle = ""
        )

        val text = DailyPostM5Handoff.from(post).asInputText()

        assertTrue(text.contains("Real title"))
        assertTrue(text.contains("Real Source"))
    }
}
