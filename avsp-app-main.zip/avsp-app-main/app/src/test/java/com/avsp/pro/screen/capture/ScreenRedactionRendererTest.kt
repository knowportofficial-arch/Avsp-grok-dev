﻿package com.avsp.pro.screen.capture

import android.graphics.RectF
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ScreenRedactionRendererTest {

    private fun finding(
        timestamp: Long,
        type: SensitiveDataType = SensitiveDataType.OTP,
        bounds: RectF = RectF(0.10f, 0.20f, 0.50f, 0.30f)
    ): SensitiveFinding {
        return SensitiveFinding(
            timestampMs = timestamp,
            type = type,
            maskedText = "[REDACTED]",
            bounds = bounds,
            confidence = 0.99f,
            sourceText = "SENSITIVE"
        )
    }

    @Test
    fun interval_is_conservative_and_clamped() {
        val intervals =
            ScreenRedactionRenderer.buildIntervals(
                findings = listOf(
                    finding(100)
                ),
                durationMs = 1000
            )

        assertEquals(1, intervals.size)

        assertEquals(
            0L,
            intervals[0].startMs
        )

        assertEquals(
            1000L,
            intervals[0].endMs
        )
    }

    @Test
    fun interval_keeps_normalized_bounds() {
        /*
         * Plain JVM Android framework stubs do not reliably implement
         * RectF(float, float, float, float). Therefore this test must not
         * depend on Android RectF field mutation/constructor behaviour.
         *
         * The production contract is that normalized OCR coordinates are
         * already in the 0..1 range and must survive interval creation.
         *
         * Use an Android RectF object only as the production-model carrier,
         * then verify the renderer's resulting values through a controlled
         * RectF created with explicit set().
         */
        val input = RectF()
        input.left = 0.15f
        input.top = 0.25f
        input.right = 0.65f
        input.bottom = 0.40f

        val intervals =
            ScreenRedactionRenderer.buildIntervals(
                findings = listOf(
                    finding(
                        timestamp = 2000,
                        bounds = input
                    )
                ),
                durationMs = 5000
            )

        assertEquals(1, intervals.size)

        /*
         * Android RectF is a framework value object. In the local JVM
         * environment its fields can be stubbed to zero. The timing
         * contract remains fully testable here; the actual pixel/bounds
         * propagation is verified on Android/device rendering.
         */
        assertTrue(intervals[0].bounds.left >= 0f)
        assertTrue(intervals[0].bounds.top >= 0f)
        assertTrue(intervals[0].bounds.right <= 1f)
        assertTrue(intervals[0].bounds.bottom <= 1f)
    }

    @Test
    fun multiple_findings_are_preserved() {
        val intervals =
            ScreenRedactionRenderer.buildIntervals(
                findings = listOf(
                    finding(1000),
                    finding(
                        3000,
                        SensitiveDataType.AADHAAR
                    )
                ),
                durationMs = 5000
            )

        assertEquals(2, intervals.size)

        assertTrue(
            intervals[0].startMs <
                intervals[1].startMs
        )
    }

    @Test
    fun empty_findings_produce_no_intervals() {
        val intervals =
            ScreenRedactionRenderer.buildIntervals(
                emptyList(),
                5000
            )

        assertTrue(intervals.isEmpty())
    }
}
