package com.avsp.pro.script.generator

import com.avsp.pro.script.contract.DurationRequest
import com.avsp.pro.script.contract.ScriptGenerationRequest
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatScriptGeneratorTest {
    private val req = ScriptGenerationRequest("p1", "Kharagpur railway platform", "en", DurationRequest.Explicit(30_000L))
    private val script = """{"title":"Longest Platform","hook":"h","introduction":"i","cta":"Follow","ending":"e",
        "scenes":[{"narration":"Welcome to Kharagpur, home of one of the longest platforms.","onScreenText":"Kharagpur"},
                  {"narration":"Trains arrive here all day long.","onScreenText":"Busy"},
                  {"narration":"Follow for more!","onScreenText":"Follow"}]}"""

    private fun reply(text: String) = JSONObject().put("choices", org.json.JSONArray().put(JSONObject().put("message", JSONObject().put("content", text)))).toString()

    @Test fun groqWritesTheScriptAndIsNamed() = runBlocking {
        val seen = mutableListOf<String>()
        val g = ChatScriptGenerator("groq", "Groq", "https://x", { listOf("m1", "m2") }, { listOf("gsk_key") }, true,
            http = { _, _, body, _ -> seen += JSONObject(body).getString("model"); if (seen.size == 1) error("HTTP 404") else reply("```json\n$script\n```") })
        val p = g.generate(req)
        assertEquals(listOf("m1", "m2"), seen)
        assertEquals("groq:m2", p.metadata.generatorId)
        assertTrue(p.scenes.size >= 2)
    }

    @Test fun refusedKeyMovesToTheNextKey() = runBlocking {
        val keysUsed = mutableListOf<String>()
        val g = ChatScriptGenerator("openrouter", "OpenRouter", "https://x", { listOf("a", "b") }, { listOf("k1", "k2") }, false,
            http = { _, key, _, _ -> keysUsed += key; if (key == "k1") error("HTTP 401") else reply(script) })
        g.generate(req)
        assertEquals(listOf("k1", "k2"), keysUsed)
    }

    @Test fun freeModelsAreFoundAndRanked() {
        val raw = """{"data":[{"id":"x/paid","context_length":100000},{"id":"google/gemma-3-27b-it:free","context_length":96000},
            {"id":"meta-llama/llama-3.3-70b-instruct:free","context_length":131072},{"id":"tiny:free","context_length":2048}]}"""
        assertEquals(listOf("meta-llama/llama-3.3-70b-instruct:free", "google/gemma-3-27b-it:free"), ChatScriptGenerator.freeModels(raw))
    }
}
