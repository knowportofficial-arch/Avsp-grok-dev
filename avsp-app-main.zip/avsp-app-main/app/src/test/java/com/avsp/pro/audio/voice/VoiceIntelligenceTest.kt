﻿package com.avsp.pro.audio.voice

import com.avsp.pro.audio.engine.TtsEngine
import com.avsp.pro.audio.engine.TtsProviderMode
import com.avsp.pro.audio.engine.TtsSynthesisRequest
import com.avsp.pro.audio.engine.TtsSynthesisResult
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test

class VoiceIntelligenceTest {

    @Test
    fun languageMismatchIsNeverSelected() {
        val engine = fake(
            id = "fake",
            languages = setOf("en"),
            catalog = listOf(
                VoiceProfile("hi", "fake", "Hindi", setOf("hi"), qualityScore = 99.0f),
                VoiceProfile("en", "fake", "English", setOf("en"), qualityScore = 50.0f)
            )
        )

        val result = VoiceIntelligence.select(
            VoiceSelectionRequest(language = "en"),
            listOf(engine)
        )

        assertEquals("en", result.selected.id)
        assertTrue(result.candidates.none { it.voice.id == "hi" })
    }

    @Test
    fun preferredVoiceWins() {
        val engine = fake(
            id = "fake",
            languages = setOf("bn"),
            catalog = listOf(
                VoiceProfile("a", "fake", "A", setOf("bn"), qualityScore = 99.0f),
                VoiceProfile("b", "fake", "B", setOf("bn"), qualityScore = 50.0f)
            )
        )

        val result = VoiceIntelligence.select(
            VoiceSelectionRequest(language = "bn", preferredVoiceId = "b"),
            listOf(engine)
        )

        assertEquals("b", result.selected.id)
    }

    @Test
    fun providerPreferenceIsHonored() {
        val a = fake("a", setOf("en"),
            listOf(VoiceProfile("voice-a", "a", "A", setOf("en"), qualityScore = 70.0f)))
        val b = fake("b", setOf("en"),
            listOf(VoiceProfile("voice-b", "b", "B", setOf("en"), qualityScore = 70.0f)))

        val result = VoiceIntelligence.select(
            VoiceSelectionRequest(language = "en", preferredProviderId = "b"),
            listOf(a, b)
        )

        assertEquals("b", result.selected.providerId)
    }

    @Test
    fun styleFitInfluencesSelection() {
        val engine = fake(
            "fake", setOf("en"),
            listOf(
                VoiceProfile("general", "fake", "General", setOf("en"),
                    styles = setOf(VoiceStyle.CONVERSATIONAL), qualityScore = 70.0f),
                VoiceProfile("news", "fake", "News", setOf("en"),
                    styles = setOf(VoiceStyle.NEWS), qualityScore = 70.0f)
            )
        )

        assertEquals(
            "news",
            VoiceIntelligence.select(
                VoiceSelectionRequest("en", VoiceContentType.NEWS),
                listOf(engine)
            ).selected.id
        )
    }

    @Test
    fun genderPreferenceInfluencesSelection() {
        val engine = fake(
            "fake", setOf("hi"),
            listOf(
                VoiceProfile("m", "fake", "Male", setOf("hi"),
                    gender = VoiceGender.MALE, qualityScore = 70.0f),
                VoiceProfile("f", "fake", "Female", setOf("hi"),
                    gender = VoiceGender.FEMALE, qualityScore = 70.0f)
            )
        )

        assertEquals(
            "f",
            VoiceIntelligence.select(
                VoiceSelectionRequest("hi", preferredGender = VoiceGender.FEMALE),
                listOf(engine)
            ).selected.id
        )
    }

    @Test
    fun unavailableVoiceIsExcluded() {
        val engine = fake(
            "fake", setOf("en"),
            listOf(
                VoiceProfile("bad", "fake", "Bad", setOf("en"), available = false, qualityScore = 100.0f),
                VoiceProfile("good", "fake", "Good", setOf("en"), qualityScore = 50.0f)
            )
        )

        assertEquals(
            "good",
            VoiceIntelligence.select(
                VoiceSelectionRequest("en"),
                listOf(engine)
            ).selected.id
        )
    }

    @Test
    fun deterministicTieBreakUsesProviderThenVoiceId() {
        val engine = fake(
            "fake", setOf("en"),
            listOf(
                VoiceProfile("z", "fake", "Z", setOf("en"), qualityScore = 50.0f),
                VoiceProfile("a", "fake", "A", setOf("en"), qualityScore = 50.0f)
            )
        )

        assertEquals(
            "a",
            VoiceIntelligence.select(
                VoiceSelectionRequest("en"),
                listOf(engine)
            ).selected.id
        )
    }

    @Test
    fun providerNeutralFallbackWorksForPlainEngine() {
        val engine = fake(
            "plain", setOf("bn", "en", "hi"), emptyList()
        )

        val result = VoiceIntelligence.select(
            VoiceSelectionRequest("bn"),
            listOf(engine)
        )

        assertEquals("default", result.selected.id)
        assertEquals("plain", result.selected.providerId)
    }

    @Test
    fun noCompatibleEngineFailsClearly() {
        val engine = fake("en-only", setOf("en"), emptyList())

        assertThrows(IllegalStateException::class.java) {
            VoiceIntelligence.select(
                VoiceSelectionRequest("bn"),
                listOf(engine)
            )
        }
    }

    private fun fake(
        id: String,
        languages: Set<String>,
        catalog: List<VoiceProfile>
    ): TtsEngine =
        FakeEngine(id, languages, catalog)

    private class FakeEngine(
        private val id: String,
        private val languages: Set<String>,
        private val catalog: List<VoiceProfile>
    ) : TtsEngine, VoiceCatalogProvider {
        override val providerId = id
        override val displayName = id
        override val mode = TtsProviderMode.MOCK
        override fun isAvailable() = true
        override fun supportedLanguages() = languages
        override fun supportsLanguage(languageCode: String) =
            languages.any { it.equals(languageCode, ignoreCase = true) }
        override fun voiceCatalog() = catalog
        override suspend fun synthesize(request: TtsSynthesisRequest): TtsSynthesisResult {
            error("Not used by VoiceIntelligence tests")
        }
    }
}


