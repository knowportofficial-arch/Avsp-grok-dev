package com.avsp.pro.audio.wav

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.nio.ByteBuffer
import java.nio.ByteOrder

class WavDurationTest {
    private fun wav(rate: Int, channels: Int, seconds: Double, dataSizeField: Int? = null, extraChunk: Boolean = false): ByteArray {
        val data = (rate * channels * 2 * seconds).toInt()
        val extra = if (extraChunk) 8 + 26 else 0
        val b = ByteBuffer.allocate(44 + extra + data).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()); b.putInt(36 + extra + data); b.put("WAVE".toByteArray())
        b.put("fmt ".toByteArray()); b.putInt(16); b.putShort(1); b.putShort(channels.toShort())
        b.putInt(rate); b.putInt(rate * channels * 2); b.putShort((channels * 2).toShort()); b.putShort(16)
        if (extraChunk) { b.put("LIST".toByteArray()); b.putInt(26); b.put(ByteArray(26)) }
        b.put("data".toByteArray()); b.putInt(dataSizeField ?: data)
        return b.array()
    }

    @Test fun phone_tts_24khz_is_measured_correctly() {
        // The old code assumed 16 kHz and returned 3000 ms here (1.5x too long).
        assertEquals(2000L, WavEncoder.durationMsFromWav(wav(24_000, 1, 2.0)))
    }

    @Test fun other_rates_extra_chunks_and_streaming_size() {
        assertEquals(1500L, WavEncoder.durationMsFromWav(wav(22_050, 1, 1.5, extraChunk = true)))
        assertEquals(1000L, WavEncoder.durationMsFromWav(wav(16_000, 2, 1.0)))
        assertEquals(2000L, WavEncoder.durationMsFromWav(wav(24_000, 1, 2.0, dataSizeField = -1)))
    }

    @Test fun not_a_wav_gives_null() {
        assertNull(WavEncoder.durationMsFromWav(ByteArray(100)))
    }
}
