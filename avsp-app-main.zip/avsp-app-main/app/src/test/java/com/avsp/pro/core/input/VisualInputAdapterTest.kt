﻿package com.avsp.pro.core.input

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class VisualInputAdapterTest {

    @Test
    fun screenshotMimeIsClassifiedAsScreenshot() {
        val result = VisualInputAdapter.adapt(
            locator = "content://media/external/images/101",
            displayName = "capture_101",
            mimeType = "image/screenshot"
        )
        assertNotNull(result)
        assertEquals(VisualInputAdapter.VisualInputKind.SCREENSHOT, result!!.kind)
        assertEquals(UnifiedInputType.SCREENSHOT, result.input.type)
    }

    @Test
    fun screenshotFilenameIsClassifiedAsScreenshot() {
        val result = VisualInputAdapter.adapt(
            locator = "/storage/emulated/0/Pictures/Screenshot_20260929.png",
            displayName = "Screenshot_20260929.png",
            mimeType = "image/png"
        )
        assertNotNull(result)
        assertEquals(VisualInputAdapter.VisualInputKind.SCREENSHOT, result!!.kind)
        assertEquals(UnifiedInputType.SCREENSHOT, result.input.type)
    }

    @Test
    fun imageMimeIsClassifiedAsImage() {
        val result = VisualInputAdapter.adapt(
            locator = "content://media/external/images/202",
            displayName = "photo.jpg",
            mimeType = "image/jpeg"
        )
        assertNotNull(result)
        assertEquals(VisualInputAdapter.VisualInputKind.IMAGE, result!!.kind)
        assertEquals(UnifiedInputType.IMAGE, result.input.type)
    }

    @Test
    fun imageExtensionIsClassifiedAsImage() {
        val result = VisualInputAdapter.adapt(
            locator = "/storage/emulated/0/Pictures/photo.webp",
            displayName = "photo.webp"
        )
        assertNotNull(result)
        assertEquals(VisualInputAdapter.VisualInputKind.IMAGE, result!!.kind)
        assertEquals(UnifiedInputType.IMAGE, result.input.type)
    }

    @Test
    fun contentUriIsPreserved() {
        val locator = "content://media/external/images/303"
        val result = VisualInputAdapter.adapt(
            locator = locator,
            displayName = "sample.png",
            mimeType = "image/png"
        )
        assertNotNull(result)
        assertEquals(locator, result!!.input.locator)
    }

    @Test
    fun metadataIdentifiesM13() {
        val result = VisualInputAdapter.adapt(
            locator = "content://media/external/images/404",
            displayName = "photo.jpg",
            mimeType = "image/jpeg"
        )
        assertNotNull(result)
        assertEquals("M13", result!!.input.metadata["adapter"])
    }

    @Test
    fun nonImageInputIsRejected() {
        val result = VisualInputAdapter.adapt(
            locator = "https://example.com/video.mp4",
            displayName = "video.mp4",
            mimeType = "video/mp4"
        )
        assertNull(result)
    }

    @Test
    fun emptyLocatorIsRejected() {
        val result = VisualInputAdapter.adapt(
            locator = "   ",
            displayName = "photo.jpg",
            mimeType = "image/jpeg"
        )
        assertNull(result)
    }
}
