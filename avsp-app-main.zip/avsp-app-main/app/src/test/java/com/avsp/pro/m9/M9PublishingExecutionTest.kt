﻿package com.avsp.pro.m9

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class M9PublishingExecutionTest {

    private fun job(
        status: M9Status = M9Status.READY,
        platforms: Set<M9Platform> = setOf(M9Platform.YOUTUBE)
    ): M9Job {

        val file =
            File.createTempFile(
                "avsp-m99-",
                ".mp4"
            )

        file.writeText("test-video")

        return M9Job(
            jobId = "job-m99",
            projectId = "project-m99",
            videoPath = file.absolutePath,
            title = "M9.9 Test",
            platforms = platforms,
            status = status,
            attempt = 0,
            maxAttempts = 3
        )
    }

    private fun configuration(
        provider: M9ProviderId,
        protocol: M9AuthProtocol = M9AuthProtocol.NONE,
        credentialPresent: Boolean = false
    ): M9ProviderAuthConfiguration {

        return M9ProviderAuthConfiguration(
            providerId = provider.name,
            protocol = protocol,
            enabled = true,
            clientId =
                if (protocol == M9AuthProtocol.OAUTH2) {
                    "client-m99"
                } else {
                    ""
                },
            redirectUri =
                if (protocol == M9AuthProtocol.OAUTH2) {
                    "https://example.com/oauth/callback"
                } else {
                    ""
                },
            scopes =
                if (protocol == M9AuthProtocol.OAUTH2) {
                    setOf("upload")
                } else {
                    emptySet()
                },
            credentialPresent = credentialPresent
        )
    }

    private fun configurations(
        vararg values: M9ProviderAuthConfiguration
    ): Map<String, M9ProviderAuthConfiguration> {
        return values.associateBy { it.providerId }
    }

    @Test
    fun blockedPreflightPreventsProviderExecution() {

        val original = job()

        val result =
            M9PublishingExecution.execute(
                job = original,
                configurations = emptyMap(),
                credentialStore = M9InMemoryCredentialStore()
            )

        assertEquals(
            M9ExecutionStatus.BLOCKED,
            result.status
        )

        assertEquals(
            listOf(M9Platform.YOUTUBE),
            result.blockedPlatforms
        )

        assertTrue(result.executedPlatforms.isEmpty())
        assertTrue(result.failedPlatforms.isEmpty())
    }

    @Test
    fun configuredButNotConfiguredProviderNeverClaimsExternalSuccess() {

        val original = job()

        val result =
            M9PublishingExecution.execute(
                job = original,
                configurations =
                    configurations(
                        configuration(
                            M9ProviderId.YOUTUBE
                        )
                    ),
                credentialStore = M9InMemoryCredentialStore()
            )

        assertEquals(
            M9ExecutionStatus.FAILED,
            result.status
        )

        assertTrue(result.executedPlatforms.isEmpty())

        assertEquals(
            listOf(M9Platform.YOUTUBE),
            result.failedPlatforms
        )

        assertFalse(
            result.platforms.any {
                it.providerResult?.realOperationPerformed == true
            }
        )
    }

    @Test
    fun allSelectedPlatformsAreEvaluated() {

        val original =
            job(
                platforms =
                    setOf(
                        M9Platform.YOUTUBE,
                        M9Platform.FACEBOOK,
                        M9Platform.INSTAGRAM
                    )
            )

        val result =
            M9PublishingExecution.execute(
                job = original,
                configurations =
                    configurations(
                        configuration(M9ProviderId.YOUTUBE),
                        configuration(M9ProviderId.FACEBOOK),
                        configuration(M9ProviderId.INSTAGRAM)
                    ),
                credentialStore = M9InMemoryCredentialStore()
            )

        assertEquals(
            3,
            result.platforms.size
        )

        assertEquals(
            listOf(
                M9Platform.FACEBOOK,
                M9Platform.INSTAGRAM,
                M9Platform.YOUTUBE
            ),
            result.platforms.map { it.platform }
        )
    }

    @Test
    fun identityIsPreserved() {

        val original = job()

        val result =
            M9PublishingExecution.execute(
                job = original,
                configurations =
                    configurations(
                        configuration(M9ProviderId.YOUTUBE)
                    ),
                credentialStore = M9InMemoryCredentialStore()
            )

        assertEquals(
            "project-m99",
            result.projectId
        )

        assertEquals(
            "job-m99",
            result.jobId
        )
    }

    @Test
    fun credentialValueNeverAppearsInExecutionResult() {

        val original = job()

        val store =
            M9InMemoryCredentialStore()

        val secret =
            "SUPER_SECRET_ACCESS_TOKEN_M99"

        store.put(
            M9CredentialKey(
                M9ProviderId.YOUTUBE.name,
                M9CredentialType.OAUTH_ACCESS_TOKEN
            ),
            secret
        )

        val result =
            M9PublishingExecution.execute(
                job = original,
                configurations =
                    configurations(
                        configuration(
                            provider = M9ProviderId.YOUTUBE,
                            protocol = M9AuthProtocol.OAUTH2,
                            credentialPresent = true
                        )
                    ),
                credentialStore = store
            )

        val rendered = result.toString()

        assertFalse(
            rendered.contains(secret)
        )

        assertNotNull(result)
    }

    @Test
    fun nonReadyJobIsBlockedByPreflight() {

        val original =
            job(
                status = M9Status.DRAFT
            )

        val result =
            M9PublishingExecution.execute(
                job = original,
                configurations =
                    configurations(
                        configuration(
                            M9ProviderId.YOUTUBE
                        )
                    ),
                credentialStore = M9InMemoryCredentialStore()
            )

        assertEquals(
            M9ExecutionStatus.BLOCKED,
            result.status
        )

        assertTrue(
            result.executedPlatforms.isEmpty()
        )
    }
}
