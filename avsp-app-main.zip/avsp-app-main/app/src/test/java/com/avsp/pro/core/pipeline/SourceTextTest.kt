package com.avsp.pro.core.pipeline

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SourceTextTest {

    @Test fun youtube_oembed_title_and_channel() {
        val r = SourceText.parseOEmbed("""{"title":"How rockets land","author_name":"Science Hub","type":"video"}""")
        assertEquals("How rockets land" to "Science Hub", r)
    }

    @Test fun youtube_description_and_captions_from_watch_page() {
        val html = """{"videoDetails":{"videoId":"x","title":"t","shortDescription":"Rockets land using grid fins.\nThey slow down with engines.\nhttps://link.example\n#space","isCrawlable":true},...""" +
            """"captionTracks":[{"baseUrl":"https://www.youtube.com/api/timedtext?v=x&lang=hi"},{"baseUrl":"https://www.youtube.com/api/timedtext?v=x&lang=en"}]"""
        val d = SourceText.youTubeDescription(html)
        assertTrue(d, d.contains("grid fins") && d.contains("slow down"))
        assertFalse(d.contains("http"))
        assertFalse(d.contains("#space"))
        assertEquals("https://www.youtube.com/api/timedtext?v=x&lang=en", SourceText.youTubeCaptionUrl(html))
        val xml = """<transcript><text start="0" dur="2">The booster comes back</text><text start="2" dur="2">and lands on a ship &amp;#39;Of course&amp;#39;</text><text start="4" dur="1">[Music]</text></transcript>"""
        assertEquals("The booster comes back and lands on a ship 'Of course'", SourceText.parseCaptions(xml))
    }

    @Test fun youtube_description_of_another_video_is_ignored() {
        val html = """{"videoDetails":{"videoId":"OTHER","shortDescription":"Nanoplastics and health"}} {"videoDetails":{"videoId":"jNQXAC9IVRw","shortDescription":"The first video on YouTube."}}"""
        assertEquals("The first video on YouTube.", SourceText.youTubeDescription(html, "jNQXAC9IVRw"))
        assertEquals("", SourceText.youTubeDescription("""{"videoDetails":{"videoId":"OTHER","shortDescription":"Nanoplastics"}}""", "jNQXAC9IVRw"))
    }

    @Test fun article_headline_summary_and_paragraphs_without_noise() {
        val html = """<html><head><title>ISRO launches weather satellite | The Hindu</title>
            <meta property="og:title" content="ISRO launches new weather satellite - The Hindu" />
            <meta name="description" content="The satellite will improve cyclone warnings." /></head>
            <body><nav><p>Home News Sports Business Opinion Entertainment and more links here</p></nav>
            <p>The Indian Space Research Organisation launched a new weather satellite on Thursday morning from Sriharikota.</p>
            <p>Subscribe to our newsletter to get the latest news every single morning in your inbox.</p>
            <p>Short.</p>
            <p>Scientists said the satellite will help coastal states prepare for cyclones much earlier than before.</p>
            <script>var x = "<p>this is script text that should never appear in the article</p>";</script>
            </body></html>"""
        val a = SourceText.parseArticle(html)
        assertEquals("ISRO launches new weather satellite", a.title)
        assertEquals("The satellite will improve cyclone warnings.", a.summary)
        assertTrue(a.body, a.body.contains("Sriharikota") && a.body.contains("coastal states"))
        assertFalse(a.body, a.body.contains("newsletter") || a.body.contains("script text") || a.body.contains("Sports"))
    }

    @Test fun text_title_is_first_sentence() {
        assertEquals("Kharagpur weather today", SourceText.titleFromText("Kharagpur weather today. It will rain in the evening."))
        assertEquals("", SourceText.titleFromText("  "))
    }

    @Test fun short_titles_lose_known_site_names() {
        assertEquals("Kharagpur", SourceText.cleanTitleSite("Kharagpur - Wikipedia"))
        assertEquals("Spider - Man", SourceText.cleanTitleSite("Spider - Man"))
    }

    @Test fun entities_are_decoded() {
        assertEquals("Tom & Jerry's “show”", SourceText.decodeEntities("Tom &amp; Jerry&#39;s &#8220;show&#8221;"))
    }

    @Test fun numeric_gallery_names_become_friendly_titles() {
        assertEquals("Photo", friendlyFileTitle("1000528295", "image/png"))
        assertEquals("PDF document", friendlyFileTitle("1000528296", "application/pdf"))
        assertEquals("Holiday trip", friendlyFileTitle("Holiday_trip.jpg", "image/jpeg"))
    }

    @Test fun encyclopedia_noise_is_removed() {
        val raw = "Kharagpur ( Bengali: [ kʰɔɽɔɡɔpuɾ ] ⓘ) is a semi- planned city. [ 6 ] It is located 120 km west of Kolkata.[citation needed]"
        assertEquals("Kharagpur is a semi-planned city. It is located 120 km west of Kolkata.", SourceText.stripReferenceNoise(raw))
    }
}
