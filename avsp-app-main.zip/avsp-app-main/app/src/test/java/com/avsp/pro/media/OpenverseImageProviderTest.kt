package com.avsp.pro.media

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class OpenverseImageProviderTest {
    private val p = OpenverseImageProvider({ error("no network") }, { _, _ -> error("no network") })

    @Test fun picks_first_large_photo_and_keeps_credit() {
        val raw = """{"results":[
            {"id":"a","url":"https://x.org/logo.svg","width":2000,"height":3000,"creator":"A","license":"by"},
            {"id":"b","url":"https://x.org/small.jpg","width":300,"height":400,"creator":"B","license":"by"},
            {"id":"c","url":"https://live.staticflickr.com/1/train.jpg","width":1600,"height":2400,"creator":"Rail Fan","license":"by-sa"}]}"""
        val pic = p.pick(raw)!!
        assertEquals("c", pic.id)
        assertEquals("Rail Fan · CC BY-SA", pic.credit)
    }

    @Test fun relevant_pictures_first_unrelated_dropped() {
        val raw = """{"results":[
            {"id":"ad","url":"https://x.org/ad.jpg","width":1600,"height":2400,"title":"Old milk food advert","tags":[{"name":"vintage"}]},
            {"id":"w","url":"https://x.org/w.jpg","width":1600,"height":2400,"title":"Glass of water","tags":[{"name":"drink"},{"name":"water"}]}]}"""
        assertEquals(listOf("w"), p.pickAll(raw, "drinking water").map { it.id })
    }

    @Test fun nothing_usable_gives_null() {
        assertNull(p.pick("""{"results":[]}"""))
    }

    @Test fun falls_back_to_any_category_when_photographs_find_nothing() {
        val calls = mutableListOf<String>()
        val town = """{"results":[{"id":"k","url":"https://upload.wikimedia.org/k.jpg","width":2000,"height":1500,"title":"Kharagpur railway station","tags":[]}]}"""
        val provider = OpenverseImageProvider({ url ->
            calls += url
            if (url.contains("category=photograph")) """{"results":[]}""" else town
        }, { _, _ -> })
        assertEquals(listOf("k"), provider.candidates("kharagpur", portrait = true).map { it.id })
        assertEquals(3, calls.size)
    }

    @Test fun all_requests_failing_is_reported() {
        val failure = runCatching {
            OpenverseImageProvider({ error("Openverse HTTP 500") }, { _, _ -> }).candidates("water", true)
        }.exceptionOrNull()
        assertEquals("Openverse HTTP 500", failure?.message)
    }
}
