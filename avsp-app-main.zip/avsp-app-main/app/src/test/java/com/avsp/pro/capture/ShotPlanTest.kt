package com.avsp.pro.capture

import com.avsp.pro.script.contract.ScriptScene
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ShotPlanTest {
    private fun scene(i: Int, text: String) = ScriptScene("s$i", i, 5_000, text)

    private val platform = listOf(
        scene(0, "I am at Kharagpur, one of the longest railway platforms in the world."),
        scene(1, "The station name board in three languages."),
        scene(2, "Watch the express train arriving at full speed."),
        scene(3, "Tea stalls and the hand of a vendor pouring chai."),
        scene(4, "Follow for more!")
    )

    @Test fun anyTopicGetsAShotPerSceneExceptTheCta() {
        val plan = ShotPlanner.offline("I am at Kharagpur railway platform", platform)
        assertEquals(listOf("s0", "s1", "s2", "s3"), plan.map { it.sceneId })
        assertEquals(TopicKind.PLACE, ShotPlanner.kind("I am at Kharagpur railway platform"))
        assertEquals(TopicKind.RECIPE, ShotPlanner.kind("Chicken soup recipe"))
        // "I am at ..." opener -> selfie with the front camera
        assertEquals(Framing.SELFIE, plan[0].framing); assertEquals(Lens.FRONT, plan[0].lens)
        // name board -> photo
        assertFalse(plan[1].video)
        // train arriving -> slow motion, filmed fast
        assertTrue(plan[2].slowMotion); assertEquals(60, plan[2].fps)
    }

    @Test fun placeWithoutSelfieOpensWithUltraWidePan() {
        val scenes = listOf(scene(0, "The longest platform stretches far away."), scene(1, "Close look at the old clock."), scene(2, "Subscribe!"))
        val plan = ShotPlanner.offline("Kharagpur railway platform", scenes)
        assertEquals(Framing.WIDE, plan[0].framing); assertEquals(Lens.ULTRA_WIDE, plan[0].lens); assertEquals(Movement.PAN, plan[0].movement)
        assertTrue(plan[0].seconds >= 5)
        assertTrue(plan[0].summary().startsWith("Wide · 0.5× · Video"))
    }

    @Test fun geminiPlanIsReadAndMissingScenesFallBack() {
        val json = """```json
            [{"scene":1,"instruction":"Stand at the end, pan slowly","framing":"wide","video":true,"seconds":20,"lens":"ULTRA_WIDE","movement":"PAN","fps":30,"uhd":true},
             {"scene":3,"instruction":"Train arriving","framing":"MEDIUM","video":true,"seconds":4,"lens":"MAIN","movement":"STATIC","slow_motion":true}]
            ```"""
        val plan = ShotPlanner.parse(json, platform)!!
        assertEquals(4, plan.size)
        assertEquals("Stand at the end, pan slowly", plan[0].instruction)
        assertEquals(Framing.WIDE, plan[0].framing); assertEquals(12, plan[0].seconds); assertTrue(plan[0].uhd)
        assertTrue(plan[2].slowMotion); assertEquals(60, plan[2].fps)
        assertFalse(plan[1].video) // scene 2 missing -> phone plan (photo of the board)
        assertNull(ShotPlanner.parse("sorry", platform))
    }

    @Test fun slowClipFillsTheSceneExactly() {
        val src = com.avsp.pro.video.engine.VideoClipPlanner.pieces(4_000, 2_501)
        val out = com.avsp.pro.video.engine.VideoClipPlanner.slowPieces(src, 0.5f, 5_003)
        assertEquals(5_003L, out.sumOf { it.durationMs })
        assertEquals(src.map { it.startMs to it.endMs }, out.map { it.startMs to it.endMs })
        // a short slow clip loops, still exact
        val loop = com.avsp.pro.video.engine.VideoClipPlanner.slowPieces(com.avsp.pro.video.engine.VideoClipPlanner.pieces(1_000, 2_500), 0.5f, 5_000)
        assertEquals(5_000L, loop.sumOf { it.durationMs }); assertEquals(3, loop.size)
    }

    @Test fun slowMotionSpeedFollowsRecordedFps() {
        assertEquals(0.25f, ShotPlanner.slowSpeed(120))
        assertEquals(0.5f, ShotPlanner.slowSpeed(60))
        assertEquals(0.7f, ShotPlanner.slowSpeed(30))
    }
}
