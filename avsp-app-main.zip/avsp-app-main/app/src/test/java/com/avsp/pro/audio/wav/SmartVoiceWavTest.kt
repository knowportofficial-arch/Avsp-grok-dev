package com.avsp.pro.audio.wav

import com.avsp.pro.audio.engine.SmartVoiceEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class SmartVoiceWavTest {
    private fun wav(rate: Int, channels: Int, frames: Int): ByteArray {
        val pcm = ByteArray(frames * channels * 2) { i -> if (i % 2 == 0) (i / 2 % 100).toByte() else 0 }
        return SmartVoiceEngine.pcmToWav(pcm, rate, channels)
    }

    @Test fun everyVoiceBecomes24kMonoWithTheSameLength() {
        // 1 s at 22.05 kHz stereo (phone voice) -> 1 s at 24 kHz mono
        val out = SmartVoiceEngine.to24kMono(wav(22_050, 2, 22_050))
        assertEquals(44 + 24_000 * 2, out.size)
        assertEquals(1_000L, SmartVoiceEngine.durationMs(out))
        // already 24 kHz mono keeps its length
        assertEquals(500L, SmartVoiceEngine.durationMs(SmartVoiceEngine.to24kMono(wav(24_000, 1, 12_000))))
    }

    @Test fun geminiAudioReplyIsDecoded() {
        val pcm = ByteArray(4_800) { 1 }
        val b64 = java.util.Base64.getEncoder().encodeToString(pcm)
        val raw = """{"candidates":[{"content":{"parts":[{"inlineData":{"mimeType":"audio/L16;codec=pcm;rate=24000","data":"$b64"}}]}}]}"""
        assertEquals(4_800, SmartVoiceEngine.geminiPcm(raw)!!.size)
        assertNull(SmartVoiceEngine.geminiPcm("""{"candidates":[]}"""))
        assertNotNull(SmartVoiceEngine.xml("a & <b>").takeIf { it == "a &amp; &lt;b&gt;" })
    }

    @Test fun longSilenceAtTheEndsIsCut() {
        // 1 s silence + 0.5 s sound + 2 s silence at 24 kHz
        val pcm = java.io.ByteArrayOutputStream()
        fun put(v: Int, frames: Int) = repeat(frames) { pcm.write(v and 0xff); pcm.write((v shr 8) and 0xff) }
        put(0, 24_000); put(5_000, 12_000); put(0, 48_000)
        val out = SmartVoiceEngine.trimSilence(SmartVoiceEngine.pcmToWav(pcm.toByteArray(), 24_000))
        // 120 ms before + 500 ms sound + 250 ms after (+1 frame)
        assertEquals(870L, SmartVoiceEngine.durationMs(out))
    }
}
