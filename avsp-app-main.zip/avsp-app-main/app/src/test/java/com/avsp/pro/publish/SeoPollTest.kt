package com.avsp.pro.publish

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SeoPollTest {
    @Test fun aiPollIsRead() {
        val seo = SeoKit.parse("""{"title":"Chicken curry in 15 min","description":"x","tags":[],"hashtags":[],
            "poll":{"question":"Spicy or mild?","options":["Spicy 🔥","Mild","Both | any"]}}""")!!
        assertEquals("Spicy or mild?|Spicy 🔥|Mild|Both / any", seo.poll)
    }

    @Test fun pollWithOneAnswerIsDropped() {
        assertEquals("", SeoKit.parse("""{"title":"T","poll":{"question":"Q?","options":["only"]}}""")!!.poll)
    }

    @Test fun offlinePollFitsTheTopic() {
        assertTrue(SeoKit.offlinePoll("Easy Indian chicken curry recipe", "en").startsWith("Will you cook this"))
        assertTrue(SeoKit.offlinePoll("Kharagpur railway platform", "en").startsWith("Have you been here"))
        assertEquals(3, SeoKit.offlinePoll("Why the sky is blue", "bn").split('|').size)
    }
}
