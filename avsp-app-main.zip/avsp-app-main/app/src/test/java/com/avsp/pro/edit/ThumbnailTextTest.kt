package com.avsp.pro.edit

import org.junit.Assert.assertEquals
import org.junit.Test

class ThumbnailTextTest {
    @Test fun short_punchy_title_with_highlight() {
        val l = ThumbnailText.make("Kharagpur Book Fair 2026 opens at the town hall - The Statesman")
        assertEquals(listOf("KHARAGPUR", "BOOK", "FAIR", "2026", "OPENS"), l.words) // 7 words would end on "the"
        assertEquals(3, l.highlight) // the number
        assertEquals("DRINKING ENOUGH WATER KEEPS THE BODY HEALTHY", ThumbnailText.make("Drinking enough water keeps the body healthy").words.joinToString(" "))
        val w = ThumbnailText.make("Weather today in Kharagpur")
        assertEquals("KHARAGPUR", w.words[w.highlight])
    }

    @Test fun bengali_title_kept_as_is() {
        val l = ThumbnailText.make("আজ খড়গপুরে বৃষ্টি")
        assertEquals(listOf("আজ", "খড়গপুরে", "বৃষ্টি"), l.words)
    }
}
