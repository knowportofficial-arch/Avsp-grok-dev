﻿package com.avsp.pro.m9

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class M9ProviderAuthBoundaryTest {

    @Test
    fun oauthWithoutClientId_requiresConfiguration() {
        val result = M9ProviderAuthBoundary.evaluate(
            M9ProviderAuthConfiguration(
                providerId = "YOUTUBE",
                protocol = M9AuthProtocol.OAUTH2,
                redirectUri = "https://example.com/oauth/callback",
                scopes = setOf("upload")
            )
        )

        assertEquals(M9AuthReadiness.CONFIGURATION_REQUIRED, result.readiness)
        assertFalse(result.configured)
    }

    @Test
    fun oauthWithValidConfiguration_isReadyForAuthWithoutPretendingAuthenticated() {
        val result = M9ProviderAuthBoundary.evaluate(
            M9ProviderAuthConfiguration(
                providerId = "YOUTUBE",
                protocol = M9AuthProtocol.OAUTH2,
                clientId = "client-id",
                redirectUri = "https://example.com/oauth/callback",
                scopes = setOf("upload")
            )
        )

        assertEquals(M9AuthReadiness.READY_FOR_AUTH, result.readiness)
        assertTrue(result.configured)
        assertFalse(result.credentialPresent)
    }

    @Test
    fun oauthWithCredentialPresence_reportsAuthenticatedBoundaryOnly() {
        val result = M9ProviderAuthBoundary.evaluate(
            M9ProviderAuthConfiguration(
                providerId = "YOUTUBE",
                protocol = M9AuthProtocol.OAUTH2,
                clientId = "client-id",
                redirectUri = "https://example.com/oauth/callback",
                scopes = setOf("upload"),
                credentialPresent = true
            )
        )

        assertEquals(M9AuthReadiness.AUTHENTICATED, result.readiness)
        assertTrue(result.credentialPresent)
        assertTrue(result.message.contains("outside M9.4"))
    }

    @Test
    fun oauthRejectsNonHttpsRedirectUri() {
        val result = M9ProviderAuthBoundary.evaluate(
            M9ProviderAuthConfiguration(
                providerId = "FACEBOOK",
                protocol = M9AuthProtocol.OAUTH2,
                clientId = "client-id",
                redirectUri = "http://example.com/callback",
                scopes = setOf("publish")
            )
        )

        assertEquals(M9AuthReadiness.INVALID, result.readiness)
    }

    @Test
    fun oauthRequiresScopes() {
        val result = M9ProviderAuthBoundary.evaluate(
            M9ProviderAuthConfiguration(
                providerId = "INSTAGRAM",
                protocol = M9AuthProtocol.OAUTH2,
                clientId = "client-id",
                redirectUri = "https://example.com/callback"
            )
        )

        assertEquals(M9AuthReadiness.CONFIGURATION_REQUIRED, result.readiness)
    }

    @Test
    fun apiKeyWithoutCredentialDoesNotClaimAuthenticated() {
        val result = M9ProviderAuthBoundary.evaluate(
            M9ProviderAuthConfiguration(
                providerId = "WEB",
                protocol = M9AuthProtocol.API_KEY
            )
        )

        assertEquals(M9AuthReadiness.READY_FOR_AUTH, result.readiness)
        assertFalse(result.credentialPresent)
    }

    @Test
    fun apiKeyWithCredentialPresenceReportsAuthenticatedBoundary() {
        val result = M9ProviderAuthBoundary.evaluate(
            M9ProviderAuthConfiguration(
                providerId = "WEB",
                protocol = M9AuthProtocol.API_KEY,
                credentialPresent = true
            )
        )

        assertEquals(M9AuthReadiness.AUTHENTICATED, result.readiness)
        assertTrue(result.credentialPresent)
    }

    @Test
    fun disabledProviderRequiresConfiguration() {
        val result = M9ProviderAuthBoundary.evaluate(
            M9ProviderAuthConfiguration(
                providerId = "TELEGRAM",
                protocol = M9AuthProtocol.API_KEY,
                enabled = false,
                credentialPresent = true
            )
        )

        assertEquals(M9AuthReadiness.CONFIGURATION_REQUIRED, result.readiness)
        assertFalse(result.configured)
    }

    @Test
    fun noAuthProviderIsNotRequired() {
        val result = M9ProviderAuthBoundary.evaluate(
            M9ProviderAuthConfiguration(
                providerId = "WEB",
                protocol = M9AuthProtocol.NONE
            )
        )

        assertEquals(M9AuthReadiness.NOT_REQUIRED, result.readiness)
        assertTrue(result.configured)
        assertFalse(result.credentialPresent)
    }

    @Test
    fun blankProviderIdIsInvalid() {
        val result = M9ProviderAuthBoundary.evaluate(
            M9ProviderAuthConfiguration(
                providerId = "   ",
                protocol = M9AuthProtocol.OAUTH2
            )
        )

        assertEquals(M9AuthReadiness.INVALID, result.readiness)
        assertFalse(result.configured)
    }
}
