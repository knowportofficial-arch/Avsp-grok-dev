package com.avsp.pro.core.pipeline

import com.avsp.pro.script.contract.DurationRequest
import com.avsp.pro.script.contract.ScriptGenerationRequest
import com.avsp.pro.script.generator.SmartOfflineScriptGenerator
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PublishKitTest {
    private val topic = "ISRO launches new weather satellite from Sriharikota - The Hindu\n\n" +
        "The Indian Space Research Organisation launched a new weather satellite on Thursday morning. " +
        "The satellite will improve cyclone warnings for coastal states. " +
        "Scientists said the launch went exactly as planned."

    private fun script() = runBlocking {
        SmartOfflineScriptGenerator().generate(ScriptGenerationRequest("p", topic, "en", DurationRequest.Explicit(30_000L)))
    }

    @Test fun kit_has_clean_title_description_and_hashtags() {
        val kit = PublishKit.from(script(), portrait = true)
        assertEquals("ISRO launches new weather satellite from Sriharikota", kit.title)
        assertTrue(kit.description, kit.description.contains("cyclone warnings"))
        assertTrue(kit.description, kit.description.endsWith("Like, share and follow!"))
        assertTrue(kit.hashtags.toString(), kit.hashtags.contains("#ISRO") && kit.hashtags.contains("#Shorts"))
        assertTrue(kit.hashtags.size <= 8)
        assertEquals(kit.hashtags.size, kit.hashtags.map { it.lowercase() }.toSet().size)
        assertTrue(kit.caption.startsWith(kit.title + "\n\n"))
        assertTrue(!kit.caption.contains("http"))
    }

    @Test fun long_text_is_cut_on_a_word() {
        val s = PublishKit.shorten("word ".repeat(60), 50)
        assertTrue(s.length <= 50)
        assertTrue(s.endsWith("word…"))
    }
}
