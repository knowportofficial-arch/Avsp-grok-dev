﻿package com.avsp.pro.audio.processing

import com.avsp.pro.audio.wav.WavEncoder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AudioPostProcessorTest {

    private fun tone(seed: String, durationMs: Long): ByteArray =
        WavEncoder.synthesizeToneWav(seed, durationMs)

    @Test
    fun concatenatesNarrationWithExpectedDuration() {
        val result = AudioPostProcessor.process(
            listOf(tone("a", 1000), tone("b", 1500))
        )
        assertEquals(2500L, result.durationMs)
        assertTrue(result.wavBytes.size > 44)
    }

    @Test
    fun appliesLeadingAndTrailingSilence() {
        val result = AudioPostProcessor.process(
            listOf(tone("a", 1000)),
            AudioPostProcessor.Options(
                leadingSilenceMs = 250,
                trailingSilenceMs = 500
            )
        )
        assertEquals(1750L, result.durationMs)
    }

    @Test
    fun appliesIntroAndOutro() {
        val result = AudioPostProcessor.process(
            listOf(tone("n", 1000)),
            AudioPostProcessor.Options(
                introWav = tone("i", 400),
                outroWav = tone("o", 600)
            )
        )
        assertEquals(2000L, result.durationMs)
    }

    @Test
    fun musicIsMixedAndOutputIsNormalized() {
        val result = AudioPostProcessor.process(
            listOf(tone("n", 1200)),
            AudioPostProcessor.Options(
                musicWav = tone("m", 500),
                musicGain = 0.08f,
                normalizePeak = 0.90f
            )
        )
        assertEquals(1200L, result.durationMs)
        assertTrue(result.peakAfterNormalization <= 0.901f)
        assertTrue(result.peakBeforeNormalization > 0f)
    }

    @Test
    fun rejectsIncompatibleInputs() {
        val wav = tone("a", 500)
        var failed = false
        try {
            AudioPostProcessor.process(
                listOf(wav, wav.copyOfRange(0, wav.size - 2))
            )
        } catch (_: IllegalArgumentException) {
            failed = true
        }
        assertTrue(failed)
    }
}
