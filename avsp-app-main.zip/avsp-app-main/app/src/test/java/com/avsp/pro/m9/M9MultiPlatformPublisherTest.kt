﻿package com.avsp.pro.m9

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class M9MultiPlatformPublisherTest {

    private fun video(): File {
        return File.createTempFile("avsp-m93-", ".mp4").apply {
            writeText("test-video")
            deleteOnExit()
        }
    }

    private fun job(
        platforms: Set<M9Platform>
    ): M9Job {
        return M9Job(
            projectId = "project-m93",
            videoPath = video().absolutePath,
            title = "M9.3 Test",
            platforms = platforms,
            status = M9Status.READY
        )
    }

    @Test
    fun allSelectedPlatformsAreEvaluatedIndependently() {
        val result = M9MultiPlatformPublisher.prepare(
            job(
                setOf(
                    M9Platform.YOUTUBE,
                    M9Platform.FACEBOOK,
                    M9Platform.INSTAGRAM
                )
            )
        )

        assertEquals(3, result.results.size)
        assertEquals(
            setOf(
                M9Platform.YOUTUBE,
                M9Platform.FACEBOOK,
                M9Platform.INSTAGRAM
            ),
            result.results.map { it.platform }.toSet()
        )
    }

    @Test
    fun unconfiguredPlatformsNeverClaimSuccessfulPublishing() {
        val result = M9MultiPlatformPublisher.prepare(
            job(setOf(M9Platform.YOUTUBE, M9Platform.FACEBOOK))
        )

        assertEquals(M9MultiPlatformStatus.FAILED, result.status)
        assertEquals(
            setOf(M9Platform.YOUTUBE, M9Platform.FACEBOOK),
            result.notConfiguredPlatforms
        )

        result.results.forEach {
            assertEquals(M9PlatformPublishStatus.NOT_CONFIGURED, it.status)
            assertFalse(it.realOperationPerformed)
            assertEquals(null, it.externalId)
        }
    }

    @Test
    fun everyM9PlatformCanBeEvaluated() {
        val result = M9MultiPlatformPublisher.prepare(
            job(M9Platform.entries.toSet())
        )

        assertEquals(
            M9Platform.entries.toSet(),
            result.notConfiguredPlatforms
        )

        assertEquals(
            M9Platform.entries.size,
            result.results.size
        )
    }

    @Test
    fun originalJobRemainsReadyDuringPreparation() {
        val job = job(setOf(M9Platform.YOUTUBE))

        val result = M9MultiPlatformPublisher.prepare(job)

        assertEquals(M9Status.READY, job.status)
        assertEquals(M9MultiPlatformStatus.FAILED, result.status)
    }

    @Test
    fun rejectsNonReadyJob() {
        val job = M9Job(
            projectId = "project",
            videoPath = video().absolutePath,
            title = "Test",
            platforms = setOf(M9Platform.YOUTUBE),
            status = M9Status.DRAFT
        )

        try {
            M9MultiPlatformPublisher.prepare(job)
            throw AssertionError("Expected IllegalArgumentException")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message!!.contains("READY"))
        }
    }

    @Test
    fun rejectsMissingVideo() {
        val job = M9Job(
            projectId = "project",
            videoPath = "C:\\missing\\m93.mp4",
            title = "Test",
            platforms = setOf(M9Platform.YOUTUBE),
            status = M9Status.READY
        )

        try {
            M9MultiPlatformPublisher.prepare(job)
            throw AssertionError("Expected IllegalArgumentException")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message!!.contains("does not exist"))
        }
    }

    @Test
    fun rejectsEmptyPlatformSet() {
        val job = M9Job(
            projectId = "project",
            videoPath = video().absolutePath,
            title = "Test",
            platforms = emptySet(),
            status = M9Status.READY
        )

        try {
            M9MultiPlatformPublisher.prepare(job)
            throw AssertionError("Expected IllegalArgumentException")
        } catch (e: IllegalArgumentException) {
            assertTrue(e.message!!.contains("at least one"))
        }
    }

    @Test
    fun preservesProjectAndJobIdentity() {
        val job = job(setOf(M9Platform.TELEGRAM))

        val result = M9MultiPlatformPublisher.prepare(job)

        assertEquals(job.projectId, result.projectId)
        assertEquals(job.jobId, result.jobId)
        assertEquals(1, result.results.size)
    }
}
