package com.avsp.pro.screen.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * P0 frame-local privacy model tests.
 *
 * Pure JVM: uses PrivacyBox (not android.graphics.RectF, whose fields are
 * stubbed to zero in local unit tests).
 */
class ScreenPrivacyTrackerTest {

    private fun box(cx: Float, cy: Float, w: Float = 0.20f, h: Float = 0.03f) =
        PrivacyBox(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)

    private fun obs(
        t: Long,
        cx: Float,
        cy: Float,
        key: String = "9876543210",
        type: SensitiveDataType = SensitiveDataType.PHONE
    ) = PrivacyObservation(t, type, box(cx, cy), key)

    private fun contains(outer: PrivacyBox, inner: PrivacyBox) =
        outer.left <= inner.left + 1e-4f &&
            outer.top <= inner.top + 1e-4f &&
            outer.right >= inner.right - 1e-4f &&
            outer.bottom >= inner.bottom - 1e-4f

    private fun coveredBy(boxes: List<PrivacyBox>, content: PrivacyBox) =
        boxes.any { contains(it, content) }

    private fun overlapsArea(boxes: List<PrivacyBox>, area: PrivacyBox) =
        boxes.any { it.iou(area) > 0f }

    // ------------------------------------------------------------------

    @Test
    fun scrolling_region_is_one_track_that_follows_content() {
        // Content scrolls up 0.1 per 200 ms.
        val samples = listOf(0L, 200L, 400L, 600L, 800L, 1000L)
        val o = samples.mapIndexed { i, t -> obs(t, 0.5f, 0.8f - 0.1f * i) }

        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 1000L)

        assertEquals(1, plan.tracks.size)
        assertEquals(6, plan.tracks[0].keyframes.size)
    }

    @Test
    fun moving_content_is_covered_at_every_millisecond() {
        // LEAK TEST: true content moves linearly; every frame must be covered.
        val samples = (0L..1000L step 200L).toList()
        val o = samples.map { t -> obs(t, 0.5f, 0.8f - 0.5f * (t / 1000f)) }
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 1000L)

        for (t in 0L..1000L) {
            val trueContent = box(0.5f, 0.8f - 0.5f * (t / 1000f))
            assertTrue(
                "content uncovered at t=$t",
                coveredBy(plan.boxesAt(t), trueContent)
            )
        }
    }

    @Test
    fun no_ghost_mosaic_left_at_old_position_during_motion() {
        // Frame N: region A at y=0.80. Then fast scroll; dense samples follow it.
        val samples = listOf(1000L, 1200L, 1400L, 1600L, 1800L, 2000L)
        val ys = listOf(0.80f, 0.65f, 0.50f, 0.35f, 0.20f, 0.05f)
        val o = samples.zip(ys).map { (t, y) -> obs(t, 0.5f, y) }
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 3000L)

        val oldPositionA = box(0.5f, 0.80f)

        // OLD model kept A until 2500 ms. NEW model: gone once content has moved on.
        for (t in 1300L..2000L step 50L) {
            assertFalse(
                "ghost mosaic at old position A at t=$t",
                overlapsArea(plan.boxesAt(t), oldPositionA)
            )
        }
    }

    @Test
    fun region_ends_at_next_sample_where_content_is_absent() {
        // Sensitive text visible at 0..1000, gone at 1200 (scrolled away / screen changed).
        val samples = listOf(0L, 1000L, 1200L, 1400L, 3000L)
        val o = listOf(obs(0L, 0.5f, 0.5f), obs(1000L, 0.5f, 0.5f))
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 3000L)

        assertTrue(plan.boxesAt(1000L).isNotEmpty())
        assertTrue(plan.boxesAt(1150L).isNotEmpty())   // still uncertain until 1200
        assertTrue(plan.boxesAt(1201L).isEmpty())      // confirmed absent -> no mosaic
        assertTrue(plan.boxesAt(2500L).isEmpty())
    }

    @Test
    fun last_region_does_not_persist_to_final_frame_when_content_left() {
        // Final frame (2960 ms) was sampled and contains no sensitive data.
        val samples = listOf(0L, 1000L, 2000L, 2200L, 2400L, 2600L, 2800L, 2960L)
        val o = listOf(
            obs(0L, 0.5f, 0.5f),
            obs(1000L, 0.5f, 0.5f),
            obs(2000L, 0.5f, 0.5f),
            obs(2200L, 0.5f, 0.3f)
        )
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 3000L)

        assertTrue(plan.boxesAt(2960L).isEmpty())
        assertTrue(plan.boxesAt(3000L).isEmpty())
    }

    @Test
    fun region_present_on_final_sample_is_kept_to_end_of_video() {
        val samples = listOf(0L, 1000L, 1960L)
        val o = samples.map { obs(it, 0.5f, 0.5f) }
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 2000L)

        assertTrue(plan.boxesAt(2000L).isNotEmpty())
    }

    @Test
    fun static_region_is_covered_continuously_with_failed_ocr_sample() {
        // OCR failed at 1000 -> 1000 is NOT a sample. Coverage must not gap.
        val samples = listOf(0L, 2000L, 3000L)
        val o = listOf(obs(0L, 0.5f, 0.5f), obs(2000L, 0.5f, 0.5f))
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 3000L)

        for (t in 0L..2000L step 10L) {
            assertTrue("gap at t=$t", coveredBy(plan.boxesAt(t), box(0.5f, 0.5f)))
        }
    }

    @Test
    fun appearing_content_has_lead_in_only_back_to_previous_sample() {
        val samples = listOf(0L, 200L, 400L)
        val o = listOf(obs(400L, 0.5f, 0.5f))
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 1000L)

        assertTrue(plan.boxesAt(199L).isEmpty())
        assertTrue(plan.boxesAt(200L).isNotEmpty())
        assertTrue(plan.boxesAt(400L).isNotEmpty())
    }

    @Test
    fun separate_values_become_separate_tracks() {
        val samples = listOf(0L, 200L)
        val o = listOf(
            obs(0L, 0.5f, 0.20f, key = "111111"),
            obs(0L, 0.5f, 0.70f, key = "222222"),
            obs(200L, 0.5f, 0.15f, key = "111111"),
            obs(200L, 0.5f, 0.65f, key = "222222")
        )
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 400L)

        assertEquals(2, plan.tracks.size)
        assertEquals(2, plan.boxesAt(100L).size)
    }

    @Test
    fun latin_and_devanagari_duplicates_merge_into_one_box() {
        val samples = listOf(0L)
        val o = listOf(
            PrivacyObservation(0L, SensitiveDataType.OTP, PrivacyBox(0.40f, 0.50f, 0.60f, 0.53f), "949147"),
            PrivacyObservation(0L, SensitiveDataType.OTP, PrivacyBox(0.41f, 0.50f, 0.61f, 0.53f), "949147")
        )
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 1000L)

        assertEquals(1, plan.tracks.size)
        val b = plan.boxesAt(0L).single()
        assertTrue(b.left <= 0.40f && b.right >= 0.61f)
    }

    @Test
    fun boxes_are_clamped_to_frame() {
        val samples = listOf(0L, 200L)
        val o = listOf(obs(0L, 0.5f, 0.05f), obs(200L, 0.5f, 0.01f))
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 600L)

        for (t in 0L..600L step 20L) {
            plan.boxesAt(t).forEach {
                assertTrue(it.left >= 0f && it.top >= 0f && it.right <= 1f && it.bottom <= 1f)
            }
        }
    }

    @Test
    fun indexed_lookup_matches_brute_force() {
        val samples = (0L..10_000L step 200L).toList()
        val o = mutableListOf<PrivacyObservation>()
        samples.forEachIndexed { i, t ->
            if (i % 7 < 4) o += obs(t, 0.3f, 0.9f - 0.02f * (i % 7), key = "a${i / 7}")
            if (i % 5 < 3) o += obs(t, 0.7f, 0.5f, key = "b${i / 5}", type = SensitiveDataType.NUMBER)
        }
        val plan = ScreenPrivacyTracker.build(o, samples, durationMs = 10_000L)

        for (t in 0L..10_000L step 37L) {
            val brute = plan.tracks.mapNotNull { ScreenPrivacyTracker.boxForTrackAt(it, t) }
            assertEquals("t=$t", brute.toSet(), plan.boxesAt(t).toSet())
        }
    }

    @Test
    fun empty_input_gives_empty_plan() {
        val plan = ScreenPrivacyTracker.build(emptyList(), listOf(0L, 1000L), 1000L)
        assertTrue(plan.isEmpty)
        assertTrue(plan.boxesAt(500L).isEmpty())
    }
}
