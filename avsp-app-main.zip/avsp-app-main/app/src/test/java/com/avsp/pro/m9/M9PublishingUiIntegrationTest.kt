﻿package com.avsp.pro.m9

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Test

class M9PublishingUiIntegrationTest {

    @Test
    fun notConfiguredProviderIsReportedExplicitly() {
        val state = M9PublishingUiIntegration.providerState(M9ProviderId.YOUTUBE)

        assertNotNull(state)
        assertEquals("YOUTUBE", state.provider)
        assertEquals("NOT_CONFIGURED", state.providerMode)
        assertEquals("NOT_CONFIGURED", state.authState)
        assertFalse(state.realOperationPerformed)
        assertEquals(null, state.externalId)
    }

    @Test
    fun allProvidersRemainExplicitlyNonRealUntilConfigured() {
        M9ProviderId.entries.forEach { provider ->
            val state = M9PublishingUiIntegration.providerState(provider)

            assertEquals(provider.name, state.provider)
            assertFalse(state.realOperationPerformed)
            assertEquals(null, state.externalId)
        }
    }
}
