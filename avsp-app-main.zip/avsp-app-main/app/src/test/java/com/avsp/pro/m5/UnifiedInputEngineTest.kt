﻿package com.avsp.pro.m5

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class UnifiedInputEngineTest {

    @Test
    fun youtubeUrl_isDetectedAsYoutube() {
        val result =
            M5InputEngine.analyzeUnifiedText(
                "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
            )

        assertEquals(
            UnifiedInputKind.YOUTUBE,
            result.kind
        )

        assertEquals(
            "dQw4w9WgXcQ",
            result.youtubeId
        )
    }

    @Test
    fun genericHttpsUrl_isDetectedAsUrl() {
        val result =
            M5InputEngine.analyzeUnifiedText(
                "https://example.com/story"
            )

        assertEquals(
            UnifiedInputKind.URL,
            result.kind
        )

        assertTrue(
            "URL confidence must be greater than zero; actual=${result.confidence}",
            result.confidence > 0.0
        )
    }

    @Test
    fun plainText_extractsNumbers() {
        val result =
            M5InputEngine.analyzeUnifiedText(
                "Gold price is 123456.78 today"
            )

        assertEquals(
            UnifiedInputKind.TEXT,
            result.kind
        )

        assertTrue(
            result.numbers.contains(123456.78)
        )
    }

    @Test
    fun mimeTypes_areClassified() {

        assertEquals(
            UnifiedInputKind.IMAGE,
            M5InputEngine.classifyUnifiedMimeType(
                "image/jpeg"
            )
        )

        assertEquals(
            UnifiedInputKind.VIDEO,
            M5InputEngine.classifyUnifiedMimeType(
                "video/mp4"
            )
        )

        assertEquals(
            UnifiedInputKind.AUDIO,
            M5InputEngine.classifyUnifiedMimeType(
                "audio/mpeg"
            )
        )

        assertEquals(
            UnifiedInputKind.DOCUMENT,
            M5InputEngine.classifyUnifiedMimeType(
                "application/pdf"
            )
        )
    }
}
