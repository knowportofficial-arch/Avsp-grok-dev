package com.avsp.pro.media

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class GalleryMatchTest {
    private val temple = GalleryLibrary.Item(1, false, 3, listOf("temple", "building", "sky"))
    private val lunch = GalleryLibrary.Item(2, false, 2, listOf("food", "dish", "table"))
    private val selfie = GalleryLibrary.Item(3, false, 5, listOf("selfie", "smile", "sky"))
    private val river = GalleryLibrary.Item(4, true, 1, listOf("water", "boat"))
    private val all = listOf(temple, lunch, selfie, river)

    @Test fun picksMatchingPhoto() {
        assertEquals(temple, GalleryLibrary.match(all, listOf("temples", "kolkata"), emptySet()))
        assertEquals(lunch, GalleryLibrary.match(all, listOf("street", "food"), emptySet()))
        assertEquals(river, GalleryLibrary.match(all, listOf("river", "cruise"), emptySet()))
    }

    @Test fun neverAPrivateSelfieForATopicAndNoReuse() {
        assertEquals(temple, GalleryLibrary.match(all, listOf("sky"), emptySet()))
        assertNull(GalleryLibrary.match(listOf(selfie), listOf("sky"), emptySet()))
        assertNull(GalleryLibrary.match(all, listOf("temple"), setOf(temple.key)))
        assertNull(GalleryLibrary.match(all, listOf("cricket"), emptySet()))
    }

    @Test fun skipsScreenshotsAndOwnOutputs() {
        assertEquals(true, GalleryLibrary.skipFolder("Pictures/Screenshots/"))
        assertEquals(true, GalleryLibrary.skipFolder("Movies/AVSP/"))
        assertEquals(false, GalleryLibrary.skipFolder("DCIM/Camera/"))
    }

    @Test fun anAirplaneCabinIsNotATrain() {
        val cabin = GalleryLibrary.Item(7, false, 9, listOf("train", "vehicle", "seat", "aircraft"))
        val track = GalleryLibrary.Item(8, false, 1, listOf("track", "train", "sky"))
        assertEquals(track, GalleryLibrary.match(listOf(cabin, track), listOf("trains", "platform"), emptySet()))
        assertNull(GalleryLibrary.match(listOf(cabin), listOf("train"), emptySet()))
        // "vehicle" alone no longer counts as a train picture
        assertNull(GalleryLibrary.match(listOf(GalleryLibrary.Item(9, false, 1, listOf("vehicle", "road"))), listOf("train"), emptySet()))
    }

    @Test fun aBroadLabelAloneIsNotAMatch() {
        val campus = GalleryLibrary.Item(10, false, 1, listOf("building", "tree", "sky"))
        // "IIT main gate building" - only broad labels would match a random building photo -> no.
        assertNull(GalleryLibrary.match(listOf(campus), listOf("IIT", "main", "gate"), emptySet()))
        // but a scene that really says "building" may use it
        assertEquals(campus, GalleryLibrary.match(listOf(campus), listOf("old", "building"), emptySet()))
    }

    @Test fun aFestivalSceneNeverGetsTheCreatorsSelfie() {
        val selfieCrowd = GalleryLibrary.Item(9, false, 9, listOf("selfie", "smile", "fun", "community"))
        assertNull(GalleryLibrary.match(listOf(selfieCrowd), listOf("durga", "puja", "crowd", "community", "festival"), emptySet()))
        assertEquals(selfieCrowd, GalleryLibrary.match(listOf(selfieCrowd), listOf("my", "selfie", "community", "smile"), emptySet()))
    }

    @Test fun ownEventShotsAreUsedAndLabelledByTheirFolder() {
        assertEquals(false, GalleryLibrary.skipFolder("Movies/AVSP/Events/2026-10-19_Ashtami_ABC-pandal/"))
        val l = GalleryLibrary.eventLabels("Movies/AVSP/Events/2026-10-19_Ashtami_ABC-Sarbojanin-pandal/")
        assertEquals(true, "ashtami" in l && "pandal" in l && "puja" in l)
        val shot = GalleryLibrary.Item(20, true, 1, l)
        assertEquals(shot, GalleryLibrary.match(listOf(shot), listOf("ashtami", "pandal", "lights"), emptySet()))
    }
}
