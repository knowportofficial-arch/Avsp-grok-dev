package com.avsp.pro.capture

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate
import java.time.LocalDateTime

class EventInfoTest {
    private val at = LocalDateTime.of(2026, 10, 19, 19, 42)
    private val e = EventInfo("ABC Sarbojanin pandal", "Kumartuli, Kolkata", "Durga Puja - Maha Ashtami", 22.6, 88.36, at, listOf("Aarti", "Dhak"))

    @Test fun shotsAreNamedAndFiledByDateDayAndPlace() {
        assertEquals("2026-10-19_Ashtami_ABC-Sarbojanin-pandal", e.folder)
        assertEquals("2026-10-19_1942_Ashtami_ABC-Sarbojanin-pandal_03.mp4", e.fileName(3, true, at))
    }

    @Test fun topicIsFirstPersonWithPlaceAndDay() {
        val t = e.topic()
        assertTrue(t, t.startsWith("LIVE EVENT: I am at ABC Sarbojanin pandal, Kumartuli, Kolkata, on Durga Puja - Maha Ashtami"))
        assertTrue(t.contains("Aarti, Dhak"))
        assertEquals(TopicKind.EVENT, ShotPlanner.kind(t))
    }

    @Test fun eventSurvivesTheProjectMetadata() {
        val back = EventInfo.fromMetadata(e.metadata())!!
        assertEquals(e.folder, back.folder); assertEquals(22.6, back.latitude!!, 1e-6)
    }

    @Test fun pujaDays2026() {
        assertEquals("Durga Puja - Maha Ashtami", FestivalCalendar.dayFor(LocalDate.of(2026, 10, 19)))
        assertEquals(null, FestivalCalendar.dayFor(LocalDate.of(2026, 10, 13)))
    }
}
