$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$files = @(
    "app/src/main/java/com/avsp/pro/m8/M8Timeline.kt",
    "app/src/main/java/com/avsp/pro/video/contract/VideoContracts.kt",
    "app/src/main/java/com/avsp/pro/video/engine/Media3VideoEngine.kt"
)
$backup = Join-Path $root "_avsp_backups\M4_emoji_music_v2"
New-Item -ItemType Directory -Force -Path $backup | Out-Null

foreach ($f in $files) {
    $src = Join-Path $root $f
    if (!(Test-Path $src)) { throw "Required source file not found: $f" }
    $dst = Join-Path $backup $f
    New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
    Copy-Item $src $dst -Force
}

function Restore-All {
    foreach ($f in $files) {
        $src = Join-Path $backup $f
        $dst = Join-Path $root $f
        if (Test-Path $src) { Copy-Item $src $dst -Force }
    }
    $newFiles = @(
        "app/src/main/java/com/avsp/pro/video/engine/TimedEmojiOverlay.kt"
    )
    foreach ($f in $newFiles) {
        $p = Join-Path $root $f
        if (Test-Path $p) { Remove-Item $p -Force }
    }
}

try {
    # ---------- M8Timeline.kt ----------
    $m8Path = Join-Path $root "app/src/main/java/com/avsp/pro/m8/M8Timeline.kt"
    $m8 = Get-Content $m8Path -Raw

    if ($m8 -notmatch 'data class M8EmojiEvent') {
        $anchor = 'data class M8CaptionEvent(val start: Double, val end: Double, val text: String, val emphasis: Boolean = false)'
        if ($m8 -notlike "*$anchor*") { throw "M8 caption event anchor not found." }
        $m8 = $m8.Replace(
            $anchor,
            $anchor + "`r`ndata class M8EmojiEvent(val start: Double, val end: Double, val emoji: String, val emphasis: Boolean = false)"
        )
    }

    if ($m8 -notmatch 'val emojiEvents: List<M8EmojiEvent>') {
        $anchor = '    val captions: List<M8CaptionEvent> = emptyList(),'
        if ($m8 -notlike "*$anchor*") { throw "M8 captions property anchor not found." }
        $m8 = $m8.Replace(
            $anchor,
            $anchor + "`r`n    val emojiEvents: List<M8EmojiEvent> = emptyList(),"
        )
    }

    if ($m8 -notmatch 'emojiEvents.forEach') {
        $anchor = '        if (duration < 0) add("duration cannot be negative")'
        if ($m8 -notlike "*$anchor*") { throw "M8 validation anchor not found." }
        $validation = @'
        emojiEvents.forEach { emoji ->
            if (emoji.start < 0.0) add("emoji start cannot be negative")
            if (emoji.end <= emoji.start) add("emoji end must be greater than start")
            if (emoji.emoji.isBlank()) add("emoji content is required")
        }
'@
        $m8 = $m8.Replace($anchor, $anchor + "`r`n" + $validation.TrimEnd())
    }

    Set-Content $m8Path $m8 -Encoding UTF8

    # ---------- VideoContracts.kt ----------
    $vcPath = Join-Path $root "app/src/main/java/com/avsp/pro/video/contract/VideoContracts.kt"
    $vc = Get-Content $vcPath -Raw

    if ($vc -notmatch 'data class VideoEmojiInput') {
        $anchor = @'
data class VideoCaptionInput(
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val emphasis: Boolean = false
)
'@
        if ($vc -notlike "*$anchor*") { throw "VideoCaptionInput anchor not found." }
        $emojiContract = @'
data class VideoEmojiInput(
    val startMs: Long,
    val endMs: Long,
    val emoji: String,
    val emphasis: Boolean = false
)
'@
        $vc = $vc.Replace($anchor, $anchor + $emojiContract)
    }

    if ($vc -notmatch 'val emojis: List<VideoEmojiInput>') {
        $anchor = '    val captions: List<VideoCaptionInput> = emptyList()'
        if ($vc -notlike "*$anchor*") { throw "VideoSceneInput captions anchor not found." }
        $vc = $vc.Replace($anchor, $anchor + ",`r`n    val emojis: List<VideoEmojiInput> = emptyList()")
    }

    if ($vc -notmatch 'val timelineEmojis = timeline.emojiEvents') {
        $anchor = '        val timelineVisuals = timeline.visuals.sortedBy { it.start }'
        if ($vc -notlike "*$anchor*") { throw "Timeline visuals anchor not found." }
        $vc = $vc.Replace(
            $anchor,
            $anchor + "`r`n        val timelineEmojis = timeline.emojiEvents.sortedBy { it.start }"
        )

        $anchor = @'
                val captionText = sceneCaptions
                    .joinToString(" ") { it.text }
                    .ifBlank { null }

                VideoSceneInput(
'@
        if ($vc -notlike "*$anchor*") { throw "Scene caption mapping anchor not found." }

        $emojiMapping = @'
                val sceneEmojis = timelineEmojis
                    .filter { emoji ->
                        emoji.end > sceneStart && emoji.start < sceneEnd
                    }
                    .map { emoji ->
                        VideoEmojiInput(
                            startMs = maxOf(segment.startMs, (emoji.start * 1000.0).toLong()),
                            endMs = minOf(segment.endMs, (emoji.end * 1000.0).toLong()),
                            emoji = emoji.emoji,
                            emphasis = emoji.emphasis
                        )
                    }
                    .filter { it.endMs > it.startMs && it.emoji.isNotBlank() }

'@
        $vc = $vc.Replace(
            $anchor,
            @'
                val captionText = sceneCaptions
                    .joinToString(" ") { it.text }
                    .ifBlank { null }

'@ + $emojiMapping + @'
                VideoSceneInput(
'@
        )

        $anchor = '                    overlayText = captionText,`r`n                    captions = sceneCaptions'
        if ($vc -notlike "*$anchor*") { throw "VideoSceneInput constructor anchor not found." }
        $vc = $vc.Replace(
            $anchor,
            "                    overlayText = captionText,`r`n                    captions = sceneCaptions,`r`n                    emojis = sceneEmojis"
        )
    }

    Set-Content $vcPath $vc -Encoding UTF8

    # ---------- TimedEmojiOverlay.kt ----------
    $emojiPath = Join-Path $root "app/src/main/java/com/avsp/pro/video/engine/TimedEmojiOverlay.kt"
    if (!(Test-Path $emojiPath)) {
        New-Item -ItemType Directory -Force -Path (Split-Path $emojiPath) | Out-Null
        @'
package com.avsp.pro.video.engine

import android.graphics.Typeface
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.TextOverlay
import com.avsp.pro.video.contract.VideoEmojiInput

@UnstableApi
class TimedEmojiOverlay(
    private val events: List<VideoEmojiInput>
) : TextOverlay() {

    override fun getText(presentationTimeUs: Long): SpannableString? {
        val timeMs = presentationTimeUs / 1000L
        val event = events.firstOrNull { timeMs >= it.startMs && timeMs < it.endMs }
            ?: return null

        val text = SpannableString(event.emoji)
        if (event.emphasis && text.isNotEmpty()) {
            text.setSpan(StyleSpan(Typeface.BOLD), 0, text.length, 0)
            text.setSpan(RelativeSizeSpan(1.25f), 0, text.length, 0)
        }
        return text
    }
}
'@ | Set-Content $emojiPath -Encoding UTF8
    }

    # ---------- Renderer ----------
    $rPath = Join-Path $root "app/src/main/java/com/avsp/pro/video/engine/Media3VideoEngine.kt"
    $r = Get-Content $rPath -Raw

    if ($r -notmatch 'import com\.avsp\.pro\.video\.engine\.TimedEmojiOverlay') {
        $anchor = 'import com.avsp.pro.video.engine.TimedTextOverlay'
        if ($r -notlike "*$anchor*") { throw "TimedTextOverlay import not found." }
        $r = $r.Replace($anchor, $anchor + "`r`nimport com.avsp.pro.video.engine.TimedEmojiOverlay")
    }

    if ($r -notmatch 'scene\.emojis\.isNotEmpty\(\)') {
        $anchor = @'
                if (scene.captions.isNotEmpty()) {
                    videoEffects += OverlayEffect(
                        listOf(TimedTextOverlay(scene.captions))
                    )
                } else {
                    scene.overlayText?.takeIf { it.isNotBlank() }?.let { text ->
                        videoEffects += OverlayEffect(
                            listOf(TextOverlay.createStaticTextOverlay(SpannableString(text)))
                        )
                    }
                }
'@
        if ($r -notlike "*$anchor*") { throw "Current timed-caption renderer block not found." }
        $replacement = $anchor + @'
                if (scene.emojis.isNotEmpty()) {
                    videoEffects += OverlayEffect(
                        listOf(TimedEmojiOverlay(scene.emojis))
                    )
                }
'@
        $r = $r.Replace($anchor, $replacement)
    }

    if ($r -notmatch 'backgroundMusicSequence') {
        $anchor = @'
          val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)
          val audioSequence = EditedMediaItemSequence.withAudioFrom(audioItems)
          val composition = Composition.Builder(videoSequence, audioSequence).build()
'@
        if ($r -notlike "*$anchor*") {
            $anchor = @'
          val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)
          val audioSequence = EditedMediaItemSequence.withAudioFrom(audioItems)
          val composition = Composition.Builder(videoSequence, audioSequence).build()
'@
        }
        if ($r -notlike "*$anchor*") { throw "Composition audio anchor not found." }

        $replacement = @'
          val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)
          val audioSequence = EditedMediaItemSequence.withAudioFrom(audioItems)

          val musicSequence = plan.musicRelativePath?.let { musicPath ->
              val musicFile = File(
                  storage.resolve(StorageArea.PROJECT_DATA, musicPath, plan.projectId)
              )
              require(musicFile.exists()) { "Missing background music: $musicPath" }

              val backgroundMusic = EditedMediaItem.Builder(
                  MediaItem.fromUri(Uri.fromFile(musicFile))
              ).build()

              EditedMediaItemSequence
                  .withAudioFrom(listOf(backgroundMusic))
                  .buildUpon()
                  .setIsLooping(true)
                  .build()
          }

          val composition = if (musicSequence != null) {
              Composition.Builder(
                  com.google.common.collect.ImmutableList.of(
                      videoSequence,
                      audioSequence,
                      musicSequence
                  )
              ).build()
          } else {
              Composition.Builder(videoSequence, audioSequence).build()
          }
'@
        $r = $r.Replace($anchor, $replacement)
    }

    Set-Content $rPath $r -Encoding UTF8

    # ---------- Focused verification ----------
    Write-Host "Running focused M4 tests..."
    & .\gradlew.bat :app:testDebugUnitTest --tests "*M8TimelineRenderBridgeTest" --tests "*TimedCaptionSelectorTest" --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Focused tests failed." }

    Write-Host "Running full verification..."
    & .\gradlew.bat clean test assembleDebug --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Full build/test failed." }

    Write-Host ""
    Write-Host "M4 EMOJI + BACKGROUND MUSIC V2 SUCCESSFUL."
    Write-Host "Emoji: timed Unicode overlay."
    Write-Host "Music: looped background audio sequence mixed with narration."
    Write-Host "No music path: existing narration-only composition preserved."
}
catch {
    Write-Host "PATCH FAILED. Restoring previous source..."
    Restore-All
    Write-Host $_.Exception.Message
    exit 1
}
