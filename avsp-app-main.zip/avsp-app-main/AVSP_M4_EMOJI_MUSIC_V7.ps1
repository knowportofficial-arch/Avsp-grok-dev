$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$backup = Join-Path $root "_avsp_backups\M4_emoji_music_v7"

$protected = @(
    "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt",
    "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt",
    "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
)

$newFiles = @(
    "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt",
    "app\src\test\java\com\avsp\pro\video\M4EmojiMusicContractTest.kt"
)

function Read-Lines([string]$relativePath) {
    return [string[]]@(Get-Content -LiteralPath (Join-Path $root $relativePath))
}

function Write-Lines([string]$relativePath, [string[]]$lines) {
    Set-Content -LiteralPath (Join-Path $root $relativePath) -Value $lines -Encoding UTF8
}

function Insert-AfterText([string[]]$lines, [string]$pattern, [string[]]$insert, [string]$label) {
    $idx = -1
    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ([string]$lines[$i] -match $pattern) {
            $idx = $i
            break
        }
    }
    if ($idx -lt 0) { throw "$label anchor not found: $pattern" }

    $out = [System.Collections.Generic.List[string]]::new()
    for ($i = 0; $i -le $idx; $i++) { [void]$out.Add([string]$lines[$i]) }
    foreach ($x in $insert) { [void]$out.Add([string]$x) }
    for ($i = $idx + 1; $i -lt $lines.Count; $i++) { [void]$out.Add([string]$lines[$i]) }
    return [string[]]$out.ToArray()
}

function Replace-Text([string[]]$lines, [string]$pattern, [string]$replacement, [string]$label) {
    $count = 0
    $out = [System.Collections.Generic.List[string]]::new()
    foreach ($line in $lines) {
        if ([string]$line -match $pattern) {
            $count++
            [void]$out.Add($replacement)
        } else {
            [void]$out.Add([string]$line)
        }
    }
    if ($count -ne 1) { throw "$label expected exactly 1 match, found $count." }
    return [string[]]$out.ToArray()
}

function Backup-All {
    New-Item -ItemType Directory -Force $backup | Out-Null
    foreach ($rel in $protected) {
        $src = Join-Path $root $rel
        $dst = Join-Path $backup $rel
        New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
        Copy-Item -LiteralPath $src -Destination $dst -Force
    }
}

function Restore-All {
    foreach ($rel in $protected) {
        $src = Join-Path $backup $rel
        $dst = Join-Path $root $rel
        if (Test-Path -LiteralPath $src) { Copy-Item -LiteralPath $src -Destination $dst -Force }
    }
    foreach ($rel in $newFiles) {
        $p = Join-Path $root $rel
        if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force }
    }
}

try {
    Backup-All

    # ============================================================
    # 1. M8Timeline.kt
    # ============================================================
    $rel = "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt"
    [string[]]$lines = Read-Lines $rel

    if (-not ($lines -contains 'data class M8EmojiEvent(val start: Double, val end: Double, val emoji: String, val emphasis: Boolean = false)')) {
        $lines = Insert-AfterText $lines `
            '^data class M8CaptionEvent\(val start: Double, val end: Double, val text: String, val emphasis: Boolean = false\)$' `
            ([string[]]@('data class M8EmojiEvent(val start: Double, val end: Double, val emoji: String, val emphasis: Boolean = false)')) `
            "M8EmojiEvent"
    }

    if (-not ($lines -contains '    val emojiEvents: List<M8EmojiEvent> = emptyList(),')) {
        $lines = Insert-AfterText $lines `
            '^\s+val captions: List<M8CaptionEvent> = emptyList\(\),' `
            ([string[]]@('    val emojiEvents: List<M8EmojiEvent> = emptyList(),')) `
            "M8Timeline emojiEvents"
    }

    if (-not ($lines -contains '        emojiEvents.forEach { emoji ->')) {
        $lines = Insert-AfterText $lines `
            '^\s+if \(duration < 0\) add\("duration cannot be negative"\)$' `
            ([string[]]@(
                '        emojiEvents.forEach { emoji ->',
                '            if (emoji.start < 0.0) add("emoji start cannot be negative")',
                '            if (emoji.end <= emoji.start) add("emoji end must be greater than start")',
                '            if (emoji.emoji.isBlank()) add("emoji text is required")',
                '        }'
            )) `
            "M8 emoji validation"
    }

    Write-Lines $rel $lines

    # ============================================================
    # 2. VideoContracts.kt
    # ============================================================
    $rel = "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt"
    [string[]]$lines = Read-Lines $rel

    if (-not ($lines -contains 'data class VideoEmojiInput(')) {
        $start = -1
        $close = -1
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -ceq 'data class VideoCaptionInput(') {
                $start = $i
                break
            }
        }
        if ($start -lt 0) { throw "VideoCaptionInput not found." }

        for ($i = $start + 1; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -ceq ')') {
                $close = $i
                break
            }
        }
        if ($close -lt 0) { throw "VideoCaptionInput close not found." }

        $out = [System.Collections.Generic.List[string]]::new()
        for ($i = 0; $i -le $close; $i++) { [void]$out.Add([string]$lines[$i]) }
        foreach ($x in @(
            'data class VideoEmojiInput(',
            '    val startMs: Long,',
            '    val endMs: Long,',
            '    val emoji: String,',
            '    val emphasis: Boolean = false',
            ')'
        )) { [void]$out.Add($x) }
        for ($i = $close + 1; $i -lt $lines.Count; $i++) { [void]$out.Add([string]$lines[$i]) }
        $lines = [string[]]$out.ToArray()
    }

    if (-not ($lines -contains '    val emojis: List<VideoEmojiInput> = emptyList()')) {
        $lines = Insert-AfterText $lines `
            '^\s+val captions: List<VideoCaptionInput> = emptyList\(\)$' `
            ([string[]]@('    val emojis: List<VideoEmojiInput> = emptyList()')) `
            "VideoSceneInput emojis"
    }

    if (-not ($lines -contains '                val sceneEmojis = timeline.emojiEvents')) {
        $lines = Insert-AfterText $lines `
            '^\s+\.filter \{ it\.endMs > it\.startMs && it\.text\.isNotBlank\(\) \}$' `
            ([string[]]@(
                '                val sceneEmojis = timeline.emojiEvents',
                '                    .filter { emoji ->',
                '                        emoji.end > sceneStart && emoji.start < sceneEnd',
                '                    }',
                '                    .map { emoji ->',
                '                        VideoEmojiInput(',
                '                            startMs = maxOf(segment.startMs, (emoji.start * 1000.0).toLong()),',
                '                            endMs = minOf(segment.endMs, (emoji.end * 1000.0).toLong()),',
                '                            emoji = emoji.emoji,',
                '                            emphasis = emoji.emphasis',
                '                        )',
                '                    }',
                '                    .filter { it.endMs > it.startMs && it.emoji.isNotBlank() }',
                ''
            )) `
            "M8 emoji bridge"
    }

    if (-not ($lines -contains '                    emojis = sceneEmojis')) {
        $lines = Insert-AfterText $lines `
            '^\s+captions = sceneCaptions$' `
            ([string[]]@('                    emojis = sceneEmojis')) `
            "VideoSceneInput emoji assignment"
    }

    Write-Lines $rel $lines

    # ============================================================
    # 3. TimedEmojiOverlay.kt
    # ============================================================
    $rel = "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt"
    $p = Join-Path $root $rel
    New-Item -ItemType Directory -Force (Split-Path $p) | Out-Null

    Write-Lines $rel ([string[]]@(
        'package com.avsp.pro.video.engine',
        '',
        'import android.graphics.Typeface',
        'import android.text.SpannableString',
        'import android.text.style.StyleSpan',
        'import androidx.media3.effect.TextOverlay',
        'import com.avsp.pro.video.contract.VideoEmojiInput',
        '',
        '@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)',
        'class TimedEmojiOverlay(',
        '    private val emojis: List<VideoEmojiInput>',
        ') : TextOverlay() {',
        '    override fun getText(presentationTimeUs: Long): SpannableString {',
        '        val timeMs = presentationTimeUs / 1000L',
        '        val active = emojis.filter { timeMs >= it.startMs && timeMs < it.endMs }',
        '        if (active.isEmpty()) return SpannableString("")',
        '        val text = active.joinToString(" ") { it.emoji.trim() }',
        '        val result = SpannableString(text)',
        '        if (active.any { it.emphasis } && text.isNotEmpty()) {',
        '            result.setSpan(',
        '                StyleSpan(Typeface.BOLD), 0, text.length,',
        '                SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE',
        '            )',
        '        }',
        '        return result',
        '    }',
        '}'
    ))

    # ============================================================
    # 4. Media3VideoEngine.kt — based on ACTUAL uploaded source
    # ============================================================
    $rel = "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
    [string[]]$lines = Read-Lines $rel

    if (-not ($lines -contains 'import com.avsp.pro.video.engine.TimedEmojiOverlay')) {
        $lines = Insert-AfterText $lines `
            '^import com\.avsp\.pro\.video\.engine\.TimedTextOverlay$' `
            ([string[]]@('import com.avsp.pro.video.engine.TimedEmojiOverlay')) `
            "TimedEmojiOverlay import"
    }

    if (-not ($lines -contains '                if (scene.emojis.isNotEmpty()) {')) {
        $lines = Insert-AfterText $lines `
            '^\s+\}\s+else \{$' `
            ([string[]]@(
                '                if (scene.emojis.isNotEmpty()) {',
                '                    videoEffects += OverlayEffect(',
                '                        listOf(TimedEmojiOverlay(scene.emojis))',
                '                    )',
                '                }'
            )) `
            "emoji renderer"
    }

    # The actual renderer has this exact logical structure:
    #   val videoSequence = ...
    #   val audioSequence = ...
    #   val composition = Composition.Builder(videoSequence, audioSequence).build()
    # Use the actual line, not the previously assumed spacing.
    if (-not ($lines -contains '          val compositionSequences = mutableListOf(videoSequence, audioSequence)')) {
        $lines = Insert-AfterText $lines `
            '^\s+val audioSequence = EditedMediaItemSequence\.withAudioFrom\(audioItems\)$' `
            ([string[]]@(
                '          val compositionSequences = mutableListOf(videoSequence, audioSequence)',
                '          plan.musicRelativePath?.takeIf { it.isNotBlank() }?.let { musicRelativePath ->',
                '              val music = File(',
                '                  storage.resolve(StorageArea.PROJECT_DATA, musicRelativePath, plan.projectId)',
                '              )',
                '              require(music.exists()) { "Missing background music: $musicRelativePath" }',
                '',
                '              val musicItem =',
                '                  EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(music))).build()',
                '',
                '              val musicSequence =',
                '                  EditedMediaItemSequence.withAudioFrom(listOf(musicItem))',
                '                      .buildUpon()',
                '                      .setIsLooping(true)',
                '                      .build()',
                '',
                '              compositionSequences += musicSequence',
                '          }'
            )) `
            "background music sequence"
    }

    if ($lines -contains '          val composition = Composition.Builder(videoSequence, audioSequence).build()') {
        $lines = Replace-Text $lines `
            '^\s+val composition = Composition\.Builder\(videoSequence, audioSequence\)\.build\(\)$' `
            '          val composition = Composition.Builder(compositionSequences).build()' `
            "composition builder"
    }

    Write-Lines $rel $lines

    # ============================================================
    # 5. Focused regression test
    # ============================================================
    $rel = "app\src\test\java\com\avsp\pro\video\M4EmojiMusicContractTest.kt"
    $p = Join-Path $root $rel
    New-Item -ItemType Directory -Force (Split-Path $p) | Out-Null

    Write-Lines $rel ([string[]]@(
        'package com.avsp.pro.video',
        '',
        'import com.avsp.pro.audio.integration.AudioToVideoHandoff',
        'import com.avsp.pro.audio.integration.VideoAudioSegmentRef',
        'import com.avsp.pro.m8.M8EmojiEvent',
        'import com.avsp.pro.m8.M8Timeline',
        'import com.avsp.pro.video.contract.VideoRenderPlanFactory',
        'import org.junit.Assert.assertEquals',
        'import org.junit.Assert.assertTrue',
        'import org.junit.Test',
        '',
        'class M4EmojiMusicContractTest {',
        '    @Test',
        '    fun emojiAndMusicSurviveM8ToM4Bridge() {',
        '        val timeline = M8Timeline(',
        '            projectId = "p1",',
        '            duration = 4.0,',
        '            emojiEvents = listOf(M8EmojiEvent(1.0, 2.5, "🔥", true)),',
        '            musicPath = "music/bg.mp3"',
        '        )',
        '        val handoff = AudioToVideoHandoff(',
        '            projectId = "p1",',
        '            scriptId = "s1",',
        '            audioPackageId = "a1",',
        '            language = "bn",',
        '            provider = "test",',
        '            voiceId = "test-voice",',
        '            totalDurationMs = 4000L,',
        '            segments = listOf(',
        '                VideoAudioSegmentRef(',
        '                    segmentId = "seg1",',
        '                    sceneId = "scene1",',
        '                    order = 0,',
        '                    relativeAudioPath = "audio/scene1.wav",',
        '                    startMs = 0L,',
        '                    endMs = 4000L,',
        '                    durationMs = 4000L,',
        '                    language = "bn",',
        '                    voiceId = "test-voice"',
        '                )',
        '            ),',
        '            audioPackageVersion = "1.0"',
        '        )',
        '        val plan = VideoRenderPlanFactory.fromM8Timeline(timeline, handoff)',
        '        assertEquals("music/bg.mp3", plan.musicRelativePath)',
        '        assertEquals(1, plan.scenes.single().emojis.size)',
        '        assertEquals(1000L, plan.scenes.single().emojis.single().startMs)',
        '        assertEquals(2500L, plan.scenes.single().emojis.single().endMs)',
        '        assertEquals("🔥", plan.scenes.single().emojis.single().emoji)',
        '        assertTrue(plan.scenes.single().emojis.single().emphasis)',
        '    }',
        '',
        '    @Test',
        '    fun invalidEmojiTimingIsRejected() {',
        '        val errors = M8Timeline(',
        '            projectId = "p1",',
        '            duration = 2.0,',
        '            emojiEvents = listOf(M8EmojiEvent(2.0, 1.0, "🔥"))',
        '        ).validate()',
        '        assertTrue(errors.any { it.contains("emoji end") })',
        '    }',
        '}'
    ))

    Write-Host "V7 patch applied against the actual renderer source."
    Write-Host "Running focused emoji/music test..."
    & .\gradlew.bat :app:testDebugUnitTest --tests com.avsp.pro.video.M4EmojiMusicContractTest --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Focused M4 Emoji/Music test failed." }

    Write-Host "Running existing M8 bridge regression..."
    & .\gradlew.bat :app:testDebugUnitTest --tests com.avsp.pro.video.contract.M8TimelineRenderBridgeTest --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Existing M8 bridge regression failed." }

    Write-Host "Running full clean test + assembleDebug..."
    & .\gradlew.bat clean test assembleDebug --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Full verification failed." }

    Write-Host "==============================================="
    Write-Host "M4 EMOJI + MUSIC V7 SUCCESSFUL"
    Write-Host "==============================================="
}
catch {
    Write-Host "PATCH FAILED. Restoring previous source..."
    Restore-All
    Write-Host $_.Exception.Message
    exit 1
}
