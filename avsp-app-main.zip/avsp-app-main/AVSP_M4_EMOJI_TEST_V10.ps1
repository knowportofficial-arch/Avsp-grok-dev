$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$testDir = Join-Path $root "app\src\test\java\com\avsp\pro\video\engine"
$testFile = Join-Path $testDir "TimedEmojiOverlayTest.kt"
$backupDir = Join-Path $root "_avsp_backups\M4_emoji_test_v10"

New-Item -ItemType Directory -Force $testDir | Out-Null
New-Item -ItemType Directory -Force $backupDir | Out-Null

$existed = Test-Path -LiteralPath $testFile
if ($existed) {
    Copy-Item -LiteralPath $testFile -Destination (Join-Path $backupDir "TimedEmojiOverlayTest.kt") -Force
}

try {
@'
package com.avsp.pro.video.engine

import com.avsp.pro.video.contract.VideoEmojiInput
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class TimedEmojiOverlayTest {

    private fun overlay(vararg emojis: VideoEmojiInput): TimedEmojiOverlay =
        TimedEmojiOverlay(emojis.toList())

    private fun textAt(overlay: TimedEmojiOverlay, timeMs: Long): String =
        overlay.getText(timeMs * 1000L).toString()

    @Test
    fun emoji_is_hidden_before_start() {
        val o = overlay(VideoEmojiInput(1000L, 2000L, "🔥"))
        assertEquals("", textAt(o, 999L))
    }

    @Test
    fun emoji_is_visible_during_interval() {
        val o = overlay(VideoEmojiInput(1000L, 2000L, "🔥"))
        assertEquals("🔥", textAt(o, 1000L))
        assertEquals("🔥", textAt(o, 1500L))
    }

    @Test
    fun emoji_is_hidden_at_end_boundary() {
        val o = overlay(VideoEmojiInput(1000L, 2000L, "🔥"))
        assertEquals("", textAt(o, 2000L))
    }

    @Test
    fun multiple_active_emojis_are_combined_in_order() {
        val o = overlay(
            VideoEmojiInput(1000L, 3000L, "🔥"),
            VideoEmojiInput(1500L, 2500L, "🚀")
        )
        assertEquals("🔥 🚀", textAt(o, 1600L))
        assertEquals("🔥", textAt(o, 2600L))
    }

    @Test
    fun inactive_emoji_is_not_included() {
        val o = overlay(
            VideoEmojiInput(1000L, 1500L, "🔥"),
            VideoEmojiInput(2000L, 3000L, "🎯")
        )
        assertEquals("🎯", textAt(o, 2200L))
    }

    @Test
    fun emphasis_applies_bold_span_to_active_text() {
        val o = overlay(VideoEmojiInput(1000L, 2000L, "🔥", emphasis = true))
        val result = o.getText(1500L * 1000L)
        assertEquals("🔥", result.toString())
        assertTrue(result.getSpans(0, result.length, android.text.style.StyleSpan::class.java).any {
            it.style == android.graphics.Typeface.BOLD
        })
    }
}
'@ | Set-Content -LiteralPath $testFile -Encoding UTF8

Write-Host "V10 focused emoji timing test added."
Write-Host "Running only TimedEmojiOverlayTest..."
& .\gradlew.bat :app:testDebugUnitTest --tests "com.avsp.pro.video.engine.TimedEmojiOverlayTest" --no-daemon --max-workers=1
if ($LASTEXITCODE -ne 0) { throw "TimedEmojiOverlayTest failed." }

Write-Host "V10 EMOJI TIMING TEST SUCCESSFUL."
}
catch {
    Write-Host "TEST PATCH FAILED. Restoring previous test source..."
    if ($existed -and (Test-Path -LiteralPath (Join-Path $backupDir "TimedEmojiOverlayTest.kt"))) {
        Copy-Item -LiteralPath (Join-Path $backupDir "TimedEmojiOverlayTest.kt") -Destination $testFile -Force
    } elseif (Test-Path -LiteralPath $testFile) {
        Remove-Item -LiteralPath $testFile -Force
    }
    Write-Host $_.Exception.Message
    exit 1
}
