$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$backup = Join-Path $root "_avsp_backups\M4_emoji_music_v6"

$targets = @(
    "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt",
    "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt",
    "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
)

function Copy-FileSafe([string]$src, [string]$dst) {
    New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
    Copy-Item -LiteralPath $src -Destination $dst -Force
}

function Insert-Lines([string[]]$source, [string]$needle, [string[]]$insert, [string]$label) {
    $idx = -1
    for ($i = 0; $i -lt $source.Count; $i++) {
        if ([string]$source[$i] -ceq $needle) {
            $idx = $i
            break
        }
    }
    if ($idx -lt 0) {
        throw "$label anchor not found: [$needle]"
    }

    $result = New-Object System.Collections.Generic.List[string]

    for ($i = 0; $i -le $idx; $i++) {
        [void]$result.Add([string]$source[$i])
    }

    foreach ($line in $insert) {
        [void]$result.Add([string]$line)
    }

    for ($i = $idx + 1; $i -lt $source.Count; $i++) {
        [void]$result.Add([string]$source[$i])
    }

    return [string[]]$result.ToArray()
}

function Replace-One([string[]]$source, [string]$old, [string]$new, [string]$label) {
    $idx = -1
    for ($i = 0; $i -lt $source.Count; $i++) {
        if ([string]$source[$i] -ceq $old) {
            if ($idx -ge 0) {
                throw "$label found more than once."
            }
            $idx = $i
        }
    }
    if ($idx -lt 0) {
        throw "$label not found: [$old]"
    }

    $result = New-Object System.Collections.Generic.List[string]

    for ($i = 0; $i -lt $source.Count; $i++) {
        if ($i -eq $idx) {
            [void]$result.Add($new)
        } else {
            [void]$result.Add([string]$source[$i])
        }
    }

    return [string[]]$result.ToArray()
}

function Backup-All {
    foreach ($rel in $targets) {
        Copy-FileSafe (Join-Path $root $rel) (Join-Path $backup $rel)
    }
}

function Restore-All {
    foreach ($rel in $targets) {
        $src = Join-Path $backup $rel
        $dst = Join-Path $root $rel
        if (Test-Path -LiteralPath $src) {
            Copy-Item -LiteralPath $src -Destination $dst -Force
        }
    }

    $newFiles = @(
        "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt",
        "app\src\test\java\com\avsp\pro\video\M4EmojiMusicContractTest.kt"
    )

    foreach ($rel in $newFiles) {
        $p = Join-Path $root $rel
        if (Test-Path -LiteralPath $p) {
            Remove-Item -LiteralPath $p -Force
        }
    }
}

try {
    New-Item -ItemType Directory -Force $backup | Out-Null
    Backup-All

    # ------------------------------------------------------------
    # M8Timeline.kt
    # ------------------------------------------------------------
    $p = Join-Path $root "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt"
    [string[]]$lines = @(Get-Content -LiteralPath $p)

    if (-not ($lines -contains 'data class M8EmojiEvent(val start: Double, val end: Double, val emoji: String, val emphasis: Boolean = false)')) {
        $insert = [string[]]@(
            'data class M8EmojiEvent(val start: Double, val end: Double, val emoji: String, val emphasis: Boolean = false)'
        )
        $lines = Insert-Lines $lines 'data class M8CaptionEvent(val start: Double, val end: Double, val text: String, val emphasis: Boolean = false)' $insert "M8EmojiEvent"
    }

    if (-not ($lines -contains '    val emojiEvents: List<M8EmojiEvent> = emptyList(),')) {
        $insert = [string[]]@(
            '    val emojiEvents: List<M8EmojiEvent> = emptyList(),'
        )
        $lines = Insert-Lines $lines '    val captions: List<M8CaptionEvent> = emptyList(),' $insert "M8Timeline.emojiEvents"
    }

    if (-not ($lines -contains '        emojiEvents.forEach { emoji ->')) {
        $insert = [string[]]@(
            '        emojiEvents.forEach { emoji ->',
            '            if (emoji.start < 0.0) add("emoji start cannot be negative")',
            '            if (emoji.end <= emoji.start) add("emoji end must be greater than start")',
            '            if (emoji.emoji.isBlank()) add("emoji text is required")',
            '        }'
        )
        $lines = Insert-Lines $lines '        if (duration < 0) add("duration cannot be negative")' $insert "M8 emoji validation"
    }

    Set-Content -LiteralPath $p -Value $lines -Encoding UTF8

    # ------------------------------------------------------------
    # VideoContracts.kt
    # ------------------------------------------------------------
    $p = Join-Path $root "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt"
    [string[]]$lines = @(Get-Content -LiteralPath $p)

    if (-not ($lines -contains 'data class VideoEmojiInput(')) {
        $insert = [string[]]@(
            'data class VideoEmojiInput(',
            '    val startMs: Long,',
            '    val endMs: Long,',
            '    val emoji: String,',
            '    val emphasis: Boolean = false',
            ')'
        )
        $captionClose = -1
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -ceq 'data class VideoCaptionInput(') {
                for ($j = $i; $j -lt $lines.Count; $j++) {
                    if ($lines[$j] -ceq ')') {
                        $captionClose = $j
                        break
                    }
                }
                break
            }
        }
        if ($captionClose -lt 0) {
            throw "VideoCaptionInput closing line not found."
        }

        $result = New-Object System.Collections.Generic.List[string]
        for ($i = 0; $i -le $captionClose; $i++) {
            [void]$result.Add([string]$lines[$i])
        }
        foreach ($line in $insert) {
            [void]$result.Add([string]$line)
        }
        for ($i = $captionClose + 1; $i -lt $lines.Count; $i++) {
            [void]$result.Add([string]$lines[$i])
        }
        $lines = [string[]]$result.ToArray()
    }

    if (-not ($lines -contains '    val emojis: List<VideoEmojiInput> = emptyList()')) {
        $insert = [string[]]@(
            '    val emojis: List<VideoEmojiInput> = emptyList()'
        )
        $lines = Insert-Lines $lines '    val captions: List<VideoCaptionInput> = emptyList()' $insert "VideoSceneInput.emojis"
    }

    if (-not ($lines -contains '                val sceneEmojis = timeline.emojiEvents')) {
        $insert = [string[]]@(
            '                val sceneEmojis = timeline.emojiEvents',
            '                    .filter { emoji ->',
            '                        emoji.end > sceneStart && emoji.start < sceneEnd',
            '                    }',
            '                    .map { emoji ->',
            '                        VideoEmojiInput(',
            '                            startMs = maxOf(segment.startMs, (emoji.start * 1000.0).toLong()),',
            '                            endMs = minOf(segment.endMs, (emoji.end * 1000.0).toLong()),',
            '                            emoji = emoji.emoji,',
            '                            emphasis = emoji.emphasis',
            '                        )',
            '                    }',
            '                    .filter { it.endMs > it.startMs && it.emoji.isNotBlank() }',
            ''
        )
        $lines = Insert-Lines $lines '                    .filter { it.endMs > it.startMs && it.text.isNotBlank() }' $insert "M8 emoji bridge"
    }

    if (-not ($lines -contains '                    emojis = sceneEmojis')) {
        $insert = [string[]]@(
            '                    emojis = sceneEmojis'
        )
        $lines = Insert-Lines $lines '                    captions = sceneCaptions' $insert "VideoSceneInput emoji assignment"
    }

    Set-Content -LiteralPath $p -Value $lines -Encoding UTF8

    # ------------------------------------------------------------
    # TimedEmojiOverlay.kt
    # ------------------------------------------------------------
    $p = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt"
    New-Item -ItemType Directory -Force (Split-Path $p) | Out-Null

    $overlay = [string[]]@(
        'package com.avsp.pro.video.engine',
        '',
        'import android.graphics.Typeface',
        'import android.text.SpannableString',
        'import android.text.style.StyleSpan',
        'import androidx.media3.effect.TextOverlay',
        'import com.avsp.pro.video.contract.VideoEmojiInput',
        '',
        '@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)',
        'class TimedEmojiOverlay(',
        '    private val emojis: List<VideoEmojiInput>',
        ') : TextOverlay() {',
        '    override fun getText(presentationTimeUs: Long): SpannableString {',
        '        val timeMs = presentationTimeUs / 1000L',
        '        val active = emojis.filter { timeMs >= it.startMs && timeMs < it.endMs }',
        '        if (active.isEmpty()) return SpannableString("")',
        '        val text = active.joinToString(" ") { it.emoji.trim() }',
        '        val result = SpannableString(text)',
        '        if (active.any { it.emphasis } && text.isNotEmpty()) {',
        '            result.setSpan(',
        '                StyleSpan(Typeface.BOLD), 0, text.length,',
        '                SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE',
        '            )',
        '        }',
        '        return result',
        '    }',
        '}'
    )
    Set-Content -LiteralPath $p -Value $overlay -Encoding UTF8

    # ------------------------------------------------------------
    # Media3VideoEngine.kt
    # ------------------------------------------------------------
    $p = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
    [string[]]$lines = @(Get-Content -LiteralPath $p)

    if (-not ($lines -contains 'import com.avsp.pro.video.engine.TimedEmojiOverlay')) {
        $insert = [string[]]@(
            'import com.avsp.pro.video.engine.TimedEmojiOverlay'
        )
        $lines = Insert-Lines $lines 'import com.avsp.pro.video.engine.TimedTextOverlay' $insert "TimedEmojiOverlay import"
    }

    if (-not ($lines -contains '                if (scene.emojis.isNotEmpty()) {')) {
        $insert = [string[]]@(
            '                if (scene.emojis.isNotEmpty()) {',
            '                    videoEffects += OverlayEffect(',
            '                        listOf(TimedEmojiOverlay(scene.emojis))',
            '                    )',
            '                }'
        )

        $captionEnd = -1
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -ceq '                    )') {
                # Search backwards for the existing TimedTextOverlay block.
                $from = [Math]::Max(0, $i - 6)
                $found = $false
                for ($j = $from; $j -le $i; $j++) {
                    if ($lines[$j] -match 'TimedTextOverlay\(scene\.captions\)') {
                        $captionEnd = $i
                        $found = $true
                        break
                    }
                }
                if ($found) { break }
            }
        }

        if ($captionEnd -lt 0) {
            throw "Verified timed-caption effect block not found."
        }

        $result = New-Object System.Collections.Generic.List[string]
        for ($i = 0; $i -le $captionEnd; $i++) {
            [void]$result.Add([string]$lines[$i])
        }
        foreach ($line in $insert) {
            [void]$result.Add([string]$line)
        }
        for ($i = $captionEnd + 1; $i -lt $lines.Count; $i++) {
            [void]$result.Add([string]$lines[$i])
        }
        $lines = [string[]]$result.ToArray()
    }

    if (-not ($lines -contains '          val compositionSequences = mutableListOf(videoSequence, audioSequence)')) {
        $insert = [string[]]@(
            '          val compositionSequences = mutableListOf(videoSequence, audioSequence)',
            '          plan.musicRelativePath?.takeIf { it.isNotBlank() }?.let { musicRelativePath ->',
            '              val music = File(',
            '                  storage.resolve(',
            '                      StorageArea.PROJECT_DATA,',
            '                      musicRelativePath,',
            '                      plan.projectId',
            '                  )',
            '              )',
            '              require(music.exists()) { "Missing background music: $musicRelativePath" }',
            '',
            '              val musicItem =',
            '                  EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(music))).build()',
            '',
            '              val musicSequence =',
            '                  EditedMediaItemSequence.withAudioFrom(listOf(musicItem))',
            '                      .buildUpon()',
            '                      .setIsLooping(true)',
            '                      .build()',
            '',
            '              compositionSequences += musicSequence',
            '          }',
            '          val composition = Composition.Builder(compositionSequences).build()'
        )

        $lines = Insert-Lines $lines '          val audioSequence = EditedMediaItemSequence.withAudioFrom(audioItems)' $insert "music composition block"

        $old = '          val composition = Composition.Builder(videoSequence, audioSequence).build()'
        if ($lines -contains $old) {
            $lines = Replace-One $lines $old '          val composition = Composition.Builder(compositionSequences).build()' "old composition line"
        }
    }

    Set-Content -LiteralPath $p -Value $lines -Encoding UTF8

    # ------------------------------------------------------------
    # Focused contract tests
    # ------------------------------------------------------------
    $p = Join-Path $root "app\src\test\java\com\avsp\pro\video\M4EmojiMusicContractTest.kt"
    New-Item -ItemType Directory -Force (Split-Path $p) | Out-Null

    $test = [string[]]@(
        'package com.avsp.pro.video',
        '',
        'import com.avsp.pro.audio.integration.AudioToVideoHandoff',
        'import com.avsp.pro.audio.integration.VideoAudioSegmentRef',
        'import com.avsp.pro.m8.M8EmojiEvent',
        'import com.avsp.pro.m8.M8Timeline',
        'import com.avsp.pro.video.contract.VideoRenderPlanFactory',
        'import org.junit.Assert.assertEquals',
        'import org.junit.Assert.assertTrue',
        'import org.junit.Test',
        '',
        'class M4EmojiMusicContractTest {',
        '    @Test',
        '    fun emojiAndMusicSurviveM8ToM4Bridge() {',
        '        val timeline = M8Timeline(',
        '            projectId = "p1",',
        '            duration = 4.0,',
        '            emojiEvents = listOf(M8EmojiEvent(1.0, 2.5, "🔥", true)),',
        '            musicPath = "music/bg.mp3"',
        '        )',
        '        val handoff = AudioToVideoHandoff(',
        '            projectId = "p1",',
        '            scriptId = "s1",',
        '            audioPackageId = "a1",',
        '            language = "bn",',
        '            provider = "test",',
        '            voiceId = "test-voice",',
        '            totalDurationMs = 4000L,',
        '            segments = listOf(',
        '                VideoAudioSegmentRef(',
        '                    segmentId = "seg1",',
        '                    sceneId = "scene1",',
        '                    order = 0,',
        '                    relativeAudioPath = "audio/scene1.wav",',
        '                    startMs = 0L,',
        '                    endMs = 4000L,',
        '                    durationMs = 4000L,',
        '                    language = "bn",',
        '                    voiceId = "test-voice"',
        '                )',
        '            ),',
        '            audioPackageVersion = "1.0"',
        '        )',
        '        val plan = VideoRenderPlanFactory.fromM8Timeline(timeline, handoff)',
        '        assertEquals("music/bg.mp3", plan.musicRelativePath)',
        '        assertEquals(1, plan.scenes.single().emojis.size)',
        '        assertEquals(1000L, plan.scenes.single().emojis.single().startMs)',
        '        assertEquals(2500L, plan.scenes.single().emojis.single().endMs)',
        '        assertEquals("🔥", plan.scenes.single().emojis.single().emoji)',
        '        assertTrue(plan.scenes.single().emojis.single().emphasis)',
        '    }',
        '',
        '    @Test',
        '    fun invalidEmojiTimingIsRejected() {',
        '        val errors = M8Timeline(',
        '            projectId = "p1",',
        '            duration = 2.0,',
        '            emojiEvents = listOf(M8EmojiEvent(2.0, 1.0, "🔥"))',
        '        ).validate()',
        '        assertTrue(errors.any { it.contains("emoji end") })',
        '    }',
        '}'
    )
    Set-Content -LiteralPath $p -Value $test -Encoding UTF8

    Write-Host ""
    Write-Host "V6 source patch completed. Running focused test..."
    & .\gradlew.bat :app:testDebugUnitTest --tests com.avsp.pro.video.M4EmojiMusicContractTest --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Focused M4 Emoji/Music test failed." }

    Write-Host ""
    Write-Host "Running existing M8 bridge regression..."
    & .\gradlew.bat :app:testDebugUnitTest --tests com.avsp.pro.video.contract.M8TimelineRenderBridgeTest --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Existing M8 bridge regression failed." }

    Write-Host ""
    Write-Host "Running full clean test + assembleDebug..."
    & .\gradlew.bat clean test assembleDebug --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Full verification failed." }

    Write-Host ""
    Write-Host "==============================================="
    Write-Host "M4 EMOJI + MUSIC V6 SUCCESSFUL"
    Write-Host "==============================================="
}
catch {
    Write-Host ""
    Write-Host "PATCH FAILED. Restoring previous source..."
    Restore-All
    Write-Host $_.Exception.Message
    exit 1
}
