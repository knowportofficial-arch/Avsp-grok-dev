$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$backup = Join-Path $root "_avsp_backups\M4_emoji_music_v4"
$targets = @(
  "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt",
  "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt",
  "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
)
New-Item -ItemType Directory -Force $backup | Out-Null

function Backup($rel) {
  $src = Join-Path $root $rel
  $dst = Join-Path $backup $rel
  New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
  Copy-Item $src $dst -Force
}
function Restore {
  foreach ($rel in $targets) {
    $src = Join-Path $backup $rel
    $dst = Join-Path $root $rel
    if (Test-Path $src) { Copy-Item $src $dst -Force }
  }
  foreach ($rel in @(
    "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt",
    "app\src\test\java\com\avsp\pro\video\M4EmojiMusicContractTest.kt"
  )) {
    $p = Join-Path $root $rel
    if (Test-Path $p) { Remove-Item $p -Force }
  }
}

try {
  foreach ($t in $targets) { Backup $t }

  # M8Timeline.kt
  $p = Join-Path $root "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt"
  $s = Get-Content $p -Raw
  if ($s -notmatch 'data class M8EmojiEvent\(') {
    $s = [regex]::Replace(
      $s,
      '(data class M8CaptionEvent\([^\r\n]*\)\r?\n)',
      '$1data class M8EmojiEvent(val start: Double, val end: Double, val emoji: String, val emphasis: Boolean = false)`r`n',
      1
    )
  }
  if ($s -notmatch 'emojiEvents: List<M8EmojiEvent>') {
    $s = [regex]::Replace(
      $s,
      '(    val captions: List<M8CaptionEvent> = emptyList\(\),\r?\n)',
      '$1    val emojiEvents: List<M8EmojiEvent> = emptyList(),`r`n',
      1
    )
  }
  if ($s -notmatch 'emoji start cannot be negative') {
    $needle = '        if \(duration < 0\) add\("duration cannot be negative"\)'
    if ($s -notmatch $needle) { throw "M8 validation line not found." }
    $insert = @'
        emojiEvents.forEach { emoji ->
            if (emoji.start < 0.0) add("emoji start cannot be negative")
            if (emoji.end <= emoji.start) add("emoji end must be greater than start")
            if (emoji.emoji.isBlank()) add("emoji text is required")
        }
'@
    $s = [regex]::Replace($s, $needle, '$0' + "`r`n" + $insert.TrimEnd(), 1)
  }
  Set-Content $p $s -Encoding UTF8

  # VideoContracts.kt
  $p = Join-Path $root "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt"
  $s = Get-Content $p -Raw
  if ($s -notmatch 'data class VideoEmojiInput\(') {
    $s = [regex]::Replace(
      $s,
      '(data class VideoCaptionInput\([\s\S]*?\r?\n\)\r?\n)',
      '$1' + @'
data class VideoEmojiInput(
    val startMs: Long,
    val endMs: Long,
    val emoji: String,
    val emphasis: Boolean = false
)
'@ + "`r`n",
      1
    )
  }
  if ($s -notmatch 'emojis: List<VideoEmojiInput>') {
    $needle = '    val captions: List<VideoCaptionInput> = emptyList\(\)'
    if ($s -notmatch $needle) { throw "VideoSceneInput captions field not found." }
    $s = [regex]::Replace($s, $needle, '$0,`r`n    val emojis: List<VideoEmojiInput> = emptyList()', 1)
  }
  if ($s -notmatch 'val sceneEmojis = timeline\.emojiEvents') {
    $anchor = '                val captionText = sceneCaptions'
    if ($s -notmatch [regex]::Escape($anchor)) { throw "M8 bridge captionText line not found." }
    $emoji = @'
                val sceneEmojis = timeline.emojiEvents
                    .filter { emoji ->
                        emoji.end > sceneStart && emoji.start < sceneEnd
                    }
                    .map { emoji ->
                        VideoEmojiInput(
                            startMs = maxOf(segment.startMs, (emoji.start * 1000.0).toLong()),
                            endMs = minOf(segment.endMs, (emoji.end * 1000.0).toLong()),
                            emoji = emoji.emoji,
                            emphasis = emoji.emphasis
                        )
                    }
                    .filter { it.endMs > it.startMs && it.emoji.isNotBlank() }

'@
    $s = $s.Replace($anchor, $emoji.TrimEnd() + "`r`n`r`n" + $anchor)
  }
  if ($s -notmatch 'emojis = sceneEmojis') {
    $needle = '                    captions = sceneCaptions'
    if ($s -notmatch [regex]::Escape($needle)) { throw "VideoSceneInput captions assignment line not found." }
    $s = $s.Replace($needle, $needle + ",`r`n                    emojis = sceneEmojis")
  }
  Set-Content $p $s -Encoding UTF8

  # TimedEmojiOverlay.kt: mirror the already verified TimedTextOverlay shape.
  $p = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt"
  New-Item -ItemType Directory -Force (Split-Path $p) | Out-Null
  @'
package com.avsp.pro.video.engine

import android.graphics.Typeface
import android.text.SpannableString
import android.text.style.StyleSpan
import androidx.media3.effect.TextOverlay
import com.avsp.pro.video.contract.VideoEmojiInput

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class TimedEmojiOverlay(
    private val emojis: List<VideoEmojiInput>
) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString {
        val timeMs = presentationTimeUs / 1000L
        val active = emojis.filter { timeMs >= it.startMs && timeMs < it.endMs }
        if (active.isEmpty()) return SpannableString("")
        val text = active.joinToString(" ") { it.emoji.trim() }
        val result = SpannableString(text)
        if (active.any { it.emphasis } && text.isNotEmpty()) {
            result.setSpan(
                StyleSpan(Typeface.BOLD), 0, text.length,
                SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        return result
    }
}
'@ | Set-Content $p -Encoding UTF8

  # Media3VideoEngine.kt: insert emoji after the existing caption/static-text block
  # by locating the next videoItems assignment, not whitespace around the block.
  $p = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
  $s = Get-Content $p -Raw
  if ($s -notmatch 'TimedEmojiOverlay') {
    $import = 'import com.avsp.pro.video.engine.TimedTextOverlay'
    if ($s -notmatch [regex]::Escape($import)) { throw "TimedTextOverlay import not found." }
    $s = $s.Replace($import, $import + "`r`nimport com.avsp.pro.video.engine.TimedEmojiOverlay")
  }
  if ($s -notmatch 'listOf\(TimedEmojiOverlay\(scene\.emojis\)\)') {
    $pattern = '(?s)(if \(scene\.captions\.isNotEmpty\(\)\) \{.*?\n\s*\}\s*else \{.*?\n\s*\}\s*)(videoItems \+= EditedMediaItem\.Builder\(item\))'
    $replacement = '$1' + @'
                if (scene.emojis.isNotEmpty()) {
                    videoEffects += OverlayEffect(
                        listOf(TimedEmojiOverlay(scene.emojis))
                    )
                }
'@ + '$2'
    $new = [regex]::Replace($s, $pattern, $replacement, 1)
    if ($new -eq $s) { throw "Caption/videoItems region not found." }
    $s = $new
  }

  # Music: preserve narration sequence; add a looped second audio sequence.
  if ($s -notmatch 'val musicSequence') {
    $pattern = '(?s)(val videoSequence = EditedMediaItemSequence\.withVideoFrom\(videoItems\)\s+val audioSequence = EditedMediaItemSequence\.withAudioFrom\(audioItems\)\s+)(val composition = Composition\.Builder\(videoSequence, audioSequence\)\.build\(\))'
    $replacement = '$1' + @'
          val compositionSequences = mutableListOf(videoSequence, audioSequence)
          plan.musicRelativePath?.takeIf { it.isNotBlank() }?.let { musicRelativePath ->
              val music = File(
                  storage.resolve(
                      StorageArea.PROJECT_DATA,
                      musicRelativePath,
                      plan.projectId
                  )
              )
              require(music.exists()) { "Missing background music: $musicRelativePath" }

              val musicItem =
                  EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(music))).build()

              val musicSequence =
                  EditedMediaItemSequence.withAudioFrom(listOf(musicItem))
                      .buildUpon()
                      .setIsLooping(true)
                      .build()

              compositionSequences += musicSequence
          }

'@ + '          val composition = Composition.Builder(compositionSequences).build()'
    $new = [regex]::Replace($s, $pattern, $replacement, 1)
    if ($new -eq $s) { throw "Composition audio block not found." }
    $s = $new
  }
  Set-Content $p $s -Encoding UTF8

  # Focused tests.
  $p = Join-Path $root "app\src\test\java\com\avsp\pro\video\M4EmojiMusicContractTest.kt"
  New-Item -ItemType Directory -Force (Split-Path $p) | Out-Null
  @'
package com.avsp.pro.video

import com.avsp.pro.audio.integration.AudioToVideoHandoff
import com.avsp.pro.audio.integration.VideoAudioSegmentRef
import com.avsp.pro.m8.M8EmojiEvent
import com.avsp.pro.m8.M8Timeline
import com.avsp.pro.video.contract.VideoRenderPlanFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class M4EmojiMusicContractTest {
    @Test
    fun emojiAndMusicSurviveM8ToM4Bridge() {
        val timeline = M8Timeline(
            projectId = "p1",
            duration = 4.0,
            emojiEvents = listOf(M8EmojiEvent(1.0, 2.5, "🔥", true)),
            musicPath = "music/bg.mp3"
        )
        val handoff = AudioToVideoHandoff(
            projectId = "p1",
            scriptId = "s1",
            audioPackageId = "a1",
            language = "bn",
            provider = "test",
            voiceId = "test-voice",
            totalDurationMs = 4000L,
            segments = listOf(
                VideoAudioSegmentRef(
                    segmentId = "seg1",
                    sceneId = "scene1",
                    order = 0,
                    relativeAudioPath = "audio/scene1.wav",
                    startMs = 0L,
                    endMs = 4000L,
                    durationMs = 4000L,
                    language = "bn",
                    voiceId = "test-voice"
                )
            ),
            audioPackageVersion = "1.0"
        )
        val plan = VideoRenderPlanFactory.fromM8Timeline(timeline, handoff)
        assertEquals("music/bg.mp3", plan.musicRelativePath)
        assertEquals(1, plan.scenes.single().emojis.size)
        assertEquals(1000L, plan.scenes.single().emojis.single().startMs)
        assertEquals(2500L, plan.scenes.single().emojis.single().endMs)
        assertEquals("🔥", plan.scenes.single().emojis.single().emoji)
        assertTrue(plan.scenes.single().emojis.single().emphasis)
    }

    @Test
    fun invalidEmojiTimingIsRejected() {
        val errors = M8Timeline(
            projectId = "p1",
            duration = 2.0,
            emojiEvents = listOf(M8EmojiEvent(2.0, 1.0, "🔥"))
        ).validate()
        assertTrue(errors.any { it.contains("emoji end") })
    }
}
'@ | Set-Content $p -Encoding UTF8

  Write-Host "M4 V4 source patch applied. Running focused verification..."
  & .\gradlew.bat :app:testDebugUnitTest --tests com.avsp.pro.video.M4EmojiMusicContractTest --no-daemon --max-workers=1
  if ($LASTEXITCODE -ne 0) { throw "M4 Emoji/Music focused tests failed." }

  & .\gradlew.bat :app:testDebugUnitTest --tests com.avsp.pro.video.contract.M8TimelineRenderBridgeTest --no-daemon --max-workers=1
  if ($LASTEXITCODE -ne 0) { throw "Existing M8 bridge regression failed." }

  Write-Host "Running full clean test + assembleDebug..."
  & .\gradlew.bat clean test assembleDebug --no-daemon --max-workers=1
  if ($LASTEXITCODE -ne 0) { throw "Full verification failed." }

  Write-Host "M4 EMOJI + MUSIC V4 SUCCESSFUL."
}
catch {
  Write-Host "PATCH FAILED. Restoring previous source..."
  Restore
  Write-Host $_.Exception.Message
  exit 1
}
