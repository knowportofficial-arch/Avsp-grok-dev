﻿@echo off
setlocal
set "ROOT=C:\Users\BSNL\AVSP_M16_DAILYPOST_RECOVERY_CLEAN"
set "AGENT=%ROOT%\_AVSP_AGENT"
powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Minimized -File "%AGENT%\START_AVSP_AGENT.ps1"
endlocal
