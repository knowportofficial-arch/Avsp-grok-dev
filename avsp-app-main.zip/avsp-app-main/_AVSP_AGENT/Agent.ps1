﻿$listener=New-Object Net.HttpListener
$listener.Prefixes.Add("http://127.0.0.1:18765/")
$listener.Start(); Add-Content -LiteralPath "$root\_AVSP_AGENT\agent.runtime.log" -Value "$(Get-Date -Format o) LISTENER_STARTED 18765"
$root="C:\Users\BSNL\AVSP_M16_DAILYPOST_RECOVERY_CLEAN"
$executor="$root\_AVSP_AGENT\Executor.ps1"
$tokenFile="$root\_AVSP_AGENT\agent.token"
if(!(Test-Path $tokenFile)){ [guid]::NewGuid().ToString("N")+[guid]::NewGuid().ToString("N") | Set-Content $tokenFile -NoNewline }
$token=(Get-Content $tokenFile -Raw).Trim()
Write-Host "AVSP AGENT RUNNING"
Write-Host "TOKEN_FILE=$tokenFile"
while($true){
  $c=$listener.GetContext()
  try{
    $auth=$c.Request.Headers["X-AVSP-Agent-Token"]
    if($auth -ne $token){ $c.Response.StatusCode=401; $j='{"ok":false,"error":"Unauthorized"}' }
    elseif($c.Request.HttpMethod -eq "GET"){ $j='{"ok":true,"agent":"AVSP","auth":"required"}' }
    else{
      $body=(New-Object IO.StreamReader($c.Request.InputStream)).ReadToEnd()
      $r=$body|ConvertFrom-Json
      if($r.action -ne "command"){ throw "Unsupported action" }
      $j=powershell -NoProfile -ExecutionPolicy Bypass -File $executor $r.command
    }
    $b=[Text.Encoding]::UTF8.GetBytes($j)
    $c.Response.ContentType="application/json"
    $c.Response.OutputStream.Write($b,0,$b.Length)
    $c.Response.Close()
  }catch{
    $j=@{ok=$false;error=$_.Exception.Message}|ConvertTo-Json -Compress
    $b=[Text.Encoding]::UTF8.GetBytes($j)
    $c.Response.StatusCode=500
    $c.Response.ContentType="application/json"
    $c.Response.OutputSream.Write($b,0,$b.Length)
    $c.Response.Close()
  }
}
