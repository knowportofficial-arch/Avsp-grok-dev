﻿$ErrorActionPreference="Stop"
$root="C:\Users\BSNL\AVSP_M16_DAILYPOST_RECOVERY_CLEAN"
$agent="$root\_AVSP_AGENT"
$agentScript="$agent\Agent.ps1"
$status="$agent\agent.status.json"

if(!(Test-Path -LiteralPath $agentScript)){
    [pscustomobject]@{
        ok=$false
        error="Agent.ps1 not found"
        path=$agentScript
        time=(Get-Date).ToString("o")
    } | ConvertTo-Json -Compress | Set-Content -LiteralPath $status -Encoding UTF8
    exit 1
}

$old=Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" |
    Where-Object { $_.CommandLine -like "*$agentScript*" }

if(!$old){
    Start-Process powershell.exe `
        -ArgumentList "-NoProfile","-ExecutionPolicy","Bypass","-File",$agentScript `
        -WorkingDirectory $agent `
        -WindowStyle Minimized
}

Start-Sleep -Seconds 2

$health=$false
try{
    $r=Invoke-WebRequest `
        -Uri "http://127.0.0.1:8765/" `
        -UseBasicParsing `
        -TimeoutSec 5
    if($r.StatusCode -eq 200){$health=$true}
}catch{}

[pscustomobject]@{
    ok=$health
    agentRunning=$true
    endpoint="http://127.0.0.1:8765/"
    root=$root
    time=(Get-Date).ToString("o")
} | ConvertTo-Json -Compress | Set-Content -LiteralPath $status -Encoding UTF8

Get-Content -LiteralPath $status -Raw | Set-Clipboard
Write-Host (Get-Content -LiteralPath $status -Raw)
