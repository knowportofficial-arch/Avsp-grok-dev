param([string]$Command)

$root="C:\Users\BSNL\AVSP_M16_DAILYPOST_RECOVERY_CLEAN"
Set-Location $root

$p=Start-Process powershell.exe -ArgumentList "-NoProfile","-Command",$Command -WorkingDirectory $root -Wait -PassThru -RedirectStandardOutput "$env:TEMP\avsp_out.txt" -RedirectStandardError "$env:TEMP\avsp_err.txt"

[pscustomobject]@{
    ok=($p.ExitCode -eq 0)
    exitCode=$p.ExitCode
    stdout=(Get-Content "$env:TEMP\avsp_out.txt" -Raw)
    stderr=(Get-Content "$env:TEMP\avsp_err.txt" -Raw)
} | ConvertTo-Json -Compress
