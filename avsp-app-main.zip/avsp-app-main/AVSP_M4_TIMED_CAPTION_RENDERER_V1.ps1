$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$engine = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
$overlay = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\TimedTextOverlay.kt"
$selector = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\TimedCaptionSelector.kt"
$test = Join-Path $root "app\src\test\java\com\avsp\pro\video\TimedCaptionSelectorTest.kt"
$backup = Join-Path $root "_avsp_backups\M4_timed_captions_renderer_v1"

function Read-Utf8($p) { [System.IO.File]::ReadAllText($p, [System.Text.UTF8Encoding]::new($false)) }
function Write-Utf8($p,$s) {
    New-Item -ItemType Directory -Path (Split-Path $p -Parent) -Force | Out-Null
    [System.IO.File]::WriteAllText($p,$s,[System.Text.UTF8Encoding]::new($false))
}

if (!(Test-Path $engine)) { throw "Media3VideoEngine.kt not found. Run from C:\AVSP_WORK_2026-09-21" }

New-Item -ItemType Directory -Path $backup -Force | Out-Null
Copy-Item $engine (Join-Path $backup "Media3VideoEngine.kt") -Force
foreach($p in @($overlay,$selector,$test)) {
    if(Test-Path $p){ Copy-Item $p (Join-Path $backup ([IO.Path]::GetFileName($p))) -Force }
}

try {
    $e = Read-Utf8 $engine

    $import = 'import androidx.media3.effect.TextOverlay'
    if (!$e.Contains('import com.avsp.pro.video.engine.TimedTextOverlay')) {
        if (!$e.Contains($import)) { throw "TextOverlay import anchor missing." }
        $e = $e.Replace($import, $import + "`r`nimport com.avsp.pro.video.engine.TimedTextOverlay")
    }

    # Current source is restored baseline: preserve overlayText exactly.
    # Only change how the renderer consumes captions when captions exist.
    $pattern = '(?ms)^(?<indent>\s*)scene\.overlayText\?\.takeIf \{ it\.isNotBlank\(\) \}\?\.let \{ text ->\s*videoEffects \+=\s*OverlayEffect\(\s*listOf\(TextOverlay\.createStaticTextOverlay\(SpannableString\(text\)\)\)\s*\)\s*\}'
    $replacement = '${indent}if (scene.captions.isNotEmpty()) {' + "`r`n" +
                   '${indent}    videoEffects += OverlayEffect(' + "`r`n" +
                   '${indent}        listOf(TimedTextOverlay(scene.captions))' + "`r`n" +
                   '${indent}    )' + "`r`n" +
                   '${indent}} else {' + "`r`n" +
                   '${indent}    scene.overlayText?.takeIf { it.isNotBlank() }?.let { text ->' + "`r`n" +
                   '${indent}        videoEffects += OverlayEffect(' + "`r`n" +
                   '${indent}            listOf(TextOverlay.createStaticTextOverlay(SpannableString(text)))' + "`r`n" +
                   '${indent}        )' + "`r`n" +
                   '${indent}    }' + "`r`n" +
                   '${indent}}'

    $e2 = [regex]::Replace($e,$pattern,$replacement,1)
    if ($e2 -eq $e) { throw "Renderer overlay block was not found. No source change made." }
    Write-Utf8 $engine $e2

    $selectorText = @'
package com.avsp.pro.video.engine

import com.avsp.pro.video.contract.VideoCaptionInput

object TimedCaptionSelector {
    fun active(captions: List<VideoCaptionInput>, timeMs: Long): List<VideoCaptionInput> =
        captions.filter { timeMs >= it.startMs && timeMs < it.endMs }
}
'@
    Write-Utf8 $selector $selectorText

    $overlayText = @'
package com.avsp.pro.video.engine

import android.graphics.Typeface
import android.text.SpannableString
import android.text.style.StyleSpan
import androidx.media3.effect.TextOverlay
import com.avsp.pro.video.contract.VideoCaptionInput

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class TimedTextOverlay(
    private val captions: List<VideoCaptionInput>
) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString {
        val active = TimedCaptionSelector.active(captions, presentationTimeUs / 1000L)
        if (active.isEmpty()) return SpannableString("")
        val text = active.joinToString(" ") { it.text.trim() }
        val result = SpannableString(text)
        if (active.any { it.emphasis } && text.isNotEmpty()) {
            result.setSpan(
                StyleSpan(Typeface.BOLD), 0, text.length,
                SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        return result
    }
}
'@
    Write-Utf8 $overlay $overlayText

    $testText = @'
package com.avsp.pro.video

import com.avsp.pro.video.contract.VideoCaptionInput
import com.avsp.pro.video.engine.TimedCaptionSelector
import org.junit.Assert.assertEquals
import org.junit.Test

class TimedCaptionSelectorTest {
    @Test
    fun selectsCaptionOnlyInsideWindow() {
        val c = VideoCaptionInput(1000L, 2000L, "Hello")
        assertEquals(emptyList<VideoCaptionInput>(), TimedCaptionSelector.active(listOf(c), 999L))
        assertEquals(listOf(c), TimedCaptionSelector.active(listOf(c), 1000L))
        assertEquals(listOf(c), TimedCaptionSelector.active(listOf(c), 1999L))
        assertEquals(emptyList<VideoCaptionInput>(), TimedCaptionSelector.active(listOf(c), 2000L))
    }

    @Test
    fun overlappingCaptionsRemainOrdered() {
        val one = VideoCaptionInput(0L, 1500L, "One")
        val two = VideoCaptionInput(1000L, 2000L, "Two")
        assertEquals(listOf(one, two), TimedCaptionSelector.active(listOf(one, two), 1200L))
    }
}
'@
    Write-Utf8 $test $testText

    Push-Location $root
    try {
        & .\gradlew.bat :app:testDebugUnitTest --tests "com.avsp.pro.video.TimedCaptionSelectorTest" --no-daemon --max-workers=1
        if($LASTEXITCODE -ne 0){ throw "Focused timed-caption test failed." }

        & .\gradlew.bat :app:testDebugUnitTest --tests "com.avsp.pro.video.contract.M8TimelineRenderBridgeTest" --no-daemon --max-workers=1
        if($LASTEXITCODE -ne 0){ throw "Existing M8 bridge regression test failed." }

        & .\gradlew.bat clean test assembleDebug --no-daemon --max-workers=1
        if($LASTEXITCODE -ne 0){ throw "Full verification failed." }
    } finally { Pop-Location }

    Write-Host "M4 TIMED CAPTION RENDERER PATCH SUCCESSFUL." -ForegroundColor Green
}
catch {
    Write-Host "PATCH FAILED. Restoring previous source..." -ForegroundColor Red
    Copy-Item (Join-Path $backup "Media3VideoEngine.kt") $engine -Force
    foreach($p in @($overlay,$selector,$test)) {
        $b = Join-Path $backup ([IO.Path]::GetFileName($p))
        if(Test-Path $b){ Copy-Item $b $p -Force }
        elseif(Test-Path $p){ Remove-Item $p -Force }
    }
    throw
}
