$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$engine = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
$contracts = Join-Path $root "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt"
$overlay = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\TimedTextOverlay.kt"
$selector = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\TimedCaptionSelector.kt"
$test = Join-Path $root "app\src\test\java\com\avsp\pro\video\TimedCaptionSelectorTest.kt"
$backup = Join-Path $root "_avsp_backups\M4_timed_captions_exact_v1"

function Read-Utf8($p) {
    [System.IO.File]::ReadAllText($p, [System.Text.UTF8Encoding]::new($false))
}
function Write-Utf8($p, $s) {
    $parent = Split-Path $p -Parent
    if (!(Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    [System.IO.File]::WriteAllText($p, $s, [System.Text.UTF8Encoding]::new($false))
}

if (!(Test-Path $engine) -or !(Test-Path $contracts)) {
    throw "Run this from C:\AVSP_WORK_2026-09-21"
}

New-Item -ItemType Directory -Path $backup -Force | Out-Null
Copy-Item $engine (Join-Path $backup "Media3VideoEngine.kt") -Force
Copy-Item $contracts (Join-Path $backup "VideoContracts.kt") -Force
foreach ($p in @($overlay,$selector,$test)) {
    if (Test-Path $p) { Copy-Item $p (Join-Path $backup ([IO.Path]::GetFileName($p))) -Force }
}

try {
    # 1. Remove the duplicated static caption text from the M8->M4 bridge.
    $c = Read-Utf8 $contracts
    $oldCaption = '                    overlayText = captionText,' 
    if (!$c.Contains($oldCaption)) {
        throw "Expected exact M8 captionText assignment was not found. Source was not modified."
    }
    $c = $c.Replace($oldCaption, '                    overlayText = null,')
    Write-Utf8 $contracts $c

    # 2. Replace only the exact renderer block observed on this machine.
    $e = Read-Utf8 $engine

    $import = 'import androidx.media3.effect.TextOverlay'
    if (!$e.Contains($import)) { throw "Expected TextOverlay import was not found." }
    if (!$e.Contains('import com.avsp.pro.video.engine.TimedTextOverlay')) {
        $e = $e.Replace($import, $import + "`r`nimport com.avsp.pro.video.engine.TimedTextOverlay")
    }

    $old = @"
                scene.overlayText?.takeIf { it.isNotBlank() }?.let { text ->
                    videoEffects +=
                        OverlayEffect(
                            listOf(TextOverlay.createStaticTextOverlay(SpannableString(text)))
                        )
                }
"@

    $new = @"
                if (scene.captions.isNotEmpty()) {
                    videoEffects +=
                        OverlayEffect(
                            listOf(TimedTextOverlay(scene.captions))
                        )
                } else {
                    scene.overlayText?.takeIf { it.isNotBlank() }?.let { text ->
                        videoEffects +=
                            OverlayEffect(
                                listOf(TextOverlay.createStaticTextOverlay(SpannableString(text)))
                            )
                    }
                }
"@

    if (!$e.Contains($old)) {
        throw "The exact renderer block was not found. Source was not modified further."
    }
    $e = $e.Replace($old, $new)
    Write-Utf8 $engine $e

    # 3. Pure selector keeps timing logic testable without requiring a device.
    $selectorText = @'
package com.avsp.pro.video.engine

import com.avsp.pro.video.contract.VideoCaptionInput

object TimedCaptionSelector {
    fun active(captions: List<VideoCaptionInput>, timeMs: Long): List<VideoCaptionInput> =
        captions.filter { timeMs >= it.startMs && timeMs < it.endMs }
}
'@
    Write-Utf8 $selector $selectorText

    $overlayText = @'
package com.avsp.pro.video.engine

import android.graphics.Typeface
import android.text.SpannableString
import android.text.style.StyleSpan
import androidx.media3.effect.TextOverlay
import com.avsp.pro.video.contract.VideoCaptionInput

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class TimedTextOverlay(
    private val captions: List<VideoCaptionInput>
) : TextOverlay() {

    override fun getText(presentationTimeUs: Long): SpannableString {
        val active = TimedCaptionSelector.active(captions, presentationTimeUs / 1000L)
        if (active.isEmpty()) return SpannableString("")

        val text = active.joinToString(" ") { it.text.trim() }
        val result = SpannableString(text)

        if (active.any { it.emphasis } && text.isNotEmpty()) {
            result.setSpan(
                StyleSpan(Typeface.BOLD),
                0,
                text.length,
                SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        return result
    }
}
'@
    Write-Utf8 $overlay $overlayText

    $testText = @'
package com.avsp.pro.video

import com.avsp.pro.video.contract.VideoCaptionInput
import com.avsp.pro.video.engine.TimedCaptionSelector
import org.junit.Assert.assertEquals
import org.junit.Test

class TimedCaptionSelectorTest {

    @Test
    fun selectsCaptionOnlyInsideItsTimeWindow() {
        val captions = listOf(VideoCaptionInput(1000L, 2000L, "Hello"))

        assertEquals(emptyList<VideoCaptionInput>(), TimedCaptionSelector.active(captions, 999L))
        assertEquals(listOf(captions[0]), TimedCaptionSelector.active(captions, 1000L))
        assertEquals(listOf(captions[0]), TimedCaptionSelector.active(captions, 1999L))
        assertEquals(emptyList<VideoCaptionInput>(), TimedCaptionSelector.active(captions, 2000L))
    }

    @Test
    fun overlappingCaptionsRemainOrdered() {
        val one = VideoCaptionInput(0L, 1500L, "One")
        val two = VideoCaptionInput(1000L, 2000L, "Two")

        assertEquals(listOf(one, two), TimedCaptionSelector.active(listOf(one, two), 1200L))
    }
}
'@
    Write-Utf8 $test $testText

    Push-Location $root
    try {
        & .\gradlew.bat :app:testDebugUnitTest --tests "com.avsp.pro.video.TimedCaptionSelectorTest" --no-daemon --max-workers=1
        if ($LASTEXITCODE -ne 0) { throw "Focused timed-caption test failed." }

        & .\gradlew.bat clean test assembleDebug --no-daemon --max-workers=1
        if ($LASTEXITCODE -ne 0) { throw "Full verification failed." }
    }
    finally {
        Pop-Location
    }

    Write-Host "M4 TIMED CAPTION EXACT PATCH SUCCESSFUL." -ForegroundColor Green
}
catch {
    Write-Host "PATCH FAILED. Restoring exact previous files..." -ForegroundColor Red
    Copy-Item (Join-Path $backup "Media3VideoEngine.kt") $engine -Force
    Copy-Item (Join-Path $backup "VideoContracts.kt") $contracts -Force

    foreach ($p in @($overlay,$selector,$test)) {
        $b = Join-Path $backup ([IO.Path]::GetFileName($p))
        if (Test-Path $b) {
            Copy-Item $b $p -Force
        } elseif (Test-Path $p) {
            Remove-Item $p -Force
        }
    }
    throw
}
