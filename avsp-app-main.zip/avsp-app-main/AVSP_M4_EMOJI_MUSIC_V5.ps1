$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$backup = Join-Path $root "_avsp_backups\M4_emoji_music_v5"
$targets = @(
    "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt",
    "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt",
    "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
)

New-Item -ItemType Directory -Force $backup | Out-Null

function Backup-Target([string]$rel) {
    $src = Join-Path $root $rel
    $dst = Join-Path $backup $rel
    New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
    Copy-Item $src $dst -Force
}

function Restore-All {
    foreach ($rel in $targets) {
        $src = Join-Path $backup $rel
        $dst = Join-Path $root $rel
        if (Test-Path $src) { Copy-Item $src $dst -Force }
    }

    foreach ($rel in @(
        "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt",
        "app\src\test\java\com\avsp\pro\video\M4EmojiMusicContractTest.kt"
    )) {
        $p = Join-Path $root $rel
        if (Test-Path $p) { Remove-Item $p -Force }
    }
}

function Insert-After-ExactLine(
    [string[]]$lines,
    [string]$needle,
    [string[]]$addition,
    [string]$label
) {
    $idx = [Array]::IndexOf($lines, $needle)
    if ($idx -lt 0) { throw "$label anchor not found: [$needle]" }

    $out = [System.Collections.Generic.List[string]]::new()
    $out.AddRange($lines[0..$idx])
    $out.AddRange($addition)
    if ($idx + 1 -lt $lines.Count) {
        $out.AddRange($lines[($idx + 1)..($lines.Count - 1)])
    }
    return $out.ToArray()
}

try {
    foreach ($rel in $targets) { Backup-Target $rel }

    # ============================================================
    # 1. M8Timeline.kt — additive emoji event + validation
    # ============================================================
    $rel = "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt"
    $p = Join-Path $root $rel
    $lines = @(Get-Content $p)

    if (-not ($lines -contains 'data class M8EmojiEvent(val start: Double, val end: Double, val emoji: String, val emphasis: Boolean = false)')) {
        $lines = Insert-After-ExactLine `
            $lines `
            'data class M8CaptionEvent(val start: Double, val end: Double, val text: String, val emphasis: Boolean = false)' `
            @('data class M8EmojiEvent(val start: Double, val end: Double, val emoji: String, val emphasis: Boolean = false)') `
            "M8 emoji event"
    }

    if (-not ($lines -contains '    val emojiEvents: List<M8EmojiEvent> = emptyList(),')) {
        $lines = Insert-After-ExactLine `
            $lines `
            '    val captions: List<M8CaptionEvent> = emptyList(),' `
            @('    val emojiEvents: List<M8EmojiEvent> = emptyList(),') `
            "M8 emojiEvents field"
    }

    if (-not ($lines -contains '        emojiEvents.forEach { emoji ->')) {
        $validation = @(
            '        emojiEvents.forEach { emoji ->',
            '            if (emoji.start < 0.0) add("emoji start cannot be negative")',
            '            if (emoji.end <= emoji.start) add("emoji end must be greater than start")',
            '            if (emoji.emoji.isBlank()) add("emoji text is required")',
            '        }'
        )
        $lines = Insert-After-ExactLine `
            $lines `
            '        if (duration < 0) add("duration cannot be negative")' `
            $validation `
            "M8 emoji validation"
    }

    Set-Content $p $lines -Encoding UTF8

    # ============================================================
    # 2. VideoContracts.kt — emoji contract + M8 bridge
    # ============================================================
    $rel = "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt"
    $p = Join-Path $root $rel
    $lines = @(Get-Content $p)

    if (-not ($lines -contains 'data class VideoEmojiInput(')) {
        $emojiContract = @(
            'data class VideoEmojiInput(',
            '    val startMs: Long,',
            '    val endMs: Long,',
            '    val emoji: String,',
            '    val emphasis: Boolean = false',
            ')'
        )
        $lines = Insert-After-ExactLine `
            $lines `
            ')' `
            $emojiContract `
            "VideoEmojiInput"
    }

    # The previous insertion above could target the first ')' in the file.
    # Guard by checking the resulting location and fail safely if not correct.
    $emojiIdx = [Array]::IndexOf($lines, 'data class VideoEmojiInput(')
    $captionIdx = [Array]::IndexOf($lines, 'data class VideoCaptionInput(')
    if ($emojiIdx -lt 0 -or $emojiIdx -le $captionIdx) {
        throw "VideoEmojiInput was not inserted after VideoCaptionInput."
    }

    if (-not ($lines -contains '    val emojis: List<VideoEmojiInput> = emptyList()')) {
        $lines = Insert-After-ExactLine `
            $lines `
            '    val captions: List<VideoCaptionInput> = emptyList()' `
            @('    val emojis: List<VideoEmojiInput> = emptyList()') `
            "VideoSceneInput emojis field"
    }

    if (-not ($lines -contains '                val sceneEmojis = timeline.emojiEvents')) {
        $emojiBridge = @(
            '                val sceneEmojis = timeline.emojiEvents',
            '                    .filter { emoji ->',
            '                        emoji.end > sceneStart && emoji.start < sceneEnd',
            '                    }',
            '                    .map { emoji ->',
            '                        VideoEmojiInput(',
            '                            startMs = maxOf(segment.startMs, (emoji.start * 1000.0).toLong()),',
            '                            endMs = minOf(segment.endMs, (emoji.end * 1000.0).toLong()),',
            '                            emoji = emoji.emoji,',
            '                            emphasis = emoji.emphasis',
            '                        )',
            '                    }',
            '                    .filter { it.endMs > it.startMs && it.emoji.isNotBlank() }',
            ''
        )
        $lines = Insert-After-ExactLine `
            $lines `
            '                    .filter { it.endMs > it.startMs && it.text.isNotBlank() }' `
            $emojiBridge `
            "M8 to M4 emoji bridge"
    }

    if (-not ($lines -contains '                    emojis = sceneEmojis')) {
        $lines = Insert-After-ExactLine `
            $lines `
            '                    captions = sceneCaptions' `
            @('                    emojis = sceneEmojis') `
            "VideoSceneInput emojis assignment"
    }

    Set-Content $p $lines -Encoding UTF8

    # ============================================================
    # 3. TimedEmojiOverlay.kt — mirror the verified TimedTextOverlay
    # ============================================================
    $rel = "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt"
    $p = Join-Path $root $rel
    New-Item -ItemType Directory -Force (Split-Path $p) | Out-Null

    $overlay = @(
        'package com.avsp.pro.video.engine',
        '',
        'import android.graphics.Typeface',
        'import android.text.SpannableString',
        'import android.text.style.StyleSpan',
        'import androidx.media3.effect.TextOverlay',
        'import com.avsp.pro.video.contract.VideoEmojiInput',
        '',
        '@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)',
        'class TimedEmojiOverlay(',
        '    private val emojis: List<VideoEmojiInput>',
        ') : TextOverlay() {',
        '    override fun getText(presentationTimeUs: Long): SpannableString {',
        '        val timeMs = presentationTimeUs / 1000L',
        '        val active = emojis.filter { timeMs >= it.startMs && timeMs < it.endMs }',
        '        if (active.isEmpty()) return SpannableString("")',
        '        val text = active.joinToString(" ") { it.emoji.trim() }',
        '        val result = SpannableString(text)',
        '        if (active.any { it.emphasis } && text.isNotEmpty()) {',
        '            result.setSpan(',
        '                StyleSpan(Typeface.BOLD), 0, text.length,',
        '                SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE',
        '            )',
        '        }',
        '        return result',
        '    }',
        '}'
    )
    Set-Content $p $overlay -Encoding UTF8

    # ============================================================
    # 4. Media3VideoEngine.kt — exact line-array edits only
    # ============================================================
    $rel = "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
    $p = Join-Path $root $rel
    $lines = @(Get-Content $p)

    if (-not ($lines -contains 'import com.avsp.pro.video.engine.TimedEmojiOverlay')) {
        $lines = Insert-After-ExactLine `
            $lines `
            'import com.avsp.pro.video.engine.TimedTextOverlay' `
            @('import com.avsp.pro.video.engine.TimedEmojiOverlay') `
            "TimedEmojiOverlay import"
    }

    if (-not ($lines -contains '                    if (scene.emojis.isNotEmpty()) {')) {
        $emojiRenderer = @(
            '                if (scene.emojis.isNotEmpty()) {',
            '                    videoEffects += OverlayEffect(',
            '                        listOf(TimedEmojiOverlay(scene.emojis))',
            '                    )',
            '                }'
        )
        $lines = Insert-After-ExactLine `
            $lines `
            '                  }' `
            $emojiRenderer `
            "emoji renderer"
    }

    # Verify the emoji renderer landed in the correct area.
    $emojiRendererIdx = [Array]::IndexOf($lines, '                if (scene.emojis.isNotEmpty()) {')
    $videoItemsIdx = [Array]::IndexOf($lines, '                  videoItems += EditedMediaItem.Builder(item)')
    if ($emojiRendererIdx -lt 0 -or $videoItemsIdx -lt 0 -or $emojiRendererIdx -ge $videoItemsIdx) {
        throw "Emoji renderer did not land before videoItems."
    }

    if (-not ($lines -contains '          val compositionSequences = mutableListOf(videoSequence, audioSequence)')) {
        $compositionBlock = @(
            '          val compositionSequences = mutableListOf(videoSequence, audioSequence)',
            '          plan.musicRelativePath?.takeIf { it.isNotBlank() }?.let { musicRelativePath ->',
            '              val music = File(',
            '                  storage.resolve(',
            '                      StorageArea.PROJECT_DATA,',
            '                      musicRelativePath,',
            '                      plan.projectId',
            '                  )',
            '              )',
            '              require(music.exists()) { "Missing background music: $musicRelativePath" }',
            '',
            '              val musicItem =',
            '                  EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(music))).build()',
            '',
            '              val musicSequence =',
            '                  EditedMediaItemSequence.withAudioFrom(listOf(musicItem))',
            '                      .buildUpon()',
            '                      .setIsLooping(true)',
            '                      .build()',
            '',
            '              compositionSequences += musicSequence',
            '          }',
            '          val composition = Composition.Builder(compositionSequences).build()'
        )

        $lines = Insert-After-ExactLine `
            $lines `
            '          val audioSequence = EditedMediaItemSequence.withAudioFrom(audioItems)' `
            $compositionBlock `
            "music composition"
    }

    # Replace the original composition line only if it still exists.
    $originalComposition = '          val composition = Composition.Builder(videoSequence, audioSequence).build()'
    if ($lines -contains $originalComposition) {
        $idx = [Array]::IndexOf($lines, $originalComposition)
        $newLines = [System.Collections.Generic.List[string]]::new()
        if ($idx -gt 0) { $newLines.AddRange($lines[0..($idx - 1)]) }
        $newLines.Add('          val composition = Composition.Builder(compositionSequences).build()')
        if ($idx + 1 -lt $lines.Count) { $newLines.AddRange($lines[($idx + 1)..($lines.Count - 1)]) }
        $lines = $newLines.ToArray()
    }

    Set-Content $p $lines -Encoding UTF8

    # ============================================================
    # 5. Focused tests
    # ============================================================
    $rel = "app\src\test\java\com\avsp\pro\video\M4EmojiMusicContractTest.kt"
    $p = Join-Path $root $rel
    New-Item -ItemType Directory -Force (Split-Path $p) | Out-Null

    $test = @(
        'package com.avsp.pro.video',
        '',
        'import com.avsp.pro.audio.integration.AudioToVideoHandoff',
        'import com.avsp.pro.audio.integration.VideoAudioSegmentRef',
        'import com.avsp.pro.m8.M8EmojiEvent',
        'import com.avsp.pro.m8.M8Timeline',
        'import com.avsp.pro.video.contract.VideoRenderPlanFactory',
        'import org.junit.Assert.assertEquals',
        'import org.junit.Assert.assertTrue',
        'import org.junit.Test',
        '',
        'class M4EmojiMusicContractTest {',
        '    @Test',
        '    fun emojiAndMusicSurviveM8ToM4Bridge() {',
        '        val timeline = M8Timeline(',
        '            projectId = "p1",',
        '            duration = 4.0,',
        '            emojiEvents = listOf(M8EmojiEvent(1.0, 2.5, "🔥", true)),',
        '            musicPath = "music/bg.mp3"',
        '        )',
        '        val handoff = AudioToVideoHandoff(',
        '            projectId = "p1",',
        '            scriptId = "s1",',
        '            audioPackageId = "a1",',
        '            language = "bn",',
        '            provider = "test",',
        '            voiceId = "test-voice",',
        '            totalDurationMs = 4000L,',
        '            segments = listOf(',
        '                VideoAudioSegmentRef(',
        '                    segmentId = "seg1",',
        '                    sceneId = "scene1",',
        '                    order = 0,',
        '                    relativeAudioPath = "audio/scene1.wav",',
        '                    startMs = 0L,',
        '                    endMs = 4000L,',
        '                    durationMs = 4000L,',
        '                    language = "bn",',
        '                    voiceId = "test-voice"',
        '                )',
        '            ),',
        '            audioPackageVersion = "1.0"',
        '        )',
        '        val plan = VideoRenderPlanFactory.fromM8Timeline(timeline, handoff)',
        '        assertEquals("music/bg.mp3", plan.musicRelativePath)',
        '        assertEquals(1, plan.scenes.single().emojis.size)',
        '        assertEquals(1000L, plan.scenes.single().emojis.single().startMs)',
        '        assertEquals(2500L, plan.scenes.single().emojis.single().endMs)',
        '        assertEquals("🔥", plan.scenes.single().emojis.single().emoji)',
        '        assertTrue(plan.scenes.single().emojis.single().emphasis)',
        '    }',
        '',
        '    @Test',
        '    fun invalidEmojiTimingIsRejected() {',
        '        val errors = M8Timeline(',
        '            projectId = "p1",',
        '            duration = 2.0,',
        '            emojiEvents = listOf(M8EmojiEvent(2.0, 1.0, "🔥"))',
        '        ).validate()',
        '        assertTrue(errors.any { it.contains("emoji end") })',
        '    }',
        '}'
    )
    Set-Content $p $test -Encoding UTF8

    Write-Host "M4 V5 source patch applied."
    Write-Host "Running focused emoji/music contract test..."

    & .\gradlew.bat :app:testDebugUnitTest --tests com.avsp.pro.video.M4EmojiMusicContractTest --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Focused M4 Emoji/Music test failed." }

    Write-Host "Running existing M8 bridge regression..."
    & .\gradlew.bat :app:testDebugUnitTest --tests com.avsp.pro.video.contract.M8TimelineRenderBridgeTest --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Existing M8 bridge regression failed." }

    Write-Host "Running full clean test + assembleDebug..."
    & .\gradlew.bat clean test assembleDebug --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Full verification failed." }

    Write-Host "M4 EMOJI + MUSIC V5 SUCCESSFUL."
}
catch {
    Write-Host "PATCH FAILED. Restoring previous source..."
    Restore-All
    Write-Host $_.Exception.Message
    exit 1
}
