$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$files = @(
  "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt",
  "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt",
  "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
)
$backup = Join-Path $root "_avsp_backups\M4_emoji_music_v3"
New-Item -ItemType Directory -Force $backup | Out-Null

function Backup-File($rel) {
  $src = Join-Path $root $rel
  $dst = Join-Path $backup $rel
  New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
  Copy-Item $src $dst -Force
}
function Restore-All {
  foreach ($rel in $files) {
    $src = Join-Path $backup $rel
    $dst = Join-Path $root $rel
    if (Test-Path $src) { Copy-Item $src $dst -Force }
  }
  $extra = @(
    "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt",
    "app\src\test\java\com\avsp\pro\video\M4EmojiMusicContractTest.kt"
  )
  foreach ($rel in $extra) {
    $p = Join-Path $root $rel
    if (Test-Path $p) { Remove-Item $p -Force }
  }
}

try {
  foreach ($f in $files) { Backup-File $f }

  # ---------- M8Timeline.kt ----------
  $p = Join-Path $root "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt"
  $s = Get-Content $p -Raw

  if ($s -notmatch 'data class M8EmojiEvent\(') {
    $s = $s -replace '(data class M8CaptionEvent\([^\r\n]+\)\r?\n)', '$1data class M8EmojiEvent(val start: Double, val end: Double, val emoji: String, val emphasis: Boolean = false)`r`n'
  }
  if ($s -notmatch 'val emojiEvents: List<M8EmojiEvent>') {
    $s = $s -replace '(val captions: List<M8CaptionEvent> = emptyList\(\),\r?\n)', '$1    val emojiEvents: List<M8EmojiEvent> = emptyList(),`r`n'
  }
  if ($s -notmatch 'emojiEvents\.forEach') {
    $needle = '        if (duration < 0) add("duration cannot be negative")'
    if ($s -notmatch [regex]::Escape($needle)) { throw "M8 duration validation anchor not found." }
    $insert = @'
        emojiEvents.forEach { emoji ->
            if (emoji.start < 0.0) add("emoji start cannot be negative")
            if (emoji.end <= emoji.start) add("emoji end must be greater than start")
            if (emoji.emoji.isBlank()) add("emoji text is required")
        }
'@
    $s = $s.Replace($needle, $needle + "`r`n" + $insert.TrimEnd())
  }
  Set-Content $p $s -Encoding UTF8

  # ---------- VideoContracts.kt ----------
  $p = Join-Path $root "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt"
  $s = Get-Content $p -Raw

  if ($s -notmatch 'data class VideoEmojiInput\(') {
    $captionBlock = @'
data class VideoCaptionInput(
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val emphasis: Boolean = false
)
'@
    if ($s -notmatch [regex]::Escape($captionBlock)) { throw "VideoCaptionInput block not found." }
    $emojiBlock = @'
data class VideoEmojiInput(
    val startMs: Long,
    val endMs: Long,
    val emoji: String,
    val emphasis: Boolean = false
)
'@
    $s = $s.Replace($captionBlock, $captionBlock + $emojiBlock)
  }

  if ($s -notmatch 'val emojis: List<VideoEmojiInput>') {
    $needle = '    val captions: List<VideoCaptionInput> = emptyList()'
    if ($s -notmatch [regex]::Escape($needle)) { throw "VideoSceneInput captions field not found." }
    $s = $s.Replace($needle, $needle + ",`r`n    val emojis: List<VideoEmojiInput> = emptyList()")
  }

  if ($s -notmatch 'val sceneEmojis = timeline\.emojiEvents') {
    $anchor = '                val captionText = sceneCaptions'
    if ($s -notmatch [regex]::Escape($anchor)) { throw "M8 bridge captionText anchor not found." }
    $emojiCode = @'
                val sceneEmojis = timeline.emojiEvents
                    .filter { emoji ->
                        emoji.end > sceneStart && emoji.start < sceneEnd
                    }
                    .map { emoji ->
                        VideoEmojiInput(
                            startMs = maxOf(segment.startMs, (emoji.start * 1000.0).toLong()),
                            endMs = minOf(segment.endMs, (emoji.end * 1000.0).toLong()),
                            emoji = emoji.emoji,
                            emphasis = emoji.emphasis
                        )
                    }
                    .filter { it.endMs > it.startMs && it.emoji.isNotBlank() }

'@
    $s = $s.Replace($anchor, $emojiCode.TrimEnd() + "`r`n`r`n" + $anchor)
  }

  if ($s -notmatch 'emojis = sceneEmojis') {
    $needle = '                    captions = sceneCaptions'
    if ($s -notmatch [regex]::Escape($needle)) { throw "VideoSceneInput captions assignment not found." }
    $s = $s.Replace($needle, $needle + ",`r`n                    emojis = sceneEmojis")
  }

  Set-Content $p $s -Encoding UTF8

  # ---------- TimedEmojiOverlay.kt ----------
  $p = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt"
  New-Item -ItemType Directory -Force (Split-Path $p) | Out-Null
  $emojiOverlay = @'
package com.avsp.pro.video.engine

import android.text.SpannableString
import android.text.style.StyleSpan
import android.graphics.Typeface
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay

@UnstableApi
class TimedEmojiOverlay(
    private val emojis: List<com.avsp.pro.video.contract.VideoEmojiInput>
) : TextOverlay {

    private val sorted = emojis.sortedBy { it.startMs }

    override fun getText(presentationTimeUs: Long): SpannableString? {
        val timeMs = presentationTimeUs / 1000L
        val event = sorted.firstOrNull { timeMs >= it.startMs && timeMs < it.endMs }
            ?: return null

        return SpannableString(event.emoji).also {
            if (event.emphasis) {
                it.setSpan(
                    StyleSpan(Typeface.BOLD),
                    0,
                    it.length,
                    SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
    }

    override fun getOverlaySettings(presentationTimeUs: Long): androidx.media3.effect.OverlaySettings {
        return androidx.media3.effect.StaticOverlaySettings.Builder()
            .setAlphaScale(1.0f)
            .build()
    }
}
'@
  Set-Content $p $emojiOverlay -Encoding UTF8

  # ---------- Media3VideoEngine.kt ----------
  $p = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
  $s = Get-Content $p -Raw

  if ($s -notmatch 'import com\.avsp\.pro\.video\.engine\.TimedEmojiOverlay') {
    $anchor = 'import com.avsp.pro.video.engine.TimedTextOverlay'
    if ($s -notmatch [regex]::Escape($anchor)) { throw "TimedTextOverlay import anchor not found." }
    $s = $s.Replace($anchor, $anchor + "`r`nimport com.avsp.pro.video.engine.TimedEmojiOverlay")
  }

  if ($s -notmatch 'TimedEmojiOverlay\(scene\.emojis\)') {
    $anchor = '                }`r`n                videoItems += EditedMediaItem.Builder(item)'
    $idx = $s.IndexOf($anchor)
    if ($idx -lt 0) {
      $anchor = "                }`n                videoItems += EditedMediaItem.Builder(item)"
      $idx = $s.IndexOf($anchor)
    }
    if ($idx -lt 0) { throw "Video effects insertion anchor not found." }

    $emojiInsert = @'
                if (scene.emojis.isNotEmpty()) {
                    videoEffects += OverlayEffect(
                        listOf(TimedEmojiOverlay(scene.emojis))
                    )
                }
'@
    $s = $s.Insert($idx, $emojiInsert + "`r`n")
  }

  if ($s -notmatch 'musicSequence') {
    $old = @'
          val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)
          val audioSequence = EditedMediaItemSequence.withAudioFrom(audioItems)
          val composition = Composition.Builder(videoSequence, audioSequence).build()
'@
    if ($s -notmatch [regex]::Escape($old)) {
      $old = @'
        val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)
        val audioSequence = EditedMediaItemSequence.withAudioFrom(audioItems)
        val composition = Composition.Builder(videoSequence, audioSequence).build()
'@
    }
    if ($s -notmatch [regex]::Escape($old)) { throw "Composition audio/video block not found." }

    $new = @'
          val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)
          val audioSequence = EditedMediaItemSequence.withAudioFrom(audioItems)

          val compositionSequences = mutableListOf(videoSequence, audioSequence)
          plan.musicRelativePath?.takeIf { it.isNotBlank() }?.let { musicRelativePath ->
              val music = File(
                  storage.resolve(
                      StorageArea.PROJECT_DATA,
                      musicRelativePath,
                      plan.projectId
                  )
              )
              require(music.exists()) { "Missing background music: $musicRelativePath" }

              val musicItem =
                  EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(music))).build()

              val musicSequence =
                  EditedMediaItemSequence.withAudioFrom(listOf(musicItem))
                      .buildUpon()
                      .setIsLooping(true)
                      .build()

              compositionSequences += musicSequence
          }

          val composition = Composition.Builder(compositionSequences).build()
'@
    $s = $s.Replace($old, $new)
  }

  Set-Content $p $s -Encoding UTF8

  # ---------- Focused contract/bridge test ----------
  $p = Join-Path $root "app\src\test\java\com\avsp\pro\video\M4EmojiMusicContractTest.kt"
  New-Item -ItemType Directory -Force (Split-Path $p) | Out-Null
  $test = @'
package com.avsp.pro.video

import com.avsp.pro.audio.integration.AudioToVideoHandoff
import com.avsp.pro.audio.integration.VideoAudioSegmentRef
import com.avsp.pro.m8.M8EmojiEvent
import com.avsp.pro.m8.M8Timeline
import com.avsp.pro.video.contract.VideoRenderPlanFactory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class M4EmojiMusicContractTest {

    @Test
    fun emojiTimelineMapsToSceneAndMusicPathSurvivesBridge() {
        val timeline = M8Timeline(
            projectId = "p1",
            duration = 4.0,
            emojiEvents = listOf(
                M8EmojiEvent(
                    start = 1.0,
                    end = 2.5,
                    emoji = "🔥",
                    emphasis = true
                )
            ),
            musicPath = "music/bg.mp3"
        )

        val handoff = AudioToVideoHandoff(
            projectId = "p1",
            scriptId = "s1",
            audioPackageId = "a1",
            language = "bn",
            provider = "test",
            voiceId = "test-voice",
            totalDurationMs = 4000L,
            segments = listOf(
                VideoAudioSegmentRef(
                    segmentId = "seg1",
                    sceneId = "scene1",
                    order = 0,
                    relativeAudioPath = "audio/scene1.wav",
                    startMs = 0L,
                    endMs = 4000L,
                    durationMs = 4000L,
                    language = "bn",
                    voiceId = "test-voice"
                )
            ),
            audioPackageVersion = "1.0"
        )

        val plan = VideoRenderPlanFactory.fromM8Timeline(timeline, handoff)

        assertEquals("music/bg.mp3", plan.musicRelativePath)
        assertEquals(1, plan.scenes.single().emojis.size)
        assertEquals(1000L, plan.scenes.single().emojis.single().startMs)
        assertEquals(2500L, plan.scenes.single().emojis.single().endMs)
        assertEquals("🔥", plan.scenes.single().emojis.single().emoji)
        assertTrue(plan.scenes.single().emojis.single().emphasis)
    }

    @Test
    fun invalidEmojiTimingIsRejected() {
        val errors = M8Timeline(
            projectId = "p1",
            duration = 2.0,
            emojiEvents = listOf(
                M8EmojiEvent(start = 2.0, end = 1.0, emoji = "🔥")
            )
        ).validate()

        assertTrue(errors.any { it.contains("emoji end") })
    }
}
'@
  Set-Content $p $test -Encoding UTF8

  Write-Host "M4 EMOJI + MUSIC V3 SOURCE PATCH APPLIED. Running focused tests..."

  & .\gradlew.bat :app:testDebugUnitTest --tests com.avsp.pro.video.M4EmojiMusicContractTest --no-daemon --max-workers=1
  if ($LASTEXITCODE -ne 0) { throw "Focused M4 Emoji/Music tests failed." }

  & .\gradlew.bat :app:testDebugUnitTest --tests com.avsp.pro.video.contract.M8TimelineRenderBridgeTest --no-daemon --max-workers=1
  if ($LASTEXITCODE -ne 0) { throw "Existing M8 bridge regression failed." }

  Write-Host "Running full clean test + assembleDebug..."
  & .\gradlew.bat clean test assembleDebug --no-daemon --max-workers=1
  if ($LASTEXITCODE -ne 0) { throw "Full verification failed." }

  Write-Host "M4 EMOJI + MUSIC V3 SUCCESSFUL."
}
catch {
  Write-Host "PATCH FAILED. Restoring previous source..."
  Restore-All
  Write-Host $_.Exception.Message
  exit 1
}
