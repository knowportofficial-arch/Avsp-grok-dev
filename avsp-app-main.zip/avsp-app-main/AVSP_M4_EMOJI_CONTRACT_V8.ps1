$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$backup = Join-Path $root "_avsp_backups\M4_emoji_contract_v8"

$files = @(
    "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt",
    "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt"
)

function Backup-All {
    New-Item -ItemType Directory -Force $backup | Out-Null
    foreach ($rel in $files) {
        $src = Join-Path $root $rel
        $dst = Join-Path $backup $rel
        New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
        Copy-Item -LiteralPath $src -Destination $dst -Force
    }
}

function Restore-All {
    foreach ($rel in $files) {
        $src = Join-Path $backup $rel
        $dst = Join-Path $root $rel
        if (Test-Path -LiteralPath $src) {
            Copy-Item -LiteralPath $src -Destination $dst -Force
        }
    }
}

try {
    Backup-All

    # ------------------------------------------------------------
    # M8Timeline.kt — complete source, additive emoji event only
    # ------------------------------------------------------------
    $m8 = @'
package com.avsp.pro.m8

data class M8VisualEvent(val start: Double, val end: Double, val path: String, val type: String = "video")
data class M8CaptionEvent(val start: Double, val end: Double, val text: String, val emphasis: Boolean = false)
data class M8EmojiEvent(val start: Double, val end: Double, val emoji: String, val emphasis: Boolean = false)
data class M8Timeline(
    val projectId: String,
    val format: String = "9:16",
    val width: Int = 1080,
    val height: Int = 1920,
    val fps: Double = 30.0,
    val duration: Double = 0.0,
    val visuals: List<M8VisualEvent> = emptyList(),
    val captions: List<M8CaptionEvent> = emptyList(),
    val emojiEvents: List<M8EmojiEvent> = emptyList(),
    val musicPath: String? = null,
    val ctaStart: Double? = null,
    val ctaEnd: Double? = null
) {
    fun validateCta(tolerance: Double = 0.15): Boolean =
        ctaStart != null && ctaEnd != null &&
            kotlin.math.abs((ctaEnd!! - ctaStart!!) - 5.0) <= tolerance

    fun validate(): List<String> = buildList {
        if (projectId.isBlank()) add("project_id is required")
        if (width <= 0 || height <= 0) add("invalid canvas dimensions")
        if (fps <= 0) add("fps must be positive")
        if (duration < 0) add("duration cannot be negative")
        emojiEvents.forEach { emoji ->
            if (emoji.start < 0.0) add("emoji start cannot be negative")
            if (emoji.end <= emoji.start) add("emoji end must be greater than start")
            if (emoji.emoji.isBlank()) add("emoji text is required")
        }
        if (ctaStart != null && ctaEnd != null && !validateCta()) add("CTA duration must be 5.0 Â± 0.15s")
    }
}
'@
    Set-Content -LiteralPath (Join-Path $root "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt") -Value $m8 -Encoding UTF8

    # ------------------------------------------------------------
    # VideoContracts.kt — complete source reconstructed from the
    # exact source pasted by the user, with emoji additions.
    # ------------------------------------------------------------
    $contracts = @'
package com.avsp.pro.video.contract

import com.avsp.pro.audio.integration.AudioToVideoHandoff

/** M4 render contract. Android and desktop backends consume the same plan. */
data class VideoCaptionInput(
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val emphasis: Boolean = false
)

data class VideoEmojiInput(
    val startMs: Long,
    val endMs: Long,
    val emoji: String,
    val emphasis: Boolean = false
)

data class VideoSceneInput(
    val sceneId: String,
    val order: Int,
    val startMs: Long,
    val endMs: Long,
    val durationMs: Long,
    val audioRelativePath: String,
    val visualRelativePath: String?,
    val visualMimeType: String? = null,
    val overlayText: String? = null,
    val captions: List<VideoCaptionInput> = emptyList(),
    val emojis: List<VideoEmojiInput> = emptyList()
)

data class VideoRenderPlan(
    val projectId: String,
    val scriptId: String,
    val audioPackageId: String,
    val language: String,
    val totalDurationMs: Long,
    val width: Int,
    val height: Int,
    val fps: Int,
    val scenes: List<VideoSceneInput>,
    val musicRelativePath: String? = null
) {
    companion object {
        const val DEFAULT_SHORTS_WIDTH = 1080
        const val DEFAULT_SHORTS_HEIGHT = 1920
        const val DEFAULT_LANDSCAPE_WIDTH = 1920
        const val DEFAULT_LANDSCAPE_HEIGHT = 1080
        const val DEFAULT_SQUARE_WIDTH = 1080
        const val DEFAULT_SQUARE_HEIGHT = 1080
        const val DEFAULT_PORTRAIT_4_5_WIDTH = 1080
        const val DEFAULT_PORTRAIT_4_5_HEIGHT = 1350
        const val DEFAULT_FPS = 30
    }
}

object VideoRenderPlanFactory {

    fun fromAudio(
        handoff: AudioToVideoHandoff,
        visualsByScene: Map<String, String>,
        visualMimeByScene: Map<String, String> = emptyMap(),
        width: Int = VideoRenderPlan.DEFAULT_SHORTS_WIDTH,
        height: Int = VideoRenderPlan.DEFAULT_SHORTS_HEIGHT,
        fps: Int = VideoRenderPlan.DEFAULT_FPS
    ): VideoRenderPlan {
        val segments = handoff.segments.sortedBy { it.order }
        return VideoRenderPlan(
            projectId = handoff.projectId,
            scriptId = handoff.scriptId,
            audioPackageId = handoff.audioPackageId,
            language = handoff.language,
            totalDurationMs = handoff.totalDurationMs,
            width = width,
            height = height,
            fps = fps,
            scenes = segments.map { segment ->
                VideoSceneInput(
                    sceneId = segment.sceneId,
                    order = segment.order,
                    startMs = segment.startMs,
                    endMs = segment.endMs,
                    durationMs = segment.durationMs,
                    audioRelativePath = segment.relativeAudioPath,
                    visualRelativePath = visualsByScene[segment.sceneId],
                    visualMimeType = visualMimeByScene[segment.sceneId]
                )
            }
        )
    }

    /**
     * Additive M8 -> M4 bridge.
     *
     * Existing M3 Audio -> M4 conversion above is unchanged.
     * M8 visual events, captions, and timed emoji events are projected
     * onto the existing VideoSceneInput contract.
     */
    fun fromM8Timeline(
        timeline: com.avsp.pro.m8.M8Timeline,
        audioHandoff: AudioToVideoHandoff,
        visualsByScene: Map<String, String> = emptyMap(),
        visualMimeByScene: Map<String, String> = emptyMap()
    ): VideoRenderPlan {
        val validation = timeline.validate()
        require(validation.isEmpty()) {
            "Invalid M8 timeline: ${validation.joinToString("; ")}"
        }
        require(timeline.projectId == audioHandoff.projectId) {
            "M8 timeline project_id does not match audio handoff project_id"
        }

        val segments = audioHandoff.segments.sortedBy { it.order }
        val timelineVisuals = timeline.visuals.sortedBy { it.start }

        return VideoRenderPlan(
            projectId = audioHandoff.projectId,
            scriptId = audioHandoff.scriptId,
            audioPackageId = audioHandoff.audioPackageId,
            language = audioHandoff.language,
            totalDurationMs = audioHandoff.totalDurationMs,
            width = timeline.width,
            height = timeline.height,
            fps = timeline.fps.toInt().coerceAtLeast(1),
            scenes = segments.map { segment ->
                val sceneStart = segment.startMs.toDouble() / 1000.0
                val sceneEnd = segment.endMs.toDouble() / 1000.0

                val matchingVisual = timelineVisuals.firstOrNull { event ->
                    event.end > sceneStart && event.start < sceneEnd
                }

                val visualPath =
                    visualsByScene[segment.sceneId] ?: matchingVisual?.path

                val visualType =
                    visualMimeByScene[segment.sceneId] ?: matchingVisual?.type

                val sceneCaptions = timeline.captions
                    .filter { caption ->
                        caption.end > sceneStart && caption.start < sceneEnd
                    }
                    .map { caption ->
                        VideoCaptionInput(
                            startMs = maxOf(segment.startMs, (caption.start * 1000.0).toLong()),
                            endMs = minOf(segment.endMs, (caption.end * 1000.0).toLong()),
                            text = caption.text,
                            emphasis = caption.emphasis
                        )
                    }
                    .filter { it.endMs > it.startMs && it.text.isNotBlank() }

                val sceneEmojis = timeline.emojiEvents
                    .filter { emoji ->
                        emoji.end > sceneStart && emoji.start < sceneEnd
                    }
                    .map { emoji ->
                        VideoEmojiInput(
                            startMs = maxOf(segment.startMs, (emoji.start * 1000.0).toLong()),
                            endMs = minOf(segment.endMs, (emoji.end * 1000.0).toLong()),
                            emoji = emoji.emoji,
                            emphasis = emoji.emphasis
                        )
                    }
                    .filter { it.endMs > it.startMs && it.emoji.isNotBlank() }

                val captionText = sceneCaptions
                    .joinToString(" ") { it.text }
                    .ifBlank { null }

                VideoSceneInput(
                    sceneId = segment.sceneId,
                    order = segment.order,
                    startMs = segment.startMs,
                    endMs = segment.endMs,
                    durationMs = segment.durationMs,
                    audioRelativePath = segment.relativeAudioPath,
                    visualRelativePath = visualPath,
                    visualMimeType = visualType,
                    overlayText = captionText,
                    captions = sceneCaptions,
                    emojis = sceneEmojis
                )
            },
            musicRelativePath = timeline.musicPath
        )
    }
}

data class VideoRenderResult(
    val projectId: String,
    val outputRelativePath: String,
    val outputAbsolutePath: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val videoCodec: String,
    val audioCodec: String,
    val status: String
)
'@
    Set-Content -LiteralPath (Join-Path $root "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt") -Value $contracts -Encoding UTF8

    Write-Host "V8 contract patch applied."
    Write-Host "Running compile/unit verification..."
    & .\gradlew.bat :app:testDebugUnitTest --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Contract verification failed." }

    Write-Host "V8 CONTRACT PATCH SUCCESSFUL."
}
catch {
    Write-Host "PATCH FAILED. Restoring previous source..."
    Restore-All
    Write-Host $_.Exception.Message
    exit 1
}
