$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$m8 = Join-Path $root "app\src\main\java\com\avsp\pro\m8\M8Timeline.kt"
$contracts = Join-Path $root "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt"
$engine = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
$emojiOverlay = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt"
$test = Join-Path $root "app\src\test\java\com\avsp\pro\video\TimedEmojiOverlayTest.kt"
$bridgeTest = Join-Path $root "app\src\test\java\com\avsp\pro\video\contract\M8TimelineRenderBridgeTest.kt"
$backup = Join-Path $root "_avsp_backups\M4_emoji_overlay_v1"

function Read-Utf8($p) { [System.IO.File]::ReadAllText($p, [System.Text.UTF8Encoding]::new($false)) }
function Write-Utf8($p,$s) {
    New-Item -ItemType Directory -Path (Split-Path $p -Parent) -Force | Out-Null
    [System.IO.File]::WriteAllText($p,$s,[System.Text.UTF8Encoding]::new($false))
}

foreach($p in @($m8,$contracts,$engine)){ if(!(Test-Path $p)){ throw "Required file missing: $p" } }

New-Item -ItemType Directory -Path $backup -Force | Out-Null
foreach($p in @($m8,$contracts,$engine,$emojiOverlay,$test,$bridgeTest)){
    if(Test-Path $p){ Copy-Item $p (Join-Path $backup ([IO.Path]::GetFileName($p))) -Force }
}

try {
    # 1. M8 contract: add a minimal timed emoji event. No positioning/animation system is invented here.
    $s = Read-Utf8 $m8
    if($s.Contains('data class M8EmojiEvent')){ throw "M8EmojiEvent already exists; refusing to duplicate it." }
    $anchor = 'data class M8CaptionEvent(val start: Double, val end: Double, val text: String, val emphasis: Boolean = false)'
    if(!$s.Contains($anchor)){ throw "M8CaptionEvent anchor not found." }
    $s = $s.Replace($anchor, $anchor + "`r`ndata class M8EmojiEvent(val start: Double, val end: Double, val emoji: String, val emphasis: Boolean = false)")
    $s = $s.Replace('    val captions: List<M8CaptionEvent> = emptyList(),', '    val captions: List<M8CaptionEvent> = emptyList(),`r`n    val emojiEvents: List<M8EmojiEvent> = emptyList(),')
    $s = $s.Replace('        if (duration < 0) add("duration cannot be negative")', '        if (duration < 0) add("duration cannot be negative")`r`n        emojiEvents.forEach { emoji ->`r`n            if (emoji.start < 0 || emoji.end <= emoji.start) add("invalid emoji timing")`r`n            if (emoji.emoji.isBlank()) add("emoji value is required")`r`n        }')
    Write-Utf8 $m8 $s

    # 2. M4 contract: timed emoji input on each scene.
    $c = Read-Utf8 $contracts
    if($c.Contains('data class VideoEmojiInput')){ throw "VideoEmojiInput already exists; refusing to duplicate it." }
    $anchor2 = 'data class VideoCaptionInput('
    $idx = $c.IndexOf($anchor2)
    if($idx -lt 0){ throw "VideoCaptionInput anchor not found." }
    $emojiContract = @'
data class VideoEmojiInput(
    val startMs: Long,
    val endMs: Long,
    val emoji: String,
    val emphasis: Boolean = false
)
'@
    $c = $c.Insert($idx, $emojiContract)
    $sceneAnchor = '    val captions: List<VideoCaptionInput> = emptyList()'
    if(!$c.Contains($sceneAnchor)){ throw "VideoSceneInput captions field not found." }
    $c = $c.Replace($sceneAnchor, $sceneAnchor + ",`r`n    val emojis: List<VideoEmojiInput> = emptyList()")
    $timelineAnchor = '                val captionText = sceneCaptions'
    $idx2 = $c.IndexOf($timelineAnchor)
    if($idx2 -lt 0){ throw "M8 bridge caption section not found." }
    $emojiBlock = @'
                val sceneEmojis = timeline.emojiEvents
                    .filter { emoji ->
                        emoji.end > sceneStart && emoji.start < sceneEnd
                    }
                    .map { emoji ->
                        VideoEmojiInput(
                            startMs = maxOf(segment.startMs, (emoji.start * 1000.0).toLong()),
                            endMs = minOf(segment.endMs, (emoji.end * 1000.0).toLong()),
                            emoji = emoji.emoji,
                            emphasis = emoji.emphasis
                        )
                    }
                    .filter { it.endMs > it.startMs && it.emoji.isNotBlank() }

'@
    $c = $c.Insert($idx2, $emojiBlock)
    $sceneCaptionsEnd = '                    captions = sceneCaptions'
    if(!$c.Contains($sceneCaptionsEnd)){ throw "VideoSceneInput captions assignment not found." }
    $c = $c.Replace($sceneCaptionsEnd, $sceneCaptionsEnd + ",`r`n                    emojis = sceneEmojis")
    Write-Utf8 $contracts $c

    # 3. Renderer: preserve verified timed captions; add emoji as a second overlay in the same Effects list.
    $e = Read-Utf8 $engine
    $import = 'import androidx.media3.effect.TextOverlay'
    if(!$e.Contains('import com.avsp.pro.video.engine.TimedEmojiOverlay')){
        if(!$e.Contains($import)){ throw "TextOverlay import anchor not found." }
        $e = $e.Replace($import, $import + "`r`nimport com.avsp.pro.video.engine.TimedEmojiOverlay")
    }
    $captionBlock = @'
                if (scene.captions.isNotEmpty()) {
                    videoEffects += OverlayEffect(
                        listOf(TimedTextOverlay(scene.captions))
                    )
                } else {
'@
    if(!$e.Contains($captionBlock)){ throw "Verified timed-caption renderer block not found. No renderer change made." }
    $emojiInsert = @'
                if (scene.emojis.isNotEmpty()) {
                    videoEffects += OverlayEffect(
                        listOf(TimedEmojiOverlay(scene.emojis))
                    )
                }

'@
    $e = $e.Replace($captionBlock, $captionBlock + $emojiInsert)
    Write-Utf8 $engine $e

    # 4. Emoji overlay: timestamp-driven Unicode emoji, rendered through Media3 TextOverlay.
    $overlayText = @'
package com.avsp.pro.video.engine

import android.graphics.Typeface
import android.text.SpannableString
import android.text.style.StyleSpan
import androidx.media3.effect.TextOverlay
import com.avsp.pro.video.contract.VideoEmojiInput

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class TimedEmojiOverlay(
    private val emojis: List<VideoEmojiInput>
) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString {
        val timeMs = presentationTimeUs / 1000L
        val active = emojis.filter { timeMs >= it.startMs && timeMs < it.endMs }
        if (active.isEmpty()) return SpannableString("")

        val text = active.joinToString(" ") { it.emoji.trim() }
        val result = SpannableString(text)
        if (active.any { it.emphasis } && text.isNotEmpty()) {
            result.setSpan(
                StyleSpan(Typeface.BOLD), 0, text.length,
                SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        return result
    }
}
'@
    Write-Utf8 $emojiOverlay $overlayText

    $testText = @'
package com.avsp.pro.video

import com.avsp.pro.video.contract.VideoEmojiInput
import com.avsp.pro.video.engine.TimedEmojiOverlay
import org.junit.Assert.assertEquals
import org.junit.Test

class TimedEmojiOverlayTest {
    @Test
    fun emojiAppearsOnlyInsideTimeWindow() {
        val overlay = TimedEmojiOverlay(listOf(VideoEmojiInput(1000L, 2000L, "😂")))
        assertEquals("", overlay.getText(999_000L).toString())
        assertEquals("😂", overlay.getText(1_000_000L).toString())
        assertEquals("😂", overlay.getText(1_999_000L).toString())
        assertEquals("", overlay.getText(2_000_000L).toString())
    }

    @Test
    fun overlappingEmojiRemainOrdered() {
        val overlay = TimedEmojiOverlay(
            listOf(
                VideoEmojiInput(0L, 1500L, "🔥"),
                VideoEmojiInput(1000L, 2000L, "💥")
            )
        )
        assertEquals("🔥 💥", overlay.getText(1_200_000L).toString())
    }
}
'@
    Write-Utf8 $test $testText

    Push-Location $root
    try {
        & .\gradlew.bat :app:testDebugUnitTest --tests "com.avsp.pro.video.TimedEmojiOverlayTest" --no-daemon --max-workers=1
        if($LASTEXITCODE -ne 0){ throw "Focused emoji test failed." }

        & .\gradlew.bat :app:testDebugUnitTest --tests "com.avsp.pro.video.contract.M8TimelineRenderBridgeTest" --no-daemon --max-workers=1
        if($LASTEXITCODE -ne 0){ throw "Existing M8 bridge regression test failed." }

        & .\gradlew.bat clean test assembleDebug --no-daemon --max-workers=1
        if($LASTEXITCODE -ne 0){ throw "Full verification failed." }
    } finally { Pop-Location }

    Write-Host "M4 EMOJI OVERLAY V1 SUCCESSFUL." -ForegroundColor Green
}
catch {
    Write-Host "PATCH FAILED. Restoring previous source..." -ForegroundColor Red
    foreach($p in @($m8,$contracts,$engine,$emojiOverlay,$test,$bridgeTest)){
        $b = Join-Path $backup ([IO.Path]::GetFileName($p))
        if(Test-Path $b){ Copy-Item $b $p -Force }
        elseif(Test-Path $p){ Remove-Item $p -Force }
    }
    throw
}
