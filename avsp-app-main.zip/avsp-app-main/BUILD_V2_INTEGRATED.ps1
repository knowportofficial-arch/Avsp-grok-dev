$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
Write-Host 'AVSP V2 integrated build'
Write-Host 'Building debug APK...'
& .\gradlew.bat :app:assembleDebug
if ($LASTEXITCODE -ne 0) { throw "Gradle build failed with exit code $LASTEXITCODE" }
$apk = Join-Path $root 'app\build\outputs\apk\debug\app-debug.apk'
if (!(Test-Path $apk)) { throw "APK not found: $apk" }
Write-Host "APK: $apk"
