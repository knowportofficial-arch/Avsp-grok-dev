$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$engineDir = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine"
$testDir = Join-Path $root "app\src\test\java\com\avsp\pro\video\engine"

$selectorFile = Join-Path $engineDir "TimedEmojiSelector.kt"
$overlayFile = Join-Path $engineDir "TimedEmojiOverlay.kt"
$testFile = Join-Path $testDir "TimedEmojiSelectorTest.kt"

$backupDir = Join-Path $root "_avsp_backups\M4_emoji_selector_v12"
New-Item -ItemType Directory -Force $backupDir | Out-Null
New-Item -ItemType Directory -Force $testDir | Out-Null

foreach ($file in @($selectorFile,$overlayFile,$testFile)) {
    if (Test-Path -LiteralPath $file) {
        Copy-Item -LiteralPath $file -Destination (Join-Path $backupDir (Split-Path $file -Leaf)) -Force
    }
}

try {
@'
package com.avsp.pro.video.engine

import com.avsp.pro.video.contract.VideoEmojiInput

object TimedEmojiSelector {
    fun active(
        emojis: List<VideoEmojiInput>,
        timeMs: Long
    ): List<VideoEmojiInput> =
        emojis.filter { timeMs >= it.startMs && timeMs < it.endMs }
}
'@ | Set-Content -LiteralPath $selectorFile -Encoding UTF8

@'
package com.avsp.pro.video.engine

import android.graphics.Typeface
import android.text.SpannableString
import android.text.style.StyleSpan
import androidx.media3.effect.TextOverlay
import com.avsp.pro.video.contract.VideoEmojiInput

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class TimedEmojiOverlay(
    private val emojis: List<VideoEmojiInput>
) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString {
        val active = TimedEmojiSelector.active(emojis, presentationTimeUs / 1000L)
        if (active.isEmpty()) return SpannableString("")

        val text = active.joinToString(" ") { it.emoji.trim() }
        val result = SpannableString(text)

        if (active.any { it.emphasis } && text.isNotEmpty()) {
            result.setSpan(
                StyleSpan(Typeface.BOLD),
                0,
                text.length,
                SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        return result
    }
}
'@ | Set-Content -LiteralPath $overlayFile -Encoding UTF8

@'
package com.avsp.pro.video.engine

import com.avsp.pro.video.contract.VideoEmojiInput
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class TimedEmojiSelectorTest {

    private val emojis = listOf(
        VideoEmojiInput(1000L, 3000L, "🔥"),
        VideoEmojiInput(1500L, 2500L, "🚀"),
        VideoEmojiInput(4000L, 5000L, "🎯", emphasis = true)
    )

    @Test
    fun before_first_interval_returns_empty() {
        assertTrue(TimedEmojiSelector.active(emojis, 999L).isEmpty())
    }

    @Test
    fun start_boundary_is_inclusive() {
        assertEquals(
            listOf("🔥"),
            TimedEmojiSelector.active(emojis, 1000L).map { it.emoji }
        )
    }

    @Test
    fun overlapping_intervals_preserve_source_order() {
        assertEquals(
            listOf("🔥", "🚀"),
            TimedEmojiSelector.active(emojis, 1600L).map { it.emoji }
        )
    }

    @Test
    fun ended_interval_is_excluded_but_other_active_interval_remains() {
        assertEquals(
            listOf("🔥"),
            TimedEmojiSelector.active(emojis, 2500L).map { it.emoji }
        )
    }

    @Test
    fun final_end_boundary_is_exclusive() {
        assertTrue(TimedEmojiSelector.active(emojis, 3000L).isEmpty())
    }

    @Test
    fun emphasis_metadata_is_preserved() {
        val active = TimedEmojiSelector.active(emojis, 4500L)
        assertEquals(1, active.size)
        assertEquals("🎯", active.single().emoji)
        assertTrue(active.single().emphasis)
    }
}
'@ | Set-Content -LiteralPath $testFile -Encoding UTF8

Write-Host "V12 corrected emoji boundary test applied."
Write-Host "Running focused selector test..."
& .\gradlew.bat :app:testDebugUnitTest --tests "com.avsp.pro.video.engine.TimedEmojiSelectorTest" --no-daemon --max-workers=1
if ($LASTEXITCODE -ne 0) { throw "TimedEmojiSelectorTest failed." }

Write-Host "Running M8/Video regression tests..."
& .\gradlew.bat :app:testDebugUnitTest --tests "*M8*" --tests "*Video*" --no-daemon --max-workers=1
if ($LASTEXITCODE -ne 0) { throw "M8/Video regression verification failed." }

Write-Host "V12 EMOJI VERIFICATION SUCCESSFUL."
}
catch {
    Write-Host "V12 FAILED. Restoring previous source..."
    foreach ($file in @($selectorFile,$overlayFile,$testFile)) {
        $backup = Join-Path $backupDir (Split-Path $file -Leaf)
        if (Test-Path -LiteralPath $backup) {
            Copy-Item -LiteralPath $backup -Destination $file -Force
        } elseif (Test-Path -LiteralPath $file) {
            Remove-Item -LiteralPath $file -Force
        }
    }
    Write-Host $_.Exception.Message
    exit 1
}
