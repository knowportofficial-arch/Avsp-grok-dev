$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$renderer = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
$emojiOverlay = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\TimedEmojiOverlay.kt"
$backup = Join-Path $root "_avsp_backups\M4_emoji_renderer_v9"

New-Item -ItemType Directory -Force $backup | Out-Null
New-Item -ItemType Directory -Force (Split-Path $emojiOverlay) | Out-Null
Copy-Item -LiteralPath $renderer -Destination (Join-Path $backup "Media3VideoEngine.kt") -Force
$overlayExisted = Test-Path -LiteralPath $emojiOverlay
if ($overlayExisted) {
    Copy-Item -LiteralPath $emojiOverlay -Destination (Join-Path $backup "TimedEmojiOverlay.kt") -Force
}

try {
    # Create the timed emoji overlay as a complete source file.
    @'
package com.avsp.pro.video.engine

import android.graphics.Typeface
import android.text.SpannableString
import android.text.style.StyleSpan
import androidx.media3.effect.TextOverlay
import com.avsp.pro.video.contract.VideoEmojiInput

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
class TimedEmojiOverlay(
    private val emojis: List<VideoEmojiInput>
) : TextOverlay() {
    override fun getText(presentationTimeUs: Long): SpannableString {
        val timeMs = presentationTimeUs / 1000L
        val active = emojis.filter { timeMs >= it.startMs && timeMs < it.endMs }
        if (active.isEmpty()) return SpannableString("")

        val text = active.joinToString(" ") { it.emoji.trim() }
        val result = SpannableString(text)

        if (active.any { it.emphasis } && text.isNotEmpty()) {
            result.setSpan(
                StyleSpan(Typeface.BOLD),
                0,
                text.length,
                SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        return result
    }
}
'@ | Set-Content -LiteralPath $emojiOverlay -Encoding UTF8

    # Read the actual current renderer and make only two additive changes:
    # 1) import TimedEmojiOverlay
    # 2) add emoji OverlayEffect after the existing caption/static-text block.
    [string[]]$lines = @(Get-Content -LiteralPath $renderer)

    if (-not ($lines -contains "import com.avsp.pro.video.engine.TimedEmojiOverlay")) {
        $idx = -1
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -ceq "import com.avsp.pro.video.engine.TimedTextOverlay") {
                $idx = $i
                break
            }
        }
        if ($idx -lt 0) { throw "TimedTextOverlay import not found." }

        $out = [System.Collections.Generic.List[string]]::new()
        for ($i = 0; $i -le $idx; $i++) { [void]$out.Add([string]$lines[$i]) }
        [void]$out.Add("import com.avsp.pro.video.engine.TimedEmojiOverlay")
        for ($i = $idx + 1; $i -lt $lines.Count; $i++) { [void]$out.Add([string]$lines[$i]) }
        $lines = [string[]]$out.ToArray()
    }

    if (-not ($lines -contains "                if (scene.emojis.isNotEmpty()) {")) {
        # Locate the actual end of the existing caption/static overlay block.
        $captionStart = -1
        for ($i = 0; $i -lt $lines.Count; $i++) {
            if ($lines[$i] -match 'if \(scene\.captions\.isNotEmpty\(\)\)') {
                $captionStart = $i
                break
            }
        }
        if ($captionStart -lt 0) { throw "Existing timed-caption renderer block not found." }

        $blockEnd = -1
        $depth = 0
        for ($i = $captionStart; $i -lt $lines.Count; $i++) {
            $line = [string]$lines[$i]
            $openCount = ([regex]::Matches($line, '\{')).Count
            $closeCount = ([regex]::Matches($line, '\}')).Count
            $depth += $openCount - $closeCount
            if ($i -gt $captionStart -and $depth -eq 0) {
                $blockEnd = $i
                break
            }
        }
        if ($blockEnd -lt 0) { throw "Could not determine caption renderer block end." }

        $insert = [string[]]@(
            "                if (scene.emojis.isNotEmpty()) {",
            "                    videoEffects += OverlayEffect(",
            "                        listOf(TimedEmojiOverlay(scene.emojis))",
            "                    )",
            "                }"
        )

        $out = [System.Collections.Generic.List[string]]::new()
        for ($i = 0; $i -le $blockEnd; $i++) { [void]$out.Add([string]$lines[$i]) }
        foreach ($line in $insert) { [void]$out.Add($line) }
        for ($i = $blockEnd + 1; $i -lt $lines.Count; $i++) { [void]$out.Add([string]$lines[$i]) }
        $lines = [string[]]$out.ToArray()
    }

    Set-Content -LiteralPath $renderer -Value $lines -Encoding UTF8

    Write-Host "V9 emoji renderer patch applied."
    Write-Host "Running focused M4 unit tests..."
    & .\gradlew.bat :app:testDebugUnitTest --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "M4 emoji renderer verification failed." }

    Write-Host "V9 EMOJI RENDERER SUCCESSFUL."
}
catch {
    Write-Host "PATCH FAILED. Restoring previous source..."
    Copy-Item -LiteralPath (Join-Path $backup "Media3VideoEngine.kt") -Destination $renderer -Force

    $backupOverlay = Join-Path $backup "TimedEmojiOverlay.kt"
    if ($overlayExisted -and (Test-Path -LiteralPath $backupOverlay)) {
        Copy-Item -LiteralPath $backupOverlay -Destination $emojiOverlay -Force
    } elseif (Test-Path -LiteralPath $emojiOverlay) {
        Remove-Item -LiteralPath $emojiOverlay -Force
    }

    Write-Host $_.Exception.Message
    exit 1
}
