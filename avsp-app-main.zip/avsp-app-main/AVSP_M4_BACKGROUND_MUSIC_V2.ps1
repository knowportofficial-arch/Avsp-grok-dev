$ErrorActionPreference = "Stop"

$root = "C:\AVSP_WORK_2026-09-21"
$engine = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
if (-not (Test-Path $engine)) { throw "Media3VideoEngine.kt not found: $engine" }

$backup = "$engine.pre_music_v2.bak"
Copy-Item $engine $backup -Force

$text = Get-Content $engine -Raw

$old = @"
        val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)
        val audioSequence = EditedMediaItemSequence.withAudioFrom(audioItems)
        val composition = Composition.Builder(videoSequence, audioSequence).build()
"@

$new = @"
        val videoSequence = EditedMediaItemSequence.withVideoFrom(videoItems)
        val audioSequence = EditedMediaItemSequence.withAudioFrom(audioItems)

        val compositionSequences = mutableListOf<EditedMediaItemSequence>(
            videoSequence,
            audioSequence
        )

        plan.musicRelativePath
            ?.takeIf { it.isNotBlank() }
            ?.let { musicRelativePath ->
                val music = File(
                    storage.resolve(
                        StorageArea.PROJECT_DATA,
                        musicRelativePath,
                        plan.projectId
                    )
                )
                require(music.exists()) {
                    "Missing background music: $musicRelativePath"
                }

                val musicItem = EditedMediaItem.Builder(
                    MediaItem.fromUri(Uri.fromFile(music))
                ).build()

                val musicSequence = EditedMediaItemSequence.Builder(
                    listOf(musicItem)
                )
                    .setIsLooping(true)
                    .build()

                compositionSequences += musicSequence
            }

        val composition = Composition.Builder(compositionSequences).build()
"@

$count = ([regex]::Matches($text, [regex]::Escape($old))).Count
if ($count -ne 1) {
    throw "Expected exactly 1 composition block, found $count. No source change made."
}

$text = $text.Replace($old, $new)
Set-Content -Path $engine -Value $text -Encoding UTF8

Write-Host "M4 background music V2 patch applied."
Write-Host "Backup: $backup"
Write-Host ""
Write-Host "Running focused M4/M8/Video/Render verification..."
Push-Location $root
try {
    & .\gradlew.bat :app:testDebugUnitTest --tests "*M8*" --tests "*Video*" --tests "*Render*" --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Focused verification failed." }
} finally {
    Pop-Location
}
Write-Host ""
Write-Host "M4 BACKGROUND MUSIC V2 PATCH + FOCUSED VERIFICATION SUCCESSFUL."
