$ErrorActionPreference = "Stop"

$root = "C:\AVSP_WORK_2026-09-21"
$engine = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
if (-not (Test-Path $engine)) { throw "Media3VideoEngine.kt not found: $engine" }

$backup = "$engine.pre_music_v4.bak"
Copy-Item $engine $backup -Force

$text = Get-Content $engine -Raw

$old = 'require\(music\.exists\(\)\) \{\r?\n\s*"Missing background music: "\r?\n\s*\}'
$new = 'require(music.exists()) {' + [Environment]::NewLine + '            "Missing background music: $musicRelativePath"' + [Environment]::NewLine + '        }'

$count = ([regex]::Matches($text, $old)).Count
if ($count -ne 1) {
    throw "Expected exactly 1 malformed music error block, found $count. No source change made."
}

$text = [regex]::Replace($text, $old, $new, 1)
Set-Content -Path $engine -Value $text -Encoding UTF8

Write-Host "M4 background music V4 correction applied."
Write-Host "Backup: $backup"
Write-Host ""
Write-Host "Running correct focused verification..."
Push-Location $root
try {
    & .\gradlew.bat :app:testDebugUnitTest --tests "*M8*" --tests "*Video*" --tests "*Render*" --no-daemon --max-workers=1
    if ($LASTEXITCODE -ne 0) { throw "Focused verification failed." }
} finally {
    Pop-Location
}
Write-Host ""
Write-Host "M4 BACKGROUND MUSIC V4 CORRECTION + FOCUSED VERIFICATION SUCCESSFUL."
