$ErrorActionPreference = "Stop"

$root = (Get-Location).Path
$engine = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\Media3VideoEngine.kt"
$contracts = Join-Path $root "app\src\main\java\com\avsp\pro\video\contract\VideoContracts.kt"
$overlay = Join-Path $root "app\src\main\java\com\avsp\pro\video\engine\TimedTextOverlay.kt"
$test = Join-Path $root "app\src\test\java\com\avsp\pro\video\TimedTextOverlayTest.kt"
$backup = Join-Path $root "_avsp_backups\M4_timed_captions_v1"

function Read-Utf8($path) {
    return [System.IO.File]::ReadAllText($path, [System.Text.UTF8Encoding]::new($false))
}
function Write-Utf8($path, $content) {
    $parent = Split-Path $path -Parent
    if (!(Test-Path $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
    [System.IO.File]::WriteAllText($path, $content, [System.Text.UTF8Encoding]::new($false))
}

if (!(Test-Path $engine) -or !(Test-Path $contracts)) {
    throw "Required M4 source files not found. Run this from C:\AVSP_WORK-2026-09-21"
}

New-Item -ItemType Directory -Path $backup -Force | Out-Null
Copy-Item $engine (Join-Path $backup "Media3VideoEngine.kt") -Force
Copy-Item $contracts (Join-Path $backup "VideoContracts.kt") -Force
if (Test-Path $overlay) { Copy-Item $overlay (Join-Path $backup "TimedTextOverlay.kt") -Force }
if (Test-Path $test) { Copy-Item $test (Join-Path $backup "TimedTextOverlayTest.kt") -Force }

try {
    $c = Read-Utf8 $contracts

    # M8 bridge: captions must remain timed. Do not flatten them into static overlayText.
    $old = 'overlayText = captionText,' 
    if (!$c.Contains($old)) { throw "VideoContracts.kt timed-caption bridge anchor not found." }
    $c = $c.Replace($old, 'overlayText = null,')
    Write-Utf8 $contracts $c

    $e = Read-Utf8 $engine

    $importAnchor = 'import android.text.SpannableString'
    if (!$e.Contains($importAnchor)) { throw "Media3VideoEngine.kt import anchor not found." }
    $e = $e.Replace(
        $importAnchor,
        $importAnchor + "`r`nimport com.avsp.pro.video.contract.VideoCaptionInput"
    )

    $oldOverlay = @'
                scene.overlayText?.takeIf { it.isNotBlank() }?.let { text ->
                    videoEffects += OverlayEffect(
                        listOf(TextOverlay.createStaticTextOverlay(SpannableString(text)))
                    )
                }
'@

    $newOverlay = @'
                if (scene.captions.isNotEmpty()) {
                    val localCaptions = scene.captions
                        .map { caption ->
                            VideoCaptionInput(
                                startMs = (caption.startMs - scene.startMs).coerceAtLeast(0L),
                                endMs = (caption.endMs - scene.startMs).coerceAtLeast(0L),
                                text = caption.text,
                                emphasis = caption.emphasis
                            )
                        }
                        .filter { it.endMs > it.startMs && it.text.isNotBlank() }

                    if (localCaptions.isNotEmpty()) {
                        videoEffects += OverlayEffect(
                            listOf(TimedTextOverlay(localCaptions))
                        )
                    }
                } else {
                    scene.overlayText?.takeIf { it.isNotBlank() }?.let { text ->
                        videoEffects += OverlayEffect(
                            listOf(TextOverlay.createStaticTextOverlay(SpannableString(text)))
                        )
                    }
                }
'@

    if (!$e.Contains($oldOverlay)) { throw "Media3VideoEngine.kt existing static overlay block not found." }
    $e = $e.Replace($oldOverlay, $newOverlay)
    Write-Utf8 $engine $e

    $overlayText = @'
package com.avsp.pro.video.engine

import android.graphics.Typeface
import android.text.SpannableString
import android.text.style.StyleSpan
import androidx.media3.effect.TextOverlay
import com.avsp.pro.video.contract.VideoCaptionInput

/**
 * M4 timed caption overlay.
 *
 * Media3 TextOverlay receives the current presentation timestamp in microseconds.
 * Caption times are local to the current EditedMediaItem.
 */
class TimedTextOverlay(
    private val captions: List<VideoCaptionInput>
) : TextOverlay() {

    override fun getText(presentationTimeUs: Long): SpannableString {
        val timeMs = presentationTimeUs / 1000L
        val active = captions.filter {
            timeMs >= it.startMs && timeMs < it.endMs
        }

        if (active.isEmpty()) {
            return SpannableString("")
        }

        val text = active.joinToString(" ") { it.text.trim() }
        val result = SpannableString(text)

        if (active.any { it.emphasis } && text.isNotEmpty()) {
            result.setSpan(
                StyleSpan(Typeface.BOLD),
                0,
                text.length,
                SpannableString.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }

        return result
    }
}
'@
    Write-Utf8 $overlay $overlayText

    $testText = @'
package com.avsp.pro.video

import com.avsp.pro.video.contract.VideoCaptionInput
import com.avsp.pro.video.engine.TimedTextOverlay
import org.junit.Assert.assertEquals
import org.junit.Test

class TimedTextOverlayTest {

    @Test
    fun captionIsVisibleOnlyInsideItsWindow() {
        val overlay = TimedTextOverlay(
            listOf(VideoCaptionInput(1000L, 2000L, "Hello"))
        )

        assertEquals("", overlay.getText(500_000L).toString())
        assertEquals("Hello", overlay.getText(1_000_000L).toString())
        assertEquals("Hello", overlay.getText(1_500_000L).toString())
        assertEquals("", overlay.getText(2_000_000L).toString())
    }

    @Test
    fun overlappingCaptionsAreCombined() {
        val overlay = TimedTextOverlay(
            listOf(
                VideoCaptionInput(0L, 1500L, "One"),
                VideoCaptionInput(1000L, 2000L, "Two")
            )
        )

        assertEquals("One Two", overlay.getText(1_200_000L).toString())
    }
}
'@
    Write-Utf8 $test $testText

    Push-Location $root
    try {
        & .\gradlew.bat :app:testDebugUnitTest --tests "com.avsp.pro.video.TimedTextOverlayTest" --no-daemon --max-workers=1
        if ($LASTEXITCODE -ne 0) { throw "Focused timed-caption test failed." }

        & .\gradlew.bat clean test assembleDebug --no-daemon --max-workers=1
        if ($LASTEXITCODE -ne 0) { throw "Full verification build failed." }
    }
    finally {
        Pop-Location
    }

    Write-Host ""
    Write-Host "M4 TIMED CAPTION PATCH SUCCESSFUL." -ForegroundColor Green
    Write-Host "Backup: $backup"
}
catch {
    Write-Host ""
    Write-Host "PATCH FAILED. Restoring previous source..." -ForegroundColor Red
    Copy-Item (Join-Path $backup "Media3VideoEngine.kt") $engine -Force
    Copy-Item (Join-Path $backup "VideoContracts.kt") $contracts -Force
    $overlayBackup = Join-Path $backup "TimedTextOverlay.kt"
    if (Test-Path $overlayBackup) {
        Copy-Item $overlayBackup $overlay -Force
    } elseif (Test-Path $overlay) {
        Remove-Item $overlay -Force
    }
    $testBackup = Join-Path $backup "TimedTextOverlayTest.kt"
    if (Test-Path $testBackup) {
        Copy-Item $testBackup $test -Force
    } elseif (Test-Path $test) {
        Remove-Item $test -Force
    }
    throw
}
